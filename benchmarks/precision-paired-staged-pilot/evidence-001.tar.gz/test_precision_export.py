import copy
import gzip
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest
from export_precision import summary,verify_raw,write_shards,sha


def comparison(n=24,exact=True):
    c=dict(requests=n,max_sequence_difference_common=0. if exact else .01,max_transition_difference_common=0. if exact else .01)
    for k,m in [('rank_positions',50),('sequence_values',50),('transition_values',250)]:
        c[k]=n*m;c['matching_'+k]=n*m if exact or k=='rank_positions' else n*m-1
    return c


def fixture():
    timing={'folded_fp32':{'median_ms':100.,'p95_ms':110.},'folded_tf32':{'median_ms':80.,'p95_ms':90.}}
    return dict(integrity_audit_passed=True,unique_users=4,paired_requests=24,
        comparison=comparison(exact=False),historical_comparisons={'folded_fp32':comparison(),'folded_tf32':comparison(exact=False)},
        repeated_comparison=comparison(88),ancestry_stable=True,candidate_bit_exact=False,control_exact=True,stability_exact=True,
        dispatch_verified=True,phases=[dict(phase=i,variant=v,warmup_comparison=comparison(4),repeat_comparison=comparison(6),
            profile_comparison=comparison(2),warmup_historical_comparison=comparison(12,exact=v=='folded_fp32'),
            measurement_compilations=0,measurement_captures=0,dispatch={'verified':True})
            for i,v in enumerate(('folded_fp32','folded_tf32','folded_tf32','folded_fp32'))],
        quality=dict(schema='paired-sid-quality-v1',primary_metrics=['ndcg@10','hit_rate@10'],
            overall={'independent_users':4},per_user=[{'cohort_index':i} for i in range(4)],
            bootstrap={'samples':10000,'seed':20261026},promotion=False,noninferiority_established=False,
            token_repeat_stability=True,output_validity={v:{'invalid_outputs':0,'duplicate_valid_sids':0} for v in ('control','candidate')}),
        validity_passed=True,latency_ms=timing,latency_by_length_ms={'76':copy.deepcopy(timing),'121':copy.deepcopy(timing)},
        latency_by_half_ms={'0':copy.deepcopy(timing),'1':copy.deepcopy(timing)},
        latency_by_length_half_ms={f'{n}:{h}':copy.deepcopy(timing) for n in (76,121) for h in (0,1)},
        performance_gate={'minimum_reduction_percent':10,'passed':True},eligible_for_full_quality_review=True,
        promotion=False,noninferiority_established=False)


class PrecisionExportTests(unittest.TestCase):
    def test_nonidentical_bits_do_not_reject_quality_track(self):
        r=summary(fixture());self.assertTrue(r['eligible_for_full_quality_review']);self.assertFalse(r['candidate_bit_exact'])
        self.assertFalse(r['promotion']);self.assertEqual(r['comparison']['max_sequence_difference_common'],.01)

    def test_negative_gate_is_kept_not_silently_promoted(self):
        a=fixture();a['latency_by_half_ms']['1']['folded_tf32']['p95_ms']=115.
        a['performance_gate']['passed']=False;a['eligible_for_full_quality_review']=False
        r=summary(a);self.assertFalse(r['eligible_for_full_quality_review'])
        self.assertEqual(r['latency_by_half_ms']['1']['folded_tf32']['p95_ms'],115.)
        a['eligible_for_full_quality_review']=True
        with self.assertRaises(AssertionError):summary(a)

    def test_stability_failure_cannot_be_reclassified_as_allowed_drift(self):
        a=fixture();a['repeated_comparison']=comparison(88,False)
        with self.assertRaises(AssertionError):summary(a)
        a['stability_exact']=False;a['eligible_for_full_quality_review']=False
        self.assertFalse(summary(a)['stability_exact'])

    def test_repeats_counts_and_production_claims_are_rejected(self):
        for edit in (lambda a:a['quality']['overall'].update(independent_users=24),
                     lambda a:a.update(promotion=True),
                     lambda a:a['comparison'].update(rank_positions=1199),
                     lambda a:a['quality'].update(noninferiority_established=True)):
            a=fixture();edit(a)
            with self.assertRaises(AssertionError):summary(a)

    def test_raw_inventory_requires_every_file_and_original_bytes(self):
        entries={'raw/a':b'bits','raw/failed-output':b'failed'}
        manifest={'run_id':'run','files':[{'path':n[4:],'size':len(v),'sha256':sha(v)} for n,v in entries.items()]}
        verify_raw(entries,manifest,'run')
        with self.assertRaises(AssertionError):verify_raw({'raw/a':b'bits'},manifest,'run')
        entries['raw/a']=b'new!'
        with self.assertRaises(AssertionError):verify_raw(entries,manifest,'run')

    def test_shards_preserve_every_member_and_failed_bits(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);entries={f'raw/{i}':bytes((j*i+j)%256 for j in range(700)) for i in range(12)}
            result=write_shards(root,entries,limit=1100);seen={}
            for shard in result['archives']:
                data=(root/shard['path']).read_bytes();self.assertEqual(sha(data),shard['sha256']);self.assertLess(len(data),1100)
                with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
                    for member in t:seen[member.name]=t.extractfile(member).read()
            self.assertEqual(seen,entries);self.assertEqual(set(result['files']),set(entries))

if __name__=='__main__':unittest.main()
