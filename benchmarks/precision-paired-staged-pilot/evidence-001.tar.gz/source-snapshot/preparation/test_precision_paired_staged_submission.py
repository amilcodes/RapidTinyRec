"""CPU-only submission boundary tests; never contact a scheduler."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('paired_guard',Path(__file__).with_name('submit_precision_paired_staged.py'))
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)

class GuardTests(unittest.TestCase):
    def setUp(self):
        self.commit='fixed-test-commit'
        self.status=dict(submission_ready=True,submitted=False,source_commit=self.commit,
            profile=g.PROFILE,config=g.CONFIG,eligible_for_full_quality_review=False,
            promotion=False,noninferiority_established=False,
            ci=dict(head_sha=self.commit,status='completed',conclusion='success',tests_passed=113,cli_checks='PASS'))
        self.ledger={}
        self.config=dict(project='rapidtinyrec-precision-paired-staged',
            ssh_target='aagraw73@sshcampus.ccv.brown.edu',remote_root='/oscar/scratch/aagraw73/agent-runs',
            profiles={g.PROFILE:copy.deepcopy(g.RESOURCES)})
        self.protocol=g.read(g.BASE/'work/rapidtinyrec_prep/precision-paired-staged-protocol.json')

    def check(self):
        g.validate_readiness(self.status,self.ledger,self.config,self.protocol,self.commit)

    def test_reviewed_protocol_can_pass_cpu_boundary(self):self.check()

    def test_unreviewed_or_previously_submitted_blocks(self):
        for key,value in [('submission_ready',False),('submitted',True),('run_id','existing'),('job_id','existing')]:
            with self.subTest(key=key),patch.dict(self.status,{key:value}):
                with self.assertRaises(AssertionError):self.check()

    def test_any_active_or_uncertain_ledger_blocks(self):
        for key in ('current_gpu_job','remaining_gpu_job','active_gpu_job','active_experiment'):
            with self.subTest(key=key),patch.dict(self.ledger,{key:'uncertain'}):
                with self.assertRaises(AssertionError):self.check()

    def test_wrong_source_or_ci_blocks(self):
        with patch.dict(self.status,source_commit='wrong'):
            with self.assertRaises(AssertionError):self.check()
        for key,value in [('head_sha','wrong'),('status','in_progress'),('conclusion','failure'),('tests_passed',112),('cli_checks','FAIL')]:
            with self.subTest(key=key),patch.dict(self.status['ci'],{key:value}):
                with self.assertRaises(AssertionError):self.check()

    def test_resource_escalation_and_extra_profile_block(self):
        for key,value in [('time','01:00:00'),('gpus',2),('cpus',8),('memory_gb',64),('qos','gpu'),('command',['bash','jobs/precision.sh'])]:
            with self.subTest(key=key),patch.dict(self.config['profiles'][g.PROFILE],{key:value}):
                with self.assertRaises(AssertionError):self.check()
        with patch.dict(self.config['profiles'],{'full500':g.RESOURCES}):
            with self.assertRaises(AssertionError):self.check()

    def test_scope_budget_and_promotion_mutations_block(self):
        for key,value in [('cohort_indices',list(range(500))),('graphs_per_phase',40),('paired_requests',500),('promotion',True)]:
            with self.subTest(key=key),patch.dict(self.protocol,{key:value}):
                with self.assertRaises(AssertionError):self.check()
        for key,value in [('supervisor_child_deadline_s',1800),('nominal_cleanup_headroom_s',0),('planning_total_child_s',1700)]:
            with patch.dict(self.protocol['budget'],{key:value}):
                with self.assertRaises(AssertionError):self.check()
        for key,value in [('variant','folded_tf32'),('fresh_process',False),('fresh_allocations',False),('fresh_graphs',False)]:
            with patch.dict(self.protocol['phases'][0],{key:value}):
                with self.assertRaises(AssertionError):self.check()

    def test_existing_intent_stops_before_any_external_call(self):
        with tempfile.TemporaryDirectory() as directory:
            intent=Path(directory)/'intent.json';intent.write_text('{}')
            with patch.object(g,'INTENT',intent),patch('sys.argv',['guard']),patch.object(g.subprocess,'check_output') as call:
                with self.assertRaisesRegex(AssertionError,'Existing intent'):g.main()
                call.assert_not_called()

    def test_recovery_without_intent_cannot_submit(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(g,'INTENT',Path(directory)/'absent'),patch.object(g.subprocess,'run') as call:
                with self.assertRaisesRegex(AssertionError,'No existing'):g.recover()
                call.assert_not_called()

    def test_finalize_rejects_other_run_before_writing_status(self):
        with patch.object(g,'read',return_value={'sha256':{'x':'saved'},'resources':g.RESOURCES,'intent_at_utc':'2026-01-01'}),patch.object(g,'record_status') as save:
            with self.assertRaises(AssertionError):g.finalize({'profile':g.PROFILE,'job_id':'x','sha256':{'x':'wrong'},'resources':g.RESOURCES})
            save.assert_not_called()

    def test_audit_targets_distinct_snapshot_and_failure_destination(self):
        args=g.audit_command('one-run')
        self.assertEqual(args[2],'rapidtinyrec.audit_precision_paired_staged')
        self.assertNotIn('--prior-review',args)
        self.assertTrue(args[-1].endswith('rapidtinyrec_precision_paired_staged_audit.json'))
        self.assertIn('--release-root',args)
        self.assertIn(str(g.H/'.oscar/source_snapshots/one-run/rapidtinyrec'),args)

if __name__=='__main__':unittest.main()
