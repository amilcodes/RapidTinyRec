# AOT ID: ['3_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
from torch._inductor.runtime.runtime_utils import assert_tensor_metadata

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-paired-staged/precision-paired-staged-pilot-20261026T121621Z-a084c4476031/compile-cache/tf32/inductor/ck/cckvoeogtkik3fvabh6wpahgnd7vvfo7wgbirhk4tknbhnscvv2v.py
# Topologically Sorted Source Nodes: [inputs_embeds, pow_1, variance, rsqrt, hidden_states_1, hidden_states_2], Original ATen: [aten.embedding, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   hidden_states_1 => mul_44
#   hidden_states_2 => mul_47
#   inputs_embeds => embedding
#   pow_1 => pow_1
#   rsqrt => rsqrt
#   variance => mean
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %arg7_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg7_1]
#   %buf0 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf0]
#   %arg6_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg6_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %pow_1 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%embedding, 2), kwargs = {})
#   %mean : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %convert_element_type_default_4 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg6_1, torch.float32), kwargs = {})
#   %add_tensor : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, %convert_element_type_default_4), kwargs = {})
#   %rsqrt : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor,), kwargs = {})
#   %mul_44 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%embedding, %rsqrt), kwargs = {})
#   %mul_47 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg7_1, %mul_44), kwargs = {})
#   return %buf0,%mul_47
triton_red_fused_embedding_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_red_fused_embedding_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_embedding_mean_mul_pow_rsqrt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 620544}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_embedding_mean_mul_pow_rsqrt_0(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    tmp12 = in_ptr3
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp9 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tl.full([1, 1], 1536.0, tl.float32)
        tmp11 = (tmp5 / tmp10)
        tmp13 = tmp12.to(tl.float32)
        tmp14 = tmp11 + tmp13
        tmp15 = libdevice.rsqrt(tmp14)
        tmp16 = tmp9 * tmp15
        tmp17 = tmp7 * tmp16
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp17, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-paired-staged/precision-paired-staged-pilot-20261026T121621Z-a084c4476031/compile-cache/tf32/inductor/5t/c5tuhgcddtxbn4pmzr4bf6uhzcvfm5yqygs3tudhruibp2wasd7x.py
# Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, sin, sin_3, linear_1, view_1, key_states, mul_6, x2_1, neg_1, x1_1, cat_2, mul_7, k_embed, key_tensors], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
# Source node to ATen node mapping:
#   cat_2 => cat_1
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   k_embed => add_216
#   key_states => permute_4
#   key_tensors => cat_2
#   linear_1 => view_8
#   matmul => mul_14
#   mul_6 => mul_103
#   mul_7 => mul_114
#   neg_1 => neg_1
#   position_ids_expanded => convert_element_type
#   sin => sin
#   sin_3 => unsqueeze_5
#   view_1 => view_9
#   x1_1 => slice_4
#   x2_1 => slice_5
# Graph fragment:
#   %arg16_1 : Tensor "f32[s16, 2, s53, 128][256*s53, 128*s53, 128, 1]cuda:0" = PlaceHolder[target=arg16_1]
#   %addmm_1 : Tensor "f32[s16, 256][256, 1]cuda:0" = PlaceHolder[target=addmm_1]
#   %arg4_1 : Tensor "f32[64][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %arg3_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg3_1]
#   %arg5_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg5_1]
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %view_8 : Tensor "f32[s16, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_1, [%arg14_1, 1, 256]), kwargs = {})
#   %view_9 : Tensor "f32[s16, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_8, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_4 : Tensor "f32[s16, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_9, [0, 2, 1, 3]), kwargs = {})
#   %mul_103 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_4, %unsqueeze_4), kwargs = {})
#   %slice_5 : Tensor "f32[s16, 2, 1, 64][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_4, 3, 64, 9223372036854775807), kwargs = {})
#   %neg_1 : Tensor "f32[s16, 2, 1, 64][128, 64, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_5,), kwargs = {})
#   %slice_4 : Tensor "f32[s16, 2, 1, 64][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_4, 3, 0, 64), kwargs = {})
#   %cat_1 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %slice_4], -1), kwargs = {})
#   %mul_114 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %unsqueeze_5), kwargs = {})
#   %add_216 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_103, %mul_114), kwargs = {})
#   %cat_2 : Tensor "f32[s16, 2, s53 + 1, 128][256*s53 + 256, 128*s53 + 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.cat.default](args = ([%arg16_1, %add_216], -2), kwargs = {})
#   return %cat_2
triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1 = async_compile.triton('triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*i64', 'in_ptr4': 'fp64', 'out_ptr0': '*fp32', 'ks0': 'i64', 'ks1': 'i64', 'ks2': 'i64', 'ks3': 'i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 11930256}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr0, ks0, ks1, ks2, ks3, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = ((xindex // 128) % ks0)
    x0 = (xindex % 128)
    x4 = xindex // ks2
    x5 = xindex
    x3 = xindex // ks3
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x1).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = (ks1).to(tl.int64)
    tmp6 = (tmp5).to(tl.int64)
    tmp7 = tmp4 < tmp6
    tmp8 = tl.load(in_ptr0 + (x0 + 128*(x1) + 128*ks1*x4), tmp7 & xmask, eviction_policy='evict_last', other=0.0)
    tmp9 = (ks1).to(tl.int32)
    tmp10 = tmp0 >= tmp9
    tmp11 = (ks0).to(tl.int32)
    tmp12 = tmp0 < tmp11
    tmp13 = tl.load(in_ptr1 + (x0 + 128*x4), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp14 = tl.load(in_ptr2 + ((x5 % 64)), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp15 = tl.load(in_ptr3 + (x3), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp16 = tmp15.to(tl.float32)
    tmp17 = tmp14 * tmp16
    tmp18 = tl_math.cos(tmp17)
    tmp19 = in_ptr4
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp18 * tmp20
    tmp22 = tmp13 * tmp21
    tmp23 = (x0).to(tl.int32)
    tmp24 = tl.full([1], 0, tl.int64)
    tmp25 = tmp23 >= tmp24
    tmp26 = (x0).to(tl.int64)
    tmp27 = (tmp26).to(tl.int64)
    tmp28 = tl.full([1], 64, tl.int64)
    tmp29 = tmp27 < tmp28
    tmp30 = tmp29 & tmp10
    tmp31 = tl.load(in_ptr1 + (64 + 128*x4 + (x0)), tmp30 & xmask, eviction_policy='evict_last', other=0.0)
    tmp32 = -tmp31
    tmp33 = tl.full(tmp32.shape, 0.0, tmp32.dtype)
    tmp34 = tl.where(tmp30, tmp32, tmp33)
    tmp35 = tmp23 >= tmp28
    tmp36 = tl.full([1], 128, tl.int64)
    tmp37 = tmp23 < tmp36
    tmp38 = tmp35 & tmp10
    tmp39 = tl.load(in_ptr1 + (128*x4 + ((-64) + x0)), tmp38 & xmask, eviction_policy='evict_last', other=0.0)
    tmp40 = tl.where(tmp29, tmp34, tmp39)
    tmp41 = tl_math.sin(tmp17)
    tmp42 = tmp41 * tmp20
    tmp43 = tmp40 * tmp42
    tmp44 = tmp22 + tmp43
    tmp45 = tl.full(tmp44.shape, 0.0, tmp44.dtype)
    tmp46 = tl.where(tmp10, tmp44, tmp45)
    tmp47 = tl.where(tmp7, tmp8, tmp46)
    tl.store(out_ptr0 + (x5), tmp47, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-paired-staged/precision-paired-staged-pilot-20261026T121621Z-a084c4476031/compile-cache/tf32/inductor/in/cin25vt2uf2cafg6u4nlozrb3f4dutv7fj55fi6ecjxdcg7kpzez.py
# Topologically Sorted Source Nodes: [linear_2, view_2, value_states, value_tensors], Original ATen: [aten.view, aten.transpose, aten.cat]
# Source node to ATen node mapping:
#   linear_2 => view_11
#   value_states => permute_6
#   value_tensors => cat_3
#   view_2 => view_12
# Graph fragment:
#   %arg17_1 : Tensor "f32[s16, 2, s53, 128][256*s53, 128*s53, 128, 1]cuda:0" = PlaceHolder[target=arg17_1]
#   %addmm_2 : Tensor "f32[s16, 256][256, 1]cuda:0" = PlaceHolder[target=addmm_2]
#   %view_11 : Tensor "f32[s16, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_2, [%arg14_1, 1, 256]), kwargs = {})
#   %view_12 : Tensor "f32[s16, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_11, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_6 : Tensor "f32[s16, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_12, [0, 2, 1, 3]), kwargs = {})
#   %cat_3 : Tensor "f32[s16, 2, s53 + 1, 128][256*s53 + 256, 128*s53 + 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.cat.default](args = ([%arg17_1, %permute_6], -2), kwargs = {})
#   return %cat_3
triton_poi_fused_cat_transpose_view_2 = async_compile.triton('triton_poi_fused_cat_transpose_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'ks0': 'i64', 'ks1': 'i64', 'ks2': 'i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_cat_transpose_view_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 11827200}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_cat_transpose_view_2(in_ptr0, in_ptr1, out_ptr0, ks0, ks1, ks2, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = ((xindex // 128) % ks0)
    x0 = (xindex % 128)
    x2 = xindex // ks2
    x3 = xindex
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x1).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = (ks1).to(tl.int64)
    tmp6 = (tmp5).to(tl.int64)
    tmp7 = tmp4 < tmp6
    tmp8 = tl.load(in_ptr0 + (x0 + 128*(x1) + 128*ks1*x2), tmp7 & xmask, eviction_policy='evict_last', other=0.0)
    tmp9 = (ks1).to(tl.int32)
    tmp10 = tmp0 >= tmp9
    tmp11 = (ks0).to(tl.int32)
    tmp12 = tmp0 < tmp11
    tmp13 = tl.load(in_ptr1 + (x0 + 128*x2), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp14 = tl.where(tmp7, tmp8, tmp13)
    tl.store(out_ptr0 + (x3), tmp14, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-paired-staged/precision-paired-staged-pilot-20261026T121621Z-a084c4476031/compile-cache/tf32/inductor/5k/c5kfpjgvc6lyueokx6kd24ubyrjmimazrfbt54w3yvguh73ln34k.py
# Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
# Source node to ATen node mapping:
#   cat_1 => cat
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   linear => view_5
#   matmul => mul_14
#   mul_4 => mul_87
#   mul_5 => mul_98
#   neg => neg
#   output => _scaled_dot_product_efficient_attention
#   packed => view_13
#   position_ids_expanded => convert_element_type
#   q_embed => add_180
#   query_states => permute_2
#   sin => sin
#   sin_3 => unsqueeze_5
#   view => view_6
#   x1 => slice_2
#   x2 => slice_3
# Graph fragment:
#   %addmm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=addmm]
#   %arg4_1 : Tensor "f32[64][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %arg3_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg3_1]
#   %arg5_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg5_1]
#   %view_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [%arg14_1, 1, 1536]), kwargs = {})
#   %view_6 : Tensor "f32[s16, 1, 12, 128][1536, 1536, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_5, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_2 : Tensor "f32[s16, 12, 1, 128][1536, 128, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_6, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %mul_87 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_2, %unsqueeze_4), kwargs = {})
#   %slice_3 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "f32[s16, 12, 1, 64][768, 64, 768, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_3,), kwargs = {})
#   %slice_2 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 0, 64), kwargs = {})
#   %cat : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_2], -1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %mul_98 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_5), kwargs = {})
#   %add_180 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_87, %mul_98), kwargs = {})
#   %view_13 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add_180, [%arg14_1, 2, 6, 128]), kwargs = {})
#   %_scaled_dot_product_efficient_attention : [num_users=1] = call_function[target=torch.ops.aten._scaled_dot_product_efficient_attention.default](args = (%view_13, %cat_2, %cat_3, None, False), kwargs = {scale: 0.08838834764831845})
#   return %buf7
triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3 = async_compile.triton('triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*i64', 'in_ptr3': 'fp64', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1536656}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x3 = xindex
    x2 = xindex // 1536
    x0 = (xindex % 128)
    x4 = xindex // 128
    tmp0 = tl.load(in_ptr0 + (x3), xmask)
    tmp1 = tl.load(in_ptr1 + ((x3 % 64)), xmask, eviction_policy='evict_last')
    tmp2 = tl.load(in_ptr2 + (x2), xmask, eviction_policy='evict_last')
    tmp6 = in_ptr3
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp1 * tmp3
    tmp5 = tl_math.cos(tmp4)
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tmp5 * tmp7
    tmp9 = tmp0 * tmp8
    tmp10 = (x0).to(tl.int32)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 >= tmp11
    tmp13 = (x0).to(tl.int64)
    tmp14 = (tmp13).to(tl.int64)
    tmp15 = tl.full([1], 64, tl.int64)
    tmp16 = tmp14 < tmp15
    tmp17 = tl.load(in_ptr0 + (64 + 128*x4 + (x0)), tmp16 & xmask, eviction_policy='evict_last', other=0.0)
    tmp18 = -tmp17
    tmp19 = tl.full(tmp18.shape, 0.0, tmp18.dtype)
    tmp20 = tl.where(tmp16, tmp18, tmp19)
    tmp21 = tmp10 >= tmp15
    tmp22 = tl.full([1], 128, tl.int64)
    tmp23 = tmp10 < tmp22
    tmp24 = tl.load(in_ptr0 + (128*x4 + ((-64) + x0)), tmp21 & xmask, eviction_policy='evict_last', other=0.0)
    tmp25 = tl.where(tmp16, tmp20, tmp24)
    tmp26 = tl_math.sin(tmp4)
    tmp27 = tmp26 * tmp7
    tmp28 = tmp25 * tmp27
    tmp29 = tmp9 + tmp28
    tl.store(out_ptr0 + (x3), tmp29, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-paired-staged/precision-paired-staged-pilot-20261026T121621Z-a084c4476031/compile-cache/tf32/inductor/hr/chrjjprrivuviusbims7kprdvank2wjgmz7x52lmec3v6cd4yg56.py
# Topologically Sorted Source Nodes: [attn_output], Original ATen: [aten.clone]
# Source node to ATen node mapping:
#   attn_output => clone_2
# Graph fragment:
#   %getitem : Tensor "f32[s16, 2, 6, 128][1536, 128, 256, 1]cuda:0" = PlaceHolder[target=getitem]
#   %clone_2 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%getitem,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone_2
triton_poi_fused_clone_4 = async_compile.triton('triton_poi_fused_clone_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_clone_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 921600}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_clone_4(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 6)
    x2 = ((xindex // 768) % 2)
    x3 = xindex // 1536
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 128*x2 + 256*x1 + 1536*x3), xmask)
    tl.store(out_ptr0 + (x4), tmp0, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-paired-staged/precision-paired-staged-pilot-20261026T121621Z-a084c4476031/compile-cache/tf32/inductor/yu/cyuadoqeapbd2t34bycowlx4e4odu3litthbwlkmmyknikc5p5zf.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, pow_2, variance_1, rsqrt_1, hidden_states_5, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   hidden_states_3 => add_273
#   hidden_states_5 => mul_207
#   hidden_states_6 => mul_210
#   inputs_embeds => embedding
#   pow_2 => pow_2
#   rsqrt_1 => rsqrt_1
#   variance_1 => mean_1
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %arg20_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg20_1]
#   %buf15 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf15]
#   %arg19_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg19_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_273 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %pow_2 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_273, 2), kwargs = {})
#   %mean_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %convert_element_type_default_6 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg19_1, torch.float32), kwargs = {})
#   %add_tensor_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, %convert_element_type_default_6), kwargs = {})
#   %rsqrt_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_1,), kwargs = {})
#   %mul_207 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_273, %rsqrt_1), kwargs = {})
#   %mul_210 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg20_1, %mul_207), kwargs = {})
#   return %buf15,%mul_210
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 927744}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    tmp16 = in_ptr4
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tmp11 + tmp12
        tmp14 = tl.full([1, 1], 1536.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tmp15 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp13 * tmp19
        tmp21 = tmp9 * tmp20
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp21, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-paired-staged/precision-paired-staged-pilot-20261026T121621Z-a084c4476031/compile-cache/tf32/inductor/ge/cgeubuhpoiyy2agm5o3xjspcpt3zzcgpqynavmr72iv5pyddffmt.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_10], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
# Source node to ATen node mapping:
#   linear_4 => view_19
#   linear_5 => view_21
#   mul_10 => mul_240
#   silu => add_313, div, exp, neg_2
# Graph fragment:
#   %mm_1 : Tensor "f32[s16, 8960][8960, 1]cuda:0" = PlaceHolder[target=mm_1]
#   %mm_2 : Tensor "f32[s16, 8960][8960, 1]cuda:0" = PlaceHolder[target=mm_2]
#   %view_19 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [%arg14_1, 1, 8960]), kwargs = {})
#   %neg_2 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%view_19,), kwargs = {})
#   %exp : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_313 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%view_19, %add_313), kwargs = {})
#   %view_21 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [%arg14_1, 1, 8960]), kwargs = {})
#   %mul_240 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%div, %view_21), kwargs = {})
#   return %mul_240
triton_poi_fused__unsafe_view_mul_silu_6 = async_compile.triton('triton_poi_fused__unsafe_view_mul_silu_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_mul_silu_6', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 7168000}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_mul_silu_6(in_out_ptr0, in_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_out_ptr0 + (x0), xmask)
    tmp6 = tl.load(in_ptr0 + (x0), xmask)
    tmp1 = -tmp0
    tmp2 = libdevice.exp(tmp1)
    tmp3 = tl.full([1], 1.0, tl.float32)
    tmp4 = tmp2 + tmp3
    tmp5 = (tmp0 / tmp4)
    tmp7 = tmp5 * tmp6
    tl.store(in_out_ptr0 + (x0), tmp7, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-paired-staged/precision-paired-staged-pilot-20261026T121621Z-a084c4476031/compile-cache/tf32/inductor/3n/c3n4p53u2b5ksqygihm5ukzkzve35a42ian3rmgaalbiujudwqah.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, down_proj, hidden_states_7, pow_3, variance_2, rsqrt_2, hidden_states_9, hidden_states_10], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   down_proj => view_23
#   hidden_states_10 => mul_267
#   hidden_states_3 => add_273
#   hidden_states_7 => add_342
#   hidden_states_9 => mul_264
#   inputs_embeds => embedding
#   pow_3 => pow_3
#   rsqrt_2 => rsqrt_2
#   variance_2 => mean_2
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %mm_3 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_3]
#   %arg25_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg25_1]
#   %buf21 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf21]
#   %arg24_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg24_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_273 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %view_23 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_342 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_273, %view_23), kwargs = {})
#   %pow_3 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_342, 2), kwargs = {})
#   %mean_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %convert_element_type_default_8 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg24_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, %convert_element_type_default_8), kwargs = {})
#   %rsqrt_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_2,), kwargs = {})
#   %mul_264 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_342, %rsqrt_2), kwargs = {})
#   %mul_267 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg25_1, %mul_264), kwargs = {})
#   return %buf21,%mul_267
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    tmp20 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp14 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp16 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tmp13 + tmp14
        tmp17 = tmp15 + tmp16
        tmp18 = tl.full([1, 1], 1536.0, tl.float32)
        tmp19 = (tmp9 / tmp18)
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp19 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp17 * tmp23
        tmp25 = tmp11 * tmp24
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp25, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-paired-staged/precision-paired-staged-pilot-20261026T121621Z-a084c4476031/compile-cache/tf32/inductor/sn/csn6ccor6ary7eqpdezyaaq4ntwang2mm355374s2sv46v6rp7fh.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, down_proj, hidden_states_7, attn_output_7, hidden_states_11, pow_4, variance_3, rsqrt_3, hidden_states_13, hidden_states_14], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   attn_output_7 => view_37
#   down_proj => view_23
#   hidden_states_11 => add_565
#   hidden_states_13 => mul_427
#   hidden_states_14 => mul_430
#   hidden_states_3 => add_273
#   hidden_states_7 => add_342
#   inputs_embeds => embedding
#   pow_4 => pow_4
#   rsqrt_3 => rsqrt_3
#   variance_3 => mean_3
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %mm_3 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_3]
#   %mm_4 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_4]
#   %add_565 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_565]
#   %arg36_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg36_1]
#   %buf37 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf37]
#   %arg35_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg35_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_273 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %view_23 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_342 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_273, %view_23), kwargs = {})
#   %view_37 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_565 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_342, %view_37), kwargs = {})
#   %pow_4 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_565, 2), kwargs = {})
#   %mean_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %convert_element_type_default_10 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg35_1, torch.float32), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, %convert_element_type_default_10), kwargs = {})
#   %rsqrt_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_427 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_565, %rsqrt_3), kwargs = {})
#   %mul_430 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg36_1, %mul_427), kwargs = {})
#   return %add_565,%buf37,%mul_430
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 2156544}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp11 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp5 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp7 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask & xmask, tmp12, _tmp11)
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp8, r0_mask & xmask)
    tmp11 = tl.sum(_tmp11, 1)[:, None]
    tmp17 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.debug_barrier()
        tmp14 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp11 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp13 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-paired-staged/precision-paired-staged-pilot-20261026T121621Z-a084c4476031/compile-cache/tf32/inductor/5l/c5llxk643ulqbekz24lcsa2sz6kwkig7mnhzxrdnnuldedvttsju.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, pow_5, variance_4, rsqrt_4, hidden_states_17, hidden_states_18], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   down_proj_1 => view_43
#   hidden_states_15 => add_634
#   hidden_states_17 => mul_484
#   hidden_states_18 => mul_487
#   pow_5 => pow_5
#   rsqrt_4 => rsqrt_4
#   variance_4 => mean_4
# Graph fragment:
#   %add_565 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_565]
#   %mm_7 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %arg41_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg41_1]
#   %buf43 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf43]
#   %arg40_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg40_1]
#   %view_43 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_634 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_565, %view_43), kwargs = {})
#   %pow_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_634, 2), kwargs = {})
#   %mean_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [-1], True), kwargs = {})
#   %convert_element_type_default_12 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg40_1, torch.float32), kwargs = {})
#   %add_tensor_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_4, %convert_element_type_default_12), kwargs = {})
#   %rsqrt_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_4,), kwargs = {})
#   %mul_484 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_634, %rsqrt_4), kwargs = {})
#   %mul_487 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg41_1, %mul_484), kwargs = {})
#   return %buf43,%mul_487
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    tmp13 = in_ptr3
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp8 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp9 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tmp8 + tmp9
        tmp11 = tl.full([1, 1], 1536.0, tl.float32)
        tmp12 = (tmp5 / tmp11)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tmp12 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp10 * tmp16
        tmp18 = tmp7 * tmp17
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp18, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-paired-staged/precision-paired-staged-pilot-20261026T121621Z-a084c4476031/compile-cache/tf32/inductor/7a/c7aklu4fbiemns3ltg3c54mrcudd2a7nyscig7bkcvaywbl72f5d.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, pow_6, variance_5, rsqrt_5, hidden_states_21, hidden_states_22], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_57
#   down_proj_1 => view_43
#   hidden_states_15 => add_634
#   hidden_states_19 => add_857
#   hidden_states_21 => mul_647
#   hidden_states_22 => mul_650
#   pow_6 => pow_6
#   rsqrt_5 => rsqrt_5
#   variance_5 => mean_5
# Graph fragment:
#   %add_565 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_565]
#   %mm_7 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %mm_8 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %arg52_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg52_1]
#   %buf58 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf58]
#   %arg51_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg51_1]
#   %view_43 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_634 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_565, %view_43), kwargs = {})
#   %view_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_857 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_634, %view_57), kwargs = {})
#   %pow_6 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_857, 2), kwargs = {})
#   %mean_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %convert_element_type_default_14 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg51_1, torch.float32), kwargs = {})
#   %add_tensor_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, %convert_element_type_default_14), kwargs = {})
#   %rsqrt_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_5,), kwargs = {})
#   %mul_647 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_857, %rsqrt_5), kwargs = {})
#   %mul_650 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg52_1, %mul_647), kwargs = {})
#   return %buf58,%mul_650
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1542144}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    tmp17 = in_ptr4
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp10 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp7 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp9 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-paired-staged/precision-paired-staged-pilot-20261026T121621Z-a084c4476031/compile-cache/tf32/inductor/sk/cskx4kb6fpqafmn3f6xhgtoz5ohz2rfyt3rnqnmrmmwximkffpn5.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, down_proj_2, hidden_states_23, pow_7, variance_6, rsqrt_6, hidden_states_25, hidden_states_26], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_57
#   down_proj_1 => view_43
#   down_proj_2 => view_63
#   hidden_states_15 => add_634
#   hidden_states_19 => add_857
#   hidden_states_23 => add_926
#   hidden_states_25 => mul_704
#   hidden_states_26 => mul_707
#   pow_7 => pow_7
#   rsqrt_6 => rsqrt_6
#   variance_6 => mean_6
# Graph fragment:
#   %add_565 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_565]
#   %mm_7 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %mm_8 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %mm_11 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_11]
#   %arg57_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg57_1]
#   %buf64 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf64]
#   %arg56_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg56_1]
#   %view_43 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_634 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_565, %view_43), kwargs = {})
#   %view_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_857 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_634, %view_57), kwargs = {})
#   %view_63 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_11, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_926 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_857, %view_63), kwargs = {})
#   %pow_7 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_926, 2), kwargs = {})
#   %mean_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [-1], True), kwargs = {})
#   %convert_element_type_default_16 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg56_1, torch.float32), kwargs = {})
#   %add_tensor_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_6, %convert_element_type_default_16), kwargs = {})
#   %rsqrt_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_6,), kwargs = {})
#   %mul_704 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_926, %rsqrt_6), kwargs = {})
#   %mul_707 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg57_1, %mul_704), kwargs = {})
#   return %buf64,%mul_707
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 10, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1849344}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    tmp21 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp17 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tl.full([1, 1], 1536.0, tl.float32)
        tmp20 = (tmp9 / tmp19)
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tmp20 + tmp22
        tmp24 = libdevice.rsqrt(tmp23)
        tmp25 = tmp18 * tmp24
        tmp26 = tmp11 * tmp25
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp26, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-paired-staged/precision-paired-staged-pilot-20261026T121621Z-a084c4476031/compile-cache/tf32/inductor/ca/ccakktfdoy2u7gzyqufh3ofs6ubj4cxdwh34rylvw24c4wkukic5.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, down_proj_2, hidden_states_23, attn_output_15, hidden_states_27, pow_8, variance_7, rsqrt_7, hidden_states_29, hidden_states_30], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_57
#   attn_output_15 => view_77
#   down_proj_1 => view_43
#   down_proj_2 => view_63
#   hidden_states_15 => add_634
#   hidden_states_19 => add_857
#   hidden_states_23 => add_926
#   hidden_states_27 => add_1149
#   hidden_states_29 => mul_867
#   hidden_states_30 => mul_870
#   pow_8 => pow_8
#   rsqrt_7 => rsqrt_7
#   variance_7 => mean_7
# Graph fragment:
#   %add_565 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_565]
#   %mm_7 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %mm_8 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %mm_11 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_11]
#   %mm_12 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_12]
#   %add_1149 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_1149]
#   %arg68_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg68_1]
#   %buf80 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf80]
#   %arg67_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg67_1]
#   %view_43 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_634 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_565, %view_43), kwargs = {})
#   %view_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_857 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_634, %view_57), kwargs = {})
#   %view_63 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_11, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_926 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_857, %view_63), kwargs = {})
#   %view_77 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_12, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_1149 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_926, %view_77), kwargs = {})
#   %pow_8 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_1149, 2), kwargs = {})
#   %mean_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_8, [-1], True), kwargs = {})
#   %convert_element_type_default_18 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg67_1, torch.float32), kwargs = {})
#   %add_tensor_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_7, %convert_element_type_default_18), kwargs = {})
#   %rsqrt_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_7,), kwargs = {})
#   %mul_867 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_1149, %rsqrt_7), kwargs = {})
#   %mul_870 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg68_1, %mul_867), kwargs = {})
#   return %add_1149,%buf80,%mul_870
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 2770944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp11 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp3 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp5 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp7 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask & xmask, tmp12, _tmp11)
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp8, r0_mask & xmask)
    tmp11 = tl.sum(_tmp11, 1)[:, None]
    tmp17 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.debug_barrier()
        tmp14 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp11 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp13 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-paired-staged/precision-paired-staged-pilot-20261026T121621Z-a084c4476031/compile-cache/tf32/inductor/cb/ccbefgmbd7oj7qu6z62xiurvt56fgv7um3maaspmw4ykilbgq55g.py
# Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, attn_output_59, hidden_states_115, down_proj_14, hidden_states_119, pow_31, variance_30, add_90, rsqrt_30, hidden_states_121, hidden_states_122], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_90 => add_4443
#   attn_output_59 => view_297
#   down_proj_13 => view_283
#   down_proj_14 => view_303
#   hidden_states_111 => add_4138
#   hidden_states_115 => add_4361
#   hidden_states_119 => add_4430
#   hidden_states_121 => mul_3344
#   hidden_states_122 => mul_3347
#   pow_31 => pow_31
#   rsqrt_30 => rsqrt_30
#   variance_30 => mean_30
# Graph fragment:
#   %add_4069 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_4069]
#   %mm_55 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_55]
#   %mm_56 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_56]
#   %mm_59 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_59]
#   %arg248_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg248_1]
#   %buf322 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf322]
#   %view_283 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_55, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4138 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4069, %view_283), kwargs = {})
#   %view_297 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_56, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4361 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4138, %view_297), kwargs = {})
#   %view_303 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_59, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4430 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4361, %view_303), kwargs = {})
#   %pow_31 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_4430, 2), kwargs = {})
#   %mean_30 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_31, [-1], True), kwargs = {})
#   %add_4443 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_30, 1e-06), kwargs = {})
#   %rsqrt_30 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4443,), kwargs = {})
#   %mul_3344 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_4430, %rsqrt_30), kwargs = {})
#   %mul_3347 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg248_1, %mul_3344), kwargs = {})
#   return %buf322,%mul_3347
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1849344}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp17 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tl.full([1, 1], 1536.0, tl.float32)
        tmp20 = (tmp9 / tmp19)
        tmp21 = tl.full([1, 1], 1e-06, tl.float32)
        tmp22 = tmp20 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp18 * tmp23
        tmp25 = tmp11 * tmp24
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp25, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-paired-staged/precision-paired-staged-pilot-20261026T121621Z-a084c4476031/compile-cache/tf32/inductor/hj/chjnrbfp6yki7eo43kbyqf56sfwh675uxditltthptlfnfa7jrcp.py
# Topologically Sorted Source Nodes: [down_proj_27, hidden_states_223, pow_57, variance_56, rsqrt_56, hidden_states_225, hidden_states_226], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   down_proj_27 => view_563
#   hidden_states_223 => add_8226
#   hidden_states_225 => mul_6204
#   hidden_states_226 => mul_6207
#   pow_57 => pow_57
#   rsqrt_56 => rsqrt_56
#   variance_56 => mean_56
# Graph fragment:
#   %add_8157 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_8157]
#   %mm_111 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_111]
#   %arg456_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg456_1]
#   %buf602 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf602]
#   %arg455_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg455_1]
#   %view_563 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_111, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_8226 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_8157, %view_563), kwargs = {})
#   %pow_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_8226, 2), kwargs = {})
#   %mean_56 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_57, [-1], True), kwargs = {})
#   %convert_element_type_default_114 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg455_1, torch.float32), kwargs = {})
#   %add_tensor_55 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_56, %convert_element_type_default_114), kwargs = {})
#   %rsqrt_56 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_55,), kwargs = {})
#   %mul_6204 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_8226, %rsqrt_56), kwargs = {})
#   %mul_6207 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg456_1, %mul_6204), kwargs = {})
#   return %buf602,%mul_6207
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': 'fp64', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    tmp13 = in_ptr2
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr1 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp8 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp9 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tmp8 + tmp9
        tmp11 = tl.full([1, 1], 1536.0, tl.float32)
        tmp12 = (tmp5 / tmp11)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tmp12 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp10 * tmp16
        tmp18 = tmp7 * tmp17
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp18, r0_mask & xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1 = args
        args.clear()
        s16 = arg0_1
        s74 = s16
        s52 = s16
        s53 = arg15_1
        s35 = arg457_1
        assert_size_stride_grouped((arg1_1, arg2_1, arg7_1, arg6_1), ((s16, 1), (152265, 1536), (1536, ), ()), ((1, 1), (1536, 1), (1, ), ()), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg1_1 = copy_if_misaligned(arg1_1)
            buf1 = empty_strided_cuda((s16, 1, 1536), (1536, 1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [inputs_embeds, pow_1, variance, rsqrt, hidden_states_1, hidden_states_2], Original ATen: [aten.embedding, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_embedding_mean_mul_pow_rsqrt_0.run(arg1_1, arg2_1, arg7_1, arg6_1.item(), buf1, s16, 1536, stream=raw_stream0)
            del arg6_1
            del arg7_1
            assert_size_stride_grouped((arg9_1, arg8_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf2 = empty_strided_cuda((s16, 1536), (1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg9_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg8_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf2)
            del arg8_1
            del arg9_1
            assert_size_stride_grouped((arg11_1, arg10_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf3 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg11_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg10_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf3)
            del arg10_1
            del arg11_1
            assert_size_stride_grouped((arg16_1, arg4_1, arg3_1, arg5_1), ((s16, 2, s53, 128), (64, ), (s16, 1), ()), ((256*s53, 128*s53, 128, 1), (1, ), (1, 1), ()), 'input')
            arg16_1 = copy_if_misaligned(arg16_1)
            arg3_1 = copy_if_misaligned(arg3_1)
            ps0 = 1 + s53
            ps1 = 128 + 128*s53
            ps2 = 256 + 256*s53
            buf4 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, sin, sin_3, linear_1, view_1, key_states, mul_6, x2_1, neg_1, x1_1, cat_2, mul_7, k_embed, key_tensors], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg16_1, buf3, arg4_1, arg3_1, arg5_1.item(), buf4, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg16_1
            assert_size_stride_grouped((arg13_1, arg12_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf5 = buf3; del buf3  # reuse
            # Topologically Sorted Source Nodes: [linear_2], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg13_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg12_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf5)
            del arg12_1
            del arg13_1
            assert_size_stride(arg17_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg17_1 = copy_if_misaligned(arg17_1)
            buf6 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_2, view_2, value_states, value_tensors], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg17_1, buf5, buf6, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg17_1
            buf7 = reinterpret_tensor(buf1, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf1  # reuse
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf2, arg4_1, arg3_1, arg5_1.item(), buf7, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            buf8 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf7, buf4, buf6, None, False, scale=0.08838834764831845)
            buf9 = buf8[0]
            assert_tensor_metadata(buf9, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf9, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf8
            buf13 = buf7; del buf7  # reuse
            # Topologically Sorted Source Nodes: [attn_output], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf9, buf13, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg18_1, (1536, 1536), (1536, 1), 'input')
            buf14 = reinterpret_tensor(buf9, (s16, 1536), (1536, 1), 0); del buf9  # reuse
            # Topologically Sorted Source Nodes: [attn_output, transpose_4, reshape_2, attn_output_3], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf13, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg18_1, (1536, 1536), (1, 1536), 0), out=buf14)
            del arg18_1
            assert_size_stride_grouped((arg20_1, arg19_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf16 = reinterpret_tensor(buf13, (s16, 1, 1536), (1536, 1536, 1), 0); del buf13  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, pow_2, variance_1, rsqrt_1, hidden_states_5, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5.run(arg1_1, arg2_1, buf14, arg20_1, arg19_1.item(), buf16, s16, 1536, stream=raw_stream0)
            del arg19_1
            del arg20_1
            assert_size_stride(arg21_1, (8960, 1536), (1536, 1), 'input')
            buf17 = empty_strided_cuda((s16, 8960), (8960, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf16, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg21_1, (1536, 8960), (1, 1536), 0), out=buf17)
            del arg21_1
            assert_size_stride(arg22_1, (8960, 1536), (1536, 1), 'input')
            buf18 = empty_strided_cuda((s16, 8960), (8960, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_5], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf16, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg22_1, (1536, 8960), (1, 1536), 0), out=buf18)
            del arg22_1
            buf19 = reinterpret_tensor(buf17, (s16, 1, 8960), (8960, 8960, 1), 0); del buf17  # reuse
            # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_10], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf19, buf18, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg23_1, (1536, 8960), (8960, 1), 'input')
            buf20 = reinterpret_tensor(buf16, (s16, 1536), (1536, 1), 0); del buf16  # reuse
            # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_10, down_proj], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf19, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg23_1, (8960, 1536), (1, 8960), 0), out=buf20)
            del arg23_1
            assert_size_stride_grouped((arg25_1, arg24_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf22 = reinterpret_tensor(buf2, (s16, 1, 1536), (1536, 1536, 1), 0); del buf2  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, down_proj, hidden_states_7, pow_3, variance_2, rsqrt_2, hidden_states_9, hidden_states_10], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7.run(arg1_1, arg2_1, buf14, buf20, arg25_1, arg24_1.item(), buf22, s16, 1536, stream=raw_stream0)
            del arg24_1
            del arg25_1
            assert_size_stride_grouped((arg27_1, arg26_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf23 = empty_strided_cuda((s16, 1536), (1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg27_1, reinterpret_tensor(buf22, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg26_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf23)
            del arg26_1
            del arg27_1
            assert_size_stride_grouped((arg29_1, arg28_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf24 = buf5; del buf5  # reuse
            # Topologically Sorted Source Nodes: [linear_8], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg29_1, reinterpret_tensor(buf22, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg28_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf24)
            del arg28_1
            del arg29_1
            assert_size_stride(arg32_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg32_1 = copy_if_misaligned(arg32_1)
            buf25 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_4, sin_4, linear_8, view_4, key_states_1, mul_15, x2_3, neg_3, x1_3, cat_6, mul_16, k_embed_1, key_tensors_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg32_1, buf24, arg4_1, arg3_1, arg5_1.item(), buf25, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg32_1
            assert_size_stride_grouped((arg31_1, arg30_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf26 = buf24; del buf24  # reuse
            # Topologically Sorted Source Nodes: [linear_9], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg31_1, reinterpret_tensor(buf22, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg30_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf26)
            del arg30_1
            del arg31_1
            assert_size_stride(arg33_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg33_1 = copy_if_misaligned(arg33_1)
            buf27 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_9, view_5, value_states_1, value_tensors_1], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg33_1, buf26, buf27, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg33_1
            buf28 = reinterpret_tensor(buf22, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf22  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_7, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_5, sin_4, mul_14, q_embed_1, packed_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf23, arg4_1, arg3_1, arg5_1.item(), buf28, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_7, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_5, sin_4, mul_14, q_embed_1, packed_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf29 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf28, buf25, buf27, None, False, scale=0.08838834764831845)
            buf30 = buf29[0]
            assert_tensor_metadata(buf30, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf30, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf29
            buf34 = buf28; del buf28  # reuse
            # Topologically Sorted Source Nodes: [attn_output_4], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf30, buf34, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg34_1, (1536, 1536), (1536, 1), 'input')
            buf35 = reinterpret_tensor(buf30, (s16, 1536), (1536, 1), 0); del buf30  # reuse
            # Topologically Sorted Source Nodes: [attn_output_4, transpose_8, reshape_5, attn_output_7], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf34, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg34_1, (1536, 1536), (1, 1536), 0), out=buf35)
            del arg34_1
            assert_size_stride_grouped((arg36_1, arg35_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf36 = reinterpret_tensor(buf14, (s16, 1, 1536), (1536, 1536*s16, 1), 0); del buf14  # reuse
            buf38 = reinterpret_tensor(buf34, (s16, 1, 1536), (1536, 1536, 1), 0); del buf34  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, down_proj, hidden_states_7, attn_output_7, hidden_states_11, pow_4, variance_3, rsqrt_3, hidden_states_13, hidden_states_14], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8.run(buf36, arg1_1, arg2_1, buf20, buf35, arg36_1, arg35_1.item(), buf38, s16, 1536, stream=raw_stream0)
            del arg1_1
            del arg35_1
            del arg36_1
            assert_size_stride(arg37_1, (8960, 1536), (1536, 1), 'input')
            buf39 = reinterpret_tensor(buf19, (s16, 8960), (8960, 1), 0); del buf19  # reuse
            # Topologically Sorted Source Nodes: [pow_4, variance_3, rsqrt_3, hidden_states_13, hidden_states_14, linear_11], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf38, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg37_1, (1536, 8960), (1, 1536), 0), out=buf39)
            del arg37_1
            assert_size_stride(arg38_1, (8960, 1536), (1536, 1), 'input')
            buf40 = buf18; del buf18  # reuse
            # Topologically Sorted Source Nodes: [linear_12], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf38, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg38_1, (1536, 8960), (1, 1536), 0), out=buf40)
            del arg38_1
            buf41 = reinterpret_tensor(buf39, (s16, 1, 8960), (8960, 8960, 1), 0); del buf39  # reuse
            # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_19], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf41, buf40, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg39_1, (1536, 8960), (8960, 1), 'input')
            buf42 = reinterpret_tensor(buf38, (s16, 1536), (1536, 1), 0); del buf38  # reuse
            # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_19, down_proj_1], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf41, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg39_1, (8960, 1536), (1, 8960), 0), out=buf42)
            del arg39_1
            assert_size_stride_grouped((arg41_1, arg40_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf44 = reinterpret_tensor(buf35, (s16, 1, 1536), (1536, 1536, 1), 0); del buf35  # reuse
            # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, pow_5, variance_4, rsqrt_4, hidden_states_17, hidden_states_18], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf36, buf42, arg41_1, arg40_1.item(), buf44, s16, 1536, stream=raw_stream0)
            del arg40_1
            del arg41_1
            assert_size_stride_grouped((arg43_1, arg42_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf45 = buf20; del buf20  # reuse
            # Topologically Sorted Source Nodes: [linear_14], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg43_1, reinterpret_tensor(buf44, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg42_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf45)
            del arg42_1
            del arg43_1
            assert_size_stride_grouped((arg45_1, arg44_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf46 = buf26; del buf26  # reuse
            # Topologically Sorted Source Nodes: [linear_15], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg45_1, reinterpret_tensor(buf44, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg44_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf46)
            del arg44_1
            del arg45_1
            assert_size_stride(arg48_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg48_1 = copy_if_misaligned(arg48_1)
            buf47 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_5, sin_5, linear_15, view_7, key_states_2, mul_24, x2_5, neg_5, x1_5, cat_10, mul_25, k_embed_2, key_tensors_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg48_1, buf46, arg4_1, arg3_1, arg5_1.item(), buf47, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg48_1
            assert_size_stride_grouped((arg47_1, arg46_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf48 = buf46; del buf46  # reuse
            # Topologically Sorted Source Nodes: [linear_16], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg47_1, reinterpret_tensor(buf44, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg46_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf48)
            del arg46_1
            del arg47_1
            assert_size_stride(arg49_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg49_1 = copy_if_misaligned(arg49_1)
            buf49 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_16, view_8, value_states_2, value_tensors_2], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg49_1, buf48, buf49, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg49_1
            buf50 = reinterpret_tensor(buf44, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf44  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_14, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_9, sin_5, mul_23, q_embed_2, packed_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf45, arg4_1, arg3_1, arg5_1.item(), buf50, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_14, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_9, sin_5, mul_23, q_embed_2, packed_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf51 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf50, buf47, buf49, None, False, scale=0.08838834764831845)
            buf52 = buf51[0]
            assert_tensor_metadata(buf52, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf52, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf51
            buf56 = buf50; del buf50  # reuse
            # Topologically Sorted Source Nodes: [attn_output_8], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf52, buf56, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg50_1, (1536, 1536), (1536, 1), 'input')
            buf57 = reinterpret_tensor(buf52, (s16, 1536), (1536, 1), 0); del buf52  # reuse
            # Topologically Sorted Source Nodes: [attn_output_8, transpose_12, reshape_8, attn_output_11], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf56, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg50_1, (1536, 1536), (1, 1536), 0), out=buf57)
            del arg50_1
            assert_size_stride_grouped((arg52_1, arg51_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf59 = reinterpret_tensor(buf56, (s16, 1, 1536), (1536, 1536, 1), 0); del buf56  # reuse
            # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, pow_6, variance_5, rsqrt_5, hidden_states_21, hidden_states_22], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf36, buf42, buf57, arg52_1, arg51_1.item(), buf59, s16, 1536, stream=raw_stream0)
            del arg51_1
            del arg52_1
            assert_size_stride(arg53_1, (8960, 1536), (1536, 1), 'input')
            buf60 = reinterpret_tensor(buf41, (s16, 8960), (8960, 1), 0); del buf41  # reuse
            # Topologically Sorted Source Nodes: [linear_18], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf59, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg53_1, (1536, 8960), (1, 1536), 0), out=buf60)
            del arg53_1
            assert_size_stride(arg54_1, (8960, 1536), (1536, 1), 'input')
            buf61 = buf40; del buf40  # reuse
            # Topologically Sorted Source Nodes: [linear_19], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf59, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg54_1, (1536, 8960), (1, 1536), 0), out=buf61)
            del arg54_1
            buf62 = reinterpret_tensor(buf60, (s16, 1, 8960), (8960, 8960, 1), 0); del buf60  # reuse
            # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_28], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf62, buf61, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg55_1, (1536, 8960), (8960, 1), 'input')
            buf63 = reinterpret_tensor(buf59, (s16, 1536), (1536, 1), 0); del buf59  # reuse
            # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_28, down_proj_2], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf62, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg55_1, (8960, 1536), (1, 8960), 0), out=buf63)
            del arg55_1
            assert_size_stride_grouped((arg57_1, arg56_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf65 = reinterpret_tensor(buf45, (s16, 1, 1536), (1536, 1536, 1), 0); del buf45  # reuse
            # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, down_proj_2, hidden_states_23, pow_7, variance_6, rsqrt_6, hidden_states_25, hidden_states_26], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf36, buf42, buf57, buf63, arg57_1, arg56_1.item(), buf65, s16, 1536, stream=raw_stream0)
            del arg56_1
            del arg57_1
            assert_size_stride_grouped((arg59_1, arg58_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf66 = buf23; del buf23  # reuse
            # Topologically Sorted Source Nodes: [linear_21], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg59_1, reinterpret_tensor(buf65, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg58_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf66)
            del arg58_1
            del arg59_1
            assert_size_stride_grouped((arg61_1, arg60_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf67 = buf48; del buf48  # reuse
            # Topologically Sorted Source Nodes: [linear_22], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg61_1, reinterpret_tensor(buf65, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg60_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf67)
            del arg60_1
            del arg61_1
            assert_size_stride(arg64_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg64_1 = copy_if_misaligned(arg64_1)
            buf68 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_6, sin_6, linear_22, view_10, key_states_3, mul_33, x2_7, neg_7, x1_7, cat_14, mul_34, k_embed_3, key_tensors_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg64_1, buf67, arg4_1, arg3_1, arg5_1.item(), buf68, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg64_1
            assert_size_stride_grouped((arg63_1, arg62_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf69 = buf67; del buf67  # reuse
            # Topologically Sorted Source Nodes: [linear_23], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg63_1, reinterpret_tensor(buf65, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg62_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf69)
            del arg62_1
            del arg63_1
            assert_size_stride(arg65_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg65_1 = copy_if_misaligned(arg65_1)
            buf70 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_23, view_11, value_states_3, value_tensors_3], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg65_1, buf69, buf70, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg65_1
            buf71 = reinterpret_tensor(buf65, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf65  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_21, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_13, sin_6, mul_32, q_embed_3, packed_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf66, arg4_1, arg3_1, arg5_1.item(), buf71, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf66
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_21, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_13, sin_6, mul_32, q_embed_3, packed_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf72 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf71, buf68, buf70, None, False, scale=0.08838834764831845)
            buf73 = buf72[0]
            assert_tensor_metadata(buf73, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf73, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf72
            buf77 = buf71; del buf71  # reuse
            # Topologically Sorted Source Nodes: [attn_output_12], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf73, buf77, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg66_1, (1536, 1536), (1536, 1), 'input')
            buf78 = reinterpret_tensor(buf73, (s16, 1536), (1536, 1), 0); del buf73  # reuse
            # Topologically Sorted Source Nodes: [attn_output_12, transpose_16, reshape_11, attn_output_15], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf77, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg66_1, (1536, 1536), (1, 1536), 0), out=buf78)
            del arg66_1
            assert_size_stride_grouped((arg68_1, arg67_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf79 = buf36; del buf36  # reuse
            buf81 = reinterpret_tensor(buf77, (s16, 1, 1536), (1536, 1536, 1), 0); del buf77  # reuse
            # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, down_proj_2, hidden_states_23, attn_output_15, hidden_states_27, pow_8, variance_7, rsqrt_7, hidden_states_29, hidden_states_30], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf79, buf42, buf57, buf63, buf78, arg68_1, arg67_1.item(), buf81, s16, 1536, stream=raw_stream0)
            del arg67_1
            del arg68_1
            del buf42
            assert_size_stride(arg69_1, (8960, 1536), (1536, 1), 'input')
            buf82 = reinterpret_tensor(buf62, (s16, 8960), (8960, 1), 0); del buf62  # reuse
            # Topologically Sorted Source Nodes: [pow_8, variance_7, rsqrt_7, hidden_states_29, hidden_states_30, linear_25], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf81, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg69_1, (1536, 8960), (1, 1536), 0), out=buf82)
            del arg69_1
            assert_size_stride(arg70_1, (8960, 1536), (1536, 1), 'input')
            buf83 = buf61; del buf61  # reuse
            # Topologically Sorted Source Nodes: [linear_26], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf81, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg70_1, (1536, 8960), (1, 1536), 0), out=buf83)
            del arg70_1
            buf84 = reinterpret_tensor(buf82, (s16, 1, 8960), (8960, 8960, 1), 0); del buf82  # reuse
            # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_37], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf84, buf83, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg71_1, (1536, 8960), (8960, 1), 'input')
            buf85 = reinterpret_tensor(buf81, (s16, 1536), (1536, 1), 0); del buf81  # reuse
            # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_37, down_proj_3], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf84, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg71_1, (8960, 1536), (1, 8960), 0), out=buf85)
            del arg71_1
            assert_size_stride_grouped((arg73_1, arg72_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf87 = reinterpret_tensor(buf78, (s16, 1, 1536), (1536, 1536, 1), 0); del buf78  # reuse
            # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_31, pow_9, variance_8, rsqrt_8, hidden_states_33, hidden_states_34], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf79, buf85, arg73_1, arg72_1.item(), buf87, s16, 1536, stream=raw_stream0)
            del arg72_1
            del arg73_1
            assert_size_stride_grouped((arg75_1, arg74_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf88 = buf63; del buf63  # reuse
            # Topologically Sorted Source Nodes: [linear_28], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg75_1, reinterpret_tensor(buf87, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg74_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf88)
            del arg74_1
            del arg75_1
            assert_size_stride_grouped((arg77_1, arg76_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf89 = buf69; del buf69  # reuse
            # Topologically Sorted Source Nodes: [linear_29], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg77_1, reinterpret_tensor(buf87, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg76_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf89)
            del arg76_1
            del arg77_1
            assert_size_stride(arg80_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg80_1 = copy_if_misaligned(arg80_1)
            buf90 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_7, sin_7, linear_29, view_13, key_states_4, mul_42, x2_9, neg_9, x1_9, cat_18, mul_43, k_embed_4, key_tensors_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg80_1, buf89, arg4_1, arg3_1, arg5_1.item(), buf90, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg80_1
            assert_size_stride_grouped((arg79_1, arg78_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf91 = buf89; del buf89  # reuse
            # Topologically Sorted Source Nodes: [linear_30], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg79_1, reinterpret_tensor(buf87, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg78_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf91)
            del arg78_1
            del arg79_1
            assert_size_stride(arg81_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg81_1 = copy_if_misaligned(arg81_1)
            buf92 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_30, view_14, value_states_4, value_tensors_4], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg81_1, buf91, buf92, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg81_1
            buf93 = reinterpret_tensor(buf87, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf87  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_28, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_17, sin_7, mul_41, q_embed_4, packed_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf88, arg4_1, arg3_1, arg5_1.item(), buf93, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_28, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_17, sin_7, mul_41, q_embed_4, packed_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf94 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf93, buf90, buf92, None, False, scale=0.08838834764831845)
            buf95 = buf94[0]
            assert_tensor_metadata(buf95, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf95, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf94
            buf99 = buf93; del buf93  # reuse
            # Topologically Sorted Source Nodes: [attn_output_16], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf95, buf99, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg82_1, (1536, 1536), (1536, 1), 'input')
            buf100 = reinterpret_tensor(buf95, (s16, 1536), (1536, 1), 0); del buf95  # reuse
            # Topologically Sorted Source Nodes: [attn_output_16, transpose_20, reshape_14, attn_output_19], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf99, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg82_1, (1536, 1536), (1, 1536), 0), out=buf100)
            del arg82_1
            assert_size_stride_grouped((arg84_1, arg83_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf102 = reinterpret_tensor(buf99, (s16, 1, 1536), (1536, 1536, 1), 0); del buf99  # reuse
            # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_31, attn_output_19, hidden_states_35, pow_10, variance_9, rsqrt_9, hidden_states_37, hidden_states_38], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf79, buf85, buf100, arg84_1, arg83_1.item(), buf102, s16, 1536, stream=raw_stream0)
            del arg83_1
            del arg84_1
            assert_size_stride(arg85_1, (8960, 1536), (1536, 1), 'input')
            buf103 = reinterpret_tensor(buf84, (s16, 8960), (8960, 1), 0); del buf84  # reuse
            # Topologically Sorted Source Nodes: [linear_32], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf102, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg85_1, (1536, 8960), (1, 1536), 0), out=buf103)
            del arg85_1
            assert_size_stride(arg86_1, (8960, 1536), (1536, 1), 'input')
            buf104 = buf83; del buf83  # reuse
            # Topologically Sorted Source Nodes: [linear_33], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf102, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg86_1, (1536, 8960), (1, 1536), 0), out=buf104)
            del arg86_1
            buf105 = reinterpret_tensor(buf103, (s16, 1, 8960), (8960, 8960, 1), 0); del buf103  # reuse
            # Topologically Sorted Source Nodes: [linear_32, silu_4, linear_33, mul_46], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf105, buf104, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg87_1, (1536, 8960), (8960, 1), 'input')
            buf106 = reinterpret_tensor(buf102, (s16, 1536), (1536, 1), 0); del buf102  # reuse
            # Topologically Sorted Source Nodes: [linear_32, silu_4, linear_33, mul_46, down_proj_4], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf105, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg87_1, (8960, 1536), (1, 8960), 0), out=buf106)
            del arg87_1
            assert_size_stride_grouped((arg89_1, arg88_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf108 = reinterpret_tensor(buf88, (s16, 1, 1536), (1536, 1536, 1), 0); del buf88  # reuse
            # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_31, attn_output_19, hidden_states_35, down_proj_4, hidden_states_39, pow_11, variance_10, rsqrt_10, hidden_states_41, hidden_states_42], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf79, buf85, buf100, buf106, arg89_1, arg88_1.item(), buf108, s16, 1536, stream=raw_stream0)
            del arg88_1
            del arg89_1
            assert_size_stride_grouped((arg91_1, arg90_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf109 = buf57; del buf57  # reuse
            # Topologically Sorted Source Nodes: [linear_35], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg91_1, reinterpret_tensor(buf108, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg90_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf109)
            del arg90_1
            del arg91_1
            assert_size_stride_grouped((arg93_1, arg92_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf110 = buf91; del buf91  # reuse
            # Topologically Sorted Source Nodes: [linear_36], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg93_1, reinterpret_tensor(buf108, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg92_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf110)
            del arg92_1
            del arg93_1
            assert_size_stride(arg96_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg96_1 = copy_if_misaligned(arg96_1)
            buf111 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_8, sin_8, linear_36, view_16, key_states_5, mul_51, x2_11, neg_11, x1_11, cat_22, mul_52, k_embed_5, key_tensors_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg96_1, buf110, arg4_1, arg3_1, arg5_1.item(), buf111, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg96_1
            assert_size_stride_grouped((arg95_1, arg94_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf112 = buf110; del buf110  # reuse
            # Topologically Sorted Source Nodes: [linear_37], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg95_1, reinterpret_tensor(buf108, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg94_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf112)
            del arg94_1
            del arg95_1
            assert_size_stride(arg97_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg97_1 = copy_if_misaligned(arg97_1)
            buf113 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_37, view_17, value_states_5, value_tensors_5], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg97_1, buf112, buf113, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg97_1
            buf114 = reinterpret_tensor(buf108, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf108  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_35, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_21, sin_8, mul_50, q_embed_5, packed_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf109, arg4_1, arg3_1, arg5_1.item(), buf114, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf109
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_35, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_21, sin_8, mul_50, q_embed_5, packed_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf115 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf114, buf111, buf113, None, False, scale=0.08838834764831845)
            buf116 = buf115[0]
            assert_tensor_metadata(buf116, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf116, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf115
            buf120 = buf114; del buf114  # reuse
            # Topologically Sorted Source Nodes: [attn_output_20], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf116, buf120, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg98_1, (1536, 1536), (1536, 1), 'input')
            buf121 = reinterpret_tensor(buf116, (s16, 1536), (1536, 1), 0); del buf116  # reuse
            # Topologically Sorted Source Nodes: [attn_output_20, transpose_24, reshape_17, attn_output_23], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf120, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg98_1, (1536, 1536), (1, 1536), 0), out=buf121)
            del arg98_1
            assert_size_stride_grouped((arg100_1, arg99_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf122 = buf79; del buf79  # reuse
            buf124 = reinterpret_tensor(buf120, (s16, 1, 1536), (1536, 1536, 1), 0); del buf120  # reuse
            # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_31, attn_output_19, hidden_states_35, down_proj_4, hidden_states_39, attn_output_23, hidden_states_43, pow_12, variance_11, rsqrt_11, hidden_states_45, hidden_states_46], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf122, buf85, buf100, buf106, buf121, arg100_1, arg99_1.item(), buf124, s16, 1536, stream=raw_stream0)
            del arg100_1
            del arg99_1
            del buf100
            assert_size_stride(arg101_1, (8960, 1536), (1536, 1), 'input')
            buf125 = reinterpret_tensor(buf105, (s16, 8960), (8960, 1), 0); del buf105  # reuse
            # Topologically Sorted Source Nodes: [pow_12, variance_11, rsqrt_11, hidden_states_45, hidden_states_46, linear_39], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf124, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg101_1, (1536, 8960), (1, 1536), 0), out=buf125)
            del arg101_1
            assert_size_stride(arg102_1, (8960, 1536), (1536, 1), 'input')
            buf126 = buf104; del buf104  # reuse
            # Topologically Sorted Source Nodes: [linear_40], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf124, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg102_1, (1536, 8960), (1, 1536), 0), out=buf126)
            del arg102_1
            buf127 = reinterpret_tensor(buf125, (s16, 1, 8960), (8960, 8960, 1), 0); del buf125  # reuse
            # Topologically Sorted Source Nodes: [linear_39, silu_5, linear_40, mul_55], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf127, buf126, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg103_1, (1536, 8960), (8960, 1), 'input')
            buf128 = reinterpret_tensor(buf124, (s16, 1536), (1536, 1), 0); del buf124  # reuse
            # Topologically Sorted Source Nodes: [linear_39, silu_5, linear_40, mul_55, down_proj_5], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf127, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg103_1, (8960, 1536), (1, 8960), 0), out=buf128)
            del arg103_1
            assert_size_stride_grouped((arg105_1, arg104_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf130 = reinterpret_tensor(buf85, (s16, 1, 1536), (1536, 1536, 1), 0); del buf85  # reuse
            # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_47, pow_13, variance_12, rsqrt_12, hidden_states_49, hidden_states_50], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf122, buf128, arg105_1, arg104_1.item(), buf130, s16, 1536, stream=raw_stream0)
            del arg104_1
            del arg105_1
            assert_size_stride_grouped((arg107_1, arg106_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf131 = buf121; del buf121  # reuse
            # Topologically Sorted Source Nodes: [linear_42], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg107_1, reinterpret_tensor(buf130, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg106_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf131)
            del arg106_1
            del arg107_1
            assert_size_stride_grouped((arg109_1, arg108_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf132 = buf112; del buf112  # reuse
            # Topologically Sorted Source Nodes: [linear_43], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg109_1, reinterpret_tensor(buf130, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg108_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf132)
            del arg108_1
            del arg109_1
            assert_size_stride(arg112_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg112_1 = copy_if_misaligned(arg112_1)
            buf133 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_9, sin_9, linear_43, view_19, key_states_6, mul_60, x2_13, neg_13, x1_13, cat_26, mul_61, k_embed_6, key_tensors_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg112_1, buf132, arg4_1, arg3_1, arg5_1.item(), buf133, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg112_1
            assert_size_stride_grouped((arg111_1, arg110_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf134 = buf132; del buf132  # reuse
            # Topologically Sorted Source Nodes: [linear_44], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg111_1, reinterpret_tensor(buf130, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg110_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf134)
            del arg110_1
            del arg111_1
            assert_size_stride(arg113_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg113_1 = copy_if_misaligned(arg113_1)
            buf135 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_44, view_20, value_states_6, value_tensors_6], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg113_1, buf134, buf135, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg113_1
            buf136 = reinterpret_tensor(buf130, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf130  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_25, sin_9, mul_59, q_embed_6, packed_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf131, arg4_1, arg3_1, arg5_1.item(), buf136, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_25, sin_9, mul_59, q_embed_6, packed_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf137 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf136, buf133, buf135, None, False, scale=0.08838834764831845)
            buf138 = buf137[0]
            assert_tensor_metadata(buf138, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf138, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf137
            buf142 = buf136; del buf136  # reuse
            # Topologically Sorted Source Nodes: [attn_output_24], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf138, buf142, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg114_1, (1536, 1536), (1536, 1), 'input')
            buf143 = reinterpret_tensor(buf138, (s16, 1536), (1536, 1), 0); del buf138  # reuse
            # Topologically Sorted Source Nodes: [attn_output_24, transpose_28, reshape_20, attn_output_27], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf142, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg114_1, (1536, 1536), (1, 1536), 0), out=buf143)
            del arg114_1
            assert_size_stride_grouped((arg116_1, arg115_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf145 = reinterpret_tensor(buf142, (s16, 1, 1536), (1536, 1536, 1), 0); del buf142  # reuse
            # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_47, attn_output_27, hidden_states_51, pow_14, variance_13, rsqrt_13, hidden_states_53, hidden_states_54], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf122, buf128, buf143, arg116_1, arg115_1.item(), buf145, s16, 1536, stream=raw_stream0)
            del arg115_1
            del arg116_1
            assert_size_stride(arg117_1, (8960, 1536), (1536, 1), 'input')
            buf146 = reinterpret_tensor(buf127, (s16, 8960), (8960, 1), 0); del buf127  # reuse
            # Topologically Sorted Source Nodes: [linear_46], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf145, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg117_1, (1536, 8960), (1, 1536), 0), out=buf146)
            del arg117_1
            assert_size_stride(arg118_1, (8960, 1536), (1536, 1), 'input')
            buf147 = buf126; del buf126  # reuse
            # Topologically Sorted Source Nodes: [linear_47], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf145, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg118_1, (1536, 8960), (1, 1536), 0), out=buf147)
            del arg118_1
            buf148 = reinterpret_tensor(buf146, (s16, 1, 8960), (8960, 8960, 1), 0); del buf146  # reuse
            # Topologically Sorted Source Nodes: [linear_46, silu_6, linear_47, mul_64], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf148, buf147, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg119_1, (1536, 8960), (8960, 1), 'input')
            buf149 = reinterpret_tensor(buf145, (s16, 1536), (1536, 1), 0); del buf145  # reuse
            # Topologically Sorted Source Nodes: [linear_46, silu_6, linear_47, mul_64, down_proj_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf148, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg119_1, (8960, 1536), (1, 8960), 0), out=buf149)
            del arg119_1
            assert_size_stride_grouped((arg121_1, arg120_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf151 = reinterpret_tensor(buf131, (s16, 1, 1536), (1536, 1536, 1), 0); del buf131  # reuse
            # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_47, attn_output_27, hidden_states_51, down_proj_6, hidden_states_55, pow_15, variance_14, rsqrt_14, hidden_states_57, hidden_states_58], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf122, buf128, buf143, buf149, arg121_1, arg120_1.item(), buf151, s16, 1536, stream=raw_stream0)
            del arg120_1
            del arg121_1
            assert_size_stride_grouped((arg123_1, arg122_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf152 = buf106; del buf106  # reuse
            # Topologically Sorted Source Nodes: [linear_49], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg123_1, reinterpret_tensor(buf151, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg122_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf152)
            del arg122_1
            del arg123_1
            assert_size_stride_grouped((arg125_1, arg124_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf153 = buf134; del buf134  # reuse
            # Topologically Sorted Source Nodes: [linear_50], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg125_1, reinterpret_tensor(buf151, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg124_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf153)
            del arg124_1
            del arg125_1
            assert_size_stride(arg128_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg128_1 = copy_if_misaligned(arg128_1)
            buf154 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_10, sin_10, linear_50, view_22, key_states_7, mul_69, x2_15, neg_15, x1_15, cat_30, mul_70, k_embed_7, key_tensors_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg128_1, buf153, arg4_1, arg3_1, arg5_1.item(), buf154, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg128_1
            assert_size_stride_grouped((arg127_1, arg126_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf155 = buf153; del buf153  # reuse
            # Topologically Sorted Source Nodes: [linear_51], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg127_1, reinterpret_tensor(buf151, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg126_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf155)
            del arg126_1
            del arg127_1
            assert_size_stride(arg129_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg129_1 = copy_if_misaligned(arg129_1)
            buf156 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_51, view_23, value_states_7, value_tensors_7], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg129_1, buf155, buf156, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg129_1
            buf157 = reinterpret_tensor(buf151, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf151  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_49, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_29, sin_10, mul_68, q_embed_7, packed_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf152, arg4_1, arg3_1, arg5_1.item(), buf157, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf152
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_49, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_29, sin_10, mul_68, q_embed_7, packed_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf158 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf157, buf154, buf156, None, False, scale=0.08838834764831845)
            buf159 = buf158[0]
            assert_tensor_metadata(buf159, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf159, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf158
            buf163 = buf157; del buf157  # reuse
            # Topologically Sorted Source Nodes: [attn_output_28], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf159, buf163, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg130_1, (1536, 1536), (1536, 1), 'input')
            buf164 = reinterpret_tensor(buf159, (s16, 1536), (1536, 1), 0); del buf159  # reuse
            # Topologically Sorted Source Nodes: [attn_output_28, transpose_32, reshape_23, attn_output_31], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf163, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg130_1, (1536, 1536), (1, 1536), 0), out=buf164)
            del arg130_1
            assert_size_stride_grouped((arg132_1, arg131_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf165 = buf122; del buf122  # reuse
            buf167 = reinterpret_tensor(buf163, (s16, 1, 1536), (1536, 1536, 1), 0); del buf163  # reuse
            # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_47, attn_output_27, hidden_states_51, down_proj_6, hidden_states_55, attn_output_31, hidden_states_59, pow_16, variance_15, rsqrt_15, hidden_states_61, hidden_states_62], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf165, buf128, buf143, buf149, buf164, arg132_1, arg131_1.item(), buf167, s16, 1536, stream=raw_stream0)
            del arg131_1
            del arg132_1
            del buf128
            assert_size_stride(arg133_1, (8960, 1536), (1536, 1), 'input')
            buf168 = reinterpret_tensor(buf148, (s16, 8960), (8960, 1), 0); del buf148  # reuse
            # Topologically Sorted Source Nodes: [pow_16, variance_15, rsqrt_15, hidden_states_61, hidden_states_62, linear_53], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf167, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg133_1, (1536, 8960), (1, 1536), 0), out=buf168)
            del arg133_1
            assert_size_stride(arg134_1, (8960, 1536), (1536, 1), 'input')
            buf169 = buf147; del buf147  # reuse
            # Topologically Sorted Source Nodes: [linear_54], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf167, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg134_1, (1536, 8960), (1, 1536), 0), out=buf169)
            del arg134_1
            buf170 = reinterpret_tensor(buf168, (s16, 1, 8960), (8960, 8960, 1), 0); del buf168  # reuse
            # Topologically Sorted Source Nodes: [linear_53, silu_7, linear_54, mul_73], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf170, buf169, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg135_1, (1536, 8960), (8960, 1), 'input')
            buf171 = reinterpret_tensor(buf167, (s16, 1536), (1536, 1), 0); del buf167  # reuse
            # Topologically Sorted Source Nodes: [linear_53, silu_7, linear_54, mul_73, down_proj_7], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf170, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg135_1, (8960, 1536), (1, 8960), 0), out=buf171)
            del arg135_1
            assert_size_stride_grouped((arg137_1, arg136_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf173 = reinterpret_tensor(buf164, (s16, 1, 1536), (1536, 1536, 1), 0); del buf164  # reuse
            # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_63, pow_17, variance_16, rsqrt_16, hidden_states_65, hidden_states_66], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf165, buf171, arg137_1, arg136_1.item(), buf173, s16, 1536, stream=raw_stream0)
            del arg136_1
            del arg137_1
            assert_size_stride_grouped((arg139_1, arg138_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf174 = buf149; del buf149  # reuse
            # Topologically Sorted Source Nodes: [linear_56], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg139_1, reinterpret_tensor(buf173, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg138_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf174)
            del arg138_1
            del arg139_1
            assert_size_stride_grouped((arg141_1, arg140_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf175 = buf155; del buf155  # reuse
            # Topologically Sorted Source Nodes: [linear_57], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg141_1, reinterpret_tensor(buf173, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg140_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf175)
            del arg140_1
            del arg141_1
            assert_size_stride(arg144_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg144_1 = copy_if_misaligned(arg144_1)
            buf176 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_11, sin_11, linear_57, view_25, key_states_8, mul_78, x2_17, neg_17, x1_17, cat_34, mul_79, k_embed_8, key_tensors_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg144_1, buf175, arg4_1, arg3_1, arg5_1.item(), buf176, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg144_1
            assert_size_stride_grouped((arg143_1, arg142_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf177 = buf175; del buf175  # reuse
            # Topologically Sorted Source Nodes: [linear_58], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg143_1, reinterpret_tensor(buf173, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg142_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf177)
            del arg142_1
            del arg143_1
            assert_size_stride(arg145_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg145_1 = copy_if_misaligned(arg145_1)
            buf178 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_58, view_26, value_states_8, value_tensors_8], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg145_1, buf177, buf178, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg145_1
            buf179 = reinterpret_tensor(buf173, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf173  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_56, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_33, sin_11, mul_77, q_embed_8, packed_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf174, arg4_1, arg3_1, arg5_1.item(), buf179, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_56, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_33, sin_11, mul_77, q_embed_8, packed_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf180 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf179, buf176, buf178, None, False, scale=0.08838834764831845)
            buf181 = buf180[0]
            assert_tensor_metadata(buf181, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf181, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf180
            buf185 = buf179; del buf179  # reuse
            # Topologically Sorted Source Nodes: [attn_output_32], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf181, buf185, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg146_1, (1536, 1536), (1536, 1), 'input')
            buf186 = reinterpret_tensor(buf181, (s16, 1536), (1536, 1), 0); del buf181  # reuse
            # Topologically Sorted Source Nodes: [attn_output_32, transpose_36, reshape_26, attn_output_35], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf185, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg146_1, (1536, 1536), (1, 1536), 0), out=buf186)
            del arg146_1
            assert_size_stride_grouped((arg148_1, arg147_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf188 = reinterpret_tensor(buf185, (s16, 1, 1536), (1536, 1536, 1), 0); del buf185  # reuse
            # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_63, attn_output_35, hidden_states_67, pow_18, variance_17, rsqrt_17, hidden_states_69, hidden_states_70], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf165, buf171, buf186, arg148_1, arg147_1.item(), buf188, s16, 1536, stream=raw_stream0)
            del arg147_1
            del arg148_1
            assert_size_stride(arg149_1, (8960, 1536), (1536, 1), 'input')
            buf189 = reinterpret_tensor(buf170, (s16, 8960), (8960, 1), 0); del buf170  # reuse
            # Topologically Sorted Source Nodes: [linear_60], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf188, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg149_1, (1536, 8960), (1, 1536), 0), out=buf189)
            del arg149_1
            assert_size_stride(arg150_1, (8960, 1536), (1536, 1), 'input')
            buf190 = buf169; del buf169  # reuse
            # Topologically Sorted Source Nodes: [linear_61], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf188, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg150_1, (1536, 8960), (1, 1536), 0), out=buf190)
            del arg150_1
            buf191 = reinterpret_tensor(buf189, (s16, 1, 8960), (8960, 8960, 1), 0); del buf189  # reuse
            # Topologically Sorted Source Nodes: [linear_60, silu_8, linear_61, mul_82], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf191, buf190, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg151_1, (1536, 8960), (8960, 1), 'input')
            buf192 = reinterpret_tensor(buf188, (s16, 1536), (1536, 1), 0); del buf188  # reuse
            # Topologically Sorted Source Nodes: [linear_60, silu_8, linear_61, mul_82, down_proj_8], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf191, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg151_1, (8960, 1536), (1, 8960), 0), out=buf192)
            del arg151_1
            assert_size_stride_grouped((arg153_1, arg152_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf194 = reinterpret_tensor(buf174, (s16, 1, 1536), (1536, 1536, 1), 0); del buf174  # reuse
            # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_63, attn_output_35, hidden_states_67, down_proj_8, hidden_states_71, pow_19, variance_18, rsqrt_18, hidden_states_73, hidden_states_74], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf165, buf171, buf186, buf192, arg153_1, arg152_1.item(), buf194, s16, 1536, stream=raw_stream0)
            del arg152_1
            del arg153_1
            assert_size_stride_grouped((arg155_1, arg154_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf195 = buf143; del buf143  # reuse
            # Topologically Sorted Source Nodes: [linear_63], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg155_1, reinterpret_tensor(buf194, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg154_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf195)
            del arg154_1
            del arg155_1
            assert_size_stride_grouped((arg157_1, arg156_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf196 = buf177; del buf177  # reuse
            # Topologically Sorted Source Nodes: [linear_64], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg157_1, reinterpret_tensor(buf194, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg156_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf196)
            del arg156_1
            del arg157_1
            assert_size_stride(arg160_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg160_1 = copy_if_misaligned(arg160_1)
            buf197 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_12, sin_12, linear_64, view_28, key_states_9, mul_87, x2_19, neg_19, x1_19, cat_38, mul_88, k_embed_9, key_tensors_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg160_1, buf196, arg4_1, arg3_1, arg5_1.item(), buf197, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg160_1
            assert_size_stride_grouped((arg159_1, arg158_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf198 = buf196; del buf196  # reuse
            # Topologically Sorted Source Nodes: [linear_65], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg159_1, reinterpret_tensor(buf194, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg158_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf198)
            del arg158_1
            del arg159_1
            assert_size_stride(arg161_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg161_1 = copy_if_misaligned(arg161_1)
            buf199 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_65, view_29, value_states_9, value_tensors_9], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg161_1, buf198, buf199, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg161_1
            buf200 = reinterpret_tensor(buf194, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf194  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_63, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_37, sin_12, mul_86, q_embed_9, packed_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf195, arg4_1, arg3_1, arg5_1.item(), buf200, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf195
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_63, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_37, sin_12, mul_86, q_embed_9, packed_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf201 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf200, buf197, buf199, None, False, scale=0.08838834764831845)
            buf202 = buf201[0]
            assert_tensor_metadata(buf202, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf202, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf201
            buf206 = buf200; del buf200  # reuse
            # Topologically Sorted Source Nodes: [attn_output_36], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf202, buf206, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg162_1, (1536, 1536), (1536, 1), 'input')
            buf207 = reinterpret_tensor(buf202, (s16, 1536), (1536, 1), 0); del buf202  # reuse
            # Topologically Sorted Source Nodes: [attn_output_36, transpose_40, reshape_29, attn_output_39], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf206, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg162_1, (1536, 1536), (1, 1536), 0), out=buf207)
            del arg162_1
            assert_size_stride_grouped((arg164_1, arg163_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf208 = buf165; del buf165  # reuse
            buf210 = reinterpret_tensor(buf206, (s16, 1, 1536), (1536, 1536, 1), 0); del buf206  # reuse
            # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_63, attn_output_35, hidden_states_67, down_proj_8, hidden_states_71, attn_output_39, hidden_states_75, pow_20, variance_19, rsqrt_19, hidden_states_77, hidden_states_78], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf208, buf171, buf186, buf192, buf207, arg164_1, arg163_1.item(), buf210, s16, 1536, stream=raw_stream0)
            del arg163_1
            del arg164_1
            del buf171
            assert_size_stride(arg165_1, (8960, 1536), (1536, 1), 'input')
            buf211 = reinterpret_tensor(buf191, (s16, 8960), (8960, 1), 0); del buf191  # reuse
            # Topologically Sorted Source Nodes: [pow_20, variance_19, rsqrt_19, hidden_states_77, hidden_states_78, linear_67], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf210, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg165_1, (1536, 8960), (1, 1536), 0), out=buf211)
            del arg165_1
            assert_size_stride(arg166_1, (8960, 1536), (1536, 1), 'input')
            buf212 = buf190; del buf190  # reuse
            # Topologically Sorted Source Nodes: [linear_68], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf210, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg166_1, (1536, 8960), (1, 1536), 0), out=buf212)
            del arg166_1
            buf213 = reinterpret_tensor(buf211, (s16, 1, 8960), (8960, 8960, 1), 0); del buf211  # reuse
            # Topologically Sorted Source Nodes: [linear_67, silu_9, linear_68, mul_91], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf213, buf212, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg167_1, (1536, 8960), (8960, 1), 'input')
            buf214 = reinterpret_tensor(buf210, (s16, 1536), (1536, 1), 0); del buf210  # reuse
            # Topologically Sorted Source Nodes: [linear_67, silu_9, linear_68, mul_91, down_proj_9], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf213, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg167_1, (8960, 1536), (1, 8960), 0), out=buf214)
            del arg167_1
            assert_size_stride_grouped((arg169_1, arg168_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf216 = reinterpret_tensor(buf207, (s16, 1, 1536), (1536, 1536, 1), 0); del buf207  # reuse
            # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_79, pow_21, variance_20, rsqrt_20, hidden_states_81, hidden_states_82], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf208, buf214, arg169_1, arg168_1.item(), buf216, s16, 1536, stream=raw_stream0)
            del arg168_1
            del arg169_1
            assert_size_stride_grouped((arg171_1, arg170_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf217 = buf192; del buf192  # reuse
            # Topologically Sorted Source Nodes: [linear_70], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg171_1, reinterpret_tensor(buf216, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg170_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf217)
            del arg170_1
            del arg171_1
            assert_size_stride_grouped((arg173_1, arg172_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf218 = buf198; del buf198  # reuse
            # Topologically Sorted Source Nodes: [linear_71], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg173_1, reinterpret_tensor(buf216, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg172_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf218)
            del arg172_1
            del arg173_1
            assert_size_stride(arg176_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg176_1 = copy_if_misaligned(arg176_1)
            buf219 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_13, sin_13, linear_71, view_31, key_states_10, mul_96, x2_21, neg_21, x1_21, cat_42, mul_97, k_embed_10, key_tensors_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg176_1, buf218, arg4_1, arg3_1, arg5_1.item(), buf219, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg176_1
            assert_size_stride_grouped((arg175_1, arg174_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf220 = buf218; del buf218  # reuse
            # Topologically Sorted Source Nodes: [linear_72], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg175_1, reinterpret_tensor(buf216, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg174_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf220)
            del arg174_1
            del arg175_1
            assert_size_stride(arg177_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg177_1 = copy_if_misaligned(arg177_1)
            buf221 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_72, view_32, value_states_10, value_tensors_10], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg177_1, buf220, buf221, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg177_1
            buf222 = reinterpret_tensor(buf216, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf216  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_70, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_41, sin_13, mul_95, q_embed_10, packed_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf217, arg4_1, arg3_1, arg5_1.item(), buf222, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_70, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_41, sin_13, mul_95, q_embed_10, packed_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf223 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf222, buf219, buf221, None, False, scale=0.08838834764831845)
            buf224 = buf223[0]
            assert_tensor_metadata(buf224, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf224, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf223
            buf228 = buf222; del buf222  # reuse
            # Topologically Sorted Source Nodes: [attn_output_40], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf224, buf228, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg178_1, (1536, 1536), (1536, 1), 'input')
            buf229 = reinterpret_tensor(buf224, (s16, 1536), (1536, 1), 0); del buf224  # reuse
            # Topologically Sorted Source Nodes: [attn_output_40, transpose_44, reshape_32, attn_output_43], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf228, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg178_1, (1536, 1536), (1, 1536), 0), out=buf229)
            del arg178_1
            assert_size_stride_grouped((arg180_1, arg179_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf231 = reinterpret_tensor(buf228, (s16, 1, 1536), (1536, 1536, 1), 0); del buf228  # reuse
            # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_79, attn_output_43, hidden_states_83, pow_22, variance_21, rsqrt_21, hidden_states_85, hidden_states_86], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf208, buf214, buf229, arg180_1, arg179_1.item(), buf231, s16, 1536, stream=raw_stream0)
            del arg179_1
            del arg180_1
            assert_size_stride(arg181_1, (8960, 1536), (1536, 1), 'input')
            buf232 = reinterpret_tensor(buf213, (s16, 8960), (8960, 1), 0); del buf213  # reuse
            # Topologically Sorted Source Nodes: [linear_74], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf231, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg181_1, (1536, 8960), (1, 1536), 0), out=buf232)
            del arg181_1
            assert_size_stride(arg182_1, (8960, 1536), (1536, 1), 'input')
            buf233 = buf212; del buf212  # reuse
            # Topologically Sorted Source Nodes: [linear_75], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf231, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg182_1, (1536, 8960), (1, 1536), 0), out=buf233)
            del arg182_1
            buf234 = reinterpret_tensor(buf232, (s16, 1, 8960), (8960, 8960, 1), 0); del buf232  # reuse
            # Topologically Sorted Source Nodes: [linear_74, silu_10, linear_75, mul_100], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf234, buf233, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg183_1, (1536, 8960), (8960, 1), 'input')
            buf235 = reinterpret_tensor(buf231, (s16, 1536), (1536, 1), 0); del buf231  # reuse
            # Topologically Sorted Source Nodes: [linear_74, silu_10, linear_75, mul_100, down_proj_10], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf234, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg183_1, (8960, 1536), (1, 8960), 0), out=buf235)
            del arg183_1
            assert_size_stride_grouped((arg185_1, arg184_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf237 = reinterpret_tensor(buf217, (s16, 1, 1536), (1536, 1536, 1), 0); del buf217  # reuse
            # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_79, attn_output_43, hidden_states_83, down_proj_10, hidden_states_87, pow_23, variance_22, rsqrt_22, hidden_states_89, hidden_states_90], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf208, buf214, buf229, buf235, arg185_1, arg184_1.item(), buf237, s16, 1536, stream=raw_stream0)
            del arg184_1
            del arg185_1
            assert_size_stride_grouped((arg187_1, arg186_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf238 = buf186; del buf186  # reuse
            # Topologically Sorted Source Nodes: [linear_77], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg187_1, reinterpret_tensor(buf237, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg186_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf238)
            del arg186_1
            del arg187_1
            assert_size_stride_grouped((arg189_1, arg188_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf239 = buf220; del buf220  # reuse
            # Topologically Sorted Source Nodes: [linear_78], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg189_1, reinterpret_tensor(buf237, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg188_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf239)
            del arg188_1
            del arg189_1
            assert_size_stride(arg192_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg192_1 = copy_if_misaligned(arg192_1)
            buf240 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_14, sin_14, linear_78, view_34, key_states_11, mul_105, x2_23, neg_23, x1_23, cat_46, mul_106, k_embed_11, key_tensors_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg192_1, buf239, arg4_1, arg3_1, arg5_1.item(), buf240, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg192_1
            assert_size_stride_grouped((arg191_1, arg190_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf241 = buf239; del buf239  # reuse
            # Topologically Sorted Source Nodes: [linear_79], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg191_1, reinterpret_tensor(buf237, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg190_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf241)
            del arg190_1
            del arg191_1
            assert_size_stride(arg193_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg193_1 = copy_if_misaligned(arg193_1)
            buf242 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_79, view_35, value_states_11, value_tensors_11], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg193_1, buf241, buf242, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg193_1
            buf243 = reinterpret_tensor(buf237, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf237  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_77, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_45, sin_14, mul_104, q_embed_11, packed_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf238, arg4_1, arg3_1, arg5_1.item(), buf243, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf238
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_77, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_45, sin_14, mul_104, q_embed_11, packed_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf244 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf243, buf240, buf242, None, False, scale=0.08838834764831845)
            buf245 = buf244[0]
            assert_tensor_metadata(buf245, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf245, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf244
            buf249 = buf243; del buf243  # reuse
            # Topologically Sorted Source Nodes: [attn_output_44], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf245, buf249, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg194_1, (1536, 1536), (1536, 1), 'input')
            buf250 = reinterpret_tensor(buf245, (s16, 1536), (1536, 1), 0); del buf245  # reuse
            # Topologically Sorted Source Nodes: [attn_output_44, transpose_48, reshape_35, attn_output_47], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf249, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg194_1, (1536, 1536), (1, 1536), 0), out=buf250)
            del arg194_1
            assert_size_stride_grouped((arg196_1, arg195_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf251 = buf208; del buf208  # reuse
            buf253 = reinterpret_tensor(buf249, (s16, 1, 1536), (1536, 1536, 1), 0); del buf249  # reuse
            # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_79, attn_output_43, hidden_states_83, down_proj_10, hidden_states_87, attn_output_47, hidden_states_91, pow_24, variance_23, rsqrt_23, hidden_states_93, hidden_states_94], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf251, buf214, buf229, buf235, buf250, arg196_1, arg195_1.item(), buf253, s16, 1536, stream=raw_stream0)
            del arg195_1
            del arg196_1
            del buf214
            assert_size_stride(arg197_1, (8960, 1536), (1536, 1), 'input')
            buf254 = reinterpret_tensor(buf234, (s16, 8960), (8960, 1), 0); del buf234  # reuse
            # Topologically Sorted Source Nodes: [pow_24, variance_23, rsqrt_23, hidden_states_93, hidden_states_94, linear_81], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf253, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg197_1, (1536, 8960), (1, 1536), 0), out=buf254)
            del arg197_1
            assert_size_stride(arg198_1, (8960, 1536), (1536, 1), 'input')
            buf255 = buf233; del buf233  # reuse
            # Topologically Sorted Source Nodes: [linear_82], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf253, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg198_1, (1536, 8960), (1, 1536), 0), out=buf255)
            del arg198_1
            buf256 = reinterpret_tensor(buf254, (s16, 1, 8960), (8960, 8960, 1), 0); del buf254  # reuse
            # Topologically Sorted Source Nodes: [linear_81, silu_11, linear_82, mul_109], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf256, buf255, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg199_1, (1536, 8960), (8960, 1), 'input')
            buf257 = reinterpret_tensor(buf253, (s16, 1536), (1536, 1), 0); del buf253  # reuse
            # Topologically Sorted Source Nodes: [linear_81, silu_11, linear_82, mul_109, down_proj_11], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf256, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg199_1, (8960, 1536), (1, 8960), 0), out=buf257)
            del arg199_1
            assert_size_stride_grouped((arg201_1, arg200_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf259 = reinterpret_tensor(buf250, (s16, 1, 1536), (1536, 1536, 1), 0); del buf250  # reuse
            # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_95, pow_25, variance_24, rsqrt_24, hidden_states_97, hidden_states_98], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf251, buf257, arg201_1, arg200_1.item(), buf259, s16, 1536, stream=raw_stream0)
            del arg200_1
            del arg201_1
            assert_size_stride_grouped((arg203_1, arg202_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf260 = buf235; del buf235  # reuse
            # Topologically Sorted Source Nodes: [linear_84], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg203_1, reinterpret_tensor(buf259, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg202_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf260)
            del arg202_1
            del arg203_1
            assert_size_stride_grouped((arg205_1, arg204_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf261 = buf241; del buf241  # reuse
            # Topologically Sorted Source Nodes: [linear_85], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg205_1, reinterpret_tensor(buf259, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg204_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf261)
            del arg204_1
            del arg205_1
            assert_size_stride(arg208_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg208_1 = copy_if_misaligned(arg208_1)
            buf262 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_15, sin_15, linear_85, view_37, key_states_12, mul_114, x2_25, neg_25, x1_25, cat_50, mul_115, k_embed_12, key_tensors_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg208_1, buf261, arg4_1, arg3_1, arg5_1.item(), buf262, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg208_1
            assert_size_stride_grouped((arg207_1, arg206_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf263 = buf261; del buf261  # reuse
            # Topologically Sorted Source Nodes: [linear_86], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg207_1, reinterpret_tensor(buf259, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg206_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf263)
            del arg206_1
            del arg207_1
            assert_size_stride(arg209_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg209_1 = copy_if_misaligned(arg209_1)
            buf264 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_86, view_38, value_states_12, value_tensors_12], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg209_1, buf263, buf264, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg209_1
            buf265 = reinterpret_tensor(buf259, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf259  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_49, sin_15, mul_113, q_embed_12, packed_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf260, arg4_1, arg3_1, arg5_1.item(), buf265, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_49, sin_15, mul_113, q_embed_12, packed_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf266 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf265, buf262, buf264, None, False, scale=0.08838834764831845)
            buf267 = buf266[0]
            assert_tensor_metadata(buf267, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf267, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf266
            buf271 = buf265; del buf265  # reuse
            # Topologically Sorted Source Nodes: [attn_output_48], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf267, buf271, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg210_1, (1536, 1536), (1536, 1), 'input')
            buf272 = reinterpret_tensor(buf267, (s16, 1536), (1536, 1), 0); del buf267  # reuse
            # Topologically Sorted Source Nodes: [attn_output_48, transpose_52, reshape_38, attn_output_51], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf271, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg210_1, (1536, 1536), (1, 1536), 0), out=buf272)
            del arg210_1
            assert_size_stride_grouped((arg212_1, arg211_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf274 = reinterpret_tensor(buf271, (s16, 1, 1536), (1536, 1536, 1), 0); del buf271  # reuse
            # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_95, attn_output_51, hidden_states_99, pow_26, variance_25, rsqrt_25, hidden_states_101, hidden_states_102], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf251, buf257, buf272, arg212_1, arg211_1.item(), buf274, s16, 1536, stream=raw_stream0)
            del arg211_1
            del arg212_1
            assert_size_stride(arg213_1, (8960, 1536), (1536, 1), 'input')
            buf275 = reinterpret_tensor(buf256, (s16, 8960), (8960, 1), 0); del buf256  # reuse
            # Topologically Sorted Source Nodes: [linear_88], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf274, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg213_1, (1536, 8960), (1, 1536), 0), out=buf275)
            del arg213_1
            assert_size_stride(arg214_1, (8960, 1536), (1536, 1), 'input')
            buf276 = buf255; del buf255  # reuse
            # Topologically Sorted Source Nodes: [linear_89], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf274, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg214_1, (1536, 8960), (1, 1536), 0), out=buf276)
            del arg214_1
            buf277 = reinterpret_tensor(buf275, (s16, 1, 8960), (8960, 8960, 1), 0); del buf275  # reuse
            # Topologically Sorted Source Nodes: [linear_88, silu_12, linear_89, mul_118], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf277, buf276, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg215_1, (1536, 8960), (8960, 1), 'input')
            buf278 = reinterpret_tensor(buf274, (s16, 1536), (1536, 1), 0); del buf274  # reuse
            # Topologically Sorted Source Nodes: [linear_88, silu_12, linear_89, mul_118, down_proj_12], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf277, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg215_1, (8960, 1536), (1, 8960), 0), out=buf278)
            del arg215_1
            assert_size_stride_grouped((arg217_1, arg216_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf280 = reinterpret_tensor(buf260, (s16, 1, 1536), (1536, 1536, 1), 0); del buf260  # reuse
            # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_95, attn_output_51, hidden_states_99, down_proj_12, hidden_states_103, pow_27, variance_26, rsqrt_26, hidden_states_105, hidden_states_106], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf251, buf257, buf272, buf278, arg217_1, arg216_1.item(), buf280, s16, 1536, stream=raw_stream0)
            del arg216_1
            del arg217_1
            assert_size_stride_grouped((arg219_1, arg218_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf281 = buf229; del buf229  # reuse
            # Topologically Sorted Source Nodes: [linear_91], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg219_1, reinterpret_tensor(buf280, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg218_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf281)
            del arg218_1
            del arg219_1
            assert_size_stride_grouped((arg221_1, arg220_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf282 = buf263; del buf263  # reuse
            # Topologically Sorted Source Nodes: [linear_92], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg221_1, reinterpret_tensor(buf280, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg220_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf282)
            del arg220_1
            del arg221_1
            assert_size_stride(arg224_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg224_1 = copy_if_misaligned(arg224_1)
            buf283 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_16, sin_16, linear_92, view_40, key_states_13, mul_123, x2_27, neg_27, x1_27, cat_54, mul_124, k_embed_13, key_tensors_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg224_1, buf282, arg4_1, arg3_1, arg5_1.item(), buf283, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg224_1
            assert_size_stride_grouped((arg223_1, arg222_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf284 = buf282; del buf282  # reuse
            # Topologically Sorted Source Nodes: [linear_93], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg223_1, reinterpret_tensor(buf280, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg222_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf284)
            del arg222_1
            del arg223_1
            assert_size_stride(arg225_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg225_1 = copy_if_misaligned(arg225_1)
            buf285 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_93, view_41, value_states_13, value_tensors_13], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg225_1, buf284, buf285, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg225_1
            buf286 = reinterpret_tensor(buf280, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf280  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_91, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_53, sin_16, mul_122, q_embed_13, packed_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf281, arg4_1, arg3_1, arg5_1.item(), buf286, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf281
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_91, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_53, sin_16, mul_122, q_embed_13, packed_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf287 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf286, buf283, buf285, None, False, scale=0.08838834764831845)
            buf288 = buf287[0]
            assert_tensor_metadata(buf288, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf288, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf287
            buf292 = buf286; del buf286  # reuse
            # Topologically Sorted Source Nodes: [attn_output_52], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf288, buf292, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg226_1, (1536, 1536), (1536, 1), 'input')
            buf293 = reinterpret_tensor(buf288, (s16, 1536), (1536, 1), 0); del buf288  # reuse
            # Topologically Sorted Source Nodes: [attn_output_52, transpose_56, reshape_41, attn_output_55], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf292, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg226_1, (1536, 1536), (1, 1536), 0), out=buf293)
            del arg226_1
            assert_size_stride_grouped((arg228_1, arg227_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf294 = buf251; del buf251  # reuse
            buf296 = reinterpret_tensor(buf292, (s16, 1, 1536), (1536, 1536, 1), 0); del buf292  # reuse
            # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_95, attn_output_51, hidden_states_99, down_proj_12, hidden_states_103, attn_output_55, hidden_states_107, pow_28, variance_27, rsqrt_27, hidden_states_109, hidden_states_110], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf294, buf257, buf272, buf278, buf293, arg228_1, arg227_1.item(), buf296, s16, 1536, stream=raw_stream0)
            del arg227_1
            del arg228_1
            del buf257
            assert_size_stride(arg229_1, (8960, 1536), (1536, 1), 'input')
            buf297 = reinterpret_tensor(buf277, (s16, 8960), (8960, 1), 0); del buf277  # reuse
            # Topologically Sorted Source Nodes: [pow_28, variance_27, rsqrt_27, hidden_states_109, hidden_states_110, linear_95], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf296, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg229_1, (1536, 8960), (1, 1536), 0), out=buf297)
            del arg229_1
            assert_size_stride(arg230_1, (8960, 1536), (1536, 1), 'input')
            buf298 = buf276; del buf276  # reuse
            # Topologically Sorted Source Nodes: [linear_96], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf296, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg230_1, (1536, 8960), (1, 1536), 0), out=buf298)
            del arg230_1
            buf299 = reinterpret_tensor(buf297, (s16, 1, 8960), (8960, 8960, 1), 0); del buf297  # reuse
            # Topologically Sorted Source Nodes: [linear_95, silu_13, linear_96, mul_127], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf299, buf298, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg231_1, (1536, 8960), (8960, 1), 'input')
            buf300 = reinterpret_tensor(buf296, (s16, 1536), (1536, 1), 0); del buf296  # reuse
            # Topologically Sorted Source Nodes: [linear_95, silu_13, linear_96, mul_127, down_proj_13], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf299, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg231_1, (8960, 1536), (1, 8960), 0), out=buf300)
            del arg231_1
            assert_size_stride_grouped((arg233_1, arg232_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf302 = reinterpret_tensor(buf293, (s16, 1, 1536), (1536, 1536, 1), 0); del buf293  # reuse
            # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, pow_29, variance_28, rsqrt_28, hidden_states_113, hidden_states_114], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf294, buf300, arg233_1, arg232_1.item(), buf302, s16, 1536, stream=raw_stream0)
            del arg232_1
            del arg233_1
            assert_size_stride_grouped((arg235_1, arg234_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf303 = buf278; del buf278  # reuse
            # Topologically Sorted Source Nodes: [linear_98], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg235_1, reinterpret_tensor(buf302, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg234_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf303)
            del arg234_1
            del arg235_1
            assert_size_stride_grouped((arg237_1, arg236_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf304 = buf284; del buf284  # reuse
            # Topologically Sorted Source Nodes: [linear_99], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg237_1, reinterpret_tensor(buf302, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg236_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf304)
            del arg236_1
            del arg237_1
            assert_size_stride(arg240_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg240_1 = copy_if_misaligned(arg240_1)
            buf305 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_17, sin_17, linear_99, view_43, key_states_14, mul_132, x2_29, neg_29, x1_29, cat_58, mul_133, k_embed_14, key_tensors_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg240_1, buf304, arg4_1, arg3_1, arg5_1.item(), buf305, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg240_1
            assert_size_stride_grouped((arg239_1, arg238_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf306 = buf304; del buf304  # reuse
            # Topologically Sorted Source Nodes: [linear_100], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg239_1, reinterpret_tensor(buf302, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg238_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf306)
            del arg238_1
            del arg239_1
            assert_size_stride(arg241_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg241_1 = copy_if_misaligned(arg241_1)
            buf307 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_100, view_44, value_states_14, value_tensors_14], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg241_1, buf306, buf307, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg241_1
            buf308 = reinterpret_tensor(buf302, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf302  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_98, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_57, sin_17, mul_131, q_embed_14, packed_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf303, arg4_1, arg3_1, arg5_1.item(), buf308, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_98, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_57, sin_17, mul_131, q_embed_14, packed_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf309 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf308, buf305, buf307, None, False, scale=0.08838834764831845)
            buf310 = buf309[0]
            assert_tensor_metadata(buf310, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf310, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf309
            buf314 = buf308; del buf308  # reuse
            # Topologically Sorted Source Nodes: [attn_output_56], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf310, buf314, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg242_1, (1536, 1536), (1536, 1), 'input')
            buf315 = reinterpret_tensor(buf310, (s16, 1536), (1536, 1), 0); del buf310  # reuse
            # Topologically Sorted Source Nodes: [attn_output_56, transpose_60, reshape_44, attn_output_59], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf314, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg242_1, (1536, 1536), (1, 1536), 0), out=buf315)
            del arg242_1
            assert_size_stride_grouped((arg244_1, arg243_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf317 = reinterpret_tensor(buf314, (s16, 1, 1536), (1536, 1536, 1), 0); del buf314  # reuse
            # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, attn_output_59, hidden_states_115, pow_30, variance_29, rsqrt_29, hidden_states_117, hidden_states_118], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf294, buf300, buf315, arg244_1, arg243_1.item(), buf317, s16, 1536, stream=raw_stream0)
            del arg243_1
            del arg244_1
            assert_size_stride(arg245_1, (8960, 1536), (1536, 1), 'input')
            buf318 = reinterpret_tensor(buf299, (s16, 8960), (8960, 1), 0); del buf299  # reuse
            # Topologically Sorted Source Nodes: [linear_102], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf317, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg245_1, (1536, 8960), (1, 1536), 0), out=buf318)
            del arg245_1
            assert_size_stride(arg246_1, (8960, 1536), (1536, 1), 'input')
            buf319 = buf298; del buf298  # reuse
            # Topologically Sorted Source Nodes: [linear_103], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf317, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg246_1, (1536, 8960), (1, 1536), 0), out=buf319)
            del arg246_1
            buf320 = reinterpret_tensor(buf318, (s16, 1, 8960), (8960, 8960, 1), 0); del buf318  # reuse
            # Topologically Sorted Source Nodes: [linear_102, silu_14, linear_103, mul_136], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf320, buf319, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg247_1, (1536, 8960), (8960, 1), 'input')
            buf321 = reinterpret_tensor(buf317, (s16, 1536), (1536, 1), 0); del buf317  # reuse
            # Topologically Sorted Source Nodes: [linear_102, silu_14, linear_103, mul_136, down_proj_14], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf320, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg247_1, (8960, 1536), (1, 8960), 0), out=buf321)
            del arg247_1
            assert_size_stride(arg248_1, (1536, ), (1, ), 'input')
            buf323 = reinterpret_tensor(buf303, (s16, 1, 1536), (1536, 1536, 1), 0); del buf303  # reuse
            # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, attn_output_59, hidden_states_115, down_proj_14, hidden_states_119, pow_31, variance_30, add_90, rsqrt_30, hidden_states_121, hidden_states_122], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf294, buf300, buf315, buf321, arg248_1, buf323, s16, 1536, stream=raw_stream0)
            del arg248_1
            assert_size_stride_grouped((arg250_1, arg249_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf324 = buf272; del buf272  # reuse
            # Topologically Sorted Source Nodes: [linear_105], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg250_1, reinterpret_tensor(buf323, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg249_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf324)
            del arg249_1
            del arg250_1
            assert_size_stride_grouped((arg252_1, arg251_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf325 = buf306; del buf306  # reuse
            # Topologically Sorted Source Nodes: [linear_106], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg252_1, reinterpret_tensor(buf323, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg251_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf325)
            del arg251_1
            del arg252_1
            assert_size_stride(arg255_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg255_1 = copy_if_misaligned(arg255_1)
            buf326 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_18, sin_18, linear_106, view_46, key_states_15, mul_141, x2_31, neg_31, x1_31, cat_62, mul_142, k_embed_15, key_tensors_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg255_1, buf325, arg4_1, arg3_1, arg5_1.item(), buf326, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg255_1
            assert_size_stride_grouped((arg254_1, arg253_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf327 = buf325; del buf325  # reuse
            # Topologically Sorted Source Nodes: [linear_107], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg254_1, reinterpret_tensor(buf323, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg253_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf327)
            del arg253_1
            del arg254_1
            assert_size_stride(arg256_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg256_1 = copy_if_misaligned(arg256_1)
            buf328 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_107, view_47, value_states_15, value_tensors_15], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg256_1, buf327, buf328, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg256_1
            buf329 = reinterpret_tensor(buf323, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf323  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_105, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_61, sin_18, mul_140, q_embed_15, packed_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf324, arg4_1, arg3_1, arg5_1.item(), buf329, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf324
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_105, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_61, sin_18, mul_140, q_embed_15, packed_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf330 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf329, buf326, buf328, None, False, scale=0.08838834764831845)
            buf331 = buf330[0]
            assert_tensor_metadata(buf331, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf331, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf330
            buf335 = buf329; del buf329  # reuse
            # Topologically Sorted Source Nodes: [attn_output_60], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf331, buf335, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg257_1, (1536, 1536), (1536, 1), 'input')
            buf336 = reinterpret_tensor(buf331, (s16, 1536), (1536, 1), 0); del buf331  # reuse
            # Topologically Sorted Source Nodes: [attn_output_60, transpose_64, reshape_47, attn_output_63], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf335, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg257_1, (1536, 1536), (1, 1536), 0), out=buf336)
            del arg257_1
            assert_size_stride_grouped((arg259_1, arg258_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf337 = buf294; del buf294  # reuse
            buf339 = reinterpret_tensor(buf335, (s16, 1, 1536), (1536, 1536, 1), 0); del buf335  # reuse
            # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, attn_output_59, hidden_states_115, down_proj_14, hidden_states_119, attn_output_63, hidden_states_123, pow_32, variance_31, rsqrt_31, hidden_states_125, hidden_states_126], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf337, buf300, buf315, buf321, buf336, arg259_1, arg258_1.item(), buf339, s16, 1536, stream=raw_stream0)
            del arg258_1
            del arg259_1
            del buf300
            assert_size_stride(arg260_1, (8960, 1536), (1536, 1), 'input')
            buf340 = reinterpret_tensor(buf320, (s16, 8960), (8960, 1), 0); del buf320  # reuse
            # Topologically Sorted Source Nodes: [pow_32, variance_31, rsqrt_31, hidden_states_125, hidden_states_126, linear_109], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf339, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg260_1, (1536, 8960), (1, 1536), 0), out=buf340)
            del arg260_1
            assert_size_stride(arg261_1, (8960, 1536), (1536, 1), 'input')
            buf341 = buf319; del buf319  # reuse
            # Topologically Sorted Source Nodes: [linear_110], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf339, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg261_1, (1536, 8960), (1, 1536), 0), out=buf341)
            del arg261_1
            buf342 = reinterpret_tensor(buf340, (s16, 1, 8960), (8960, 8960, 1), 0); del buf340  # reuse
            # Topologically Sorted Source Nodes: [linear_109, silu_15, linear_110, mul_145], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf342, buf341, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg262_1, (1536, 8960), (8960, 1), 'input')
            buf343 = reinterpret_tensor(buf339, (s16, 1536), (1536, 1), 0); del buf339  # reuse
            # Topologically Sorted Source Nodes: [linear_109, silu_15, linear_110, mul_145, down_proj_15], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf342, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg262_1, (8960, 1536), (1, 8960), 0), out=buf343)
            del arg262_1
            assert_size_stride_grouped((arg264_1, arg263_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf345 = reinterpret_tensor(buf336, (s16, 1, 1536), (1536, 1536, 1), 0); del buf336  # reuse
            # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_127, pow_33, variance_32, rsqrt_32, hidden_states_129, hidden_states_130], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf337, buf343, arg264_1, arg263_1.item(), buf345, s16, 1536, stream=raw_stream0)
            del arg263_1
            del arg264_1
            assert_size_stride_grouped((arg266_1, arg265_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf346 = buf321; del buf321  # reuse
            # Topologically Sorted Source Nodes: [linear_112], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg266_1, reinterpret_tensor(buf345, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg265_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf346)
            del arg265_1
            del arg266_1
            assert_size_stride_grouped((arg268_1, arg267_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf347 = buf327; del buf327  # reuse
            # Topologically Sorted Source Nodes: [linear_113], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg268_1, reinterpret_tensor(buf345, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg267_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf347)
            del arg267_1
            del arg268_1
            assert_size_stride(arg271_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg271_1 = copy_if_misaligned(arg271_1)
            buf348 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_19, sin_19, linear_113, view_49, key_states_16, mul_150, x2_33, neg_33, x1_33, cat_66, mul_151, k_embed_16, key_tensors_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg271_1, buf347, arg4_1, arg3_1, arg5_1.item(), buf348, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg271_1
            assert_size_stride_grouped((arg270_1, arg269_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf349 = buf347; del buf347  # reuse
            # Topologically Sorted Source Nodes: [linear_114], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg270_1, reinterpret_tensor(buf345, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg269_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf349)
            del arg269_1
            del arg270_1
            assert_size_stride(arg272_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg272_1 = copy_if_misaligned(arg272_1)
            buf350 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_114, view_50, value_states_16, value_tensors_16], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg272_1, buf349, buf350, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg272_1
            buf351 = reinterpret_tensor(buf345, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf345  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_112, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_65, sin_19, mul_149, q_embed_16, packed_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf346, arg4_1, arg3_1, arg5_1.item(), buf351, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_112, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_65, sin_19, mul_149, q_embed_16, packed_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf352 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf351, buf348, buf350, None, False, scale=0.08838834764831845)
            buf353 = buf352[0]
            assert_tensor_metadata(buf353, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf353, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf352
            buf357 = buf351; del buf351  # reuse
            # Topologically Sorted Source Nodes: [attn_output_64], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf353, buf357, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg273_1, (1536, 1536), (1536, 1), 'input')
            buf358 = reinterpret_tensor(buf353, (s16, 1536), (1536, 1), 0); del buf353  # reuse
            # Topologically Sorted Source Nodes: [attn_output_64, transpose_68, reshape_50, attn_output_67], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf357, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg273_1, (1536, 1536), (1, 1536), 0), out=buf358)
            del arg273_1
            assert_size_stride_grouped((arg275_1, arg274_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf360 = reinterpret_tensor(buf357, (s16, 1, 1536), (1536, 1536, 1), 0); del buf357  # reuse
            # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_127, attn_output_67, hidden_states_131, pow_34, variance_33, rsqrt_33, hidden_states_133, hidden_states_134], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf337, buf343, buf358, arg275_1, arg274_1.item(), buf360, s16, 1536, stream=raw_stream0)
            del arg274_1
            del arg275_1
            assert_size_stride(arg276_1, (8960, 1536), (1536, 1), 'input')
            buf361 = reinterpret_tensor(buf342, (s16, 8960), (8960, 1), 0); del buf342  # reuse
            # Topologically Sorted Source Nodes: [linear_116], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf360, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg276_1, (1536, 8960), (1, 1536), 0), out=buf361)
            del arg276_1
            assert_size_stride(arg277_1, (8960, 1536), (1536, 1), 'input')
            buf362 = buf341; del buf341  # reuse
            # Topologically Sorted Source Nodes: [linear_117], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf360, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg277_1, (1536, 8960), (1, 1536), 0), out=buf362)
            del arg277_1
            buf363 = reinterpret_tensor(buf361, (s16, 1, 8960), (8960, 8960, 1), 0); del buf361  # reuse
            # Topologically Sorted Source Nodes: [linear_116, silu_16, linear_117, mul_154], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf363, buf362, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg278_1, (1536, 8960), (8960, 1), 'input')
            buf364 = reinterpret_tensor(buf360, (s16, 1536), (1536, 1), 0); del buf360  # reuse
            # Topologically Sorted Source Nodes: [linear_116, silu_16, linear_117, mul_154, down_proj_16], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf363, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg278_1, (8960, 1536), (1, 8960), 0), out=buf364)
            del arg278_1
            assert_size_stride_grouped((arg280_1, arg279_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf366 = reinterpret_tensor(buf346, (s16, 1, 1536), (1536, 1536, 1), 0); del buf346  # reuse
            # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_127, attn_output_67, hidden_states_131, down_proj_16, hidden_states_135, pow_35, variance_34, rsqrt_34, hidden_states_137, hidden_states_138], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf337, buf343, buf358, buf364, arg280_1, arg279_1.item(), buf366, s16, 1536, stream=raw_stream0)
            del arg279_1
            del arg280_1
            assert_size_stride_grouped((arg282_1, arg281_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf367 = buf315; del buf315  # reuse
            # Topologically Sorted Source Nodes: [linear_119], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg282_1, reinterpret_tensor(buf366, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg281_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf367)
            del arg281_1
            del arg282_1
            assert_size_stride_grouped((arg284_1, arg283_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf368 = buf349; del buf349  # reuse
            # Topologically Sorted Source Nodes: [linear_120], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg284_1, reinterpret_tensor(buf366, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg283_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf368)
            del arg283_1
            del arg284_1
            assert_size_stride(arg287_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg287_1 = copy_if_misaligned(arg287_1)
            buf369 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_20, sin_20, linear_120, view_52, key_states_17, mul_159, x2_35, neg_35, x1_35, cat_70, mul_160, k_embed_17, key_tensors_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg287_1, buf368, arg4_1, arg3_1, arg5_1.item(), buf369, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg287_1
            assert_size_stride_grouped((arg286_1, arg285_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf370 = buf368; del buf368  # reuse
            # Topologically Sorted Source Nodes: [linear_121], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg286_1, reinterpret_tensor(buf366, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg285_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf370)
            del arg285_1
            del arg286_1
            assert_size_stride(arg288_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg288_1 = copy_if_misaligned(arg288_1)
            buf371 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_121, view_53, value_states_17, value_tensors_17], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg288_1, buf370, buf371, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg288_1
            buf372 = reinterpret_tensor(buf366, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf366  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_119, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_69, sin_20, mul_158, q_embed_17, packed_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf367, arg4_1, arg3_1, arg5_1.item(), buf372, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf367
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_119, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_69, sin_20, mul_158, q_embed_17, packed_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf373 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf372, buf369, buf371, None, False, scale=0.08838834764831845)
            buf374 = buf373[0]
            assert_tensor_metadata(buf374, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf374, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf373
            buf378 = buf372; del buf372  # reuse
            # Topologically Sorted Source Nodes: [attn_output_68], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf374, buf378, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg289_1, (1536, 1536), (1536, 1), 'input')
            buf379 = reinterpret_tensor(buf374, (s16, 1536), (1536, 1), 0); del buf374  # reuse
            # Topologically Sorted Source Nodes: [attn_output_68, transpose_72, reshape_53, attn_output_71], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf378, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg289_1, (1536, 1536), (1, 1536), 0), out=buf379)
            del arg289_1
            assert_size_stride_grouped((arg291_1, arg290_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf380 = buf337; del buf337  # reuse
            buf382 = reinterpret_tensor(buf378, (s16, 1, 1536), (1536, 1536, 1), 0); del buf378  # reuse
            # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_127, attn_output_67, hidden_states_131, down_proj_16, hidden_states_135, attn_output_71, hidden_states_139, pow_36, variance_35, rsqrt_35, hidden_states_141, hidden_states_142], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf380, buf343, buf358, buf364, buf379, arg291_1, arg290_1.item(), buf382, s16, 1536, stream=raw_stream0)
            del arg290_1
            del arg291_1
            del buf343
            assert_size_stride(arg292_1, (8960, 1536), (1536, 1), 'input')
            buf383 = reinterpret_tensor(buf363, (s16, 8960), (8960, 1), 0); del buf363  # reuse
            # Topologically Sorted Source Nodes: [pow_36, variance_35, rsqrt_35, hidden_states_141, hidden_states_142, linear_123], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf382, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg292_1, (1536, 8960), (1, 1536), 0), out=buf383)
            del arg292_1
            assert_size_stride(arg293_1, (8960, 1536), (1536, 1), 'input')
            buf384 = buf362; del buf362  # reuse
            # Topologically Sorted Source Nodes: [linear_124], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf382, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg293_1, (1536, 8960), (1, 1536), 0), out=buf384)
            del arg293_1
            buf385 = reinterpret_tensor(buf383, (s16, 1, 8960), (8960, 8960, 1), 0); del buf383  # reuse
            # Topologically Sorted Source Nodes: [linear_123, silu_17, linear_124, mul_163], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf385, buf384, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg294_1, (1536, 8960), (8960, 1), 'input')
            buf386 = reinterpret_tensor(buf382, (s16, 1536), (1536, 1), 0); del buf382  # reuse
            # Topologically Sorted Source Nodes: [linear_123, silu_17, linear_124, mul_163, down_proj_17], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf385, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg294_1, (8960, 1536), (1, 8960), 0), out=buf386)
            del arg294_1
            assert_size_stride_grouped((arg296_1, arg295_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf388 = reinterpret_tensor(buf379, (s16, 1, 1536), (1536, 1536, 1), 0); del buf379  # reuse
            # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_143, pow_37, variance_36, rsqrt_36, hidden_states_145, hidden_states_146], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf380, buf386, arg296_1, arg295_1.item(), buf388, s16, 1536, stream=raw_stream0)
            del arg295_1
            del arg296_1
            assert_size_stride_grouped((arg298_1, arg297_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf389 = buf364; del buf364  # reuse
            # Topologically Sorted Source Nodes: [linear_126], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg298_1, reinterpret_tensor(buf388, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg297_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf389)
            del arg297_1
            del arg298_1
            assert_size_stride_grouped((arg300_1, arg299_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf390 = buf370; del buf370  # reuse
            # Topologically Sorted Source Nodes: [linear_127], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg300_1, reinterpret_tensor(buf388, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg299_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf390)
            del arg299_1
            del arg300_1
            assert_size_stride(arg303_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg303_1 = copy_if_misaligned(arg303_1)
            buf391 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_21, sin_21, linear_127, view_55, key_states_18, mul_168, x2_37, neg_37, x1_37, cat_74, mul_169, k_embed_18, key_tensors_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg303_1, buf390, arg4_1, arg3_1, arg5_1.item(), buf391, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg303_1
            assert_size_stride_grouped((arg302_1, arg301_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf392 = buf390; del buf390  # reuse
            # Topologically Sorted Source Nodes: [linear_128], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg302_1, reinterpret_tensor(buf388, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg301_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf392)
            del arg301_1
            del arg302_1
            assert_size_stride(arg304_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg304_1 = copy_if_misaligned(arg304_1)
            buf393 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_128, view_56, value_states_18, value_tensors_18], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg304_1, buf392, buf393, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg304_1
            buf394 = reinterpret_tensor(buf388, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf388  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_73, sin_21, mul_167, q_embed_18, packed_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf389, arg4_1, arg3_1, arg5_1.item(), buf394, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_73, sin_21, mul_167, q_embed_18, packed_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf395 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf394, buf391, buf393, None, False, scale=0.08838834764831845)
            buf396 = buf395[0]
            assert_tensor_metadata(buf396, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf396, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf395
            buf400 = buf394; del buf394  # reuse
            # Topologically Sorted Source Nodes: [attn_output_72], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf396, buf400, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg305_1, (1536, 1536), (1536, 1), 'input')
            buf401 = reinterpret_tensor(buf396, (s16, 1536), (1536, 1), 0); del buf396  # reuse
            # Topologically Sorted Source Nodes: [attn_output_72, transpose_76, reshape_56, attn_output_75], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf400, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg305_1, (1536, 1536), (1, 1536), 0), out=buf401)
            del arg305_1
            assert_size_stride_grouped((arg307_1, arg306_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf403 = reinterpret_tensor(buf400, (s16, 1, 1536), (1536, 1536, 1), 0); del buf400  # reuse
            # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_143, attn_output_75, hidden_states_147, pow_38, variance_37, rsqrt_37, hidden_states_149, hidden_states_150], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf380, buf386, buf401, arg307_1, arg306_1.item(), buf403, s16, 1536, stream=raw_stream0)
            del arg306_1
            del arg307_1
            assert_size_stride(arg308_1, (8960, 1536), (1536, 1), 'input')
            buf404 = reinterpret_tensor(buf385, (s16, 8960), (8960, 1), 0); del buf385  # reuse
            # Topologically Sorted Source Nodes: [linear_130], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf403, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg308_1, (1536, 8960), (1, 1536), 0), out=buf404)
            del arg308_1
            assert_size_stride(arg309_1, (8960, 1536), (1536, 1), 'input')
            buf405 = buf384; del buf384  # reuse
            # Topologically Sorted Source Nodes: [linear_131], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf403, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg309_1, (1536, 8960), (1, 1536), 0), out=buf405)
            del arg309_1
            buf406 = reinterpret_tensor(buf404, (s16, 1, 8960), (8960, 8960, 1), 0); del buf404  # reuse
            # Topologically Sorted Source Nodes: [linear_130, silu_18, linear_131, mul_172], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf406, buf405, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg310_1, (1536, 8960), (8960, 1), 'input')
            buf407 = reinterpret_tensor(buf403, (s16, 1536), (1536, 1), 0); del buf403  # reuse
            # Topologically Sorted Source Nodes: [linear_130, silu_18, linear_131, mul_172, down_proj_18], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf406, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg310_1, (8960, 1536), (1, 8960), 0), out=buf407)
            del arg310_1
            assert_size_stride_grouped((arg312_1, arg311_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf409 = reinterpret_tensor(buf389, (s16, 1, 1536), (1536, 1536, 1), 0); del buf389  # reuse
            # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_143, attn_output_75, hidden_states_147, down_proj_18, hidden_states_151, pow_39, variance_38, rsqrt_38, hidden_states_153, hidden_states_154], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf380, buf386, buf401, buf407, arg312_1, arg311_1.item(), buf409, s16, 1536, stream=raw_stream0)
            del arg311_1
            del arg312_1
            assert_size_stride_grouped((arg314_1, arg313_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf410 = buf358; del buf358  # reuse
            # Topologically Sorted Source Nodes: [linear_133], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg314_1, reinterpret_tensor(buf409, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg313_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf410)
            del arg313_1
            del arg314_1
            assert_size_stride_grouped((arg316_1, arg315_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf411 = buf392; del buf392  # reuse
            # Topologically Sorted Source Nodes: [linear_134], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg316_1, reinterpret_tensor(buf409, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg315_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf411)
            del arg315_1
            del arg316_1
            assert_size_stride(arg319_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg319_1 = copy_if_misaligned(arg319_1)
            buf412 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_22, sin_22, linear_134, view_58, key_states_19, mul_177, x2_39, neg_39, x1_39, cat_78, mul_178, k_embed_19, key_tensors_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg319_1, buf411, arg4_1, arg3_1, arg5_1.item(), buf412, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg319_1
            assert_size_stride_grouped((arg318_1, arg317_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf413 = buf411; del buf411  # reuse
            # Topologically Sorted Source Nodes: [linear_135], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg318_1, reinterpret_tensor(buf409, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg317_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf413)
            del arg317_1
            del arg318_1
            assert_size_stride(arg320_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg320_1 = copy_if_misaligned(arg320_1)
            buf414 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_135, view_59, value_states_19, value_tensors_19], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg320_1, buf413, buf414, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg320_1
            buf415 = reinterpret_tensor(buf409, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf409  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_133, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_77, sin_22, mul_176, q_embed_19, packed_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf410, arg4_1, arg3_1, arg5_1.item(), buf415, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf410
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_133, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_77, sin_22, mul_176, q_embed_19, packed_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf416 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf415, buf412, buf414, None, False, scale=0.08838834764831845)
            buf417 = buf416[0]
            assert_tensor_metadata(buf417, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf417, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf416
            buf421 = buf415; del buf415  # reuse
            # Topologically Sorted Source Nodes: [attn_output_76], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf417, buf421, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg321_1, (1536, 1536), (1536, 1), 'input')
            buf422 = reinterpret_tensor(buf417, (s16, 1536), (1536, 1), 0); del buf417  # reuse
            # Topologically Sorted Source Nodes: [attn_output_76, transpose_80, reshape_59, attn_output_79], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf421, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg321_1, (1536, 1536), (1, 1536), 0), out=buf422)
            del arg321_1
            assert_size_stride_grouped((arg323_1, arg322_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf423 = buf380; del buf380  # reuse
            buf425 = reinterpret_tensor(buf421, (s16, 1, 1536), (1536, 1536, 1), 0); del buf421  # reuse
            # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_143, attn_output_75, hidden_states_147, down_proj_18, hidden_states_151, attn_output_79, hidden_states_155, pow_40, variance_39, rsqrt_39, hidden_states_157, hidden_states_158], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf423, buf386, buf401, buf407, buf422, arg323_1, arg322_1.item(), buf425, s16, 1536, stream=raw_stream0)
            del arg322_1
            del arg323_1
            del buf386
            assert_size_stride(arg324_1, (8960, 1536), (1536, 1), 'input')
            buf426 = reinterpret_tensor(buf406, (s16, 8960), (8960, 1), 0); del buf406  # reuse
            # Topologically Sorted Source Nodes: [pow_40, variance_39, rsqrt_39, hidden_states_157, hidden_states_158, linear_137], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf425, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg324_1, (1536, 8960), (1, 1536), 0), out=buf426)
            del arg324_1
            assert_size_stride(arg325_1, (8960, 1536), (1536, 1), 'input')
            buf427 = buf405; del buf405  # reuse
            # Topologically Sorted Source Nodes: [linear_138], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf425, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg325_1, (1536, 8960), (1, 1536), 0), out=buf427)
            del arg325_1
            buf428 = reinterpret_tensor(buf426, (s16, 1, 8960), (8960, 8960, 1), 0); del buf426  # reuse
            # Topologically Sorted Source Nodes: [linear_137, silu_19, linear_138, mul_181], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf428, buf427, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg326_1, (1536, 8960), (8960, 1), 'input')
            buf429 = reinterpret_tensor(buf425, (s16, 1536), (1536, 1), 0); del buf425  # reuse
            # Topologically Sorted Source Nodes: [linear_137, silu_19, linear_138, mul_181, down_proj_19], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf428, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg326_1, (8960, 1536), (1, 8960), 0), out=buf429)
            del arg326_1
            assert_size_stride_grouped((arg328_1, arg327_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf431 = reinterpret_tensor(buf422, (s16, 1, 1536), (1536, 1536, 1), 0); del buf422  # reuse
            # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_159, pow_41, variance_40, rsqrt_40, hidden_states_161, hidden_states_162], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf423, buf429, arg328_1, arg327_1.item(), buf431, s16, 1536, stream=raw_stream0)
            del arg327_1
            del arg328_1
            assert_size_stride_grouped((arg330_1, arg329_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf432 = buf407; del buf407  # reuse
            # Topologically Sorted Source Nodes: [linear_140], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg330_1, reinterpret_tensor(buf431, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg329_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf432)
            del arg329_1
            del arg330_1
            assert_size_stride_grouped((arg332_1, arg331_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf433 = buf413; del buf413  # reuse
            # Topologically Sorted Source Nodes: [linear_141], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg332_1, reinterpret_tensor(buf431, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg331_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf433)
            del arg331_1
            del arg332_1
            assert_size_stride(arg335_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg335_1 = copy_if_misaligned(arg335_1)
            buf434 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_23, sin_23, linear_141, view_61, key_states_20, mul_186, x2_41, neg_41, x1_41, cat_82, mul_187, k_embed_20, key_tensors_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg335_1, buf433, arg4_1, arg3_1, arg5_1.item(), buf434, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg335_1
            assert_size_stride_grouped((arg334_1, arg333_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf435 = buf433; del buf433  # reuse
            # Topologically Sorted Source Nodes: [linear_142], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg334_1, reinterpret_tensor(buf431, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg333_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf435)
            del arg333_1
            del arg334_1
            assert_size_stride(arg336_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg336_1 = copy_if_misaligned(arg336_1)
            buf436 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_142, view_62, value_states_20, value_tensors_20], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg336_1, buf435, buf436, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg336_1
            buf437 = reinterpret_tensor(buf431, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf431  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_140, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_81, sin_23, mul_185, q_embed_20, packed_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf432, arg4_1, arg3_1, arg5_1.item(), buf437, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_140, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_81, sin_23, mul_185, q_embed_20, packed_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf438 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf437, buf434, buf436, None, False, scale=0.08838834764831845)
            buf439 = buf438[0]
            assert_tensor_metadata(buf439, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf439, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf438
            buf443 = buf437; del buf437  # reuse
            # Topologically Sorted Source Nodes: [attn_output_80], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf439, buf443, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg337_1, (1536, 1536), (1536, 1), 'input')
            buf444 = reinterpret_tensor(buf439, (s16, 1536), (1536, 1), 0); del buf439  # reuse
            # Topologically Sorted Source Nodes: [attn_output_80, transpose_84, reshape_62, attn_output_83], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf443, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg337_1, (1536, 1536), (1, 1536), 0), out=buf444)
            del arg337_1
            assert_size_stride_grouped((arg339_1, arg338_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf446 = reinterpret_tensor(buf443, (s16, 1, 1536), (1536, 1536, 1), 0); del buf443  # reuse
            # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_159, attn_output_83, hidden_states_163, pow_42, variance_41, rsqrt_41, hidden_states_165, hidden_states_166], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf423, buf429, buf444, arg339_1, arg338_1.item(), buf446, s16, 1536, stream=raw_stream0)
            del arg338_1
            del arg339_1
            assert_size_stride(arg340_1, (8960, 1536), (1536, 1), 'input')
            buf447 = reinterpret_tensor(buf428, (s16, 8960), (8960, 1), 0); del buf428  # reuse
            # Topologically Sorted Source Nodes: [linear_144], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf446, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg340_1, (1536, 8960), (1, 1536), 0), out=buf447)
            del arg340_1
            assert_size_stride(arg341_1, (8960, 1536), (1536, 1), 'input')
            buf448 = buf427; del buf427  # reuse
            # Topologically Sorted Source Nodes: [linear_145], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf446, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg341_1, (1536, 8960), (1, 1536), 0), out=buf448)
            del arg341_1
            buf449 = reinterpret_tensor(buf447, (s16, 1, 8960), (8960, 8960, 1), 0); del buf447  # reuse
            # Topologically Sorted Source Nodes: [linear_144, silu_20, linear_145, mul_190], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf449, buf448, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg342_1, (1536, 8960), (8960, 1), 'input')
            buf450 = reinterpret_tensor(buf446, (s16, 1536), (1536, 1), 0); del buf446  # reuse
            # Topologically Sorted Source Nodes: [linear_144, silu_20, linear_145, mul_190, down_proj_20], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf449, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg342_1, (8960, 1536), (1, 8960), 0), out=buf450)
            del arg342_1
            assert_size_stride_grouped((arg344_1, arg343_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf452 = reinterpret_tensor(buf432, (s16, 1, 1536), (1536, 1536, 1), 0); del buf432  # reuse
            # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_159, attn_output_83, hidden_states_163, down_proj_20, hidden_states_167, pow_43, variance_42, rsqrt_42, hidden_states_169, hidden_states_170], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf423, buf429, buf444, buf450, arg344_1, arg343_1.item(), buf452, s16, 1536, stream=raw_stream0)
            del arg343_1
            del arg344_1
            assert_size_stride_grouped((arg346_1, arg345_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf453 = buf401; del buf401  # reuse
            # Topologically Sorted Source Nodes: [linear_147], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg346_1, reinterpret_tensor(buf452, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg345_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf453)
            del arg345_1
            del arg346_1
            assert_size_stride_grouped((arg348_1, arg347_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf454 = buf435; del buf435  # reuse
            # Topologically Sorted Source Nodes: [linear_148], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg348_1, reinterpret_tensor(buf452, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg347_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf454)
            del arg347_1
            del arg348_1
            assert_size_stride(arg351_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg351_1 = copy_if_misaligned(arg351_1)
            buf455 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_24, sin_24, linear_148, view_64, key_states_21, mul_195, x2_43, neg_43, x1_43, cat_86, mul_196, k_embed_21, key_tensors_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg351_1, buf454, arg4_1, arg3_1, arg5_1.item(), buf455, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg351_1
            assert_size_stride_grouped((arg350_1, arg349_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf456 = buf454; del buf454  # reuse
            # Topologically Sorted Source Nodes: [linear_149], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg350_1, reinterpret_tensor(buf452, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg349_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf456)
            del arg349_1
            del arg350_1
            assert_size_stride(arg352_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg352_1 = copy_if_misaligned(arg352_1)
            buf457 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_149, view_65, value_states_21, value_tensors_21], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg352_1, buf456, buf457, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg352_1
            buf458 = reinterpret_tensor(buf452, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf452  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_147, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_85, sin_24, mul_194, q_embed_21, packed_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf453, arg4_1, arg3_1, arg5_1.item(), buf458, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf453
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_147, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_85, sin_24, mul_194, q_embed_21, packed_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf459 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf458, buf455, buf457, None, False, scale=0.08838834764831845)
            buf460 = buf459[0]
            assert_tensor_metadata(buf460, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf460, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf459
            buf464 = buf458; del buf458  # reuse
            # Topologically Sorted Source Nodes: [attn_output_84], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf460, buf464, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg353_1, (1536, 1536), (1536, 1), 'input')
            buf465 = reinterpret_tensor(buf460, (s16, 1536), (1536, 1), 0); del buf460  # reuse
            # Topologically Sorted Source Nodes: [attn_output_84, transpose_88, reshape_65, attn_output_87], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf464, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg353_1, (1536, 1536), (1, 1536), 0), out=buf465)
            del arg353_1
            assert_size_stride_grouped((arg355_1, arg354_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf466 = buf423; del buf423  # reuse
            buf468 = reinterpret_tensor(buf464, (s16, 1, 1536), (1536, 1536, 1), 0); del buf464  # reuse
            # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_159, attn_output_83, hidden_states_163, down_proj_20, hidden_states_167, attn_output_87, hidden_states_171, pow_44, variance_43, rsqrt_43, hidden_states_173, hidden_states_174], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf466, buf429, buf444, buf450, buf465, arg355_1, arg354_1.item(), buf468, s16, 1536, stream=raw_stream0)
            del arg354_1
            del arg355_1
            del buf429
            assert_size_stride(arg356_1, (8960, 1536), (1536, 1), 'input')
            buf469 = reinterpret_tensor(buf449, (s16, 8960), (8960, 1), 0); del buf449  # reuse
            # Topologically Sorted Source Nodes: [pow_44, variance_43, rsqrt_43, hidden_states_173, hidden_states_174, linear_151], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf468, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg356_1, (1536, 8960), (1, 1536), 0), out=buf469)
            del arg356_1
            assert_size_stride(arg357_1, (8960, 1536), (1536, 1), 'input')
            buf470 = buf448; del buf448  # reuse
            # Topologically Sorted Source Nodes: [linear_152], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf468, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg357_1, (1536, 8960), (1, 1536), 0), out=buf470)
            del arg357_1
            buf471 = reinterpret_tensor(buf469, (s16, 1, 8960), (8960, 8960, 1), 0); del buf469  # reuse
            # Topologically Sorted Source Nodes: [linear_151, silu_21, linear_152, mul_199], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf471, buf470, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg358_1, (1536, 8960), (8960, 1), 'input')
            buf472 = reinterpret_tensor(buf468, (s16, 1536), (1536, 1), 0); del buf468  # reuse
            # Topologically Sorted Source Nodes: [linear_151, silu_21, linear_152, mul_199, down_proj_21], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf471, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg358_1, (8960, 1536), (1, 8960), 0), out=buf472)
            del arg358_1
            assert_size_stride_grouped((arg360_1, arg359_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf474 = reinterpret_tensor(buf465, (s16, 1, 1536), (1536, 1536, 1), 0); del buf465  # reuse
            # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_175, pow_45, variance_44, rsqrt_44, hidden_states_177, hidden_states_178], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf466, buf472, arg360_1, arg359_1.item(), buf474, s16, 1536, stream=raw_stream0)
            del arg359_1
            del arg360_1
            assert_size_stride_grouped((arg362_1, arg361_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf475 = buf450; del buf450  # reuse
            # Topologically Sorted Source Nodes: [linear_154], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg362_1, reinterpret_tensor(buf474, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg361_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf475)
            del arg361_1
            del arg362_1
            assert_size_stride_grouped((arg364_1, arg363_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf476 = buf456; del buf456  # reuse
            # Topologically Sorted Source Nodes: [linear_155], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg364_1, reinterpret_tensor(buf474, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg363_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf476)
            del arg363_1
            del arg364_1
            assert_size_stride(arg367_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg367_1 = copy_if_misaligned(arg367_1)
            buf477 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_25, sin_25, linear_155, view_67, key_states_22, mul_204, x2_45, neg_45, x1_45, cat_90, mul_205, k_embed_22, key_tensors_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg367_1, buf476, arg4_1, arg3_1, arg5_1.item(), buf477, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg367_1
            assert_size_stride_grouped((arg366_1, arg365_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf478 = buf476; del buf476  # reuse
            # Topologically Sorted Source Nodes: [linear_156], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg366_1, reinterpret_tensor(buf474, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg365_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf478)
            del arg365_1
            del arg366_1
            assert_size_stride(arg368_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg368_1 = copy_if_misaligned(arg368_1)
            buf479 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_156, view_68, value_states_22, value_tensors_22], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg368_1, buf478, buf479, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg368_1
            buf480 = reinterpret_tensor(buf474, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf474  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_154, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_89, sin_25, mul_203, q_embed_22, packed_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf475, arg4_1, arg3_1, arg5_1.item(), buf480, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_154, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_89, sin_25, mul_203, q_embed_22, packed_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf481 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf480, buf477, buf479, None, False, scale=0.08838834764831845)
            buf482 = buf481[0]
            assert_tensor_metadata(buf482, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf482, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf481
            buf486 = buf480; del buf480  # reuse
            # Topologically Sorted Source Nodes: [attn_output_88], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf482, buf486, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg369_1, (1536, 1536), (1536, 1), 'input')
            buf487 = reinterpret_tensor(buf482, (s16, 1536), (1536, 1), 0); del buf482  # reuse
            # Topologically Sorted Source Nodes: [attn_output_88, transpose_92, reshape_68, attn_output_91], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf486, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg369_1, (1536, 1536), (1, 1536), 0), out=buf487)
            del arg369_1
            assert_size_stride_grouped((arg371_1, arg370_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf489 = reinterpret_tensor(buf486, (s16, 1, 1536), (1536, 1536, 1), 0); del buf486  # reuse
            # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_175, attn_output_91, hidden_states_179, pow_46, variance_45, rsqrt_45, hidden_states_181, hidden_states_182], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf466, buf472, buf487, arg371_1, arg370_1.item(), buf489, s16, 1536, stream=raw_stream0)
            del arg370_1
            del arg371_1
            assert_size_stride(arg372_1, (8960, 1536), (1536, 1), 'input')
            buf490 = reinterpret_tensor(buf471, (s16, 8960), (8960, 1), 0); del buf471  # reuse
            # Topologically Sorted Source Nodes: [linear_158], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf489, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg372_1, (1536, 8960), (1, 1536), 0), out=buf490)
            del arg372_1
            assert_size_stride(arg373_1, (8960, 1536), (1536, 1), 'input')
            buf491 = buf470; del buf470  # reuse
            # Topologically Sorted Source Nodes: [linear_159], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf489, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg373_1, (1536, 8960), (1, 1536), 0), out=buf491)
            del arg373_1
            buf492 = reinterpret_tensor(buf490, (s16, 1, 8960), (8960, 8960, 1), 0); del buf490  # reuse
            # Topologically Sorted Source Nodes: [linear_158, silu_22, linear_159, mul_208], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf492, buf491, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg374_1, (1536, 8960), (8960, 1), 'input')
            buf493 = reinterpret_tensor(buf489, (s16, 1536), (1536, 1), 0); del buf489  # reuse
            # Topologically Sorted Source Nodes: [linear_158, silu_22, linear_159, mul_208, down_proj_22], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf492, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg374_1, (8960, 1536), (1, 8960), 0), out=buf493)
            del arg374_1
            assert_size_stride_grouped((arg376_1, arg375_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf495 = reinterpret_tensor(buf475, (s16, 1, 1536), (1536, 1536, 1), 0); del buf475  # reuse
            # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_175, attn_output_91, hidden_states_179, down_proj_22, hidden_states_183, pow_47, variance_46, rsqrt_46, hidden_states_185, hidden_states_186], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf466, buf472, buf487, buf493, arg376_1, arg375_1.item(), buf495, s16, 1536, stream=raw_stream0)
            del arg375_1
            del arg376_1
            assert_size_stride_grouped((arg378_1, arg377_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf496 = buf444; del buf444  # reuse
            # Topologically Sorted Source Nodes: [linear_161], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg378_1, reinterpret_tensor(buf495, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg377_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf496)
            del arg377_1
            del arg378_1
            assert_size_stride_grouped((arg380_1, arg379_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf497 = buf478; del buf478  # reuse
            # Topologically Sorted Source Nodes: [linear_162], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg380_1, reinterpret_tensor(buf495, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg379_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf497)
            del arg379_1
            del arg380_1
            assert_size_stride(arg383_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg383_1 = copy_if_misaligned(arg383_1)
            buf498 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_26, sin_26, linear_162, view_70, key_states_23, mul_213, x2_47, neg_47, x1_47, cat_94, mul_214, k_embed_23, key_tensors_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg383_1, buf497, arg4_1, arg3_1, arg5_1.item(), buf498, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg383_1
            assert_size_stride_grouped((arg382_1, arg381_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf499 = buf497; del buf497  # reuse
            # Topologically Sorted Source Nodes: [linear_163], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg382_1, reinterpret_tensor(buf495, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg381_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf499)
            del arg381_1
            del arg382_1
            assert_size_stride(arg384_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg384_1 = copy_if_misaligned(arg384_1)
            buf500 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_163, view_71, value_states_23, value_tensors_23], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg384_1, buf499, buf500, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg384_1
            buf501 = reinterpret_tensor(buf495, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf495  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_161, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_93, sin_26, mul_212, q_embed_23, packed_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf496, arg4_1, arg3_1, arg5_1.item(), buf501, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf496
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_161, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_93, sin_26, mul_212, q_embed_23, packed_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf502 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf501, buf498, buf500, None, False, scale=0.08838834764831845)
            buf503 = buf502[0]
            assert_tensor_metadata(buf503, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf503, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf502
            buf507 = buf501; del buf501  # reuse
            # Topologically Sorted Source Nodes: [attn_output_92], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf503, buf507, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg385_1, (1536, 1536), (1536, 1), 'input')
            buf508 = reinterpret_tensor(buf503, (s16, 1536), (1536, 1), 0); del buf503  # reuse
            # Topologically Sorted Source Nodes: [attn_output_92, transpose_96, reshape_71, attn_output_95], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf507, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg385_1, (1536, 1536), (1, 1536), 0), out=buf508)
            del arg385_1
            assert_size_stride_grouped((arg387_1, arg386_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf509 = buf466; del buf466  # reuse
            buf511 = reinterpret_tensor(buf507, (s16, 1, 1536), (1536, 1536, 1), 0); del buf507  # reuse
            # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_175, attn_output_91, hidden_states_179, down_proj_22, hidden_states_183, attn_output_95, hidden_states_187, pow_48, variance_47, rsqrt_47, hidden_states_189, hidden_states_190], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf509, buf472, buf487, buf493, buf508, arg387_1, arg386_1.item(), buf511, s16, 1536, stream=raw_stream0)
            del arg386_1
            del arg387_1
            del buf472
            assert_size_stride(arg388_1, (8960, 1536), (1536, 1), 'input')
            buf512 = reinterpret_tensor(buf492, (s16, 8960), (8960, 1), 0); del buf492  # reuse
            # Topologically Sorted Source Nodes: [pow_48, variance_47, rsqrt_47, hidden_states_189, hidden_states_190, linear_165], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf511, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg388_1, (1536, 8960), (1, 1536), 0), out=buf512)
            del arg388_1
            assert_size_stride(arg389_1, (8960, 1536), (1536, 1), 'input')
            buf513 = buf491; del buf491  # reuse
            # Topologically Sorted Source Nodes: [linear_166], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf511, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg389_1, (1536, 8960), (1, 1536), 0), out=buf513)
            del arg389_1
            buf514 = reinterpret_tensor(buf512, (s16, 1, 8960), (8960, 8960, 1), 0); del buf512  # reuse
            # Topologically Sorted Source Nodes: [linear_165, silu_23, linear_166, mul_217], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf514, buf513, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg390_1, (1536, 8960), (8960, 1), 'input')
            buf515 = reinterpret_tensor(buf511, (s16, 1536), (1536, 1), 0); del buf511  # reuse
            # Topologically Sorted Source Nodes: [linear_165, silu_23, linear_166, mul_217, down_proj_23], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf514, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg390_1, (8960, 1536), (1, 8960), 0), out=buf515)
            del arg390_1
            assert_size_stride_grouped((arg392_1, arg391_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf517 = reinterpret_tensor(buf508, (s16, 1, 1536), (1536, 1536, 1), 0); del buf508  # reuse
            # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_191, pow_49, variance_48, rsqrt_48, hidden_states_193, hidden_states_194], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf509, buf515, arg392_1, arg391_1.item(), buf517, s16, 1536, stream=raw_stream0)
            del arg391_1
            del arg392_1
            assert_size_stride_grouped((arg394_1, arg393_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf518 = buf493; del buf493  # reuse
            # Topologically Sorted Source Nodes: [linear_168], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg394_1, reinterpret_tensor(buf517, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg393_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf518)
            del arg393_1
            del arg394_1
            assert_size_stride_grouped((arg396_1, arg395_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf519 = buf499; del buf499  # reuse
            # Topologically Sorted Source Nodes: [linear_169], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg396_1, reinterpret_tensor(buf517, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg395_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf519)
            del arg395_1
            del arg396_1
            assert_size_stride(arg399_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg399_1 = copy_if_misaligned(arg399_1)
            buf520 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_27, sin_27, linear_169, view_73, key_states_24, mul_222, x2_49, neg_49, x1_49, cat_98, mul_223, k_embed_24, key_tensors_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg399_1, buf519, arg4_1, arg3_1, arg5_1.item(), buf520, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg399_1
            assert_size_stride_grouped((arg398_1, arg397_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf521 = buf519; del buf519  # reuse
            # Topologically Sorted Source Nodes: [linear_170], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg398_1, reinterpret_tensor(buf517, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg397_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf521)
            del arg397_1
            del arg398_1
            assert_size_stride(arg400_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg400_1 = copy_if_misaligned(arg400_1)
            buf522 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_170, view_74, value_states_24, value_tensors_24], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg400_1, buf521, buf522, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg400_1
            buf523 = reinterpret_tensor(buf517, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf517  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_168, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_97, sin_27, mul_221, q_embed_24, packed_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf518, arg4_1, arg3_1, arg5_1.item(), buf523, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_168, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_97, sin_27, mul_221, q_embed_24, packed_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf524 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf523, buf520, buf522, None, False, scale=0.08838834764831845)
            buf525 = buf524[0]
            assert_tensor_metadata(buf525, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf525, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf524
            buf529 = buf523; del buf523  # reuse
            # Topologically Sorted Source Nodes: [attn_output_96], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf525, buf529, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg401_1, (1536, 1536), (1536, 1), 'input')
            buf530 = reinterpret_tensor(buf525, (s16, 1536), (1536, 1), 0); del buf525  # reuse
            # Topologically Sorted Source Nodes: [attn_output_96, transpose_100, reshape_74, attn_output_99], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf529, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg401_1, (1536, 1536), (1, 1536), 0), out=buf530)
            del arg401_1
            assert_size_stride_grouped((arg403_1, arg402_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf532 = reinterpret_tensor(buf529, (s16, 1, 1536), (1536, 1536, 1), 0); del buf529  # reuse
            # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_191, attn_output_99, hidden_states_195, pow_50, variance_49, rsqrt_49, hidden_states_197, hidden_states_198], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf509, buf515, buf530, arg403_1, arg402_1.item(), buf532, s16, 1536, stream=raw_stream0)
            del arg402_1
            del arg403_1
            assert_size_stride(arg404_1, (8960, 1536), (1536, 1), 'input')
            buf533 = reinterpret_tensor(buf514, (s16, 8960), (8960, 1), 0); del buf514  # reuse
            # Topologically Sorted Source Nodes: [linear_172], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf532, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg404_1, (1536, 8960), (1, 1536), 0), out=buf533)
            del arg404_1
            assert_size_stride(arg405_1, (8960, 1536), (1536, 1), 'input')
            buf534 = buf513; del buf513  # reuse
            # Topologically Sorted Source Nodes: [linear_173], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf532, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg405_1, (1536, 8960), (1, 1536), 0), out=buf534)
            del arg405_1
            buf535 = reinterpret_tensor(buf533, (s16, 1, 8960), (8960, 8960, 1), 0); del buf533  # reuse
            # Topologically Sorted Source Nodes: [linear_172, silu_24, linear_173, mul_226], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf535, buf534, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg406_1, (1536, 8960), (8960, 1), 'input')
            buf536 = reinterpret_tensor(buf532, (s16, 1536), (1536, 1), 0); del buf532  # reuse
            # Topologically Sorted Source Nodes: [linear_172, silu_24, linear_173, mul_226, down_proj_24], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf535, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg406_1, (8960, 1536), (1, 8960), 0), out=buf536)
            del arg406_1
            assert_size_stride_grouped((arg408_1, arg407_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf538 = reinterpret_tensor(buf518, (s16, 1, 1536), (1536, 1536, 1), 0); del buf518  # reuse
            # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_191, attn_output_99, hidden_states_195, down_proj_24, hidden_states_199, pow_51, variance_50, rsqrt_50, hidden_states_201, hidden_states_202], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf509, buf515, buf530, buf536, arg408_1, arg407_1.item(), buf538, s16, 1536, stream=raw_stream0)
            del arg407_1
            del arg408_1
            assert_size_stride_grouped((arg410_1, arg409_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf539 = buf487; del buf487  # reuse
            # Topologically Sorted Source Nodes: [linear_175], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg410_1, reinterpret_tensor(buf538, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg409_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf539)
            del arg409_1
            del arg410_1
            assert_size_stride_grouped((arg412_1, arg411_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf540 = buf521; del buf521  # reuse
            # Topologically Sorted Source Nodes: [linear_176], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg412_1, reinterpret_tensor(buf538, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg411_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf540)
            del arg411_1
            del arg412_1
            assert_size_stride(arg415_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg415_1 = copy_if_misaligned(arg415_1)
            buf541 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_28, sin_28, linear_176, view_76, key_states_25, mul_231, x2_51, neg_51, x1_51, cat_102, mul_232, k_embed_25, key_tensors_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg415_1, buf540, arg4_1, arg3_1, arg5_1.item(), buf541, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg415_1
            assert_size_stride_grouped((arg414_1, arg413_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf542 = buf540; del buf540  # reuse
            # Topologically Sorted Source Nodes: [linear_177], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg414_1, reinterpret_tensor(buf538, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg413_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf542)
            del arg413_1
            del arg414_1
            assert_size_stride(arg416_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg416_1 = copy_if_misaligned(arg416_1)
            buf543 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_177, view_77, value_states_25, value_tensors_25], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg416_1, buf542, buf543, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg416_1
            buf544 = reinterpret_tensor(buf538, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf538  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_175, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_101, sin_28, mul_230, q_embed_25, packed_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf539, arg4_1, arg3_1, arg5_1.item(), buf544, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf539
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_175, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_101, sin_28, mul_230, q_embed_25, packed_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf545 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf544, buf541, buf543, None, False, scale=0.08838834764831845)
            buf546 = buf545[0]
            assert_tensor_metadata(buf546, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf546, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf545
            buf550 = buf544; del buf544  # reuse
            # Topologically Sorted Source Nodes: [attn_output_100], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf546, buf550, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg417_1, (1536, 1536), (1536, 1), 'input')
            buf551 = reinterpret_tensor(buf546, (s16, 1536), (1536, 1), 0); del buf546  # reuse
            # Topologically Sorted Source Nodes: [attn_output_100, transpose_104, reshape_77, attn_output_103], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf550, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg417_1, (1536, 1536), (1, 1536), 0), out=buf551)
            del arg417_1
            assert_size_stride_grouped((arg419_1, arg418_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf552 = buf509; del buf509  # reuse
            buf554 = reinterpret_tensor(buf550, (s16, 1, 1536), (1536, 1536, 1), 0); del buf550  # reuse
            # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_191, attn_output_99, hidden_states_195, down_proj_24, hidden_states_199, attn_output_103, hidden_states_203, pow_52, variance_51, rsqrt_51, hidden_states_205, hidden_states_206], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf552, buf515, buf530, buf536, buf551, arg419_1, arg418_1.item(), buf554, s16, 1536, stream=raw_stream0)
            del arg418_1
            del arg419_1
            del buf515
            assert_size_stride(arg420_1, (8960, 1536), (1536, 1), 'input')
            buf555 = reinterpret_tensor(buf535, (s16, 8960), (8960, 1), 0); del buf535  # reuse
            # Topologically Sorted Source Nodes: [pow_52, variance_51, rsqrt_51, hidden_states_205, hidden_states_206, linear_179], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf554, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg420_1, (1536, 8960), (1, 1536), 0), out=buf555)
            del arg420_1
            assert_size_stride(arg421_1, (8960, 1536), (1536, 1), 'input')
            buf556 = buf534; del buf534  # reuse
            # Topologically Sorted Source Nodes: [linear_180], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf554, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg421_1, (1536, 8960), (1, 1536), 0), out=buf556)
            del arg421_1
            buf557 = reinterpret_tensor(buf555, (s16, 1, 8960), (8960, 8960, 1), 0); del buf555  # reuse
            # Topologically Sorted Source Nodes: [linear_179, silu_25, linear_180, mul_235], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf557, buf556, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg422_1, (1536, 8960), (8960, 1), 'input')
            buf558 = reinterpret_tensor(buf554, (s16, 1536), (1536, 1), 0); del buf554  # reuse
            # Topologically Sorted Source Nodes: [linear_179, silu_25, linear_180, mul_235, down_proj_25], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf557, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg422_1, (8960, 1536), (1, 8960), 0), out=buf558)
            del arg422_1
            assert_size_stride_grouped((arg424_1, arg423_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf560 = reinterpret_tensor(buf551, (s16, 1, 1536), (1536, 1536, 1), 0); del buf551  # reuse
            # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_207, pow_53, variance_52, rsqrt_52, hidden_states_209, hidden_states_210], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf552, buf558, arg424_1, arg423_1.item(), buf560, s16, 1536, stream=raw_stream0)
            del arg423_1
            del arg424_1
            assert_size_stride_grouped((arg426_1, arg425_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf561 = buf536; del buf536  # reuse
            # Topologically Sorted Source Nodes: [linear_182], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg426_1, reinterpret_tensor(buf560, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg425_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf561)
            del arg425_1
            del arg426_1
            assert_size_stride_grouped((arg428_1, arg427_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf562 = buf542; del buf542  # reuse
            # Topologically Sorted Source Nodes: [linear_183], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg428_1, reinterpret_tensor(buf560, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg427_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf562)
            del arg427_1
            del arg428_1
            assert_size_stride(arg431_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg431_1 = copy_if_misaligned(arg431_1)
            buf563 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_29, sin_29, linear_183, view_79, key_states_26, mul_240, x2_53, neg_53, x1_53, cat_106, mul_241, k_embed_26, key_tensors_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg431_1, buf562, arg4_1, arg3_1, arg5_1.item(), buf563, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg431_1
            assert_size_stride_grouped((arg430_1, arg429_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf564 = buf562; del buf562  # reuse
            # Topologically Sorted Source Nodes: [linear_184], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg430_1, reinterpret_tensor(buf560, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg429_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf564)
            del arg429_1
            del arg430_1
            assert_size_stride(arg432_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg432_1 = copy_if_misaligned(arg432_1)
            buf565 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_184, view_80, value_states_26, value_tensors_26], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg432_1, buf564, buf565, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg432_1
            buf566 = reinterpret_tensor(buf560, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf560  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_182, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_105, sin_29, mul_239, q_embed_26, packed_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf561, arg4_1, arg3_1, arg5_1.item(), buf566, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_182, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_105, sin_29, mul_239, q_embed_26, packed_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf567 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf566, buf563, buf565, None, False, scale=0.08838834764831845)
            buf568 = buf567[0]
            assert_tensor_metadata(buf568, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf568, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf567
            buf572 = buf566; del buf566  # reuse
            # Topologically Sorted Source Nodes: [attn_output_104], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf568, buf572, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg433_1, (1536, 1536), (1536, 1), 'input')
            buf573 = reinterpret_tensor(buf568, (s16, 1536), (1536, 1), 0); del buf568  # reuse
            # Topologically Sorted Source Nodes: [attn_output_104, transpose_108, reshape_80, attn_output_107], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf572, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg433_1, (1536, 1536), (1, 1536), 0), out=buf573)
            del arg433_1
            assert_size_stride_grouped((arg435_1, arg434_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf575 = reinterpret_tensor(buf572, (s16, 1, 1536), (1536, 1536, 1), 0); del buf572  # reuse
            # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_207, attn_output_107, hidden_states_211, pow_54, variance_53, rsqrt_53, hidden_states_213, hidden_states_214], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf552, buf558, buf573, arg435_1, arg434_1.item(), buf575, s16, 1536, stream=raw_stream0)
            del arg434_1
            del arg435_1
            assert_size_stride(arg436_1, (8960, 1536), (1536, 1), 'input')
            buf576 = reinterpret_tensor(buf557, (s16, 8960), (8960, 1), 0); del buf557  # reuse
            # Topologically Sorted Source Nodes: [linear_186], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf575, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg436_1, (1536, 8960), (1, 1536), 0), out=buf576)
            del arg436_1
            assert_size_stride(arg437_1, (8960, 1536), (1536, 1), 'input')
            buf577 = buf556; del buf556  # reuse
            # Topologically Sorted Source Nodes: [linear_187], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf575, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg437_1, (1536, 8960), (1, 1536), 0), out=buf577)
            del arg437_1
            buf578 = reinterpret_tensor(buf576, (s16, 1, 8960), (8960, 8960, 1), 0); del buf576  # reuse
            # Topologically Sorted Source Nodes: [linear_186, silu_26, linear_187, mul_244], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf578, buf577, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg438_1, (1536, 8960), (8960, 1), 'input')
            buf579 = reinterpret_tensor(buf575, (s16, 1536), (1536, 1), 0); del buf575  # reuse
            # Topologically Sorted Source Nodes: [linear_186, silu_26, linear_187, mul_244, down_proj_26], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf578, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg438_1, (8960, 1536), (1, 8960), 0), out=buf579)
            del arg438_1
            assert_size_stride_grouped((arg440_1, arg439_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf581 = reinterpret_tensor(buf561, (s16, 1, 1536), (1536, 1536, 1), 0); del buf561  # reuse
            # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_207, attn_output_107, hidden_states_211, down_proj_26, hidden_states_215, pow_55, variance_54, rsqrt_54, hidden_states_217, hidden_states_218], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf552, buf558, buf573, buf579, arg440_1, arg439_1.item(), buf581, s16, 1536, stream=raw_stream0)
            del arg439_1
            del arg440_1
            assert_size_stride_grouped((arg442_1, arg441_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf582 = buf530; del buf530  # reuse
            # Topologically Sorted Source Nodes: [linear_189], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg442_1, reinterpret_tensor(buf581, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg441_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf582)
            del arg441_1
            del arg442_1
            assert_size_stride_grouped((arg444_1, arg443_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf583 = buf564; del buf564  # reuse
            # Topologically Sorted Source Nodes: [linear_190], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg444_1, reinterpret_tensor(buf581, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg443_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf583)
            del arg443_1
            del arg444_1
            assert_size_stride(arg447_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg447_1 = copy_if_misaligned(arg447_1)
            buf584 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_30, sin_30, linear_190, view_82, key_states_27, mul_249, x2_55, neg_55, x1_55, cat_110, mul_250, k_embed_27, key_tensors_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg447_1, buf583, arg4_1, arg3_1, arg5_1.item(), buf584, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg447_1
            assert_size_stride_grouped((arg446_1, arg445_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf585 = buf583; del buf583  # reuse
            # Topologically Sorted Source Nodes: [linear_191], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg446_1, reinterpret_tensor(buf581, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg445_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf585)
            del arg445_1
            del arg446_1
            assert_size_stride(arg448_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg448_1 = copy_if_misaligned(arg448_1)
            buf586 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_191, view_83, value_states_27, value_tensors_27], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg448_1, buf585, buf586, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg448_1
            del buf585
            buf587 = reinterpret_tensor(buf581, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf581  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_189, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_109, sin_30, mul_248, q_embed_27, packed_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf582, arg4_1, arg3_1, arg5_1.item(), buf587, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg3_1
            del arg4_1
            del arg5_1
            del buf582
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_189, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_109, sin_30, mul_248, q_embed_27, packed_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf588 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf587, buf584, buf586, None, False, scale=0.08838834764831845)
            buf589 = buf588[0]
            assert_tensor_metadata(buf589, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf589, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf588
            buf593 = buf587; del buf587  # reuse
            # Topologically Sorted Source Nodes: [attn_output_108], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf589, buf593, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg449_1, (1536, 1536), (1536, 1), 'input')
            buf594 = reinterpret_tensor(buf589, (s16, 1536), (1536, 1), 0); del buf589  # reuse
            # Topologically Sorted Source Nodes: [attn_output_108, transpose_112, reshape_83, attn_output_111], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf593, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg449_1, (1536, 1536), (1, 1536), 0), out=buf594)
            del arg449_1
            assert_size_stride_grouped((arg451_1, arg450_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf595 = buf552; del buf552  # reuse
            buf597 = reinterpret_tensor(buf593, (s16, 1, 1536), (1536, 1536, 1), 0); del buf593  # reuse
            # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_207, attn_output_107, hidden_states_211, down_proj_26, hidden_states_215, attn_output_111, hidden_states_219, pow_56, variance_55, rsqrt_55, hidden_states_221, hidden_states_222], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf595, buf558, buf573, buf579, buf594, arg451_1, arg450_1.item(), buf597, s16, 1536, stream=raw_stream0)
            del arg450_1
            del arg451_1
            del buf558
            del buf573
            del buf579
            del buf594
            assert_size_stride(arg452_1, (8960, 1536), (1536, 1), 'input')
            buf598 = reinterpret_tensor(buf578, (s16, 8960), (8960, 1), 0); del buf578  # reuse
            # Topologically Sorted Source Nodes: [pow_56, variance_55, rsqrt_55, hidden_states_221, hidden_states_222, linear_193], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf597, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg452_1, (1536, 8960), (1, 1536), 0), out=buf598)
            del arg452_1
            assert_size_stride(arg453_1, (8960, 1536), (1536, 1), 'input')
            buf599 = buf577; del buf577  # reuse
            # Topologically Sorted Source Nodes: [linear_194], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf597, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg453_1, (1536, 8960), (1, 1536), 0), out=buf599)
            del arg453_1
            buf600 = reinterpret_tensor(buf598, (s16, 1, 8960), (8960, 8960, 1), 0); del buf598  # reuse
            # Topologically Sorted Source Nodes: [linear_193, silu_27, linear_194, mul_253], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf600, buf599, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            del buf599
            assert_size_stride(arg454_1, (1536, 8960), (8960, 1), 'input')
            buf601 = reinterpret_tensor(buf597, (s16, 1536), (1536, 1), 0); del buf597  # reuse
            # Topologically Sorted Source Nodes: [linear_193, silu_27, linear_194, mul_253, down_proj_27], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf600, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg454_1, (8960, 1536), (1, 8960), 0), out=buf601)
            del arg454_1
            del buf600
            assert_size_stride_grouped((arg456_1, arg455_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf603 = reinterpret_tensor(buf595, (s16, 1, 1536), (1536, 1536, 1), 0); del buf595  # reuse
            # Topologically Sorted Source Nodes: [down_proj_27, hidden_states_223, pow_57, variance_56, rsqrt_56, hidden_states_225, hidden_states_226], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14.run(buf603, buf601, arg456_1, arg455_1.item(), s16, 1536, stream=raw_stream0)
            del arg455_1
            del arg456_1
            del buf601
            buf604 = empty_strided_cuda((s16, 152265), (152265, 1), torch.float32)
            # Topologically Sorted Source Nodes: [down_proj_27, hidden_states_223, pow_57, variance_56, rsqrt_56, hidden_states_225, hidden_states_226, getitem_1768, logits], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.slice, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf603, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg2_1, (1536, 152265), (1, 1536), 0), out=buf604)
            del arg2_1
            del buf603
        return (buf6, buf4, buf27, buf25, buf49, buf47, buf70, buf68, buf92, buf90, buf113, buf111, buf135, buf133, buf156, buf154, buf178, buf176, buf199, buf197, buf221, buf219, buf242, buf240, buf264, buf262, buf285, buf283, buf307, buf305, buf328, buf326, buf350, buf348, buf371, buf369, buf393, buf391, buf414, buf412, buf436, buf434, buf457, buf455, buf479, buf477, buf500, buf498, buf522, buf520, buf543, buf541, buf565, buf563, buf586, buf584, reinterpret_tensor(buf604, (s16, 1, 152265), (152265, 152265, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = 50
    arg1_1 = rand_strided((50, 1), (1, 1), device='cuda:0', dtype=torch.int64)
    arg2_1 = rand_strided((152265, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg3_1 = rand_strided((50, 1), (1, 1), device='cuda:0', dtype=torch.int64)
    arg4_1 = rand_strided((64, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg5_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg6_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg7_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg8_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg9_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg10_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg11_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg12_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg13_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg14_1 = 50
    arg15_1 = 76
    arg16_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg17_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg18_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg19_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg20_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg21_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg22_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg23_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg24_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg25_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg26_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg27_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg28_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg29_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg30_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg31_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg32_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg33_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg34_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg35_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg36_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg37_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg38_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg39_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg40_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg41_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg42_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg43_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg44_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg45_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg46_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg47_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg48_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg49_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg50_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg51_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg52_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg53_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg54_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg55_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg56_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg57_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg58_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg59_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg60_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg61_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg62_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg63_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg64_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg65_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg66_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg67_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg68_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg69_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg70_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg71_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg72_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg73_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg74_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg75_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg76_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg77_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg78_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg79_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg80_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg81_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg82_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg83_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg84_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg85_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg86_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg87_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg88_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg89_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg90_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg91_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg92_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg93_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg94_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg95_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg96_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg97_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg98_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg99_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg100_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg101_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg102_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg103_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg104_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg105_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg106_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg107_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg108_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg109_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg110_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg111_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg112_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg113_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg114_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg115_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg116_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg117_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg118_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg119_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg120_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg121_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg122_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg123_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg124_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg125_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg126_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg127_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg128_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg129_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg130_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg131_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg132_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg133_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg134_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg135_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg136_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg137_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg138_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg139_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg140_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg141_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg142_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg143_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg144_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg145_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg146_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg147_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg148_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg149_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg150_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg151_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg152_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg153_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg154_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg155_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg156_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg157_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg158_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg159_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg160_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg161_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg162_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg163_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg164_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg165_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg166_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg167_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg168_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg169_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg170_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg171_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg172_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg173_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg174_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg175_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg176_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg177_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg178_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg179_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg180_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg181_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg182_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg183_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg184_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg185_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg186_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg187_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg188_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg189_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg190_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg191_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg192_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg193_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg194_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg195_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg196_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg197_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg198_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg199_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg200_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg201_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg202_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg203_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg204_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg205_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg206_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg207_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg208_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg209_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg210_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg211_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg212_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg213_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg214_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg215_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg216_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg217_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg218_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg219_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg220_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg221_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg222_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg223_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg224_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg225_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg226_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg227_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg228_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg229_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg230_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg231_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg232_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg233_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg234_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg235_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg236_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg237_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg238_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg239_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg240_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg241_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg242_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg243_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg244_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg245_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg246_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg247_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg248_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg249_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg250_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg251_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg252_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg253_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg254_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg255_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg256_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg257_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg258_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg259_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg260_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg261_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg262_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg263_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg264_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg265_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg266_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg267_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg268_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg269_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg270_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg271_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg272_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg273_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg274_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg275_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg276_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg277_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg278_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg279_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg280_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg281_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg282_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg283_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg284_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg285_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg286_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg287_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg288_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg289_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg290_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg291_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg292_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg293_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg294_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg295_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg296_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg297_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg298_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg299_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg300_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg301_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg302_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg303_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg304_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg305_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg306_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg307_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg308_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg309_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg310_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg311_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg312_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg313_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg314_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg315_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg316_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg317_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg318_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg319_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg320_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg321_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg322_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg323_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg324_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg325_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg326_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg327_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg328_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg329_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg330_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg331_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg332_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg333_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg334_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg335_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg336_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg337_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg338_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg339_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg340_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg341_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg342_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg343_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg344_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg345_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg346_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg347_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg348_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg349_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg350_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg351_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg352_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg353_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg354_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg355_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg356_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg357_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg358_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg359_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg360_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg361_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg362_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg363_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg364_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg365_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg366_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg367_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg368_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg369_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg370_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg371_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg372_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg373_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg374_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg375_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg376_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg377_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg378_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg379_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg380_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg381_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg382_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg383_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg384_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg385_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg386_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg387_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg388_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg389_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg390_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg391_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg392_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg393_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg394_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg395_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg396_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg397_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg398_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg399_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg400_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg401_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg402_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg403_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg404_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg405_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg406_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg407_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg408_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg409_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg410_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg411_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg412_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg413_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg414_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg415_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg416_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg417_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg418_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg419_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg420_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg421_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg422_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg423_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg424_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg425_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg426_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg427_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg428_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg429_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg430_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg431_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg432_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg433_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg434_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg435_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg436_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg437_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg438_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg439_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg440_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg441_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg442_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg443_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg444_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg445_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg446_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg447_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg448_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg449_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg450_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg451_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg452_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg453_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg454_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg455_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg456_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg457_1 = 1
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
