"""Same-agent raw-row cross-check; does not rerun or replace the frozen audit."""
import hashlib
import json
from pathlib import Path
import statistics
import struct
from export_precision import summary

BASE=Path(__file__).resolve().parents[2]
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
V=('folded_fp32','folded_tf32')


def main():
    s=read(BASE/'outputs/rapidtinyrec_precision_paired_staged_status.json')
    a=read(s['audit_result']);summary(a)
    root=Path(s['harness'])/'.oscar/results'/s['run_id']/'outputs'
    joined={}
    for phase in range(4):
        rows=read(root/f'phase_{phase}'/'requests.json');assert len(rows)==12
        for row in rows:
            key=(row['repeat'],row['cohort_index']);runs=joined.setdefault(key,{})
            assert row['variant'] not in runs;runs[row['variant']]=row['run']
    assert len(joined)==24 and all(set(r)==set(V) for r in joined.values())
    def latency(items):
        result={}
        for v in V:
            values=[1000*r[v]['elapsed_s'] for r in items]
            result[v]=dict(n=len(values),median_ms=statistics.median(values),p95_ms=statistics.quantiles(values,n=100,method='inclusive')[94])
        return result
    assert latency(joined.values())==a['latency_ms']
    ranks=sum(x==y for r in joined.values() for x,y in zip(r[V[0]]['token_ids'],r[V[1]]['token_ids']))
    assert ranks==a['comparison']['matching_rank_positions']==1182
    bits=lambda x:struct.pack('!f',x)
    for key,width in [('sequence_logp',50),('transition_logp',250)]:
        def values(run):
            return run[key] if width==50 else [x for row in run[key] for x in row]
        matches=sum(bits(x)==bits(y) for r in joined.values() for x,y in zip(values(r[V[0]]),values(r[V[1]])))
        assert matches==0
    per_user={}
    for user in (1,2,6,10):
        rows=[r for (repeat,u),r in joined.items() if u==user]
        timing=latency(rows)
        per_user[str(user)]=dict(latency_ms=timing,paired_generation_delta_ms=[1000*(r[V[1]]['elapsed_s']-r[V[0]]['elapsed_s']) for r in rows])
        assert all(r[V[1]]['elapsed_s']<r[V[0]]['elapsed_s'] for r in rows)
    for user in a['quality']['per_user']:
        assert all(x==0 for m in user['paired_changes'].values() for x in m.values())
    child=a['provenance']['wrapper']['child'];assert child['completed_normally'] and child['elapsed_s']<1620
    review=dict(schema='precision-paired-staged-review-v1',reviewer='Same-agent diagnostic cross-check, not an independent reviewer',
        run_id=s['run_id'],job_id=s['job_id'],scheduler_state=s['scheduler_state'],audit_sha256=sha(s['audit_result']),
        integrity_audit_passed=True,eligible_for_full_quality_review=a['eligible_for_full_quality_review'],promotion=False,noninferiority_established=False,
        decision='PILOT_GATES_PASSED_DESIGN_SEPARATE_FULL500_REVIEW',
        latency_ms=a['latency_ms'],reductions_percent=a['reductions_percent'],per_user_latency=per_user,
        candidate_fidelity=a['comparison'],unique_rank_matches=197,unique_rank_positions=200,changed_ranking_user=6,
        quality='All four unique users have unchanged Hit/NDCG/MRR at1/5/10/20/50; one user ranking differs. No observed primary regression in this tiny cohort.',
        uncertainty='Zero bootstrap intervals result from resampling four observed zero metric deltas; they do not demonstrate population parity or noninferiority. No numeric quality-loss margin accepted.',
        scope='24pairedrequests,4uniqueusers,6repeats/user; SID-level only, all four targets unambiguous. No full500 results, production promotion, logging-causality claim or compounded historical speedup.',
        setup_s_by_phase=[p['setup_s'] for p in a['phases']],child_elapsed_s=child['elapsed_s'],
        follow_up='Publish complete evidence, then design/freeze separate full500 schedule/profile/allocated-compute quality audit/budget/guard. Do not reuse this submitted guard or automatically launch another job.')
    dest=BASE/'outputs/quality_frontier/precision-paired-staged-independent-review.json'
    with dest.open('x') as f:json.dump(review,f,indent=2);f.write('\n')
    print(json.dumps(review,indent=2))


if __name__=='__main__':main()
