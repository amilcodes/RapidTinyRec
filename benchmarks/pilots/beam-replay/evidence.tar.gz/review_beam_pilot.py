"""Independent standard-library review of immutable beam pilot evidence."""
import collections,datetime,gzip,hashlib,json,math,statistics,struct
from pathlib import Path
B=Path(__file__).resolve().parents[2]
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def flatten(x):return [v for row in x for v in flatten(row)] if isinstance(x,list) else [x]
def floats(x):return b''.join(struct.pack('<f',v) for v in flatten(x))
def stats(x):
 x=sorted(x);q=(len(x)-1)*.95;i=int(q)
 return dict(n=len(x),median_ms=statistics.median(x),p95_ms=x[i]+(x[min(i+1,len(x)-1)]-x[i])*(q-i))
s=read(B/'outputs/rapidtinyrec_beam_replay_pilot_status.json');a=read(Path(s['audit_result']));raw=Path(s['harness'])/'.oscar/results'/s['run_id'];root=raw/'outputs';snap=Path(s['source_snapshot'])
record=read(Path(s['harness'])/'.oscar/runs'/(s['run_id']+'.json'))
assert all(sha(snap/n)==h for n,h in record['sha256'].items())
assert read(raw/'source-manifest.json')['sha256']==record['sha256']
assert read(snap/'.submission-config.json')==read(snap/s['config'])
manifest=read(Path(s['raw_manifest']));assert all(sha(raw/f['path'])==f['sha256'] and not ((raw/f['path']).stat().st_mode&0o222) for f in manifest['files'])
historical=Path(s['audit_command'][s['audit_command'].index('--historical')+1]);paired={};counts=collections.Counter();mem=[];probe_counts=collections.Counter();details=[]
def equal(left,right,label):
 assert left['token_ids']==right['token_ids'],label+' ranks'
 assert floats(left['sequence_logp'])==floats(right['sequence_logp']),label+' sequence'
 assert floats(left['transition_logp'])==floats(right['transition_logp']),label+' transitions'
 counts[label]+=1
for phase in range(4):
 p=root/f'phase_{phase}';rows=read(p/'requests.json');setup=read(p/'setup.json');summary=read(p/'summary.json');comp=read(p/'compilation.json');variant='beam_replay' if phase in (1,2) else 'folded_prefix_replay'
 assert comp['measurement_compilations']==0
 assert setup['replay']['events']==summary['replay']['events'] and summary['replay']['graphs']==8 and summary['replay']['frozen']
 for r in rows:
  pair=paired.setdefault((r['repeat'],r['cohort_index']),dict(prompt_tokens=r['prompt_tokens'],half=r['repeat']//3))
  pair[variant]=r['run'];equal(read(historical/'users'/f"{r['cohort_index']:04d}.json")['runs']['compiled_gqa'],r['run'],'timed_historical')
 for f in (p/'warmup_outputs').glob('*.json'):
  index=int(f.name.split('_')[0]);equal(read(historical/'users'/f'{index:04d}.json')['runs']['compiled_gqa'],read(f),'warm_historical')
 mem.append(dict(phase=phase,measurement=summary['memory'],setup=setup['memory']))
 if phase not in (1,2):continue
 report=summary['beam_replay'];before=setup['beam_replay'];assert report['events']==before['events'] and report['graphs']==20 and report['frozen'];assert report['disjoint_step_storage'] and not report['active_request'] and not report['aborted_requests']
 assert report['requests']-before['requests']==12 and report['replays']-before['replays']==120
 assert report['staged_bytes']-before['staged_bytes']==6*report['input_logical_bytes']
 owners=read(p/'score_ownership.json');assert len(owners)==20
 for o in owners:
  assert o['distinct_helper_output_storages']==35 and o['distinct_saved_score_storages']==5 and o['saved_outputs_independent_of_graphs'] and o['lease_open_during_extraction']
  for c in o['final_output_comparisons']:assert c['matching_bits']==c['values'] and c['left_sha256']==c['right_sha256'] and c['max_abs_finite']==0
 probe=read(p/'beam_probe.json');assert sha(p/probe['raw_outputs_file'])==probe['raw_outputs_sha256']
 with gzip.open(p/probe['raw_outputs_file'],'rt') as f:
  rows_raw=[json.loads(line) for line in f]
 assert len(rows_raw)==280
 for r in rows_raw:
  for category,field,other in [('graph_direct','comparisons','graph'),('direct_repeat','direct_repeat_comparisons','direct_repeat')]:
   for l,t,c in zip(r['direct'],r[other],r[field]):
    fmt={'torch.float32':'f','torch.int64':'q','torch.int32':'i','torch.bool':'?'}[c['dtype']]
    pack=lambda x:b''.join(struct.pack('<'+fmt,v) for v in flatten(x))
    lb,tb=pack(l),pack(t);assert lb==tb
    assert hashlib.sha256(lb).hexdigest()==c['left_sha256']==c['right_sha256']
    assert c['matching_bits']==c['values']==len(flatten(l));probe_counts[category]+=c['values']
 for r in probe['retained_after_five_steps']:
  assert r['independent_step_outputs']
  for c in r['comparisons']:
   assert c['values']==c['matching_bits'] and c['max_abs_finite']==0 and c['left_sha256']==c['right_sha256'];probe_counts['retained']+=c['values']
for pair in paired.values():equal(pair['folded_prefix_replay'],pair['beam_replay'],'paired')
assert counts['paired']==24 and counts['timed_historical']==48 and counts['warm_historical']==48
variants=('folded_prefix_replay','beam_replay');timing={v:stats([p[v]['elapsed_s']*1000 for p in paired.values()]) for v in variants};assert timing==a['latency_ms']
for half in (0,1):
 for n in (76,121):
  ps=[p for p in paired.values() if p['half']==half and p['prompt_tokens']==n];t={v:stats([p[v]['elapsed_s']*1000 for p in ps]) for v in variants}
  delta=[(p[variants[0]]['elapsed_s']-p[variants[1]]['elapsed_s'])*1000 for p in ps]
  details.append(dict(half=half,prompt_tokens=n,latency_ms=t,candidate_faster_requests=sum(d>0 for d in delta),paired_median_saving_ms=statistics.median(delta)))
assert all(d['latency_ms'][variants[1]][k]<d['latency_ms'][variants[0]][k] for d in details for k in ('median_ms','p95_ms'))
assert a['integrity_audit_passed'] and a['exactness_passed'] and a['beam_probe_exact'] and a['final_outputs_exact']
review=dict(run_id=s['run_id'],reviewed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_files_verified=len(record['sha256']),raw_files_verified=len(manifest['files']),independent_output_comparisons=dict(counts),raw_probe_bit_comparisons=dict(probe_counts),latency_ms=timing,latency_by_length_and_half=details,memory=mem,
 performance_gate=True,full500_authorized_by_gate=True,decision='Proceed to one same-source full500: exact ranks/sequence/transition bits and ownership pass; median improves 0.509ms (0.438%) and p95 1.658ms (1.369%), with median/p95 lower in both lengths, both halves and every length-by-half stratum, for 3,182,080 additional allocated bytes. Benefit is modest and one length/half has a negative median paired-request saving; this is a reason to validate once on 500 users, not a confirmed general speedup.',
 limits='Four independent users and six repeats; one ABBA allocation. Phase aggregate median/p95 are lower, but only 16/24 individual pairs are faster; half0 length121 paired median saving is -0.089228ms. No statistical or population quality equivalence claim. Setup is nested and excluded from generation.',
 audit_revision=dict(commit=s['audit_revision_commit'],original_failure=s['original_audit'],correction=s['audit_correction']),
 quality=a['quality'],measurement_compilations=0,measurement_captures=0,actual_model_graphs=8,actual_helper_graphs=20,minimum_helper_input_output_bytes=3112010)
p=B/'outputs/rapidtinyrec_beam_replay_pilot_independent_review.json';p.write_text(json.dumps(review,indent=2)+'\n')
s.update(status='PILOT_PASSED_AUDITED_PENDING_FULL500',integrity_audit_passed=True,exactness_passed=True,performance_gate=True,full500_authorized_by_gate=True,independent_review=str(p),decision=review['decision'],next_action='Publish pilot evidence and submit one guarded same-source full500 comparison; no new candidate.',updated_at_utc=review['reviewed_at_utc']);(B/'outputs/rapidtinyrec_beam_replay_pilot_status.json').write_text(json.dumps(s,indent=2)+'\n')
l=B/'outputs/rapidtinyrec_research_loop_state.json';d=read(l);d.update(active_experiment=s,current_gpu_job=None,remaining_gpu_job=None,updated_at_utc=review['reviewed_at_utc'],next_action=s['next_action'],full500_disposition=review['decision']);l.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:review[k] for k in ('independent_output_comparisons','raw_probe_bit_comparisons','performance_gate','decision')},indent=2))
