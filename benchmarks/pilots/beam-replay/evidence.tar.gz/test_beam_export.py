import copy
import io
from pathlib import Path
import tarfile
import tempfile
import unittest

from export_beam_replay import export_pair, summary, write_archive, export_probes, VARIANTS


def pair():
    run = dict(elapsed_s=0.1, token_ids=[[i, 2, 3, 198, 151645] for i in range(50)],
               sequence_logp=[-float(i) for i in range(50)],
               transition_logp=[[-float(i), 0., 0., 0., 0.] for i in range(50)])
    return dict(repeat=0, cohort_index=1, prompt_tokens=76,
                phases={VARIANTS[0]: 0, VARIANTS[1]: 1},
                runs={VARIANTS[0]: run, VARIANTS[1]: copy.deepcopy(run)})


class BeamExportTests(unittest.TestCase):
    def test_signed_zero_mismatch_is_preserved(self):
        p = pair(); p['runs'][VARIANTS[1]]['sequence_logp'][0] = 0.
        row = export_pair(p)
        self.assertEqual(row['matching_sequence_values'], 49)
        self.assertEqual(row['max_sequence_difference_at_rank'], 0.)
        self.assertNotEqual(row[VARIANTS[0] + '_sequence_logp_sha256'], row[VARIANTS[1] + '_sequence_logp_sha256'])

    def test_rank_change_and_common_candidate_deltas_are_distinct(self):
        p = pair(); candidate = p['runs'][VARIANTS[1]]
        for field in ('token_ids', 'sequence_logp', 'transition_logp'):
            candidate[field][0], candidate[field][1] = candidate[field][1], candidate[field][0]
        row = export_pair(p)
        self.assertEqual(row['matching_rank_positions'], 48)
        self.assertEqual(row['max_sequence_difference_at_rank'], 1.)
        self.assertEqual(row['max_sequence_difference_common'], 0.)

    def test_negative_probe_gate_survives_even_with_exact_pairs(self):
        row = export_pair(pair())
        audit = dict(integrity_audit_passed=True, paired_requests=1, unique_users=1,
                     exactness_passed=False, beam_probe_exact=False,
                     comparison={k: row[k] for k in ('matching_rank_positions', 'matching_sequence_values', 'matching_transition_values')},
                     quality={'paired_mean_changes': {'1': {'hit_rate': -0.25}}})
        audit['comparison']['matching_rank_lists'] = 1
        result = summary(audit, [row])
        self.assertFalse(result['exactness_passed'])
        self.assertFalse(result['beam_probe_exact'])
        self.assertEqual(result['quality'], audit['quality'])
        bad = copy.deepcopy(audit); bad['comparison']['matching_sequence_values'] -= 1
        with self.assertRaises(AssertionError): summary(bad, [row])

    def test_archive_is_deterministic_and_retains_raw_bytes(self):
        entries = {'raw/failure.json': b'{"matching_bits":0}\n', 'source-snapshot/source.py': b'print("source")\n'}
        with tempfile.TemporaryDirectory() as directory:
            paths = [Path(directory) / name for name in ('a.tar.gz', 'b.tar.gz')]
            for path in paths: write_archive(path, entries)
            self.assertEqual(paths[0].read_bytes(), paths[1].read_bytes())
            with tarfile.open(fileobj=io.BytesIO(paths[0].read_bytes()), mode='r:gz') as archive:
                self.assertEqual({p.name: archive.extractfile(p).read() for p in archive.getmembers()}, entries)

    def test_probe_index_drift_and_retained_corruption_are_preserved(self):
        probe=dict(graph_direct=[],retained_after_five_steps=[])
        for scenario in range(7):
            for request in range(4):
                for step in range(5):
                    for helper,count in (('_get_running_beams_for_next_iteration',3),('_update_finished_beams',4)):
                        c=dict(dtype='torch.int32',shape=[1,50,8],values=400,matching_bits=400,max_abs_finite=0.,
                            finite_mask_equal=True,no_nan=True,left_sha256='a'*64,right_sha256='a'*64)
                        row=dict(scenario=str(scenario),request=request,prompt_tokens=76,step=step,method=helper,
                            comparisons=[copy.deepcopy(c) for _ in range(count)],
                            direct_repeat_comparisons=[copy.deepcopy(c) for _ in range(count)])
                        probe['graph_direct'].append(row)
                        probe['retained_after_five_steps'].append(dict(copy.deepcopy(row),independent_step_outputs=True))
        for field,comparisons in (('graph_direct','comparisons'),('graph_direct','direct_repeat_comparisons'),('retained_after_five_steps','comparisons')):
            c=probe[field][0][comparisons][-1];c.update(matching_bits=399,max_abs_finite=1.,right_sha256='b'*64)
        totals=dict(values=980*400,matching_bits=980*400-1,max_abs_finite=1.)
        audited={k:totals for k in ('graph_direct','direct_repeated','retained_after_five_steps')}
        rows=export_probes(probe,1,audited)
        self.assertEqual(len(rows),2940)
        self.assertEqual(sum(r['matching_bits']!=r['values'] for r in rows),3)
        self.assertEqual({r['dtype'] for r in rows},{'torch.int32'})
        bad=copy.deepcopy(probe);bad['retained_after_five_steps'].pop()
        with self.assertRaises(AssertionError):export_probes(bad,1,audited)


if __name__ == '__main__':
    unittest.main()
