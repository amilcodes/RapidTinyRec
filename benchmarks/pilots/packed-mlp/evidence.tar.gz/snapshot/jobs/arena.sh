#!/bin/bash
set -euo pipefail
test -n "${SLURM_JOB_ID:-}"
export TORCHINDUCTOR_COMPILE_THREADS=4
export TORCH_LOGS=recompiles
for phase in 0 1 2 3; do
    export TORCHINDUCTOR_CACHE_DIR="$OSCAR_RUN_DIR/compile-cache/phase-$phase/inductor"
    export TRITON_CACHE_DIR="$OSCAR_RUN_DIR/compile-cache/phase-$phase/triton"
    test ! -e "$TORCHINDUCTOR_CACHE_DIR"
    /oscar/scratch/aagraw73/minionerec-shared-prefill/envs/torch214-cu126-transformers4554/bin/python -u -m rapidtinyrec.benchmark_input_arena \
        --release-root /oscar/scratch/aagraw73/minionerec-shared-prefill/release \
        --reference-results /oscar/scratch/aagraw73/agent-runs/minionerec-shared-prefill/benchmark-gqa-fp32-20261023T054059Z-7b4f0ee334cb/outputs/gqa_500_users \
        --output-root "$OSCAR_OUTPUT_DIR" --phase "$phase" "$@"
done
