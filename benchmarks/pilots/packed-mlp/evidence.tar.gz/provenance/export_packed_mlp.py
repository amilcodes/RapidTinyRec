"""Export independently audited packed-mlp results without user histories."""
import argparse,csv,hashlib,json,struct
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]
read=lambda p:json.loads(p.read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
p=argparse.ArgumentParser();p.add_argument('run');p.add_argument('--audit',type=Path,required=True);p.add_argument('--commit',required=True);a=p.parse_args()
ROOT=BASE/'work/rapidtinyrec_replay/.oscar/results'/a.run/'outputs'
audit=read(a.audit);assert audit['integrity_audit_passed']
full=audit['unique_users']==500
OUT=BASE/'RapidTinyRec/benchmarks'/('results' if full else 'pilots')/'packed-mlp';OUT.mkdir(parents=True,exist_ok=True)
variants=['folded_prefix_replay','packed_mlp_replay'];joined={}
for phase in range(4):
 for row in read(ROOT/f'phase_{phase}/requests.json'):
  key=(row['repeat'],row['cohort_index']);r=joined.setdefault(key,{k:row[k] for k in ['repeat','cohort_index','prompt_tokens']})
  r[row['variant']]=row['run'];r[row['variant']+'_phase']=phase
exported=[]
for key in sorted(joined):
 row=joined[key];r={k:row[k] for k in ['cohort_index','prompt_tokens','repeat']}
 for v in variants:
  run=row[v];r[v+'_phase']=row[v+'_phase'];r[v+'_ms']=run['elapsed_s']*1000
  r[v+'_ranking_sha256']=sha(json.dumps(run['token_ids'],separators=(',',':')).encode())
  for field in ['sequence_logp','transition_logp']:
   values=run[field] if field=='sequence_logp' else [x for part in run[field] for x in part]
   r[v+'_'+field+'_sha256']=sha(b''.join(struct.pack('!f',x) for x in values))
 left,right=[row[v] for v in variants]
 r['matching_rank_positions']=sum(x==y for x,y in zip(left['token_ids'],right['token_ids']))
 for field,label in [('sequence_logp','sequence'),('transition_logp','transition')]:
  values=[run[field] if field=='sequence_logp' else [x for part in run[field] for x in part] for run in (left,right)]
  r['matching_'+label+'_values']=sum(struct.pack('!f',x)==struct.pack('!f',y) for x,y in zip(*values))
  r['max_'+label+'_difference']=max(abs(x-y) for x,y in zip(*values))
 exported.append(r)
with (OUT/'requests.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(exported[0]),lineterminator='\n');w.writeheader();w.writerows(exported)
summary={'experiment':'packed-mlp','experiment_date':'2026-10-24','hardware':'NVIDIA RTX A6000','dtype':'float32','tf32':False,
 'exactness_passed':audit['exactness_passed'],'users':audit['unique_users'],'paired_requests':audit['paired_requests'],'beams':50,'cohort_sha256':audit['cohort_sha256'],
 'control':variants[0],'candidate':variants[1],'requests_sha256':sha((OUT/'requests.csv').read_bytes()),
 'latency_ms':{v:{'median':audit['latency_ms'][v]['median_ms'],'p95':audit['latency_ms'][v]['p95_ms']} for v in variants},
 'matching_rank_lists':sum(r['matching_rank_positions']==50 for r in exported),
 'phases':audit['phases'],'scope':audit['note'],'measurement_compilations':0,'measurement_captures':0}
for k in ['matching_rank_positions','matching_sequence_values','matching_transition_values']:
 summary[k]=sum(r[k] for r in exported);assert summary[k]==audit['comparison'][k]
for label in ['sequence','transition']:summary['max_'+label+'_difference']=max(r['max_'+label+'_difference'] for r in exported)
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
record=read(BASE/'work/rapidtinyrec_replay/.oscar/runs'/f'{a.run}.json')
source={'run_id':a.run,'measured_repository_commit':a.commit,'submitted_source_sha256':record['sha256'],
 'raw_output_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in ROOT.rglob('*.json')},
 'published_source_sha256':{name:sha((BASE/'RapidTinyRec'/name).read_bytes()) for name in record['sha256'] if name.startswith('rapidtinyrec/')},
 'evidence_sha256':{p.name:sha(p.read_bytes()) for p in OUT.iterdir() if p.is_file() and p.name!='source.json'}}
for name,value in source['published_source_sha256'].items():assert value==record['sha256'][name],name
(OUT/'source.json').write_text(json.dumps(source,indent=2)+'\n')
print(f'Exported {len(exported)} pairs to {OUT}')
