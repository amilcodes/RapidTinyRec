import copy
import io
from pathlib import Path
import tarfile
import tempfile
import unittest

from export_constraint_replay import export_pair, summary, write_archive, VARIANTS


def pair():
    run = dict(elapsed_s=0.1, token_ids=[[i, 2, 3, 198, 151645] for i in range(50)],
               sequence_logp=[-float(i) for i in range(50)],
               transition_logp=[[-float(i), 0., 0., 0., 0.] for i in range(50)])
    return dict(repeat=0, cohort_index=1, prompt_tokens=76,
                phases={VARIANTS[0]: 0, VARIANTS[1]: 1},
                runs={VARIANTS[0]: run, VARIANTS[1]: copy.deepcopy(run)})


class ConstraintExportTests(unittest.TestCase):
    def test_signed_zero_mismatch_is_preserved(self):
        p = pair(); p['runs'][VARIANTS[1]]['sequence_logp'][0] = 0.
        row = export_pair(p)
        self.assertEqual(row['matching_sequence_values'], 49)
        self.assertEqual(row['max_sequence_difference_at_rank'], 0.)
        self.assertNotEqual(row[VARIANTS[0] + '_sequence_logp_sha256'], row[VARIANTS[1] + '_sequence_logp_sha256'])

    def test_rank_change_and_common_candidate_deltas_are_distinct(self):
        p = pair(); candidate = p['runs'][VARIANTS[1]]
        for field in ('token_ids', 'sequence_logp', 'transition_logp'):
            candidate[field][0], candidate[field][1] = candidate[field][1], candidate[field][0]
        row = export_pair(p)
        self.assertEqual(row['matching_rank_positions'], 48)
        self.assertEqual(row['max_sequence_difference_at_rank'], 1.)
        self.assertEqual(row['max_sequence_difference_common'], 0.)

    def test_negative_probe_gate_survives_even_with_exact_pairs(self):
        row = export_pair(pair())
        audit = dict(integrity_audit_passed=True, paired_requests=1, unique_users=1,
                     exactness_passed=False, constraint_probe_exact=False,
                     comparison={k: row[k] for k in ('matching_rank_positions', 'matching_sequence_values', 'matching_transition_values')},
                     quality={'paired_mean_changes': {'1': {'hit_rate': -0.25}}})
        audit['comparison']['matching_rank_lists'] = 1
        result = summary(audit, [row])
        self.assertFalse(result['exactness_passed'])
        self.assertFalse(result['constraint_probe_exact'])
        self.assertEqual(result['quality'], audit['quality'])
        bad = copy.deepcopy(audit); bad['comparison']['matching_sequence_values'] -= 1
        with self.assertRaises(AssertionError): summary(bad, [row])

    def test_archive_is_deterministic_and_retains_raw_bytes(self):
        entries = {'raw/failure.json': b'{"matching_bits":0}\n', 'source-snapshot/source.py': b'print("source")\n'}
        with tempfile.TemporaryDirectory() as directory:
            paths = [Path(directory) / name for name in ('a.tar.gz', 'b.tar.gz')]
            for path in paths: write_archive(path, entries)
            self.assertEqual(paths[0].read_bytes(), paths[1].read_bytes())
            with tarfile.open(fileobj=io.BytesIO(paths[0].read_bytes()), mode='r:gz') as archive:
                self.assertEqual({p.name: archive.extractfile(p).read() for p in archive.getmembers()}, entries)


if __name__ == '__main__':
    unittest.main()
