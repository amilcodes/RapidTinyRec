"""Publish audited constraint-replay evidence, retaining negative exactness results."""
import argparse
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import struct
import tarfile
import tempfile

BASE = Path(__file__).resolve().parents[2]
VARIANTS = ('folded_prefix_replay', 'constraint_replay')


def read(path):
    return json.loads(path.read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def flatten(run, field):
    return run[field] if field == 'sequence_logp' else [x for row in run[field] for x in row]


def bit_bytes(values):
    return b''.join(struct.pack('!f', value) for value in values)


def export_pair(pair):
    row = {k: pair[k] for k in ('repeat', 'cohort_index', 'prompt_tokens')}
    for variant in VARIANTS:
        run = pair['runs'][variant]
        row[variant + '_phase'] = pair['phases'][variant]
        row[variant + '_ms'] = run['elapsed_s'] * 1000
        row[variant + '_ranking_sha256'] = digest(json.dumps(run['token_ids'], separators=(',', ':')).encode())
        for field in ('sequence_logp', 'transition_logp'):
            row[variant + '_' + field + '_sha256'] = digest(bit_bytes(flatten(run, field)))
    left, right = (pair['runs'][v] for v in VARIANTS)
    row['matching_rank_positions'] = sum(a == b for a, b in zip(left['token_ids'], right['token_ids']))
    row['matching_rank_list'] = left['token_ids'] == right['token_ids']
    for field, label in (('sequence_logp', 'sequence'), ('transition_logp', 'transition')):
        a, b = (flatten(run, field) for run in (left, right))
        row['matching_' + label + '_values'] = sum(bit_bytes([x]) == bit_bytes([y]) for x, y in zip(a, b))
        row['max_' + label + '_difference_at_rank'] = max(abs(x - y) for x, y in zip(a, b))
        # Also report common-candidate deltas; rank-position and candidate-aligned
        # comparisons answer different questions if ordering changes.
        a, b = ({tuple(ids): score for ids, score in zip(run['token_ids'], run[field])} for run in (left, right))
        deltas = []
        for ids in a.keys() & b.keys():
            x, y = ([a[ids]], [b[ids]]) if label == 'sequence' else (a[ids], b[ids])
            deltas.extend(abs(i-j) for i, j in zip(x, y))
        row['max_' + label + '_difference_common'] = max(deltas, default=0.)
    return row


def summary(audit, rows):
    assert audit['integrity_audit_passed'] and len(rows) == audit['paired_requests']
    assert len({r['cohort_index'] for r in rows}) == audit['unique_users']
    for field in ('matching_rank_positions', 'matching_sequence_values', 'matching_transition_values'):
        assert sum(r[field] for r in rows) == audit['comparison'][field], field
    assert sum(r['matching_rank_list'] for r in rows) == audit['comparison']['matching_rank_lists']
    # Carry the entire audit, including every negative probe/repeat/quality gate,
    # instead of reconstructing a successful subset or replacing counts by totals.
    return dict(audit, experiment='constraint-replay', control=VARIANTS[0], candidate=VARIANTS[1],
        timing_boundary='Synchronized generation call including staging and original HF score clones; excludes input preparation, output/transition extraction, post-request audit scans and file writes.',
        max_sequence_difference_at_rank=max(r['max_sequence_difference_at_rank'] for r in rows),
        max_transition_difference_at_rank=max(r['max_transition_difference_at_rank'] for r in rows))


def add_tree(entries, root, prefix):
    assert root.is_dir()
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            name = prefix + '/' + path.relative_to(root).as_posix()
            assert name not in entries
            entries[name] = path.read_bytes()


def write_archive(path, entries):
    with path.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in sorted(entries.items()):
                item = tarfile.TarInfo(name)
                item.size = len(data); item.mode = 0o444; item.mtime = 0
                archive.addfile(item, io.BytesIO(data))


def export(status_path, audit_path, destination):
    status = read(status_path); audit = read(audit_path)
    assert status['scheduler_state'] == 'COMPLETED', 'Execution failures need a failure-specific report'
    assert not destination.exists(), 'Preserve existing exports; choose a new destination'
    harness = Path(status['harness']); run_id = status['run_id']
    raw = harness / '.oscar/results' / run_id
    snapshot = Path(status['source_snapshot'])
    record_path = harness / '.oscar/runs' / (run_id + '.json')
    record = read(record_path)
    assert record['run_id'] == run_id and record['job_id'] == status['job_id']
    assert record['resources'] == status['resources']
    assert read(raw / 'source-manifest.json')['sha256'] == record['sha256']
    assert (raw / 'job-id').read_text().strip() == record['job_id']
    assert audit['snapshot_files_verified'] == len(record['files']) == len(record['sha256'])
    for name, expected in record['sha256'].items():
        assert digest((snapshot / name).read_bytes()) == expected, name
    assert digest((snapshot / 'rapidtinyrec/audit_constraint_replay.py').read_bytes()) == audit['audit_script_sha256']
    provenance = read(snapshot / 'source-provenance.json')
    assert provenance['source_commit'] == status['source_commit']
    joined = {}
    for phase, variant in enumerate((VARIANTS[0], VARIANTS[1], VARIANTS[1], VARIANTS[0])):
        path = raw / 'outputs' / f'phase_{phase}'
        assert read(path / 'manifest.json')['variant'] == variant
        for item in read(path / 'requests.json'):
            assert item['variant'] == variant
            key = item['repeat'], item['cohort_index']
            pair = joined.setdefault(key, dict(repeat=key[0], cohort_index=key[1], prompt_tokens=item['prompt_tokens'], runs={}, phases={}))
            assert pair['prompt_tokens'] == item['prompt_tokens'] and variant not in pair['runs']
            pair['runs'][variant] = item['run']; pair['phases'][variant] = phase
    assert all(set(pair['runs']) == set(VARIANTS) for pair in joined.values())
    rows = [export_pair(joined[key]) for key in sorted(joined)]
    result = summary(audit, rows)
    review = read(Path(status['independent_review']))
    assert review['run_id'] == run_id
    result.update(performance_gate=review['performance_gate'], decision=review['decision'])
    entries = {}
    add_tree(entries, raw, 'raw')
    add_tree(entries, snapshot, 'source-snapshot')
    entries['run-record.json'] = record_path.read_bytes()
    entries['status.json'] = status_path.read_bytes()
    entries['audit.json'] = audit_path.read_bytes()
    entries['export_constraint_replay.py'] = Path(__file__).read_bytes()
    for name in ('submit_constraint_pilot.py', 'test_constraint_export.py'):
        entries[name] = Path(__file__).with_name(name).read_bytes()
    for field in ('independent_review', 'raw_manifest', 'audit_stdout', 'audit_stderr', 'ci_log'):
        path = Path(status[field])
        entries['review/' + path.name] = path.read_bytes()
    entries['reproduce.json'] = json.dumps(dict(audit_command=status['audit_command'], audit_cwd=status['audit_cwd'],
        submitted_profile=record['profile'], resources=record['resources'],
        archive_reproduction='Run python3 -m rapidtinyrec.audit_constraint_replay raw/outputs from source-snapshot with the archived run-record and the pinned historical GQA results/token map. Absolute paths in the original exact command must be relocated explicitly.'), indent=2).encode()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=destination.parent, prefix='.constraint-evidence-') as temporary:
        staged = Path(temporary) / 'result'; staged.mkdir()
        with (staged / 'requests.csv').open('w') as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator='\n')
            writer.writeheader(); writer.writerows(rows)
        result['requests_sha256'] = digest((staged / 'requests.csv').read_bytes())
        (staged / 'summary.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
        (staged / 'audit.json').write_bytes(audit_path.read_bytes())
        write_archive(staged / 'evidence.tar.gz', entries)
        manifest = {name: dict(bytes=len(data), sha256=digest(data)) for name, data in sorted(entries.items())}
        (staged / 'archive-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
        source = dict(run_id=run_id, job_id=status['job_id'], measured_repository_commit=status['source_commit'],
            submitted_source_sha256=record['sha256'], resources=record['resources'],
            raw_sha256={n: digest(v) for n, v in entries.items() if n.startswith('raw/')},
            evidence_sha256={p.name: digest(p.read_bytes()) for p in staged.iterdir()})
        (staged / 'source.json').write_text(json.dumps(source, indent=2) + '\n')
        staged.rename(destination)
    return dict(destination=str(destination), pairs=len(rows), archive_files=len(entries), exactness_passed=audit['exactness_passed'])


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--status', type=Path, required=True)
    ap.add_argument('--audit', type=Path, required=True)
    ap.add_argument('--destination', type=Path, required=True)
    args = ap.parse_args()
    print(json.dumps(export(args.status, args.audit, args.destination), indent=2))


if __name__ == '__main__':
    main()
