#!/bin/bash -l
#SBATCH --job-name=constraint-replay-pilot-20261026T011855Z-4b7e1f8d3254
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --time=00:30:00
#SBATCH --output=/oscar/scratch/aagraw73/agent-runs/rapidtinyrec-constraint-replay/constraint-replay-pilot-20261026T011855Z-4b7e1f8d3254/logs/stdout.log
#SBATCH --error=/oscar/scratch/aagraw73/agent-runs/rapidtinyrec-constraint-replay/constraint-replay-pilot-20261026T011855Z-4b7e1f8d3254/logs/stderr.log
#SBATCH --partition=gpu
#SBATCH --qos=norm-gpu
#SBATCH --constraint=ampere
#SBATCH --gres=gpu:nvidia_rtx_a6000:1

set -euo pipefail
umask 077
export OSCAR_RUN_DIR=/oscar/scratch/aagraw73/agent-runs/rapidtinyrec-constraint-replay/constraint-replay-pilot-20261026T011855Z-4b7e1f8d3254
export OSCAR_OUTPUT_DIR="$OSCAR_RUN_DIR/outputs"
export PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=4
cd "$OSCAR_RUN_DIR/code"
module purge
srun --ntasks=1 bash jobs/constraint-replay.sh
