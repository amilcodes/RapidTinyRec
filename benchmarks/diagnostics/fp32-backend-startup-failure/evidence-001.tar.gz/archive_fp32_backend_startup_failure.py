"""Preserve the observed build-guard failure before correcting its source pin."""
import json
from pathlib import Path
from export_fp32_backend import add_tree, sha, write_shards

BASE = Path(__file__).resolve().parents[2]
STATUS = BASE/'outputs/rapidtinyrec_fp32_backend_status.json'
DEST = BASE/'work/rapidtinyrec_fp32_backend_source/benchmarks/diagnostics/fp32-backend-startup-failure'


def main():
    assert not DEST.exists()
    status = json.loads(STATUS.read_text())
    assert status['job_id']=='7955758' and status['scheduler_state']=='FAILED'
    run=status['run_id'];harness=Path(status['harness']);raw=harness/'.oscar/results'/run
    record_path=harness/'.oscar/runs'/(run+'.json');record=json.loads(record_path.read_text())
    diagnosis=json.loads((raw/'outputs/diagnosis/diagnosis.json').read_text())
    assert diagnosis['complete'] is False and diagnosis['cases']==[] and diagnosis['setup']=={}
    assert diagnosis['torch_git_version']=='08187d9e0fba026dc8217405802ab5381dc88d90'
    assert 'Review installed build' in diagnosis['failure']
    audit_path=Path(status['audit_result']);audit=json.loads(audit_path.read_text())
    assert audit['integrity_audit_passed'] is False and audit['errors']==["KeyError: 'release_sha256'"]
    snapshot=Path(status['source_snapshot'])
    assert len(record['sha256'])==47
    for name,digest in record['sha256'].items():assert sha((snapshot/name).read_bytes())==digest
    proof_root=BASE/'outputs/fp32_backend/build-identity';proof=json.loads((proof_root/'proof.json').read_text())
    assert len(proof['source_files'])==5 and proof['changed_files']==['test/test_transformers.py']
    for file in proof['source_files']:
        assert sha((proof_root/'installed-source'/file['path']).read_bytes())==file['installed_sha256']==file['tag_sha256']
    entries={};add_tree(entries,raw,'raw');add_tree(entries,snapshot,'source-snapshot');add_tree(entries,proof_root,'build-identity')
    manifest=json.loads(Path(status['raw_manifest']).read_text())
    actual={n.removeprefix('raw/'):dict(size=len(v),sha256=sha(v)) for n,v in entries.items() if n.startswith('raw/')}
    assert actual=={r['path']:dict(size=r['size'],sha256=r['sha256']) for r in manifest['files']}
    entries.update({'status.json':STATUS.read_bytes(),'run-record.json':record_path.read_bytes(),'audit.json':audit_path.read_bytes()})
    for field in ('raw_manifest','audit_stdout','audit_stderr','ci_log'):
        p=Path(status[field]);entries['review/'+p.name]=p.read_bytes()
    for name in ('archive_fp32_backend_startup_failure.py','export_fp32_backend.py','submit_fp32_backend.py'):
        entries[name]=Path(__file__).with_name(name).read_bytes()
    entries['build-identity/reviewed-tag-source-manifest.json']=(BASE/'outputs/fp32_backend_preparation/source-manifest.json').read_bytes()
    summary=dict(run_id=run,job_id=status['job_id'],scheduler_state='FAILED',exit_code='1:0',elapsed_s=16,
        measured_source_commit=status['source_commit'],completed_cases=0,model_loaded=False,
        backend_exactness_established=False,backend_latency_measured=False,ranking_quality_measured=False,
        original_audit_exit_code=1,original_audit_errors=audit['errors'],raw_files_verified=len(actual),source_files_verified=47,
        observed_wheel_commit=proof['installed_commit'],original_guard_commit=proof['reviewed_tag_commit'],
        numerical_source_files_byte_identical=5,changed_upstream_files=proof['changed_files'],
        decision='Repair the build identity pin only after reviewing official source equivalence. Preserve this failed run. Fresh CI and separately guarded retry required; no algorithm or equality changes.',
        original_audit_command=status['audit_command'],original_audit_cwd=status['audit_cwd'])
    DEST.mkdir(parents=True)
    archive_manifest=write_shards(DEST,entries)
    (DEST/'archive-manifest.json').write_text(json.dumps(archive_manifest,indent=2)+'\n')
    (DEST/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (DEST/'README.md').write_text('''# FP32 backend startup failure

Job7955758 failed before model loading or any projection measurements. This is an implementation/provenance failure, not a measured numerical or performance failure. The installed PyTorch release wheel is the immediate parent of the reviewed release tag; the tag adds only a test-file import. All five reviewed numerical/backend source files are byte-identical. The corrected diagnostic pins the observed wheel commit; exactness gates remain unchanged.

`summary.json` records the failure and original audit command. Extract every `evidence-*.tar.gz` into one folder; `archive-manifest.json` hashes every member and archive. The archive preserves all raw outputs/logs, original source/config/resources, run record, CI log, original failed audit, and official upstream build-identity evidence. It also includes the publication and guarded-submission utilities.

To reproduce the original failed audit, from extracted `source-snapshot` run:

```bash
python3 -m rapidtinyrec.audit_fp32_backend ../raw/outputs/diagnosis --snapshot . --run-record ../run-record.json --output ../reproduced-failure-audit.json
```

Expected exit1 with the preserved missing-release-provenance error. No score, ranking or latency claim follows from this run. Do not submit the archived job again.
''')
    (DEST/'source.json').write_text(json.dumps(dict(run_id=run,job_id=status['job_id'],source_sha256=record['sha256'],
        files_sha256={p.name:sha(p.read_bytes()) for p in DEST.iterdir()}),indent=2)+'\n')
    report=BASE/'outputs/fp32_backend/report.md'
    report.write_text((DEST/'README.md').read_text()+'\nPublished evidence destination: '+str(DEST)+'\n')
    print(json.dumps(dict(destination=str(DEST),archive_files=len(entries),raw_files=len(actual),source_files=47)))


if __name__=='__main__':main()
