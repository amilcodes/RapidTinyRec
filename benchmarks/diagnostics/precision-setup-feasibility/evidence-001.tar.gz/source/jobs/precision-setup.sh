#!/bin/bash
set -euo pipefail
test -n "${SLURM_JOB_ID:-}"
test -n "${OSCAR_RUN_DIR:-}"
test -d "${OSCAR_OUTPUT_DIR:-}"
python_bin=/oscar/scratch/aagraw73/minionerec-shared-prefill/envs/torch214-cu126-transformers4554/bin/python
if (( $# == 0 )); then
    exec "$python_bin" -u -m rapidtinyrec.precision_log_runner \
        --local-root /tmp --output-root "$OSCAR_OUTPUT_DIR" --timeout-seconds 1620 \
        -- bash "$0" --child '{LOG_LOCAL_ROOT}'
fi
test "$#" -eq 2
test "$1" = --child
test "$2" = "${RAPIDTINYREC_LOG_STAGE_WRAPPER:-}"
test -d "$2"
export TORCHINDUCTOR_COMPILE_THREADS=4
export TORCH_LOGS=recompiles
export PYTORCH_TUNABLEOP_ENABLED=0
export PYTORCH_TUNABLEOP_TUNING=0
export TORCHINDUCTOR_CACHE_DIR="$OSCAR_RUN_DIR/compile-cache/tf32/inductor"
export TRITON_CACHE_DIR="$OSCAR_RUN_DIR/compile-cache/tf32/triton"
for phase in 1 2; do
    extra=()
    if (( phase == 1 )); then
        test ! -e "$TORCHINDUCTOR_CACHE_DIR"
        test ! -e "$TRITON_CACHE_DIR"
    else
        test -d "$TORCHINDUCTOR_CACHE_DIR"
        test -d "$TRITON_CACHE_DIR"
        extra+=(--reuse-compiler-artifacts)
    fi
    "$python_bin" -u -m rapidtinyrec.benchmark_precision \
        --release-root /oscar/scratch/aagraw73/minionerec-shared-prefill/release \
        --reference-results /oscar/scratch/aagraw73/agent-runs/minionerec-shared-prefill/benchmark-gqa-fp32-20261023T054059Z-7b4f0ee334cb/outputs/gqa_500_users \
        --output-root "$OSCAR_OUTPUT_DIR" --phase "$phase" --api-log-local-root "$2" \
        --setup-feasibility "${extra[@]}"
done
