"""Publish the completed setup diagnostic; never infer paired quality eligibility."""
import json
from pathlib import Path
import tarfile
from export_precision import add_tree, sha, write_shards

BASE = Path(__file__).resolve().parents[2]
read = lambda p: json.loads(Path(p).read_text())


def main():
    status_path = BASE/'outputs/rapidtinyrec_precision_setup_status.json'
    s = read(status_path)
    a = read(s['audit_result']); r = read(s['independent_review'])
    assert s['scheduler_state'] == r['scheduler_state'] == 'COMPLETED'
    assert a['schema'] == 'precision-setup-feasibility-audit-v1'
    assert a['run_id'] == r['run_id'] == s['run_id']
    assert a['job_id'] == r['job_id'] == s['job_id'] == '7972055'
    assert a['integrity_audit_passed'] is True
    assert a['setup_diagnostic_passed'] == r['setup_diagnostic_passed']
    for k in ('eligible_for_full_quality_review','promotion','noninferiority_established',
              'full_abba_retry_authorized_by_diagnostic_alone'):
        assert a[k] is r[k] is False
    assert sha(Path(s['audit_result']).read_bytes()) == r['audit_sha256']
    assert [p['phase'] for p in a['phases']] == [1, 2]
    assert all(p['variant'] == 'folded_tf32' for p in a['phases'])
    assert a['unique_users'] == 4 and a['requests'] == 24
    root = Path(s['harness'])/'.oscar/results'/s['run_id']
    snapshot = Path(s['source_snapshot'])
    record = Path(s['harness'])/'.oscar/runs'/(s['run_id']+'.json')
    entries = {}; add_tree(entries, root, 'raw'); add_tree(entries, snapshot, 'source')
    raw = read(s['raw_manifest'])['files']
    assert len(raw) == 227
    assert {k[4:] for k in entries if k.startswith('raw/')} == {x['path'] for x in raw}
    for row in raw:
        data = entries['raw/'+row['path']]
        assert len(data) == row['size'] and sha(data) == row['sha256']
    for name, digest in read(record)['sha256'].items():
        assert sha(entries['source/'+name]) == digest
    extra = {'run-record.json':record, 'status-at-export.json':status_path,
             'audit.json':Path(s['audit_result']), 'raw-manifest.json':Path(s['raw_manifest']),
             'audit.stdout':Path(s['audit_stdout']), 'audit.stderr':Path(s['audit_stderr']),
             'independent-review.json':Path(s['independent_review']),
             'ci-measured-source.log':Path(s['ci_log']), 'submission-script.py':Path(s['submission_script']),
             'submission-intent.json':BASE/'outputs/rapidtinyrec_precision_setup_submission_intent.json',
             'preparation-review.json':Path(s['preparation_review']),
             'archive_precision_setup.py':Path(__file__),
             'export_precision.py':Path(__file__).with_name('export_precision.py')}
    for name, path in extra.items(): entries['review/'+name] = path.read_bytes()
    dest = BASE/'work/rapidtinyrec_quality_source/benchmarks/diagnostics/precision-setup-feasibility'
    dest.mkdir(parents=True, exist_ok=False)
    archive = write_shards(dest, entries); seen = set()
    for item in archive['archives']:
        path = dest/item['path']
        assert sha(path.read_bytes()) == item['sha256'] and path.stat().st_size < 48*1024*1024
        with tarfile.open(path, 'r:gz') as tf:
            for member in tf.getmembers():
                assert member.isfile() and member.name not in seen
                data = tf.extractfile(member).read(); expected = archive['files'][member.name]
                assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
                seen.add(member.name)
    assert seen == set(entries)
    archive.update(schema='precision-setup-archive-v1', run_id=s['run_id'], verified_members=len(seen))
    for name, value in [('archive-manifest.json',archive),('summary.json',r),('audit.json',a)]:
        (dest/name).write_text(json.dumps(value,indent=2)+'\n')
    (dest/'reproduction.json').write_text(json.dumps({
        'audit_cwd':s['audit_cwd'], 'audit_command':s['audit_command'], 'expected_exit_code':0,
        'requirements':'Restore archived source and raw files to the recorded workspace paths, with pinned historical GQA and preserved original pilot references. Use a new audit output path to preserve the original. No GPU submission is needed.',
        'archive_verification':'Verify each shard and every member against archive-manifest.json.',
        'scope':'Setup feasibility only; no paired performance or quality gate.'},indent=2)+'\n')
    print(json.dumps({'members':len(seen),'archives':archive['archives'],'destination':str(dest)},indent=2))


if __name__ == '__main__': main()
