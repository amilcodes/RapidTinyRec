"""One fail-closed submission; --recover can only recover the same saved run."""
import argparse
import datetime
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
H = BASE / 'work/rapidtinyrec_precision_setup'
SRC = BASE / 'work/rapidtinyrec_quality_source'
OUT = BASE / 'outputs'
KIT = '/Users/AmilAgrawal/Documents/Codex/2026-10-22/hel/outputs/oscar-agent-kit/oscar.py'
CONFIG = 'oscar.precision-setup.json'
PROFILE = 'precision-setup-feasibility'
STATUS = OUT / 'rapidtinyrec_precision_setup_status.json'
INTENT = OUT / 'rapidtinyrec_precision_setup_submission_intent.json'
LEDGER = OUT / 'rapidtinyrec_research_loop_state.json'
FROZEN = H / '.oscar/pre_submission/setup'

PROTOCOL = 'benchmarks/preparation/quality-frontier/setup-feasibility-protocol.json'
RESOURCES = dict(partition='gpu',qos='norm-gpu',constraint='ampere',gpu_type='nvidia_rtx_a6000',
                 gpus=1,cpus=4,memory_gb=32,time='00:30:00',setup=['module purge'],
                 command=['bash','jobs/precision-setup.sh'])


def validate_readiness(status, ledger, config, protocol, commit):
    assert status['submission_ready'] is True, 'Reviewed readiness required'
    assert not status.get('submitted') and not status.get('run_id') and not status.get('job_id')
    assert not any(ledger.get(k) for k in ('current_gpu_job','remaining_gpu_job','active_gpu_job','active_experiment'))
    assert status['profile']==PROFILE and status['config']==CONFIG
    assert status['source_commit']==commit
    ci=status['ci']
    assert ci['head_sha']==commit and ci['status']=='completed' and ci['conclusion']=='success'
    assert ci['tests_passed']>=95 and ci['cli_checks']=='PASS'
    assert config['project']=='rapidtinyrec-precision-setup'
    assert config['ssh_target']=='aagraw73@sshcampus.ccv.brown.edu'
    assert config['remote_root']=='/oscar/scratch/aagraw73/agent-runs'
    assert config['profiles']=={PROFILE:RESOURCES}
    assert protocol['schema']=='precision-setup-feasibility-v1'
    assert protocol['phases']==[dict(phase=1,variant='folded_tf32',disk_cache='cold',repeats=[0,1,2]),
                               dict(phase=2,variant='folded_tf32',disk_cache='same-variant-reuse',repeats=[3,4,5])]
    assert protocol['cohort_indices']==[1,2,6,10] and protocol['prompt_lengths']==[76,121]
    assert protocol['resources']=={k:v for k,v in RESOURCES.items() if k not in ('setup','command')}
    assert protocol['supervisor_child_deadline_s']==1620 and protocol['minimum_reserved_cleanup_s']==180
    assert protocol['graphs_per_phase']==8 and protocol['requests_per_phase']==12 and protocol['fresh_processes'] is True
    for key in ('eligible_for_full_quality_review','promotion','noninferiority_established'):
        assert status[key] is False and protocol[key] is False
    assert protocol['full_abba_retry_authorized_by_diagnostic_alone'] is False


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, indent=2) + '\n')
    tmp.replace(path)


def record_status(status):
    status['updated_at_utc'] = now()
    status['active_gpu_job'] = status.get('job_id')
    save(STATUS, status)
    quality=read(OUT / 'rapidtinyrec_quality_status.json')
    quality.update(active_gpu_job=status.get('job_id'),setup_diagnostic_status=str(STATUS),status=status['status'],next_action=status.get('next_action'),updated_at_utc=status['updated_at_utc'])
    save(OUT / 'rapidtinyrec_quality_status.json',quality)
    ledger = read(LEDGER)
    ledger.update(active_experiment=status, active_gpu_job=status.get('job_id'), next_experiment=None, current_gpu_job=status.get('job_id'),
                  remaining_gpu_job=status.get('job_id'), updated_at_utc=status['updated_at_utc'])
    for candidate in ledger.get('candidate_queue', []):
        if candidate['name'] == status['name']:
            candidate['status'] = status['status']
    save(LEDGER, ledger)


def audit_command(run):
    snapshot = H / '.oscar/source_snapshots' / run
    return [
        'python3', '-m', 'rapidtinyrec.audit_precision_setup',
        str(H / '.oscar/results' / run / 'outputs'),
        '--historical', str(BASE / 'work/minionerec_oscar/.oscar/results/benchmark-gqa-fp32-20261023T054059Z-7b4f0ee334cb/outputs/gqa_500_users'),
        '--snapshot', str(snapshot / 'rapidtinyrec'),
        '--run-record', str(H / '.oscar/runs' / (run + '.json')),
        '--prior-root', str(BASE / 'work/rapidtinyrec_precision/.oscar/results/precision-pilot-20261026T053441Z-f040754d1743'),
        '--prior-manifest', str(OUT / 'quality_frontier/precision-pilot-raw-manifest.json'),
        '--prior-review', str(OUT / 'quality_frontier/precision-timeout-independent-review.json'),
        '--output', str(OUT / 'rapidtinyrec_precision_setup_audit.json')]


def finalize(record):
    assert record['profile'] == PROFILE and record['job_id']
    intent=read(INTENT)
    assert record['sha256']==intent['sha256'] and record['resources']==intent['resources']
    assert intent.get('run_id') in (None,record['run_id'])
    assert record['created_at']>=intent['intent_at_utc']
    status = read(STATUS)
    assert status.get('run_id') in (None, record['run_id'])
    assert status.get('job_id') in (None, record['job_id'])
    snapshot = H / '.oscar/source_snapshots' / record['run_id']
    # Persist identity before any additional checks/copying or other work.
    status.update(status='SUBMITTED', submitted=True, run_id=record['run_id'], job_id=record['job_id'],
                  submitted_at_utc=record['created_at'], resources=record['resources'],
                  source_snapshot=str(snapshot), audit_cwd=str(snapshot),
                  audit_command=audit_command(record['run_id']))
    record_status(status)
    save(INTENT, dict(read(INTENT), run_id=record['run_id'], job_id=record['job_id'], submitted=True))
    intent = read(INTENT)
    assert record['sha256'] == intent['sha256']
    assert record['resources'] == read(FROZEN / CONFIG)['profiles'][PROFILE]
    snapshot.mkdir(parents=True, exist_ok=True)
    for name, expected in record['sha256'].items():
        source = FROZEN / name
        assert sha(source) == expected
        target = snapshot / name
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        assert sha(target) == expected
        target.chmod(0o444)
    target = snapshot / '.submission-config.json'
    if not target.exists():
        shutil.copy2(FROZEN / CONFIG, target)
    assert sha(target) == sha(FROZEN / CONFIG)
    target.chmod(0o444)
    status.update(snapshot_files_verified=len(record['files']),
                  next_action='Monitor this existing setup diagnostic only; fetch after terminal, hash/freeze raw files, execute saved frozen setup auditor, and review setup budget/stability/dispatch/recovery. Preserve failure; no automatic replacement/fullABBA/full500. No paired quality/speed or logging causality claim.')
    record_status(status)
    ledger = read(LEDGER)
    if not any(e.get('run_id') == record['run_id'] for e in ledger['experiments']):
        ledger['experiments'].append(dict(status))
    save(LEDGER, ledger)
    print(json.dumps(status, indent=2))


def recover():
    assert INTENT.exists(), 'No existing submission intent to recover'
    intent = read(INTENT)
    records = [p for p in (H / '.oscar/runs').glob(PROFILE + '-*.json')
               if read(p)['created_at'] >= intent['intent_at_utc']]
    assert len(records) == 1, 'Inspect intent/stdout/remote state; never submit a replacement here'
    record = read(records[0])
    assert record['profile']==PROFILE and record['sha256']==intent['sha256']
    assert record['resources']==intent['resources']
    assert sha(H/CONFIG)==sha(FROZEN/CONFIG)
    if not record.get('job_id'):
        subprocess.run(['python3', KIT, '--config', CONFIG, 'recover', record['run_id']], cwd=H, check=True)
        record = read(records[0])
    finalize(record)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    mode=ap.add_mutually_exclusive_group()
    mode.add_argument('--recover', action='store_true')
    mode.add_argument('--check', action='store_true',help='Validate local readiness only; never submit')
    args = ap.parse_args()
    if args.recover:
        recover()
        return
    assert not INTENT.exists(), 'Existing intent: use --recover, never submit again'
    status = read(STATUS); ledger = read(LEDGER)
    assert not status.get('submitted') and not status.get('run_id') and not status.get('job_id')
    assert not any(ledger.get(k) for k in ('current_gpu_job','remaining_gpu_job','active_gpu_job'))
    assert ledger.get('active_experiment') in (None, status), 'Another active or uncertain experiment'
    assert not read(OUT / 'rapidtinyrec_serving_status.json').get('active_gpu_job')
    assert not read(OUT / 'rapidtinyrec_quality_status.json').get('active_gpu_job')
    assert not list((H / '.oscar/runs').glob(PROFILE + '-*.json'))
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SRC, text=True).strip()
    commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SRC, text=True).strip()
    assert commit == status['source_commit'] == read(H / 'source-provenance.json')['source_commit']
    ci=status['ci']
    config = read(H / CONFIG)
    preparation=read(Path(status['preparation_review']))
    protocol=read(H / PROTOCOL)
    validate_readiness(status,ledger,config,protocol,commit)
    assert sha(H / CONFIG)==preparation['config_sha256']
    assert sha(H / PROTOCOL)==status['protocol_sha256']
    assert sha(Path(ci['log']))==ci['log_sha256']
    assert sha(Path(__file__))==status['submission_guard_sha256']
    assert sha(BASE/'work/rapidtinyrec_prep/test_precision_setup_submission.py')==status['submission_guard_test_sha256']
    for key,name in [('raw_manifest_sha256','precision-pilot-raw-manifest.json'),('diagnostic_review_sha256','precision-timeout-independent-review.json')]:
        assert sha(OUT/'quality_frontier'/name)==protocol['prior_tf32_reference'][key]
    plan = json.loads(subprocess.check_output(['python3', KIT, '--config', CONFIG, 'plan', '--profile', PROFILE], cwd=H, text=True))
    assert plan['resources'] == config['profiles'][PROFILE]
    hashes = {name: sha(H / name) for name in plan['files']}
    provenance = read(H / 'source-provenance.json')
    for name, expected in provenance['source_files'].items():
        assert hashes[name] == expected
        assert hashlib.sha256(subprocess.check_output(['git', 'show', f"{commit}:{provenance['repository_paths'][name]}"], cwd=SRC)).hexdigest() == expected
    assert set(hashes)==set(provenance['source_files']) | set(provenance['preparation_files']) | {CONFIG,'source-provenance.json'}
    for name,expected in provenance['preparation_files'].items():assert hashes[name]==expected
    assert hashes['preparation/submit_precision_setup.py']==status['submission_guard_sha256']
    assert hashes['preparation/test_precision_setup_submission.py']==status['submission_guard_test_sha256']
    if args.check:
        print('Local readiness passed; no scheduler query or submission')
        return
    queue = subprocess.check_output(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15',
        config['ssh_target'], 'squeue -u aagraw73 -h -o "%i|%j|%T|%M|%R"'], text=True)
    assert not queue.strip(), 'Existing account jobs: inspect; one GPU experiment at a time'
    FROZEN.mkdir(parents=True, exist_ok=False)
    for name, expected in hashes.items():
        target = FROZEN / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(H / name, target)
        assert sha(target) == expected
        target.chmod(0o444)
    intent = dict(intent_at_utc=now(), source_commit=commit, sha256=hashes, resources=plan['resources'],
                  profile=PROFILE, harness=str(H), submitted=False, ci=ci,
                  audit_command_template=audit_command('{run_id}'),
                  audit_cwd_template=str(H / '.oscar/source_snapshots/{run_id}'))
    with INTENT.open('x') as f:
        json.dump(intent, f, indent=2)
    status.update(status='SUBMITTING_DO_NOT_DUPLICATE', ci_conclusion='success', ci_url='https://github.com/amilcodes/RapidTinyRec/actions/runs/'+str(ci['run_id']),
                  resources=plan['resources'], automation_id='packed-mlp-rounding-diagnostic-follow-up')
    record_status(status)
    stdout = OUT / 'rapidtinyrec_precision_setup_submit.json'
    stderr = OUT / 'rapidtinyrec_precision_setup_submit.stderr'
    with stdout.open('x') as f, stderr.open('x') as e:
        result = subprocess.run(['python3', KIT, '--config', CONFIG, 'submit', '--profile', PROFILE], cwd=H, stdout=f, stderr=e)
    if result.returncode:
        raise SystemExit('Submission uncertain: inspect saved outputs and run records; --recover only, never resubmit')
    finalize(read(stdout))


if __name__ == '__main__':
    main()
