"""Bounded fixed-input GEMM diagnosis, not an end-to-end benchmark or promotion."""
import argparse
import collections
import hashlib
import json
import os
from pathlib import Path
import statistics
import time

import torch
from torch.nn import functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig, LogitsProcessorList
from rapidtinyrec.folded_attention import fold_decode_attention
from rapidtinyrec.shared_prefill import PrefillOnce
from rapidtinyrec.gpu_constraints import GpuSidConstraintTables, GpuSidConstrainedLogitsProcessor


def save(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temp.replace(path)


def compare(a, b):
    a, b = a.contiguous(), b.contiguous()
    delta = (a - b).abs()
    return {'values': a.numel(), 'matching_bits': int((a.view(torch.int32) == b.view(torch.int32)).sum()),
            'max_abs': float(delta.max()), 'mean_abs': float(delta.mean()),
            'finite': bool(torch.isfinite(a).all() and torch.isfinite(b).all())}


def separate(x, gate, up, packed):
    return torch.mm(x, gate.t()), torch.mm(x, up.t())


def packed_views(x, gate, up, packed):
    g, u = packed.split(8960, dim=0)
    return torch.mm(x, g.t()), torch.mm(x, u.t())


def wide(x, gate, up, packed):
    return torch.mm(x, packed.t()).split(8960, dim=-1)


def batched(x, gate, up, packed):
    result = torch.bmm(x.unsqueeze(0).expand(2, -1, -1), packed.view(2, 8960, 1536).transpose(1, 2))
    return result[0], result[1]


@torch.inference_mode()
def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--release', type=Path, required=True)
    ap.add_argument('--historical', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    assert os.environ.get('SLURM_JOB_ID'), 'Allocated compute only'
    assert torch.cuda.is_available() and torch.cuda.device_count() == 1
    assert torch.cuda.get_device_name() == 'NVIDIA RTX A6000'
    torch.set_num_threads(4)
    torch.manual_seed(42)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    args.output.mkdir(parents=True, exist_ok=False)
    expected = json.loads(Path('rapidtinyrec/expected.json').read_text())
    for name, digest in expected['release_sha256'].items():
        assert hashlib.sha256((args.release / name).read_bytes()).hexdigest() == digest, name
    reference = json.loads((args.historical / 'manifest.json').read_text())
    assert hashlib.sha256(json.dumps(reference['users'], sort_keys=True).encode()).hexdigest() == expected['users_sha256']
    users = [reference['users'][i] for i in (1, 2, 6, 10)]
    tok = AutoTokenizer.from_pretrained(args.release / 'Office_ckpt', local_files_only=True)
    tok.pad_token = tok.eos_token
    constraints = collections.defaultdict(set)
    for line in (args.release / 'Amazon/info/Office_Products_5_2016-10-2018-11.txt').read_text().splitlines():
        ids = tok('### Response:\n' + line.split('\t')[0].strip() + '\n').input_ids + [tok.eos_token_id]
        for j in range(3, len(ids)):
            constraints[tuple(ids[:j] if j == 3 else ids[3:j])].add(ids[j])
    tables = GpuSidConstraintTables({k: list(v) for k, v in constraints.items()}, users[0]['prompt_token_ids'][-3:], 198, tok.eos_token_id, 'cuda')
    model = AutoModelForCausalLM.from_pretrained(args.release / 'Office_ckpt', torch_dtype=torch.float32,
                                               local_files_only=True, attn_implementation='sdpa').to('cuda').eval()
    cfg = GenerationConfig(max_new_tokens=8, length_penalty=0., num_beams=50, num_return_sequences=50,
                           pad_token_id=tok.eos_token_id, eos_token_id=tok.eos_token_id,
                           bos_token_id=tok.bos_token_id, do_sample=False, top_k=None, top_p=None, use_cache=True)
    layer_indices = (0, 13, 27)
    captured = {}
    def hook(layer):
        def capture(module, inputs):
            x = inputs[0]
            if x.shape == (50, 1, 1536) and layer not in captured:
                captured[layer] = x[:, 0, :].clone()
        return capture
    handles = [model.model.layers[i].mlp.register_forward_pre_hook(hook(i)) for i in layer_indices]
    cases = []
    started = time.perf_counter()
    with fold_decode_attention(True):
        for user in users:
            captured.clear()
            ids = torch.tensor([user['prompt_token_ids']], device='cuda')
            with PrefillOnce(model, 50):
                model.generate(ids, attention_mask=torch.ones_like(ids), generation_config=cfg,
                               logits_processor=LogitsProcessorList([GpuSidConstrainedLogitsProcessor(tables)]))
            assert set(captured) == set(layer_indices)
            cases.extend((user['cohort_index'], layer, captured[layer]) for layer in layer_indices)
    for handle in handles:
        handle.remove()
    torch.cuda.synchronize()
    report = {'scope': 'Same-input gate/up GEMM and pointwise diagnosis only. Activations are from eager folded-attention shared-prefill generation, not a replay of the original compiled intermediate tensors. Microtimings are CUDA graph replays of projections only, not request latency.',
              'job_id': os.environ['SLURM_JOB_ID'], 'hardware': torch.cuda.get_device_name(),
              'torch': torch.__version__, 'cuda': torch.version.cuda, 'tf32': False,
              'activation_collection_s': time.perf_counter() - started, 'cases': [], 'complete': False}
    functions = {'separate': separate, 'packed_views_separate': packed_views, 'packed_wide': wide, 'batched_two': batched}
    # A separate fixed-value probe checks whether contiguous versus split views
    # change the compiler's SiLU/product arithmetic with identical input bits.
    pointwise = torch.compile(lambda g, u: F.silu(g) * u, fullgraph=True)
    for index, layer, x in cases:
        mlp = model.model.layers[layer].mlp
        gate, up = mlp.gate_proj.weight, mlp.up_proj.weight
        packed = torch.cat((gate, up), dim=0)
        assert torch.equal(packed[:8960].view(torch.int32), gate.view(torch.int32))
        assert torch.equal(packed[8960:].view(torch.int32), up.view(torch.int32))
        inputs = x, gate, up, packed
        baseline = separate(*inputs)
        row = {'cohort_index': index, 'layer': layer, 'shape': list(x.shape),
               'input_sha256': hashlib.sha256(x.cpu().numpy().tobytes()).hexdigest(), 'variants': {}}
        original_product = pointwise(*baseline)
        packed_baseline = torch.cat(baseline, dim=-1).split(8960, dim=-1)
        row['identical_value_split_pointwise'] = compare(original_product, pointwise(*packed_baseline))
        graphs = {}
        for name, fn in functions.items():
            result = fn(*inputs)
            product = pointwise(*result)
            detail = {'gate': compare(baseline[0], result[0]), 'up': compare(baseline[1], result[1]),
                      'silu_product': compare(original_product, product),
                      'down_output': compare(torch.mm(original_product, mlp.down_proj.weight.t()),
                                             torch.mm(product, mlp.down_proj.weight.t()))}
            stream = torch.cuda.Stream()
            stream.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(stream):
                for _ in range(3): fn(*inputs)
            torch.cuda.current_stream().wait_stream(stream)
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                frozen = fn(*inputs)
            graphs[name] = (graph, frozen)
            graph.replay()
            torch.cuda.synchronize()
            detail['graph_matches_direct'] = [compare(a, b) for a, b in zip(result, frozen)]
            detail['graph_replay_projection_us'] = []
            row['variants'][name] = detail
        # Reverse each round's order; every sample averages 32 graph replays.
        for repeat in range(8):
            order = list(functions)
            if repeat % 2: order.reverse()
            for name in order:
                graph = graphs[name][0]
                begin, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
                begin.record()
                for _ in range(32): graph.replay()
                end.record(); end.synchronize()
                row['variants'][name]['graph_replay_projection_us'].append(begin.elapsed_time(end) * 1000 / 32)
        for name, detail in row['variants'].items():
            samples = detail['graph_replay_projection_us']
            detail['projection_median_us'] = statistics.median(samples)
            detail['projection_p95_us'] = statistics.quantiles(samples, n=100, method='inclusive')[94]
        if index == 1 and layer == 0:
            for name, fn in functions.items():
                with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU, torch.profiler.ProfilerActivity.CUDA]) as prof:
                    fn(*inputs)
                    torch.cuda.synchronize()
                prof.export_chrome_trace(str(args.output / (name + '_trace.json')))
                row['variants'][name]['cuda_kernels'] = sorted({event.name for event in prof.events()
                                                               if str(event.device_type).endswith('CUDA')})
        report['cases'].append(row)
        save(args.output / 'diagnosis.json', report)
        print(json.dumps({'completed_case': [index, layer], 'exact_projection_variants': [name for name, detail in row['variants'].items()
                          if all(detail[k]['matching_bits'] == detail[k]['values'] for k in ('gate', 'up'))]}), flush=True)
        del graphs, frozen, baseline, original_product, packed_baseline, result, product, packed
    report['complete'] = True
    report['memory'] = {'allocated': torch.cuda.memory_allocated(), 'reserved': torch.cuda.memory_reserved(),
                        'peak_allocated': torch.cuda.max_memory_allocated(), 'peak_reserved': torch.cuda.max_memory_reserved()}
    save(args.output / 'diagnosis.json', report)


if __name__ == '__main__':
    main()
