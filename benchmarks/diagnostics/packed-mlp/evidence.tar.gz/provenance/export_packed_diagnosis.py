"""Publish the completed fixed-input diagnostic without changing its raw data."""
import hashlib
import io
import json
from pathlib import Path
import statistics
import tarfile

BASE = Path(__file__).resolve().parents[2]
OUT = BASE / 'RapidTinyRec/benchmarks/diagnostics/packed-mlp'
read = lambda p: json.loads(p.read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()


def main():
    status = read(BASE / 'outputs/rapidtinyrec_packed_mlp_diagnosis_status.json')
    run = status['run_id']
    harness = Path(status['harness'])
    raw = harness / '.oscar/results' / run
    snapshot = Path(status['source_snapshot'])
    record = read(harness / '.oscar/runs' / (run + '.json'))
    audit = read(BASE / 'outputs/packed_mlp_diagnosis/gpu_audit.json')
    data = read(raw / 'outputs/diagnosis/diagnosis.json')
    assert audit['integrity_passed'] and data['complete']
    assert audit['two_original_gemm_controls_exact']
    assert audit['identical_input_split_pointwise_exact']
    kernels = {}
    for variant in audit['aggregates']:
        trace = read(raw / 'outputs/diagnosis' / (variant + '_trace.json'))
        kernels[variant] = [{k: e.get(k) for k in ('name', 'dur', 'args')}
                            for e in trace['traceEvents'] if e.get('cat') in ('kernel', 'gpu_memset')]
    rows = []
    for row in data['cases']:
        timing = {}
        for variant, detail in row['variants'].items():
            samples = detail['graph_replay_projection_us']
            timing[variant] = dict(median_us=statistics.median(samples),
                p95_us=statistics.quantiles(samples, n=100, method='inclusive')[94],
                min_us=min(samples), max_us=max(samples))
        rows.append(dict(cohort_index=row['cohort_index'], layer=row['layer'], timing=timing))
    summary = dict(run_id=run, job_id=status['job_id'], package_source=status['source_commit'],
        integrity_passed=True, cases=12, independent_users=4,
        aggregates=audit['aggregates'], controls_exact=True, identical_value_pointwise_exact=True,
        graph_direct_matching_values=sum(c['values'] for r in data['cases'] for v in r['variants'].values()
                                         for c in v['graph_matches_direct']),
        projection_timing_by_case=rows, first_case_kernel_launches=kernels,
        median_of_case_medians_us=audit['microtiming_median_of_case_medians_us'],
        median_of_case_p95_us={v:statistics.median(r['timing'][v]['p95_us'] for r in rows)
                               for v in audit['aggregates']},
        memory_bytes=data['memory'], activation_collection_s=data['activation_collection_s'],
        hardware=data['hardware'], torch=data['torch'], cuda=data['cuda'], tf32=data['tf32'],
        decision='Reject wide and batched projections under the FP32-bit contract. Separate packed views are exact but show no consistent useful projection improvement. Proceed to constraint-operation graph replay.',
        limitations=[data['scope'],
            'GPU output tensors were compared on device; raw activations and projection outputs were not persisted. Saved evidence contains input hashes, comparison counts/deltas, traces and all timing samples.',
            'Matching error summaries for wide and batched variants do not prove their tensors are equal to each other.',
            'Launch grid changes are consistent with different split-K/reduction organization; kernel names and grid dimensions alone do not expose proprietary cuBLAS internals.',
            'Memory is diagnostic-process current and lifetime-peak allocator usage, not per-variant inference memory. Model loading/packing/compilation/capture intervals were not separately timed here.'])
    OUT.mkdir(parents=True, exist_ok=True)
    files = {}
    for prefix, directory in [('raw', raw), ('snapshot', snapshot)]:
        for p in sorted(directory.rglob('*')):
            if p.is_file(): files[prefix + '/' + str(p.relative_to(directory))] = p.read_bytes()
    files['provenance/run-record.json'] = (harness / '.oscar/runs' / (run + '.json')).read_bytes()
    files['provenance/audit-command.json'] = (json.dumps({k:status[k] for k in ('audit_command','audit_cwd')}, indent=2)+'\n').encode()
    for name in ('gpu_audit.json', 'score_analysis.json', 'compiler-sources-manifest.json', 'report.md'):
        files['provenance/' + name] = (BASE / 'outputs/packed_mlp_diagnosis' / name).read_bytes()
    for name in ('audit_packed_diagnosis.py','analyze_packed_scores.py','export_packed_diagnosis.py'):
        files['provenance/' + name] = (BASE / 'work/rapidtinyrec_prep' / name).read_bytes()
    for p in sorted((BASE / 'outputs/packed_mlp_diagnosis/compiler-sources').rglob('*')):
        if p.is_file(): files['compiler-sources/' + str(p.relative_to(BASE / 'outputs/packed_mlp_diagnosis/compiler-sources'))] = p.read_bytes()
    files['provenance/resources.json'] = json.dumps(dict(job_id='7949846', state='COMPLETED', exit_code='0:0',
        allocated_cpus=4, requested_cpus=4, allocated_tres='billing=112,cpu=4,gres/gpu=1,mem=32G,node=1',
        start_utc='2026-10-26T00:52:32Z', end_utc='2026-10-26T00:53:37Z', node='gpu1503',
        source='sacct -j 7949846 -X -P --format=JobID,State,ExitCode,AllocCPUS,ReqCPUS,AllocTRES,Start,End,NodeList'),indent=2).encode()
    for name, digest in record['sha256'].items():
        assert sha(files['snapshot/' + name]) == digest
    for name, digest in audit['raw_sha256'].items():
        assert sha(files['raw/' + name]) == digest
    with tarfile.open(OUT / 'evidence.tar.gz', 'w:gz') as tar:
        for name, content in sorted(files.items()):
            entry=tarfile.TarInfo(name);entry.size=len(content);entry.mode=0o444;entry.mtime=0
            tar.addfile(entry, io.BytesIO(content))
    manifest = {n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())}
    for name, obj in [('summary.json',summary),('audit.json',audit),('archive-manifest.json',manifest)]:
        (OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
    source = dict(run_id=run, package_source=status['source_commit'], submitted_source_sha256=record['sha256'],
                  archived_files=len(files), evidence_sha256={p.name:sha(p.read_bytes()) for p in OUT.iterdir()
                  if p.is_file() and p.name != 'source.json'})
    (OUT/'source.json').write_text(json.dumps(source,indent=2)+'\n')
    print(json.dumps(dict(output=str(OUT), archived_files=len(files), archive_bytes=(OUT/'evidence.tar.gz').stat().st_size)))


if __name__ == '__main__':
    main()
