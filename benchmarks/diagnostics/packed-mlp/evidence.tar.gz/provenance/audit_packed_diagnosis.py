"""Audit the one fixed-input diagnostic; never promotes it to an end-to-end win."""
import hashlib
import json
import math
from pathlib import Path
import statistics

BASE = Path(__file__).resolve().parents[2]

def main():
    status = json.loads((BASE/'outputs/rapidtinyrec_packed_mlp_diagnosis_status.json').read_text())
    h, run = Path(status['harness']), status['run_id']
    record = json.loads((h/'.oscar/runs'/f'{run}.json').read_text())
    raw = h/'.oscar/results'/run
    remote = json.loads((raw/'source-manifest.json').read_text())
    assert remote['sha256'] == record['sha256']
    assert (raw/'job-id').read_text().strip() == record['job_id'] == status['job_id']
    snapshot = Path(status['source_snapshot'])
    for name,want in record['sha256'].items():
        assert hashlib.sha256((snapshot/name).read_bytes()).hexdigest() == want, name
    report = json.loads((raw/'outputs/diagnosis/diagnosis.json').read_text())
    assert report['complete'] is True and report['job_id'] == record['job_id']
    assert report['hardware'] == 'NVIDIA RTX A6000' and report['tf32'] is False
    assert len(report['cases']) == 12
    assert {(r['cohort_index'],r['layer']) for r in report['cases']} == {(i,l) for i in (1,2,6,10) for l in (0,13,27)}
    variants = ('separate','packed_views_separate','packed_wide','batched_two')
    aggregates = {v:{k:{'values':0,'matching_bits':0,'max_abs':0.} for k in ('gate','up','silu_product','down_output')} for v in variants}
    pointwise_exact = True
    for row in report['cases']:
        assert row['shape'] == [50,1536]
        probe = row['identical_value_split_pointwise']
        assert probe['values'] == 448000 and probe['finite']
        pointwise_exact &= probe['matching_bits'] == probe['values']
        assert set(row['variants']) == set(variants)
        for name,detail in row['variants'].items():
            for key,total in aggregates[name].items():
                data = detail[key]
                assert data['finite'] and data['values'] == (76800 if key=='down_output' else 448000)
                assert 0 <= data['matching_bits'] <= data['values']
                assert math.isfinite(data['max_abs']) and data['max_abs'] >= 0
                total['values'] += data['values']; total['matching_bits'] += data['matching_bits']
                total['max_abs'] = max(total['max_abs'],data['max_abs'])
            for check in detail['graph_matches_direct']:
                assert check['finite'] and check['matching_bits'] == check['values'] == 448000
            samples = detail['graph_replay_projection_us']
            assert len(samples) == 8 and all(math.isfinite(v) and v>0 for v in samples)
            assert detail['projection_median_us'] == statistics.median(samples)
            assert detail['projection_p95_us'] == statistics.quantiles(samples,n=100,method='inclusive')[94]
    controls_exact = all(aggregates[v][k]['values']==aggregates[v][k]['matching_bits'] for v in ('separate','packed_views_separate') for k in aggregates[v])
    hashes = {str(p.relative_to(raw)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(raw.rglob('*')) if p.is_file()}
    audit = {'run_id':run,'job_id':record['job_id'],'integrity_passed':True,'source_files_verified':len(record['sha256']),
        'cases':12,'aggregates':aggregates,'identical_input_split_pointwise_exact':pointwise_exact,'two_original_gemm_controls_exact':controls_exact,
        'kernel_names':{v:report['cases'][0]['variants'][v].get('cuda_kernels',[]) for v in variants},
        'microtiming_median_of_case_medians_us':{v:statistics.median(r['variants'][v]['projection_median_us'] for r in report['cases']) for v in variants},
        'scope':report['scope'],'source_sha256':record['sha256'],'raw_sha256':hashes,'no_end_to_end_promotion':True}
    out = BASE/'outputs/packed_mlp_diagnosis/gpu_audit.json'
    out.write_text(json.dumps(audit,indent=2)+'\n')
    print(json.dumps({k:v for k,v in audit.items() if k not in ('source_sha256','raw_sha256')},indent=2))
    assert controls_exact, 'Control mismatch: preserve and diagnose'

if __name__ == '__main__':
    main()
