"""Recompute four-user quality and score diagnostics from immutable pilot outputs."""
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import struct

BASE = Path(__file__).resolve().parents[2]
RUN = 'packed-mlp-pilot-20261024T215118Z-533138a5b479'
RAW = BASE / 'work/rapidtinyrec_replay/.oscar/results' / RUN / 'outputs'
HIST = BASE / 'work/minionerec_oscar/.oscar/results/benchmark-gqa-fp32-20261023T054059Z-7b4f0ee334cb/outputs/gqa_500_users'
OUT = BASE / 'outputs/packed_mlp_diagnosis'

def bits(value):
    return struct.pack('<f', value)

def stats(a, b):
    deltas = [y-x for x,y in zip(a,b)]
    return {'values': len(a), 'matching_bits': sum(bits(x)==bits(y) for x,y in zip(a,b)),
            'max_abs_delta': max(map(abs,deltas)), 'median_signed_delta': statistics.median(deltas),
            'min_signed_delta': min(deltas), 'max_signed_delta': max(deltas)}

def main():
    expected = json.loads((BASE / 'RapidTinyRec/rapidtinyrec/expected.json').read_text())
    token_path = BASE / 'work/minionerec_trace/release/Office_ckpt/added_tokens.json'
    assert hashlib.sha256(token_path.read_bytes()).hexdigest() == expected['release_sha256']['Office_ckpt/added_tokens.json']
    token_map = json.loads(token_path.read_text())
    manifest = json.loads((HIST / 'manifest.json').read_text())
    assert hashlib.sha256(json.dumps(manifest['users'],sort_keys=True).encode()).hexdigest() == expected['users_sha256']
    source_hashes = {str(token_path.relative_to(BASE)): hashlib.sha256(token_path.read_bytes()).hexdigest(),
                     str((HIST/'manifest.json').relative_to(BASE)): hashlib.sha256((HIST/'manifest.json').read_bytes()).hexdigest()}
    rows = []
    for index in (1,2,6,10):
        user = manifest['users'][index]
        values = []
        for phase in (0,1):
            p = RAW / f'phase_{phase}/users/0_{index:04d}.json'
            source_hashes[str(p.relative_to(BASE))] = hashlib.sha256(p.read_bytes()).hexdigest()
            values.append(json.loads(p.read_text())['run'])
        a,b = values
        assert a['token_ids'] == b['token_ids']
        target = [token_map[t] for t in re.findall(r'<[^>]+>',user['target_sid'])]
        assert len(target) == 3
        ranks = [[i+1 for i,seq in enumerate(v['token_ids']) if seq[:3]==target] for v in values]
        assert ranks[0] == ranks[1]
        gaps = [x-y for x,y in zip(a['sequence_logp'],a['sequence_logp'][1:])]
        rows.append({'cohort_index':index, 'prompt_tokens':user['prompt_tokens'], 'matching_rank_positions':50,
                     'sequence_scores':stats(a['sequence_logp'],b['sequence_logp']),
                     'transitions_by_step':[stats([seq[t] for seq in a['transition_logp']], [seq[t] for seq in b['transition_logp']]) for t in range(5)],
                     'target_sid_rank_folded': ranks[0][0] if ranks[0] else None,
                     'target_sid_rank_packed': ranks[1][0] if ranks[1] else None,
                     'min_adjacent_top50_sequence_gap':min(gaps)})
    metrics = {}
    for name in ('folded','packed'):
        ranks = [r['target_sid_rank_'+name] for r in rows]
        metrics[name] = {str(k):{'hits':sum(r is not None and r<=k for r in ranks),
            'hit_rate':sum(r is not None and r<=k for r in ranks)/4,
            'ndcg':sum(1/math.log2(r+1) for r in ranks if r is not None and r<=k)/4,
            'mrr':sum(1/r for r in ranks if r is not None and r<=k)/4} for k in (1,5,10,20,50)}
    max_delta = max(r['sequence_scores']['max_abs_delta'] for r in rows)
    result = {'pilot_run':RUN,'independent_users':4,'paired_repetitions_per_user':6,
              'scope':'Single held-out SID per user; SID-level metrics, not item-level collision disambiguation. Four users only. Repetitions are not independent quality samples. Unobserved top51 and intermediate beam-pruning margins are unavailable.',
              'rows':rows, 'target_sid_metrics':metrics, 'quality_metric_deltas':{str(k):{'hit_rate':0.,'ndcg':0.,'mrr':0.} for k in (1,5,10,20,50)},
              'max_sequence_abs_delta':max_delta, 'max_multiplicative_probability_change_bound':math.expm1(max_delta),
              'source_sha256':source_hashes}
    (OUT/'score_analysis.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('rows','source_sha256')},indent=2))

if __name__ == '__main__':
    main()
