# AOT ID: ['5_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
from torch._inductor.runtime.runtime_utils import assert_tensor_metadata

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/ck/cckvoeogtkik3fvabh6wpahgnd7vvfo7wgbirhk4tknbhnscvv2v.py
# Topologically Sorted Source Nodes: [inputs_embeds, pow_1, variance, rsqrt, hidden_states_1, hidden_states_2], Original ATen: [aten.embedding, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   hidden_states_1 => mul_44
#   hidden_states_2 => mul_47
#   inputs_embeds => embedding
#   pow_1 => pow_1
#   rsqrt => rsqrt
#   variance => mean
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %arg7_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg7_1]
#   %buf0 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf0]
#   %arg6_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg6_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %pow_1 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%embedding, 2), kwargs = {})
#   %mean : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %convert_element_type_default_4 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg6_1, torch.float32), kwargs = {})
#   %add_tensor : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, %convert_element_type_default_4), kwargs = {})
#   %rsqrt : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor,), kwargs = {})
#   %mul_44 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%embedding, %rsqrt), kwargs = {})
#   %mul_47 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg7_1, %mul_44), kwargs = {})
#   return %buf0,%mul_47
triton_red_fused_embedding_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_red_fused_embedding_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_embedding_mean_mul_pow_rsqrt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 620544}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_embedding_mean_mul_pow_rsqrt_0(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    tmp12 = in_ptr3
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp9 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tl.full([1, 1], 1536.0, tl.float32)
        tmp11 = (tmp5 / tmp10)
        tmp13 = tmp12.to(tl.float32)
        tmp14 = tmp11 + tmp13
        tmp15 = libdevice.rsqrt(tmp14)
        tmp16 = tmp9 * tmp15
        tmp17 = tmp7 * tmp16
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp17, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/ga/cgateun2feykz2hvaxvlj33lb6mkifswl7gzxo7c2kmm6n4nasud.py
# Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, sin, sin_3, linear_1, view_1, key_states, mul_6, x2_1, neg_1, x1_1, cat_2, mul_7, k_embed], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
# Source node to ATen node mapping:
#   cat_2 => cat_1
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   k_embed => add_216
#   key_states => permute_4
#   linear_1 => view_8
#   matmul => mul_14
#   mul_6 => mul_103
#   mul_7 => mul_114
#   neg_1 => neg_1
#   position_ids_expanded => convert_element_type
#   sin => sin
#   sin_3 => unsqueeze_5
#   view_1 => view_9
#   x1_1 => slice_4
#   x2_1 => slice_5
# Graph fragment:
#   %addmm_1 : Tensor "f32[s16, 256][256, 1]cuda:0" = PlaceHolder[target=addmm_1]
#   %arg4_1 : Tensor "f32[64][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %arg3_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg3_1]
#   %arg5_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg5_1]
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %view_8 : Tensor "f32[s16, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_1, [%arg14_1, 1, 256]), kwargs = {})
#   %view_9 : Tensor "f32[s16, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_8, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_4 : Tensor "f32[s16, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_9, [0, 2, 1, 3]), kwargs = {})
#   %mul_103 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_4, %unsqueeze_4), kwargs = {})
#   %slice_5 : Tensor "f32[s16, 2, 1, 64][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_4, 3, 64, 9223372036854775807), kwargs = {})
#   %neg_1 : Tensor "f32[s16, 2, 1, 64][128, 64, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_5,), kwargs = {})
#   %slice_4 : Tensor "f32[s16, 2, 1, 64][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_4, 3, 0, 64), kwargs = {})
#   %cat_1 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %slice_4], -1), kwargs = {})
#   %mul_114 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %unsqueeze_5), kwargs = {})
#   %add_216 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_103, %mul_114), kwargs = {})
#   return %add_216
triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1 = async_compile.triton('triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16384}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*i64', 'in_ptr3': 'fp64', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 256656}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x3 = xindex
    x2 = xindex // 256
    x0 = (xindex % 128)
    x4 = xindex // 128
    tmp0 = tl.load(in_ptr0 + (x3), xmask)
    tmp1 = tl.load(in_ptr1 + ((x3 % 64)), xmask, eviction_policy='evict_last')
    tmp2 = tl.load(in_ptr2 + (x2), xmask, eviction_policy='evict_last')
    tmp6 = in_ptr3
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp1 * tmp3
    tmp5 = tl_math.cos(tmp4)
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tmp5 * tmp7
    tmp9 = tmp0 * tmp8
    tmp10 = (x0).to(tl.int32)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 >= tmp11
    tmp13 = (x0).to(tl.int64)
    tmp14 = (tmp13).to(tl.int64)
    tmp15 = tl.full([1], 64, tl.int64)
    tmp16 = tmp14 < tmp15
    tmp17 = tl.load(in_ptr0 + (64 + 128*x4 + (x0)), tmp16 & xmask, eviction_policy='evict_last', other=0.0)
    tmp18 = -tmp17
    tmp19 = tl.full(tmp18.shape, 0.0, tmp18.dtype)
    tmp20 = tl.where(tmp16, tmp18, tmp19)
    tmp21 = tmp10 >= tmp15
    tmp22 = tl.full([1], 128, tl.int64)
    tmp23 = tmp10 < tmp22
    tmp24 = tl.load(in_ptr0 + (128*x4 + ((-64) + x0)), tmp21 & xmask, eviction_policy='evict_last', other=0.0)
    tmp25 = tl.where(tmp16, tmp20, tmp24)
    tmp26 = tl_math.sin(tmp4)
    tmp27 = tmp26 * tmp7
    tmp28 = tmp25 * tmp27
    tmp29 = tmp9 + tmp28
    tl.store(out_ptr0 + (x3), tmp29, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/ni/cnipjlnjtfvknyfvj2gktqha2gyxmk4ovk7jftxrycez5ytajbce.py
# Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, linear_2, view_2, value_states, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
# Source node to ATen node mapping:
#   cat_1 => cat
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   expand_1 => expand_4
#   expand_2 => expand_5
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   key_tensors => cat_2
#   linear => view_5
#   linear_2 => view_11
#   matmul => mul_14
#   mul_4 => mul_87
#   mul_5 => mul_98
#   neg => neg
#   output => _scaled_dot_product_efficient_attention
#   packed => view_13
#   position_ids_expanded => convert_element_type
#   q_embed => add_180
#   query_states => permute_2
#   sin => sin
#   sin_3 => unsqueeze_5
#   value_states => permute_6
#   value_tensors => cat_3
#   view => view_6
#   view_2 => view_12
#   x1 => slice_2
#   x2 => slice_3
# Graph fragment:
#   %addmm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=addmm]
#   %arg4_1 : Tensor "f32[64][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %arg3_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg3_1]
#   %arg5_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg5_1]
#   %view_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [%arg14_1, 1, 1536]), kwargs = {})
#   %view_6 : Tensor "f32[s16, 1, 12, 128][1536, 1536, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_5, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_2 : Tensor "f32[s16, 12, 1, 128][1536, 128, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_6, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %mul_87 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_2, %unsqueeze_4), kwargs = {})
#   %slice_3 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "f32[s16, 12, 1, 64][768, 64, 768, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_3,), kwargs = {})
#   %slice_2 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 0, 64), kwargs = {})
#   %cat : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_2], -1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %mul_98 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_5), kwargs = {})
#   %add_180 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_87, %mul_98), kwargs = {})
#   %view_13 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add_180, [%arg14_1, 2, 6, 128]), kwargs = {})
#   %expand_4 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg18_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %cat_2 : Tensor "f32[s16, 2, s91 + 1, 128][256*s91 + 256, 128*s91 + 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_4, %add_216], -2), kwargs = {})
#   %expand_5 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg19_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %view_11 : Tensor "f32[s16, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_2, [%arg14_1, 1, 256]), kwargs = {})
#   %view_12 : Tensor "f32[s16, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_11, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_6 : Tensor "f32[s16, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_12, [0, 2, 1, 3]), kwargs = {})
#   %cat_3 : Tensor "f32[s16, 2, s91 + 1, 128][256*s91 + 256, 128*s91 + 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_5, %permute_6], -2), kwargs = {})
#   %_scaled_dot_product_efficient_attention : [num_users=1] = call_function[target=torch.ops.aten._scaled_dot_product_efficient_attention.default](args = (%view_13, %cat_2, %cat_3, None, False), kwargs = {scale: 0.08838834764831845})
#   return %buf6
triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2 = async_compile.triton('triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*i64', 'in_ptr3': 'fp64', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1536656}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x3 = xindex
    x2 = xindex // 1536
    x0 = (xindex % 128)
    x4 = xindex // 128
    tmp0 = tl.load(in_ptr0 + (x3), xmask)
    tmp1 = tl.load(in_ptr1 + ((x3 % 64)), xmask, eviction_policy='evict_last')
    tmp2 = tl.load(in_ptr2 + (x2), xmask, eviction_policy='evict_last')
    tmp6 = in_ptr3
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp1 * tmp3
    tmp5 = tl_math.cos(tmp4)
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tmp5 * tmp7
    tmp9 = tmp0 * tmp8
    tmp10 = (x0).to(tl.int32)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 >= tmp11
    tmp13 = (x0).to(tl.int64)
    tmp14 = (tmp13).to(tl.int64)
    tmp15 = tl.full([1], 64, tl.int64)
    tmp16 = tmp14 < tmp15
    tmp17 = tl.load(in_ptr0 + (64 + 128*x4 + (x0)), tmp16 & xmask, eviction_policy='evict_last', other=0.0)
    tmp18 = -tmp17
    tmp19 = tl.full(tmp18.shape, 0.0, tmp18.dtype)
    tmp20 = tl.where(tmp16, tmp18, tmp19)
    tmp21 = tmp10 >= tmp15
    tmp22 = tl.full([1], 128, tl.int64)
    tmp23 = tmp10 < tmp22
    tmp24 = tl.load(in_ptr0 + (128*x4 + ((-64) + x0)), tmp21 & xmask, eviction_policy='evict_last', other=0.0)
    tmp25 = tl.where(tmp16, tmp20, tmp24)
    tmp26 = tl_math.sin(tmp4)
    tmp27 = tmp26 * tmp7
    tmp28 = tmp25 * tmp27
    tmp29 = tmp9 + tmp28
    tl.store(out_ptr0 + (x3), tmp29, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/ft/cftrprs67pmjpkgoa7igfogfk6blesiyk6g2wc6cv34qaedcqeeo.py
# Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, linear_2, view_2, value_states, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
# Source node to ATen node mapping:
#   cat_1 => cat
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   expand_1 => expand_4
#   expand_2 => expand_5
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   key_tensors => cat_2
#   linear => view_5
#   linear_2 => view_11
#   matmul => mul_14
#   mul_4 => mul_87
#   mul_5 => mul_98
#   neg => neg
#   output => _scaled_dot_product_efficient_attention
#   packed => view_13
#   position_ids_expanded => convert_element_type
#   q_embed => add_180
#   query_states => permute_2
#   sin => sin
#   sin_3 => unsqueeze_5
#   value_states => permute_6
#   value_tensors => cat_3
#   view => view_6
#   view_2 => view_12
#   x1 => slice_2
#   x2 => slice_3
# Graph fragment:
#   %arg18_1 : Tensor "f32[1, 2, s91, 128][256*s91, 128*s91, 128, 1]cuda:0" = PlaceHolder[target=arg18_1]
#   %add_216 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0" = PlaceHolder[target=add_216]
#   %view_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [%arg14_1, 1, 1536]), kwargs = {})
#   %view_6 : Tensor "f32[s16, 1, 12, 128][1536, 1536, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_5, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_2 : Tensor "f32[s16, 12, 1, 128][1536, 128, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_6, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %mul_87 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_2, %unsqueeze_4), kwargs = {})
#   %slice_3 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "f32[s16, 12, 1, 64][768, 64, 768, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_3,), kwargs = {})
#   %slice_2 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 0, 64), kwargs = {})
#   %cat : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_2], -1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %mul_98 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_5), kwargs = {})
#   %add_180 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_87, %mul_98), kwargs = {})
#   %view_13 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add_180, [%arg14_1, 2, 6, 128]), kwargs = {})
#   %expand_4 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg18_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %cat_2 : Tensor "f32[s16, 2, s91 + 1, 128][256*s91 + 256, 128*s91 + 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_4, %add_216], -2), kwargs = {})
#   %expand_5 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg19_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %view_11 : Tensor "f32[s16, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_2, [%arg14_1, 1, 256]), kwargs = {})
#   %view_12 : Tensor "f32[s16, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_11, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_6 : Tensor "f32[s16, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_12, [0, 2, 1, 3]), kwargs = {})
#   %cat_3 : Tensor "f32[s16, 2, s91 + 1, 128][256*s91 + 256, 128*s91 + 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_5, %permute_6], -2), kwargs = {})
#   %_scaled_dot_product_efficient_attention : [num_users=1] = call_function[target=torch.ops.aten._scaled_dot_product_efficient_attention.default](args = (%view_13, %cat_2, %cat_3, None, False), kwargs = {scale: 0.08838834764831845})
#   return %buf7
triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3 = async_compile.triton('triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'ks0': 'i64', 'ks1': 'i64', 'ks2': 'i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 8013824}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3(in_ptr0, in_ptr1, out_ptr0, ks0, ks1, ks2, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = ((xindex // 128) % ks0)
    x0 = (xindex % 128)
    x2 = ((xindex // ks2) % 2)
    x5 = xindex // ks2
    x4 = xindex
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x1).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = (ks1).to(tl.int64)
    tmp6 = (tmp5).to(tl.int64)
    tmp7 = tmp4 < tmp6
    tmp8 = tl.load(in_ptr0 + (x0 + 128*(x1) + 128*ks1*x2), tmp7 & xmask, eviction_policy='evict_last', other=0.0)
    tmp9 = (ks1).to(tl.int32)
    tmp10 = tmp0 >= tmp9
    tmp11 = (ks0).to(tl.int32)
    tmp12 = tmp0 < tmp11
    tmp13 = tl.load(in_ptr1 + (x0 + 128*x5), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp14 = tl.where(tmp7, tmp8, tmp13)
    tl.store(out_ptr0 + (x4), tmp14, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/hr/chrjjprrivuviusbims7kprdvank2wjgmz7x52lmec3v6cd4yg56.py
# Topologically Sorted Source Nodes: [attn_output], Original ATen: [aten.clone]
# Source node to ATen node mapping:
#   attn_output => clone_4
# Graph fragment:
#   %getitem : Tensor "f32[s16, 2, 6, 128][1536, 128, 256, 1]cuda:0" = PlaceHolder[target=getitem]
#   %clone_4 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%getitem,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone_4
triton_poi_fused_clone_4 = async_compile.triton('triton_poi_fused_clone_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_clone_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 921600}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_clone_4(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 6)
    x2 = ((xindex // 768) % 2)
    x3 = xindex // 1536
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 128*x2 + 256*x1 + 1536*x3), xmask)
    tl.store(out_ptr0 + (x4), tmp0, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/yu/cyuadoqeapbd2t34bycowlx4e4odu3litthbwlkmmyknikc5p5zf.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, pow_2, variance_1, rsqrt_1, hidden_states_5, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   hidden_states_3 => add_291
#   hidden_states_5 => mul_217
#   hidden_states_6 => mul_220
#   inputs_embeds => embedding
#   pow_2 => pow_2
#   rsqrt_1 => rsqrt_1
#   variance_1 => mean_1
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %arg22_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg22_1]
#   %buf16 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf16]
#   %arg21_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg21_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_291 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %pow_2 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_291, 2), kwargs = {})
#   %mean_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %convert_element_type_default_6 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg21_1, torch.float32), kwargs = {})
#   %add_tensor_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, %convert_element_type_default_6), kwargs = {})
#   %rsqrt_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_1,), kwargs = {})
#   %mul_217 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_291, %rsqrt_1), kwargs = {})
#   %mul_220 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg22_1, %mul_217), kwargs = {})
#   return %buf16,%mul_220
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 927744}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    tmp16 = in_ptr4
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tmp11 + tmp12
        tmp14 = tl.full([1, 1], 1536.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tmp15 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp13 * tmp19
        tmp21 = tmp9 * tmp20
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp21, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/sb/csb5ohivem2gxn4easponmidqbw3v6dqsipebvwyhymbwavesgg7.py
# Topologically Sorted Source Nodes: [linear_4, split, silu, mul_10], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
# Source node to ATen node mapping:
#   linear_4 => view_19
#   mul_10 => mul_244
#   silu => add_339, div, exp, neg_2
#   split => split
# Graph fragment:
#   %mm_1 : Tensor "f32[s16, 17920][17920, 1]cuda:0" = PlaceHolder[target=mm_1]
#   %view_19 : Tensor "f32[s16, 1, 17920][17920, 17920, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [%arg14_1, 1, 17920]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_19, 8960, -1), kwargs = {})
#   %neg_2 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_4,), kwargs = {})
#   %exp : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_339 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%getitem_4, %add_339), kwargs = {})
#   %mul_244 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%div, %getitem_5), kwargs = {})
#   return %mul_244
triton_poi_fused__unsafe_view_mul_silu_split_6 = async_compile.triton('triton_poi_fused__unsafe_view_mul_silu_split_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_mul_silu_split_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 7168000}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_mul_silu_split_6(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 8960)
    x1 = xindex // 8960
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 17920*x1), xmask)
    tmp6 = tl.load(in_ptr0 + (8960 + x0 + 17920*x1), xmask)
    tmp1 = -tmp0
    tmp2 = libdevice.exp(tmp1)
    tmp3 = tl.full([1], 1.0, tl.float32)
    tmp4 = tmp2 + tmp3
    tmp5 = (tmp0 / tmp4)
    tmp7 = tmp5 * tmp6
    tl.store(out_ptr0 + (x2), tmp7, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/3n/c3n4p53u2b5ksqygihm5ukzkzve35a42ian3rmgaalbiujudwqah.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, hidden_states_7, hidden_states_8, pow_3, variance_2, rsqrt_2, hidden_states_10, hidden_states_11], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   hidden_states_10 => mul_268
#   hidden_states_11 => mul_271
#   hidden_states_3 => add_291
#   hidden_states_7 => view_21
#   hidden_states_8 => add_358
#   inputs_embeds => embedding
#   pow_3 => pow_3
#   rsqrt_2 => rsqrt_2
#   variance_2 => mean_2
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %mm_2 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_2]
#   %arg26_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg26_1]
#   %buf21 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf21]
#   %arg25_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg25_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_291 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %view_21 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_358 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_291, %view_21), kwargs = {})
#   %pow_3 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_358, 2), kwargs = {})
#   %mean_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %convert_element_type_default_8 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg25_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, %convert_element_type_default_8), kwargs = {})
#   %rsqrt_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_2,), kwargs = {})
#   %mul_268 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_358, %rsqrt_2), kwargs = {})
#   %mul_271 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg26_1, %mul_268), kwargs = {})
#   return %buf21,%mul_271
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    tmp20 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp14 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp16 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tmp13 + tmp14
        tmp17 = tmp15 + tmp16
        tmp18 = tl.full([1, 1], 1536.0, tl.float32)
        tmp19 = (tmp9 / tmp18)
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp19 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp17 * tmp23
        tmp25 = tmp11 * tmp24
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp25, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/sn/csn6ccor6ary7eqpdezyaaq4ntwang2mm355374s2sv46v6rp7fh.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, hidden_states_7, hidden_states_8, attn_output_7, hidden_states_12, pow_4, variance_3, rsqrt_3, hidden_states_14, hidden_states_15], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   attn_output_7 => view_35
#   hidden_states_12 => add_599
#   hidden_states_14 => mul_441
#   hidden_states_15 => mul_444
#   hidden_states_3 => add_291
#   hidden_states_7 => view_21
#   hidden_states_8 => add_358
#   inputs_embeds => embedding
#   pow_4 => pow_4
#   rsqrt_3 => rsqrt_3
#   variance_3 => mean_3
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %mm_2 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_2]
#   %mm_3 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_3]
#   %add_599 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_599]
#   %arg39_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg39_1]
#   %buf38 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf38]
#   %arg38_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg38_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_291 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %view_21 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_358 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_291, %view_21), kwargs = {})
#   %view_35 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_599 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_358, %view_35), kwargs = {})
#   %pow_4 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_599, 2), kwargs = {})
#   %mean_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %convert_element_type_default_10 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg38_1, torch.float32), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, %convert_element_type_default_10), kwargs = {})
#   %rsqrt_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_441 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_599, %rsqrt_3), kwargs = {})
#   %mul_444 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg39_1, %mul_441), kwargs = {})
#   return %add_599,%buf38,%mul_444
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 2156544}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp11 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp5 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp7 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask & xmask, tmp12, _tmp11)
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp8, r0_mask & xmask)
    tmp11 = tl.sum(_tmp11, 1)[:, None]
    tmp17 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.debug_barrier()
        tmp14 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp11 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp13 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/5l/c5llxk643ulqbekz24lcsa2sz6kwkig7mnhzxrdnnuldedvttsju.py
# Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, pow_5, variance_4, rsqrt_4, hidden_states_19, hidden_states_20], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   hidden_states_16 => view_39
#   hidden_states_17 => add_666
#   hidden_states_19 => mul_492
#   hidden_states_20 => mul_495
#   pow_5 => pow_5
#   rsqrt_4 => rsqrt_4
#   variance_4 => mean_4
# Graph fragment:
#   %add_599 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_599]
#   %mm_5 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_5]
#   %arg43_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg43_1]
#   %buf43 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf43]
#   %arg42_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg42_1]
#   %view_39 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_666 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_599, %view_39), kwargs = {})
#   %pow_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_666, 2), kwargs = {})
#   %mean_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [-1], True), kwargs = {})
#   %convert_element_type_default_12 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg42_1, torch.float32), kwargs = {})
#   %add_tensor_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_4, %convert_element_type_default_12), kwargs = {})
#   %rsqrt_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_4,), kwargs = {})
#   %mul_492 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_666, %rsqrt_4), kwargs = {})
#   %mul_495 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg43_1, %mul_492), kwargs = {})
#   return %buf43,%mul_495
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    tmp13 = in_ptr3
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp8 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp9 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tmp8 + tmp9
        tmp11 = tl.full([1, 1], 1536.0, tl.float32)
        tmp12 = (tmp5 / tmp11)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tmp12 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp10 * tmp16
        tmp18 = tmp7 * tmp17
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp18, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/7a/c7aklu4fbiemns3ltg3c54mrcudd2a7nyscig7bkcvaywbl72f5d.py
# Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, pow_6, variance_5, rsqrt_5, hidden_states_23, hidden_states_24], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_53
#   hidden_states_16 => view_39
#   hidden_states_17 => add_666
#   hidden_states_21 => add_907
#   hidden_states_23 => mul_665
#   hidden_states_24 => mul_668
#   pow_6 => pow_6
#   rsqrt_5 => rsqrt_5
#   variance_5 => mean_5
# Graph fragment:
#   %add_599 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_599]
#   %mm_5 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_5]
#   %mm_6 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_6]
#   %arg56_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg56_1]
#   %buf59 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf59]
#   %arg55_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg55_1]
#   %view_39 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_666 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_599, %view_39), kwargs = {})
#   %view_53 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_907 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_666, %view_53), kwargs = {})
#   %pow_6 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_907, 2), kwargs = {})
#   %mean_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %convert_element_type_default_14 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg55_1, torch.float32), kwargs = {})
#   %add_tensor_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, %convert_element_type_default_14), kwargs = {})
#   %rsqrt_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_5,), kwargs = {})
#   %mul_665 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_907, %rsqrt_5), kwargs = {})
#   %mul_668 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg56_1, %mul_665), kwargs = {})
#   return %buf59,%mul_668
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1542144}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    tmp17 = in_ptr4
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp10 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp7 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp9 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/sk/cskx4kb6fpqafmn3f6xhgtoz5ohz2rfyt3rnqnmrmmwximkffpn5.py
# Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, hidden_states_25, hidden_states_26, pow_7, variance_6, rsqrt_6, hidden_states_28, hidden_states_29], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_53
#   hidden_states_16 => view_39
#   hidden_states_17 => add_666
#   hidden_states_21 => add_907
#   hidden_states_25 => view_57
#   hidden_states_26 => add_974
#   hidden_states_28 => mul_716
#   hidden_states_29 => mul_719
#   pow_7 => pow_7
#   rsqrt_6 => rsqrt_6
#   variance_6 => mean_6
# Graph fragment:
#   %add_599 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_599]
#   %mm_5 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_5]
#   %mm_6 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_6]
#   %mm_8 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %arg60_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg60_1]
#   %buf64 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf64]
#   %arg59_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg59_1]
#   %view_39 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_666 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_599, %view_39), kwargs = {})
#   %view_53 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_907 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_666, %view_53), kwargs = {})
#   %view_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_974 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_907, %view_57), kwargs = {})
#   %pow_7 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_974, 2), kwargs = {})
#   %mean_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [-1], True), kwargs = {})
#   %convert_element_type_default_16 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg59_1, torch.float32), kwargs = {})
#   %add_tensor_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_6, %convert_element_type_default_16), kwargs = {})
#   %rsqrt_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_6,), kwargs = {})
#   %mul_716 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_974, %rsqrt_6), kwargs = {})
#   %mul_719 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg60_1, %mul_716), kwargs = {})
#   return %buf64,%mul_719
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 10, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1849344}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    tmp21 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp17 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tl.full([1, 1], 1536.0, tl.float32)
        tmp20 = (tmp9 / tmp19)
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tmp20 + tmp22
        tmp24 = libdevice.rsqrt(tmp23)
        tmp25 = tmp18 * tmp24
        tmp26 = tmp11 * tmp25
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp26, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/ca/ccakktfdoy2u7gzyqufh3ofs6ubj4cxdwh34rylvw24c4wkukic5.py
# Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, hidden_states_25, hidden_states_26, attn_output_15, hidden_states_30, pow_8, variance_7, rsqrt_7, hidden_states_32, hidden_states_33], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_53
#   attn_output_15 => view_71
#   hidden_states_16 => view_39
#   hidden_states_17 => add_666
#   hidden_states_21 => add_907
#   hidden_states_25 => view_57
#   hidden_states_26 => add_974
#   hidden_states_30 => add_1215
#   hidden_states_32 => mul_889
#   hidden_states_33 => mul_892
#   pow_8 => pow_8
#   rsqrt_7 => rsqrt_7
#   variance_7 => mean_7
# Graph fragment:
#   %add_599 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_599]
#   %mm_5 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_5]
#   %mm_6 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_6]
#   %mm_8 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %mm_9 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_9]
#   %add_1215 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_1215]
#   %arg73_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg73_1]
#   %buf81 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf81]
#   %arg72_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg72_1]
#   %view_39 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_666 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_599, %view_39), kwargs = {})
#   %view_53 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_907 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_666, %view_53), kwargs = {})
#   %view_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_974 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_907, %view_57), kwargs = {})
#   %view_71 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_9, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_1215 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_974, %view_71), kwargs = {})
#   %pow_8 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_1215, 2), kwargs = {})
#   %mean_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_8, [-1], True), kwargs = {})
#   %convert_element_type_default_18 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg72_1, torch.float32), kwargs = {})
#   %add_tensor_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_7, %convert_element_type_default_18), kwargs = {})
#   %rsqrt_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_7,), kwargs = {})
#   %mul_889 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_1215, %rsqrt_7), kwargs = {})
#   %mul_892 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg73_1, %mul_889), kwargs = {})
#   return %add_1215,%buf81,%mul_892
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 2770944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp11 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp3 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp5 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp7 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask & xmask, tmp12, _tmp11)
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp8, r0_mask & xmask)
    tmp11 = tl.sum(_tmp11, 1)[:, None]
    tmp17 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.debug_barrier()
        tmp14 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp11 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp13 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/cb/ccbefgmbd7oj7qu6z62xiurvt56fgv7um3maaspmw4ykilbgq55g.py
# Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, attn_output_59, hidden_states_129, hidden_states_133, hidden_states_134, pow_31, variance_30, add_90, rsqrt_30, hidden_states_136, hidden_states_137], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_90 => add_4683
#   attn_output_59 => view_269
#   hidden_states_124 => view_255
#   hidden_states_125 => add_4362
#   hidden_states_129 => add_4603
#   hidden_states_133 => view_273
#   hidden_states_134 => add_4670
#   hidden_states_136 => mul_3404
#   hidden_states_137 => mul_3407
#   pow_31 => pow_31
#   rsqrt_30 => rsqrt_30
#   variance_30 => mean_30
# Graph fragment:
#   %add_4295 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_4295]
#   %mm_41 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_41]
#   %mm_42 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_42]
#   %mm_44 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_44]
#   %arg263_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg263_1]
#   %buf322 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf322]
#   %view_255 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_41, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4362 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4295, %view_255), kwargs = {})
#   %view_269 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_42, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4603 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4362, %view_269), kwargs = {})
#   %view_273 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_44, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4670 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4603, %view_273), kwargs = {})
#   %pow_31 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_4670, 2), kwargs = {})
#   %mean_30 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_31, [-1], True), kwargs = {})
#   %add_4683 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_30, 1e-06), kwargs = {})
#   %rsqrt_30 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4683,), kwargs = {})
#   %mul_3404 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_4670, %rsqrt_30), kwargs = {})
#   %mul_3407 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg263_1, %mul_3404), kwargs = {})
#   return %buf322,%mul_3407
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1849344}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp17 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tl.full([1, 1], 1536.0, tl.float32)
        tmp20 = (tmp9 / tmp19)
        tmp21 = tl.full([1, 1], 1e-06, tl.float32)
        tmp22 = tmp20 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp18 * tmp23
        tmp25 = tmp11 * tmp24
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp25, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/ok/cokj6pzt5wpj7spgw3uq4s6dpva4cuf2g3ueahcpnduhkr5ene6y.py
# Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, attn_output_91, hidden_states_201, pow_46, variance_45, add_136, rsqrt_45, hidden_states_203, hidden_states_204], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_136 => add_7080
#   attn_output_91 => view_413
#   hidden_states_196 => view_399
#   hidden_states_197 => add_6826
#   hidden_states_201 => add_7067
#   hidden_states_203 => mul_5145
#   hidden_states_204 => mul_5148
#   pow_46 => pow_46
#   rsqrt_45 => rsqrt_45
#   variance_45 => mean_45
# Graph fragment:
#   %add_6759 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_6759]
#   %mm_65 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_65]
#   %mm_66 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_66]
#   %arg394_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg394_1]
#   %buf489 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf489]
#   %view_399 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_65, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_6826 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_6759, %view_399), kwargs = {})
#   %view_413 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_66, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_7067 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_6826, %view_413), kwargs = {})
#   %pow_46 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_7067, 2), kwargs = {})
#   %mean_45 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_46, [-1], True), kwargs = {})
#   %add_7080 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_45, 1e-06), kwargs = {})
#   %rsqrt_45 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7080,), kwargs = {})
#   %mul_5145 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_7067, %rsqrt_45), kwargs = {})
#   %mul_5148 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg394_1, %mul_5145), kwargs = {})
#   return %buf489,%mul_5148
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1542144}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp10 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp7 / tmp15)
        tmp17 = tl.full([1, 1], 1e-06, tl.float32)
        tmp18 = tmp16 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp14 * tmp19
        tmp21 = tmp9 * tmp20
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp21, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/hp/chpam4npgnp34nonval3gujwdkgw5yahnn36jidjbterbbrps6ye.py
# Topologically Sorted Source Nodes: [hidden_states_250, hidden_states_251, pow_57, variance_56, add_168, rsqrt_56, hidden_states_253, hidden_states_254], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_168 => add_8687
#   hidden_states_250 => view_507
#   hidden_states_251 => add_8674
#   hidden_states_253 => mul_6316
#   hidden_states_254 => mul_6319
#   pow_57 => pow_57
#   rsqrt_56 => rsqrt_56
#   variance_56 => mean_56
# Graph fragment:
#   %add_8607 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_8607]
#   %mm_83 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_83]
#   %arg482_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg482_1]
#   %buf602 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf602]
#   %view_507 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_83, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_8674 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_8607, %view_507), kwargs = {})
#   %pow_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_8674, 2), kwargs = {})
#   %mean_56 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_57, [-1], True), kwargs = {})
#   %add_8687 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_56, 1e-06), kwargs = {})
#   %rsqrt_56 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_8687,), kwargs = {})
#   %mul_6316 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_8674, %rsqrt_56), kwargs = {})
#   %mul_6319 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg482_1, %mul_6316), kwargs = {})
#   return %buf602,%mul_6319
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr1 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp8 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp9 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tmp8 + tmp9
        tmp11 = tl.full([1, 1], 1536.0, tl.float32)
        tmp12 = (tmp5 / tmp11)
        tmp13 = tl.full([1, 1], 1e-06, tl.float32)
        tmp14 = tmp12 + tmp13
        tmp15 = libdevice.rsqrt(tmp14)
        tmp16 = tmp10 * tmp15
        tmp17 = tmp7 * tmp16
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp17, r0_mask & xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1, arg458_1, arg459_1, arg460_1, arg461_1, arg462_1, arg463_1, arg464_1, arg465_1, arg466_1, arg467_1, arg468_1, arg469_1, arg470_1, arg471_1, arg472_1, arg473_1, arg474_1, arg475_1, arg476_1, arg477_1, arg478_1, arg479_1, arg480_1, arg481_1, arg482_1, arg483_1 = args
        args.clear()
        s16 = arg0_1
        s74 = s16
        s52 = s16
        s91 = arg17_1
        s35 = arg483_1
        assert_size_stride_grouped((arg1_1, arg2_1, arg7_1, arg6_1), ((s16, 1), (152265, 1536), (1536, ), ()), ((1, 1), (1536, 1), (1, ), ()), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg1_1 = copy_if_misaligned(arg1_1)
            buf1 = empty_strided_cuda((s16, 1, 1536), (1536, 1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [inputs_embeds, pow_1, variance, rsqrt, hidden_states_1, hidden_states_2], Original ATen: [aten.embedding, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_embedding_mean_mul_pow_rsqrt_0.run(arg1_1, arg2_1, arg7_1, arg6_1.item(), buf1, s16, 1536, stream=raw_stream0)
            del arg6_1
            del arg7_1
            assert_size_stride_grouped((arg9_1, arg8_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf2 = empty_strided_cuda((s16, 1536), (1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg9_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg8_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf2)
            del arg8_1
            del arg9_1
            assert_size_stride_grouped((arg11_1, arg10_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf3 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg11_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg10_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf3)
            del arg10_1
            del arg11_1
            assert_size_stride_grouped((arg4_1, arg3_1, arg5_1), ((64, ), (s16, 1), ()), ((1, ), (1, 1), ()), 'input')
            arg3_1 = copy_if_misaligned(arg3_1)
            buf4 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, sin, sin_3, linear_1, view_1, key_states, mul_6, x2_1, neg_1, x1_1, cat_2, mul_7, k_embed], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf3, arg4_1, arg3_1, arg5_1.item(), buf4, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg13_1, arg12_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf5 = buf3; del buf3  # reuse
            # Topologically Sorted Source Nodes: [linear_2], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg13_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg12_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf5)
            del arg12_1
            del arg13_1
            buf6 = reinterpret_tensor(buf1, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf1  # reuse
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, linear_2, view_2, value_states, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf2, arg4_1, arg3_1, arg5_1.item(), buf6, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg18_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg18_1 = copy_if_misaligned(arg18_1)
            ps0 = 1 + s91
            ps1 = 128 + 128*s91
            buf7 = empty_strided_cuda((s16, 2, 1 + s91, 128), (256 + 256*s91, 128 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, linear_2, view_2, value_states, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg18_1, buf4, buf7, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg18_1
            assert_size_stride(arg19_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg19_1 = copy_if_misaligned(arg19_1)
            buf8 = empty_strided_cuda((s16, 2, 1 + s91, 128), (256 + 256*s91, 128 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, linear_2, view_2, value_states, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg19_1, buf5, buf8, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg19_1
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, linear_2, view_2, value_states, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            buf9 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf6, buf7, buf8, None, False, scale=0.08838834764831845)
            buf10 = buf9[0]
            assert_tensor_metadata(buf10, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf10, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf9
            buf14 = buf6; del buf6  # reuse
            # Topologically Sorted Source Nodes: [attn_output], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf10, buf14, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg20_1, (1536, 1536), (1536, 1), 'input')
            buf15 = reinterpret_tensor(buf10, (s16, 1536), (1536, 1), 0); del buf10  # reuse
            # Topologically Sorted Source Nodes: [attn_output, transpose_4, reshape_2, attn_output_3], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf14, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg20_1, (1536, 1536), (1, 1536), 0), out=buf15)
            del arg20_1
            assert_size_stride_grouped((arg22_1, arg21_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf17 = reinterpret_tensor(buf14, (s16, 1, 1536), (1536, 1536, 1), 0); del buf14  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, pow_2, variance_1, rsqrt_1, hidden_states_5, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5.run(arg1_1, arg2_1, buf15, arg22_1, arg21_1.item(), buf17, s16, 1536, stream=raw_stream0)
            del arg21_1
            del arg22_1
            assert_size_stride(arg23_1, (17920, 1536), (1536, 1), 'input')
            buf18 = empty_strided_cuda((s16, 17920), (17920, 1), torch.float32)
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, pow_2, variance_1, rsqrt_1, hidden_states_5, hidden_states_6, linear_4], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf17, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg23_1, (1536, 17920), (1, 1536), 0), out=buf18)
            del arg23_1
            buf19 = empty_strided_cuda((s16, 1, 8960), (8960, 8960, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_4, split, silu, mul_10], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf18, buf19, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg24_1, (1536, 8960), (8960, 1), 'input')
            buf20 = reinterpret_tensor(buf17, (s16, 1536), (1536, 1), 0); del buf17  # reuse
            # Topologically Sorted Source Nodes: [linear_4, split, silu, mul_10, hidden_states_7], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf19, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg24_1, (8960, 1536), (1, 8960), 0), out=buf20)
            del arg24_1
            assert_size_stride_grouped((arg26_1, arg25_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf22 = reinterpret_tensor(buf2, (s16, 1, 1536), (1536, 1536, 1), 0); del buf2  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, hidden_states_7, hidden_states_8, pow_3, variance_2, rsqrt_2, hidden_states_10, hidden_states_11], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7.run(arg1_1, arg2_1, buf15, buf20, arg26_1, arg25_1.item(), buf22, s16, 1536, stream=raw_stream0)
            del arg25_1
            del arg26_1
            assert_size_stride_grouped((arg28_1, arg27_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf23 = empty_strided_cuda((s16, 1536), (1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_6], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg28_1, reinterpret_tensor(buf22, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg27_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf23)
            del arg27_1
            del arg28_1
            assert_size_stride_grouped((arg30_1, arg29_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf24 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg30_1, reinterpret_tensor(buf22, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg29_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf24)
            del arg29_1
            del arg30_1
            buf25 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_4, sin_4, linear_7, view_4, key_states_1, mul_15, x2_3, neg_3, x1_3, cat_8, mul_16, k_embed_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf24, arg4_1, arg3_1, arg5_1.item(), buf25, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg32_1, arg31_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf26 = buf24; del buf24  # reuse
            # Topologically Sorted Source Nodes: [linear_8], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg32_1, reinterpret_tensor(buf22, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg31_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf26)
            del arg31_1
            del arg32_1
            buf27 = reinterpret_tensor(buf22, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf22  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_6, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, linear_8, view_5, value_states_1, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf23, arg4_1, arg3_1, arg5_1.item(), buf27, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg35_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg35_1 = copy_if_misaligned(arg35_1)
            buf28 = buf8; del buf8  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_6, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, linear_8, view_5, value_states_1, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg35_1, buf25, buf28, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg35_1
            assert_size_stride(arg36_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg36_1 = copy_if_misaligned(arg36_1)
            buf29 = buf7; del buf7  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_6, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, linear_8, view_5, value_states_1, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg36_1, buf26, buf29, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg36_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_6, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, linear_8, view_5, value_states_1, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf30 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf27, buf28, buf29, None, False, scale=0.08838834764831845)
            buf31 = buf30[0]
            assert_tensor_metadata(buf31, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf31, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf30
            buf35 = buf27; del buf27  # reuse
            # Topologically Sorted Source Nodes: [attn_output_4], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf31, buf35, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg37_1, (1536, 1536), (1536, 1), 'input')
            buf36 = reinterpret_tensor(buf31, (s16, 1536), (1536, 1), 0); del buf31  # reuse
            # Topologically Sorted Source Nodes: [attn_output_4, transpose_8, reshape_5, attn_output_7], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf35, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg37_1, (1536, 1536), (1, 1536), 0), out=buf36)
            del arg37_1
            assert_size_stride_grouped((arg39_1, arg38_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf37 = reinterpret_tensor(buf15, (s16, 1, 1536), (1536, 1536*s16, 1), 0); del buf15  # reuse
            buf39 = reinterpret_tensor(buf35, (s16, 1, 1536), (1536, 1536, 1), 0); del buf35  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, hidden_states_7, hidden_states_8, attn_output_7, hidden_states_12, pow_4, variance_3, rsqrt_3, hidden_states_14, hidden_states_15], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8.run(buf37, arg1_1, arg2_1, buf20, buf36, arg39_1, arg38_1.item(), buf39, s16, 1536, stream=raw_stream0)
            del arg1_1
            del arg38_1
            del arg39_1
            assert_size_stride(arg40_1, (17920, 1536), (1536, 1), 'input')
            buf40 = buf18; del buf18  # reuse
            # Topologically Sorted Source Nodes: [pow_4, variance_3, rsqrt_3, hidden_states_14, hidden_states_15, linear_10], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf39, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg40_1, (1536, 17920), (1, 1536), 0), out=buf40)
            del arg40_1
            buf41 = buf19; del buf19  # reuse
            # Topologically Sorted Source Nodes: [linear_10, split_1, silu_1, mul_19], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf40, buf41, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg41_1, (1536, 8960), (8960, 1), 'input')
            buf42 = reinterpret_tensor(buf39, (s16, 1536), (1536, 1), 0); del buf39  # reuse
            # Topologically Sorted Source Nodes: [linear_10, split_1, silu_1, mul_19, hidden_states_16], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf41, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg41_1, (8960, 1536), (1, 8960), 0), out=buf42)
            del arg41_1
            assert_size_stride_grouped((arg43_1, arg42_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf44 = reinterpret_tensor(buf36, (s16, 1, 1536), (1536, 1536, 1), 0); del buf36  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, pow_5, variance_4, rsqrt_4, hidden_states_19, hidden_states_20], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf37, buf42, arg43_1, arg42_1.item(), buf44, s16, 1536, stream=raw_stream0)
            del arg42_1
            del arg43_1
            assert_size_stride_grouped((arg45_1, arg44_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf45 = buf20; del buf20  # reuse
            # Topologically Sorted Source Nodes: [linear_12], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg45_1, reinterpret_tensor(buf44, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg44_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf45)
            del arg44_1
            del arg45_1
            assert_size_stride_grouped((arg47_1, arg46_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf46 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_13], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg47_1, reinterpret_tensor(buf44, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg46_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf46)
            del arg46_1
            del arg47_1
            buf47 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_5, sin_5, linear_13, view_7, key_states_2, mul_24, x2_5, neg_5, x1_5, cat_14, mul_25, k_embed_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf46, arg4_1, arg3_1, arg5_1.item(), buf47, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg49_1, arg48_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf48 = buf46; del buf46  # reuse
            # Topologically Sorted Source Nodes: [linear_14], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg49_1, reinterpret_tensor(buf44, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg48_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf48)
            del arg48_1
            del arg49_1
            buf49 = reinterpret_tensor(buf44, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf44  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_12, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, linear_14, view_8, value_states_2, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf45, arg4_1, arg3_1, arg5_1.item(), buf49, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg52_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg52_1 = copy_if_misaligned(arg52_1)
            buf50 = buf29; del buf29  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_12, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, linear_14, view_8, value_states_2, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg52_1, buf47, buf50, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg52_1
            assert_size_stride(arg53_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg53_1 = copy_if_misaligned(arg53_1)
            buf51 = buf28; del buf28  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_12, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, linear_14, view_8, value_states_2, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg53_1, buf48, buf51, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg53_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_12, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, linear_14, view_8, value_states_2, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf52 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf49, buf50, buf51, None, False, scale=0.08838834764831845)
            buf53 = buf52[0]
            assert_tensor_metadata(buf53, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf53, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf52
            buf57 = buf49; del buf49  # reuse
            # Topologically Sorted Source Nodes: [attn_output_8], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf53, buf57, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg54_1, (1536, 1536), (1536, 1), 'input')
            buf58 = reinterpret_tensor(buf53, (s16, 1536), (1536, 1), 0); del buf53  # reuse
            # Topologically Sorted Source Nodes: [attn_output_8, transpose_12, reshape_8, attn_output_11], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf57, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg54_1, (1536, 1536), (1, 1536), 0), out=buf58)
            del arg54_1
            assert_size_stride_grouped((arg56_1, arg55_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf60 = reinterpret_tensor(buf57, (s16, 1, 1536), (1536, 1536, 1), 0); del buf57  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, pow_6, variance_5, rsqrt_5, hidden_states_23, hidden_states_24], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf37, buf42, buf58, arg56_1, arg55_1.item(), buf60, s16, 1536, stream=raw_stream0)
            del arg55_1
            del arg56_1
            assert_size_stride(arg57_1, (17920, 1536), (1536, 1), 'input')
            buf61 = buf40; del buf40  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, pow_6, variance_5, rsqrt_5, hidden_states_23, hidden_states_24, linear_16], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf60, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg57_1, (1536, 17920), (1, 1536), 0), out=buf61)
            del arg57_1
            buf62 = buf41; del buf41  # reuse
            # Topologically Sorted Source Nodes: [linear_16, split_2, silu_2, mul_28], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf61, buf62, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg58_1, (1536, 8960), (8960, 1), 'input')
            buf63 = reinterpret_tensor(buf60, (s16, 1536), (1536, 1), 0); del buf60  # reuse
            # Topologically Sorted Source Nodes: [linear_16, split_2, silu_2, mul_28, hidden_states_25], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf62, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg58_1, (8960, 1536), (1, 8960), 0), out=buf63)
            del arg58_1
            assert_size_stride_grouped((arg60_1, arg59_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf65 = reinterpret_tensor(buf45, (s16, 1, 1536), (1536, 1536, 1), 0); del buf45  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, hidden_states_25, hidden_states_26, pow_7, variance_6, rsqrt_6, hidden_states_28, hidden_states_29], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf37, buf42, buf58, buf63, arg60_1, arg59_1.item(), buf65, s16, 1536, stream=raw_stream0)
            del arg59_1
            del arg60_1
            assert_size_stride_grouped((arg62_1, arg61_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf66 = buf23; del buf23  # reuse
            # Topologically Sorted Source Nodes: [linear_18], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg62_1, reinterpret_tensor(buf65, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg61_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf66)
            del arg61_1
            del arg62_1
            assert_size_stride_grouped((arg64_1, arg63_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf67 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_19], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg64_1, reinterpret_tensor(buf65, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg63_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf67)
            del arg63_1
            del arg64_1
            buf68 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_6, sin_6, linear_19, view_10, key_states_3, mul_33, x2_7, neg_7, x1_7, cat_20, mul_34, k_embed_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf67, arg4_1, arg3_1, arg5_1.item(), buf68, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg66_1, arg65_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf69 = buf67; del buf67  # reuse
            # Topologically Sorted Source Nodes: [linear_20], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg66_1, reinterpret_tensor(buf65, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg65_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf69)
            del arg65_1
            del arg66_1
            buf70 = reinterpret_tensor(buf65, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf65  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_18, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, linear_20, view_11, value_states_3, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf66, arg4_1, arg3_1, arg5_1.item(), buf70, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf66
            assert_size_stride(arg69_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg69_1 = copy_if_misaligned(arg69_1)
            buf71 = buf51; del buf51  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_18, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, linear_20, view_11, value_states_3, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg69_1, buf68, buf71, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg69_1
            assert_size_stride(arg70_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg70_1 = copy_if_misaligned(arg70_1)
            buf72 = buf50; del buf50  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_18, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, linear_20, view_11, value_states_3, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg70_1, buf69, buf72, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg70_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_18, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, linear_20, view_11, value_states_3, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf73 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf70, buf71, buf72, None, False, scale=0.08838834764831845)
            buf74 = buf73[0]
            assert_tensor_metadata(buf74, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf74, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf73
            buf78 = buf70; del buf70  # reuse
            # Topologically Sorted Source Nodes: [attn_output_12], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf74, buf78, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg71_1, (1536, 1536), (1536, 1), 'input')
            buf79 = reinterpret_tensor(buf74, (s16, 1536), (1536, 1), 0); del buf74  # reuse
            # Topologically Sorted Source Nodes: [attn_output_12, transpose_16, reshape_11, attn_output_15], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf78, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg71_1, (1536, 1536), (1, 1536), 0), out=buf79)
            del arg71_1
            assert_size_stride_grouped((arg73_1, arg72_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf80 = buf37; del buf37  # reuse
            buf82 = reinterpret_tensor(buf78, (s16, 1, 1536), (1536, 1536, 1), 0); del buf78  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, hidden_states_25, hidden_states_26, attn_output_15, hidden_states_30, pow_8, variance_7, rsqrt_7, hidden_states_32, hidden_states_33], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf80, buf42, buf58, buf63, buf79, arg73_1, arg72_1.item(), buf82, s16, 1536, stream=raw_stream0)
            del arg72_1
            del arg73_1
            del buf42
            assert_size_stride(arg74_1, (17920, 1536), (1536, 1), 'input')
            buf83 = buf61; del buf61  # reuse
            # Topologically Sorted Source Nodes: [pow_8, variance_7, rsqrt_7, hidden_states_32, hidden_states_33, linear_22], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf82, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg74_1, (1536, 17920), (1, 1536), 0), out=buf83)
            del arg74_1
            buf84 = buf62; del buf62  # reuse
            # Topologically Sorted Source Nodes: [linear_22, split_3, silu_3, mul_37], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf83, buf84, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg75_1, (1536, 8960), (8960, 1), 'input')
            buf85 = reinterpret_tensor(buf82, (s16, 1536), (1536, 1), 0); del buf82  # reuse
            # Topologically Sorted Source Nodes: [linear_22, split_3, silu_3, mul_37, hidden_states_34], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf84, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg75_1, (8960, 1536), (1, 8960), 0), out=buf85)
            del arg75_1
            assert_size_stride_grouped((arg77_1, arg76_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf87 = reinterpret_tensor(buf79, (s16, 1, 1536), (1536, 1536, 1), 0); del buf79  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_34, hidden_states_35, pow_9, variance_8, rsqrt_8, hidden_states_37, hidden_states_38], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf80, buf85, arg77_1, arg76_1.item(), buf87, s16, 1536, stream=raw_stream0)
            del arg76_1
            del arg77_1
            assert_size_stride_grouped((arg79_1, arg78_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf88 = buf63; del buf63  # reuse
            # Topologically Sorted Source Nodes: [linear_24], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg79_1, reinterpret_tensor(buf87, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg78_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf88)
            del arg78_1
            del arg79_1
            assert_size_stride_grouped((arg81_1, arg80_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf89 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_25], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg81_1, reinterpret_tensor(buf87, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg80_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf89)
            del arg80_1
            del arg81_1
            buf90 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_7, sin_7, linear_25, view_13, key_states_4, mul_42, x2_9, neg_9, x1_9, cat_26, mul_43, k_embed_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf89, arg4_1, arg3_1, arg5_1.item(), buf90, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg83_1, arg82_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf91 = buf89; del buf89  # reuse
            # Topologically Sorted Source Nodes: [linear_26], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg83_1, reinterpret_tensor(buf87, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg82_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf91)
            del arg82_1
            del arg83_1
            buf92 = reinterpret_tensor(buf87, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf87  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_24, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, linear_26, view_14, value_states_4, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf88, arg4_1, arg3_1, arg5_1.item(), buf92, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg86_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg86_1 = copy_if_misaligned(arg86_1)
            buf93 = buf72; del buf72  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_24, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, linear_26, view_14, value_states_4, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg86_1, buf90, buf93, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg86_1
            assert_size_stride(arg87_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg87_1 = copy_if_misaligned(arg87_1)
            buf94 = buf71; del buf71  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_24, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, linear_26, view_14, value_states_4, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg87_1, buf91, buf94, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg87_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_24, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, linear_26, view_14, value_states_4, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf95 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf92, buf93, buf94, None, False, scale=0.08838834764831845)
            buf96 = buf95[0]
            assert_tensor_metadata(buf96, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf96, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf95
            buf100 = buf92; del buf92  # reuse
            # Topologically Sorted Source Nodes: [attn_output_16], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf96, buf100, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg88_1, (1536, 1536), (1536, 1), 'input')
            buf101 = reinterpret_tensor(buf96, (s16, 1536), (1536, 1), 0); del buf96  # reuse
            # Topologically Sorted Source Nodes: [attn_output_16, transpose_20, reshape_14, attn_output_19], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf100, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg88_1, (1536, 1536), (1, 1536), 0), out=buf101)
            del arg88_1
            assert_size_stride_grouped((arg90_1, arg89_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf103 = reinterpret_tensor(buf100, (s16, 1, 1536), (1536, 1536, 1), 0); del buf100  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_34, hidden_states_35, attn_output_19, hidden_states_39, pow_10, variance_9, rsqrt_9, hidden_states_41, hidden_states_42], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf80, buf85, buf101, arg90_1, arg89_1.item(), buf103, s16, 1536, stream=raw_stream0)
            del arg89_1
            del arg90_1
            assert_size_stride(arg91_1, (17920, 1536), (1536, 1), 'input')
            buf104 = buf83; del buf83  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_34, hidden_states_35, attn_output_19, hidden_states_39, pow_10, variance_9, rsqrt_9, hidden_states_41, hidden_states_42, linear_28], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf103, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg91_1, (1536, 17920), (1, 1536), 0), out=buf104)
            del arg91_1
            buf105 = buf84; del buf84  # reuse
            # Topologically Sorted Source Nodes: [linear_28, split_4, silu_4, mul_46], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf104, buf105, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg92_1, (1536, 8960), (8960, 1), 'input')
            buf106 = reinterpret_tensor(buf103, (s16, 1536), (1536, 1), 0); del buf103  # reuse
            # Topologically Sorted Source Nodes: [linear_28, split_4, silu_4, mul_46, hidden_states_43], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf105, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg92_1, (8960, 1536), (1, 8960), 0), out=buf106)
            del arg92_1
            assert_size_stride_grouped((arg94_1, arg93_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf108 = reinterpret_tensor(buf88, (s16, 1, 1536), (1536, 1536, 1), 0); del buf88  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_34, hidden_states_35, attn_output_19, hidden_states_39, hidden_states_43, hidden_states_44, pow_11, variance_10, rsqrt_10, hidden_states_46, hidden_states_47], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf80, buf85, buf101, buf106, arg94_1, arg93_1.item(), buf108, s16, 1536, stream=raw_stream0)
            del arg93_1
            del arg94_1
            assert_size_stride_grouped((arg96_1, arg95_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf109 = buf58; del buf58  # reuse
            # Topologically Sorted Source Nodes: [linear_30], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg96_1, reinterpret_tensor(buf108, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg95_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf109)
            del arg95_1
            del arg96_1
            assert_size_stride_grouped((arg98_1, arg97_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf110 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_31], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg98_1, reinterpret_tensor(buf108, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg97_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf110)
            del arg97_1
            del arg98_1
            buf111 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_8, sin_8, linear_31, view_16, key_states_5, mul_51, x2_11, neg_11, x1_11, cat_32, mul_52, k_embed_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf110, arg4_1, arg3_1, arg5_1.item(), buf111, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg100_1, arg99_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf112 = buf110; del buf110  # reuse
            # Topologically Sorted Source Nodes: [linear_32], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg100_1, reinterpret_tensor(buf108, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg99_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf112)
            del arg100_1
            del arg99_1
            buf113 = reinterpret_tensor(buf108, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf108  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_30, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, linear_32, view_17, value_states_5, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf109, arg4_1, arg3_1, arg5_1.item(), buf113, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf109
            assert_size_stride(arg103_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg103_1 = copy_if_misaligned(arg103_1)
            buf114 = buf94; del buf94  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_30, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, linear_32, view_17, value_states_5, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg103_1, buf111, buf114, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg103_1
            assert_size_stride(arg104_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg104_1 = copy_if_misaligned(arg104_1)
            buf115 = buf93; del buf93  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_30, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, linear_32, view_17, value_states_5, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg104_1, buf112, buf115, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg104_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_30, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, linear_32, view_17, value_states_5, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf116 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf113, buf114, buf115, None, False, scale=0.08838834764831845)
            buf117 = buf116[0]
            assert_tensor_metadata(buf117, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf117, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf116
            buf121 = buf113; del buf113  # reuse
            # Topologically Sorted Source Nodes: [attn_output_20], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf117, buf121, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg105_1, (1536, 1536), (1536, 1), 'input')
            buf122 = reinterpret_tensor(buf117, (s16, 1536), (1536, 1), 0); del buf117  # reuse
            # Topologically Sorted Source Nodes: [attn_output_20, transpose_24, reshape_17, attn_output_23], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf121, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg105_1, (1536, 1536), (1, 1536), 0), out=buf122)
            del arg105_1
            assert_size_stride_grouped((arg107_1, arg106_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf123 = buf80; del buf80  # reuse
            buf125 = reinterpret_tensor(buf121, (s16, 1, 1536), (1536, 1536, 1), 0); del buf121  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_34, hidden_states_35, attn_output_19, hidden_states_39, hidden_states_43, hidden_states_44, attn_output_23, hidden_states_48, pow_12, variance_11, rsqrt_11, hidden_states_50, hidden_states_51], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf123, buf85, buf101, buf106, buf122, arg107_1, arg106_1.item(), buf125, s16, 1536, stream=raw_stream0)
            del arg106_1
            del arg107_1
            del buf101
            assert_size_stride(arg108_1, (17920, 1536), (1536, 1), 'input')
            buf126 = buf104; del buf104  # reuse
            # Topologically Sorted Source Nodes: [pow_12, variance_11, rsqrt_11, hidden_states_50, hidden_states_51, linear_34], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf125, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg108_1, (1536, 17920), (1, 1536), 0), out=buf126)
            del arg108_1
            buf127 = buf105; del buf105  # reuse
            # Topologically Sorted Source Nodes: [linear_34, split_5, silu_5, mul_55], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf126, buf127, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg109_1, (1536, 8960), (8960, 1), 'input')
            buf128 = reinterpret_tensor(buf125, (s16, 1536), (1536, 1), 0); del buf125  # reuse
            # Topologically Sorted Source Nodes: [linear_34, split_5, silu_5, mul_55, hidden_states_52], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf127, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg109_1, (8960, 1536), (1, 8960), 0), out=buf128)
            del arg109_1
            assert_size_stride_grouped((arg111_1, arg110_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf130 = reinterpret_tensor(buf85, (s16, 1, 1536), (1536, 1536, 1), 0); del buf85  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_52, hidden_states_53, pow_13, variance_12, rsqrt_12, hidden_states_55, hidden_states_56], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf123, buf128, arg111_1, arg110_1.item(), buf130, s16, 1536, stream=raw_stream0)
            del arg110_1
            del arg111_1
            assert_size_stride_grouped((arg113_1, arg112_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf131 = buf122; del buf122  # reuse
            # Topologically Sorted Source Nodes: [linear_36], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg113_1, reinterpret_tensor(buf130, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg112_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf131)
            del arg112_1
            del arg113_1
            assert_size_stride_grouped((arg115_1, arg114_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf132 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_37], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg115_1, reinterpret_tensor(buf130, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg114_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf132)
            del arg114_1
            del arg115_1
            buf133 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_9, sin_9, linear_37, view_19, key_states_6, mul_60, x2_13, neg_13, x1_13, cat_38, mul_61, k_embed_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf132, arg4_1, arg3_1, arg5_1.item(), buf133, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg117_1, arg116_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf134 = buf132; del buf132  # reuse
            # Topologically Sorted Source Nodes: [linear_38], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg117_1, reinterpret_tensor(buf130, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg116_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf134)
            del arg116_1
            del arg117_1
            buf135 = reinterpret_tensor(buf130, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf130  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_36, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, linear_38, view_20, value_states_6, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf131, arg4_1, arg3_1, arg5_1.item(), buf135, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg120_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg120_1 = copy_if_misaligned(arg120_1)
            buf136 = buf115; del buf115  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_36, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, linear_38, view_20, value_states_6, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg120_1, buf133, buf136, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg120_1
            assert_size_stride(arg121_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg121_1 = copy_if_misaligned(arg121_1)
            buf137 = buf114; del buf114  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_36, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, linear_38, view_20, value_states_6, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg121_1, buf134, buf137, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg121_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_36, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, linear_38, view_20, value_states_6, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf138 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf135, buf136, buf137, None, False, scale=0.08838834764831845)
            buf139 = buf138[0]
            assert_tensor_metadata(buf139, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf139, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf138
            buf143 = buf135; del buf135  # reuse
            # Topologically Sorted Source Nodes: [attn_output_24], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf139, buf143, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg122_1, (1536, 1536), (1536, 1), 'input')
            buf144 = reinterpret_tensor(buf139, (s16, 1536), (1536, 1), 0); del buf139  # reuse
            # Topologically Sorted Source Nodes: [attn_output_24, transpose_28, reshape_20, attn_output_27], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf143, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg122_1, (1536, 1536), (1, 1536), 0), out=buf144)
            del arg122_1
            assert_size_stride_grouped((arg124_1, arg123_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf146 = reinterpret_tensor(buf143, (s16, 1, 1536), (1536, 1536, 1), 0); del buf143  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_52, hidden_states_53, attn_output_27, hidden_states_57, pow_14, variance_13, rsqrt_13, hidden_states_59, hidden_states_60], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf123, buf128, buf144, arg124_1, arg123_1.item(), buf146, s16, 1536, stream=raw_stream0)
            del arg123_1
            del arg124_1
            assert_size_stride(arg125_1, (17920, 1536), (1536, 1), 'input')
            buf147 = buf126; del buf126  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_52, hidden_states_53, attn_output_27, hidden_states_57, pow_14, variance_13, rsqrt_13, hidden_states_59, hidden_states_60, linear_40], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf146, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg125_1, (1536, 17920), (1, 1536), 0), out=buf147)
            del arg125_1
            buf148 = buf127; del buf127  # reuse
            # Topologically Sorted Source Nodes: [linear_40, split_6, silu_6, mul_64], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf147, buf148, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg126_1, (1536, 8960), (8960, 1), 'input')
            buf149 = reinterpret_tensor(buf146, (s16, 1536), (1536, 1), 0); del buf146  # reuse
            # Topologically Sorted Source Nodes: [linear_40, split_6, silu_6, mul_64, hidden_states_61], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf148, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg126_1, (8960, 1536), (1, 8960), 0), out=buf149)
            del arg126_1
            assert_size_stride_grouped((arg128_1, arg127_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf151 = reinterpret_tensor(buf131, (s16, 1, 1536), (1536, 1536, 1), 0); del buf131  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_52, hidden_states_53, attn_output_27, hidden_states_57, hidden_states_61, hidden_states_62, pow_15, variance_14, rsqrt_14, hidden_states_64, hidden_states_65], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf123, buf128, buf144, buf149, arg128_1, arg127_1.item(), buf151, s16, 1536, stream=raw_stream0)
            del arg127_1
            del arg128_1
            assert_size_stride_grouped((arg130_1, arg129_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf152 = buf106; del buf106  # reuse
            # Topologically Sorted Source Nodes: [linear_42], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg130_1, reinterpret_tensor(buf151, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg129_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf152)
            del arg129_1
            del arg130_1
            assert_size_stride_grouped((arg132_1, arg131_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf153 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_43], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg132_1, reinterpret_tensor(buf151, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg131_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf153)
            del arg131_1
            del arg132_1
            buf154 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_10, sin_10, linear_43, view_22, key_states_7, mul_69, x2_15, neg_15, x1_15, cat_44, mul_70, k_embed_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf153, arg4_1, arg3_1, arg5_1.item(), buf154, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg134_1, arg133_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf155 = buf153; del buf153  # reuse
            # Topologically Sorted Source Nodes: [linear_44], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg134_1, reinterpret_tensor(buf151, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg133_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf155)
            del arg133_1
            del arg134_1
            buf156 = reinterpret_tensor(buf151, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf151  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, linear_44, view_23, value_states_7, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf152, arg4_1, arg3_1, arg5_1.item(), buf156, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf152
            assert_size_stride(arg137_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg137_1 = copy_if_misaligned(arg137_1)
            buf157 = buf137; del buf137  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, linear_44, view_23, value_states_7, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg137_1, buf154, buf157, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg137_1
            assert_size_stride(arg138_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg138_1 = copy_if_misaligned(arg138_1)
            buf158 = buf136; del buf136  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, linear_44, view_23, value_states_7, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg138_1, buf155, buf158, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg138_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, linear_44, view_23, value_states_7, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf159 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf156, buf157, buf158, None, False, scale=0.08838834764831845)
            buf160 = buf159[0]
            assert_tensor_metadata(buf160, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf160, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf159
            buf164 = buf156; del buf156  # reuse
            # Topologically Sorted Source Nodes: [attn_output_28], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf160, buf164, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg139_1, (1536, 1536), (1536, 1), 'input')
            buf165 = reinterpret_tensor(buf160, (s16, 1536), (1536, 1), 0); del buf160  # reuse
            # Topologically Sorted Source Nodes: [attn_output_28, transpose_32, reshape_23, attn_output_31], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf164, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg139_1, (1536, 1536), (1, 1536), 0), out=buf165)
            del arg139_1
            assert_size_stride_grouped((arg141_1, arg140_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf166 = buf123; del buf123  # reuse
            buf168 = reinterpret_tensor(buf164, (s16, 1, 1536), (1536, 1536, 1), 0); del buf164  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_52, hidden_states_53, attn_output_27, hidden_states_57, hidden_states_61, hidden_states_62, attn_output_31, hidden_states_66, pow_16, variance_15, rsqrt_15, hidden_states_68, hidden_states_69], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf166, buf128, buf144, buf149, buf165, arg141_1, arg140_1.item(), buf168, s16, 1536, stream=raw_stream0)
            del arg140_1
            del arg141_1
            del buf128
            assert_size_stride(arg142_1, (17920, 1536), (1536, 1), 'input')
            buf169 = buf147; del buf147  # reuse
            # Topologically Sorted Source Nodes: [pow_16, variance_15, rsqrt_15, hidden_states_68, hidden_states_69, linear_46], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf168, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg142_1, (1536, 17920), (1, 1536), 0), out=buf169)
            del arg142_1
            buf170 = buf148; del buf148  # reuse
            # Topologically Sorted Source Nodes: [linear_46, split_7, silu_7, mul_73], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf169, buf170, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg143_1, (1536, 8960), (8960, 1), 'input')
            buf171 = reinterpret_tensor(buf168, (s16, 1536), (1536, 1), 0); del buf168  # reuse
            # Topologically Sorted Source Nodes: [linear_46, split_7, silu_7, mul_73, hidden_states_70], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf170, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg143_1, (8960, 1536), (1, 8960), 0), out=buf171)
            del arg143_1
            assert_size_stride_grouped((arg145_1, arg144_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf173 = reinterpret_tensor(buf165, (s16, 1, 1536), (1536, 1536, 1), 0); del buf165  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_70, hidden_states_71, pow_17, variance_16, rsqrt_16, hidden_states_73, hidden_states_74], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf166, buf171, arg145_1, arg144_1.item(), buf173, s16, 1536, stream=raw_stream0)
            del arg144_1
            del arg145_1
            assert_size_stride_grouped((arg147_1, arg146_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf174 = buf149; del buf149  # reuse
            # Topologically Sorted Source Nodes: [linear_48], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg147_1, reinterpret_tensor(buf173, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg146_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf174)
            del arg146_1
            del arg147_1
            assert_size_stride_grouped((arg149_1, arg148_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf175 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_49], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg149_1, reinterpret_tensor(buf173, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg148_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf175)
            del arg148_1
            del arg149_1
            buf176 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_11, sin_11, linear_49, view_25, key_states_8, mul_78, x2_17, neg_17, x1_17, cat_50, mul_79, k_embed_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf175, arg4_1, arg3_1, arg5_1.item(), buf176, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg151_1, arg150_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf177 = buf175; del buf175  # reuse
            # Topologically Sorted Source Nodes: [linear_50], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg151_1, reinterpret_tensor(buf173, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg150_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf177)
            del arg150_1
            del arg151_1
            buf178 = reinterpret_tensor(buf173, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf173  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_48, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, linear_50, view_26, value_states_8, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf174, arg4_1, arg3_1, arg5_1.item(), buf178, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg154_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg154_1 = copy_if_misaligned(arg154_1)
            buf179 = buf158; del buf158  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_48, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, linear_50, view_26, value_states_8, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg154_1, buf176, buf179, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg154_1
            assert_size_stride(arg155_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg155_1 = copy_if_misaligned(arg155_1)
            buf180 = buf157; del buf157  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_48, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, linear_50, view_26, value_states_8, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg155_1, buf177, buf180, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg155_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_48, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, linear_50, view_26, value_states_8, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf181 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf178, buf179, buf180, None, False, scale=0.08838834764831845)
            buf182 = buf181[0]
            assert_tensor_metadata(buf182, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf182, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf181
            buf186 = buf178; del buf178  # reuse
            # Topologically Sorted Source Nodes: [attn_output_32], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf182, buf186, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg156_1, (1536, 1536), (1536, 1), 'input')
            buf187 = reinterpret_tensor(buf182, (s16, 1536), (1536, 1), 0); del buf182  # reuse
            # Topologically Sorted Source Nodes: [attn_output_32, transpose_36, reshape_26, attn_output_35], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf186, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg156_1, (1536, 1536), (1, 1536), 0), out=buf187)
            del arg156_1
            assert_size_stride_grouped((arg158_1, arg157_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf189 = reinterpret_tensor(buf186, (s16, 1, 1536), (1536, 1536, 1), 0); del buf186  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_70, hidden_states_71, attn_output_35, hidden_states_75, pow_18, variance_17, rsqrt_17, hidden_states_77, hidden_states_78], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf166, buf171, buf187, arg158_1, arg157_1.item(), buf189, s16, 1536, stream=raw_stream0)
            del arg157_1
            del arg158_1
            assert_size_stride(arg159_1, (17920, 1536), (1536, 1), 'input')
            buf190 = buf169; del buf169  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_70, hidden_states_71, attn_output_35, hidden_states_75, pow_18, variance_17, rsqrt_17, hidden_states_77, hidden_states_78, linear_52], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf189, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg159_1, (1536, 17920), (1, 1536), 0), out=buf190)
            del arg159_1
            buf191 = buf170; del buf170  # reuse
            # Topologically Sorted Source Nodes: [linear_52, split_8, silu_8, mul_82], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf190, buf191, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg160_1, (1536, 8960), (8960, 1), 'input')
            buf192 = reinterpret_tensor(buf189, (s16, 1536), (1536, 1), 0); del buf189  # reuse
            # Topologically Sorted Source Nodes: [linear_52, split_8, silu_8, mul_82, hidden_states_79], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf191, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg160_1, (8960, 1536), (1, 8960), 0), out=buf192)
            del arg160_1
            assert_size_stride_grouped((arg162_1, arg161_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf194 = reinterpret_tensor(buf174, (s16, 1, 1536), (1536, 1536, 1), 0); del buf174  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_70, hidden_states_71, attn_output_35, hidden_states_75, hidden_states_79, hidden_states_80, pow_19, variance_18, rsqrt_18, hidden_states_82, hidden_states_83], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf166, buf171, buf187, buf192, arg162_1, arg161_1.item(), buf194, s16, 1536, stream=raw_stream0)
            del arg161_1
            del arg162_1
            assert_size_stride_grouped((arg164_1, arg163_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf195 = buf144; del buf144  # reuse
            # Topologically Sorted Source Nodes: [linear_54], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg164_1, reinterpret_tensor(buf194, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg163_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf195)
            del arg163_1
            del arg164_1
            assert_size_stride_grouped((arg166_1, arg165_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf196 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_55], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg166_1, reinterpret_tensor(buf194, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg165_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf196)
            del arg165_1
            del arg166_1
            buf197 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_12, sin_12, linear_55, view_28, key_states_9, mul_87, x2_19, neg_19, x1_19, cat_56, mul_88, k_embed_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf196, arg4_1, arg3_1, arg5_1.item(), buf197, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg168_1, arg167_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf198 = buf196; del buf196  # reuse
            # Topologically Sorted Source Nodes: [linear_56], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg168_1, reinterpret_tensor(buf194, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg167_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf198)
            del arg167_1
            del arg168_1
            buf199 = reinterpret_tensor(buf194, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf194  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_54, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, linear_56, view_29, value_states_9, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf195, arg4_1, arg3_1, arg5_1.item(), buf199, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf195
            assert_size_stride(arg171_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg171_1 = copy_if_misaligned(arg171_1)
            buf200 = buf180; del buf180  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_54, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, linear_56, view_29, value_states_9, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg171_1, buf197, buf200, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg171_1
            assert_size_stride(arg172_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg172_1 = copy_if_misaligned(arg172_1)
            buf201 = buf179; del buf179  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_54, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, linear_56, view_29, value_states_9, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg172_1, buf198, buf201, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg172_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_54, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, linear_56, view_29, value_states_9, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf202 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf199, buf200, buf201, None, False, scale=0.08838834764831845)
            buf203 = buf202[0]
            assert_tensor_metadata(buf203, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf203, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf202
            buf207 = buf199; del buf199  # reuse
            # Topologically Sorted Source Nodes: [attn_output_36], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf203, buf207, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg173_1, (1536, 1536), (1536, 1), 'input')
            buf208 = reinterpret_tensor(buf203, (s16, 1536), (1536, 1), 0); del buf203  # reuse
            # Topologically Sorted Source Nodes: [attn_output_36, transpose_40, reshape_29, attn_output_39], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf207, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg173_1, (1536, 1536), (1, 1536), 0), out=buf208)
            del arg173_1
            assert_size_stride_grouped((arg175_1, arg174_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf209 = buf166; del buf166  # reuse
            buf211 = reinterpret_tensor(buf207, (s16, 1, 1536), (1536, 1536, 1), 0); del buf207  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_70, hidden_states_71, attn_output_35, hidden_states_75, hidden_states_79, hidden_states_80, attn_output_39, hidden_states_84, pow_20, variance_19, rsqrt_19, hidden_states_86, hidden_states_87], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf209, buf171, buf187, buf192, buf208, arg175_1, arg174_1.item(), buf211, s16, 1536, stream=raw_stream0)
            del arg174_1
            del arg175_1
            del buf171
            assert_size_stride(arg176_1, (17920, 1536), (1536, 1), 'input')
            buf212 = buf190; del buf190  # reuse
            # Topologically Sorted Source Nodes: [pow_20, variance_19, rsqrt_19, hidden_states_86, hidden_states_87, linear_58], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf211, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg176_1, (1536, 17920), (1, 1536), 0), out=buf212)
            del arg176_1
            buf213 = buf191; del buf191  # reuse
            # Topologically Sorted Source Nodes: [linear_58, split_9, silu_9, mul_91], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf212, buf213, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg177_1, (1536, 8960), (8960, 1), 'input')
            buf214 = reinterpret_tensor(buf211, (s16, 1536), (1536, 1), 0); del buf211  # reuse
            # Topologically Sorted Source Nodes: [linear_58, split_9, silu_9, mul_91, hidden_states_88], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf213, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg177_1, (8960, 1536), (1, 8960), 0), out=buf214)
            del arg177_1
            assert_size_stride_grouped((arg179_1, arg178_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf216 = reinterpret_tensor(buf208, (s16, 1, 1536), (1536, 1536, 1), 0); del buf208  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_88, hidden_states_89, pow_21, variance_20, rsqrt_20, hidden_states_91, hidden_states_92], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf209, buf214, arg179_1, arg178_1.item(), buf216, s16, 1536, stream=raw_stream0)
            del arg178_1
            del arg179_1
            assert_size_stride_grouped((arg181_1, arg180_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf217 = buf192; del buf192  # reuse
            # Topologically Sorted Source Nodes: [linear_60], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg181_1, reinterpret_tensor(buf216, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg180_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf217)
            del arg180_1
            del arg181_1
            assert_size_stride_grouped((arg183_1, arg182_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf218 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_61], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg183_1, reinterpret_tensor(buf216, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg182_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf218)
            del arg182_1
            del arg183_1
            buf219 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_13, sin_13, linear_61, view_31, key_states_10, mul_96, x2_21, neg_21, x1_21, cat_62, mul_97, k_embed_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf218, arg4_1, arg3_1, arg5_1.item(), buf219, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg185_1, arg184_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf220 = buf218; del buf218  # reuse
            # Topologically Sorted Source Nodes: [linear_62], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg185_1, reinterpret_tensor(buf216, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg184_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf220)
            del arg184_1
            del arg185_1
            buf221 = reinterpret_tensor(buf216, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf216  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_60, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, linear_62, view_32, value_states_10, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf217, arg4_1, arg3_1, arg5_1.item(), buf221, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg188_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg188_1 = copy_if_misaligned(arg188_1)
            buf222 = buf201; del buf201  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_60, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, linear_62, view_32, value_states_10, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg188_1, buf219, buf222, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg188_1
            assert_size_stride(arg189_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg189_1 = copy_if_misaligned(arg189_1)
            buf223 = buf200; del buf200  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_60, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, linear_62, view_32, value_states_10, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg189_1, buf220, buf223, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg189_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_60, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, linear_62, view_32, value_states_10, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf224 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf221, buf222, buf223, None, False, scale=0.08838834764831845)
            buf225 = buf224[0]
            assert_tensor_metadata(buf225, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf225, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf224
            buf229 = buf221; del buf221  # reuse
            # Topologically Sorted Source Nodes: [attn_output_40], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf225, buf229, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg190_1, (1536, 1536), (1536, 1), 'input')
            buf230 = reinterpret_tensor(buf225, (s16, 1536), (1536, 1), 0); del buf225  # reuse
            # Topologically Sorted Source Nodes: [attn_output_40, transpose_44, reshape_32, attn_output_43], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf229, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg190_1, (1536, 1536), (1, 1536), 0), out=buf230)
            del arg190_1
            assert_size_stride_grouped((arg192_1, arg191_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf232 = reinterpret_tensor(buf229, (s16, 1, 1536), (1536, 1536, 1), 0); del buf229  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_88, hidden_states_89, attn_output_43, hidden_states_93, pow_22, variance_21, rsqrt_21, hidden_states_95, hidden_states_96], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf209, buf214, buf230, arg192_1, arg191_1.item(), buf232, s16, 1536, stream=raw_stream0)
            del arg191_1
            del arg192_1
            assert_size_stride(arg193_1, (17920, 1536), (1536, 1), 'input')
            buf233 = buf212; del buf212  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_88, hidden_states_89, attn_output_43, hidden_states_93, pow_22, variance_21, rsqrt_21, hidden_states_95, hidden_states_96, linear_64], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf232, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg193_1, (1536, 17920), (1, 1536), 0), out=buf233)
            del arg193_1
            buf234 = buf213; del buf213  # reuse
            # Topologically Sorted Source Nodes: [linear_64, split_10, silu_10, mul_100], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf233, buf234, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg194_1, (1536, 8960), (8960, 1), 'input')
            buf235 = reinterpret_tensor(buf232, (s16, 1536), (1536, 1), 0); del buf232  # reuse
            # Topologically Sorted Source Nodes: [linear_64, split_10, silu_10, mul_100, hidden_states_97], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf234, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg194_1, (8960, 1536), (1, 8960), 0), out=buf235)
            del arg194_1
            assert_size_stride_grouped((arg196_1, arg195_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf237 = reinterpret_tensor(buf217, (s16, 1, 1536), (1536, 1536, 1), 0); del buf217  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_88, hidden_states_89, attn_output_43, hidden_states_93, hidden_states_97, hidden_states_98, pow_23, variance_22, rsqrt_22, hidden_states_100, hidden_states_101], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf209, buf214, buf230, buf235, arg196_1, arg195_1.item(), buf237, s16, 1536, stream=raw_stream0)
            del arg195_1
            del arg196_1
            assert_size_stride_grouped((arg198_1, arg197_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf238 = buf187; del buf187  # reuse
            # Topologically Sorted Source Nodes: [linear_66], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg198_1, reinterpret_tensor(buf237, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg197_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf238)
            del arg197_1
            del arg198_1
            assert_size_stride_grouped((arg200_1, arg199_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf239 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_67], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg200_1, reinterpret_tensor(buf237, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg199_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf239)
            del arg199_1
            del arg200_1
            buf240 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_14, sin_14, linear_67, view_34, key_states_11, mul_105, x2_23, neg_23, x1_23, cat_68, mul_106, k_embed_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf239, arg4_1, arg3_1, arg5_1.item(), buf240, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg202_1, arg201_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf241 = buf239; del buf239  # reuse
            # Topologically Sorted Source Nodes: [linear_68], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg202_1, reinterpret_tensor(buf237, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg201_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf241)
            del arg201_1
            del arg202_1
            buf242 = reinterpret_tensor(buf237, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf237  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_66, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, linear_68, view_35, value_states_11, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf238, arg4_1, arg3_1, arg5_1.item(), buf242, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf238
            assert_size_stride(arg205_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg205_1 = copy_if_misaligned(arg205_1)
            buf243 = buf223; del buf223  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_66, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, linear_68, view_35, value_states_11, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg205_1, buf240, buf243, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg205_1
            assert_size_stride(arg206_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg206_1 = copy_if_misaligned(arg206_1)
            buf244 = buf222; del buf222  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_66, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, linear_68, view_35, value_states_11, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg206_1, buf241, buf244, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg206_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_66, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, linear_68, view_35, value_states_11, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf245 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf242, buf243, buf244, None, False, scale=0.08838834764831845)
            buf246 = buf245[0]
            assert_tensor_metadata(buf246, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf246, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf245
            buf250 = buf242; del buf242  # reuse
            # Topologically Sorted Source Nodes: [attn_output_44], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf246, buf250, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg207_1, (1536, 1536), (1536, 1), 'input')
            buf251 = reinterpret_tensor(buf246, (s16, 1536), (1536, 1), 0); del buf246  # reuse
            # Topologically Sorted Source Nodes: [attn_output_44, transpose_48, reshape_35, attn_output_47], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf250, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg207_1, (1536, 1536), (1, 1536), 0), out=buf251)
            del arg207_1
            assert_size_stride_grouped((arg209_1, arg208_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf252 = buf209; del buf209  # reuse
            buf254 = reinterpret_tensor(buf250, (s16, 1, 1536), (1536, 1536, 1), 0); del buf250  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_88, hidden_states_89, attn_output_43, hidden_states_93, hidden_states_97, hidden_states_98, attn_output_47, hidden_states_102, pow_24, variance_23, rsqrt_23, hidden_states_104, hidden_states_105], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf252, buf214, buf230, buf235, buf251, arg209_1, arg208_1.item(), buf254, s16, 1536, stream=raw_stream0)
            del arg208_1
            del arg209_1
            del buf214
            assert_size_stride(arg210_1, (17920, 1536), (1536, 1), 'input')
            buf255 = buf233; del buf233  # reuse
            # Topologically Sorted Source Nodes: [pow_24, variance_23, rsqrt_23, hidden_states_104, hidden_states_105, linear_70], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf254, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg210_1, (1536, 17920), (1, 1536), 0), out=buf255)
            del arg210_1
            buf256 = buf234; del buf234  # reuse
            # Topologically Sorted Source Nodes: [linear_70, split_11, silu_11, mul_109], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf255, buf256, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg211_1, (1536, 8960), (8960, 1), 'input')
            buf257 = reinterpret_tensor(buf254, (s16, 1536), (1536, 1), 0); del buf254  # reuse
            # Topologically Sorted Source Nodes: [linear_70, split_11, silu_11, mul_109, hidden_states_106], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf256, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg211_1, (8960, 1536), (1, 8960), 0), out=buf257)
            del arg211_1
            assert_size_stride_grouped((arg213_1, arg212_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf259 = reinterpret_tensor(buf251, (s16, 1, 1536), (1536, 1536, 1), 0); del buf251  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_106, hidden_states_107, pow_25, variance_24, rsqrt_24, hidden_states_109, hidden_states_110], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf252, buf257, arg213_1, arg212_1.item(), buf259, s16, 1536, stream=raw_stream0)
            del arg212_1
            del arg213_1
            assert_size_stride_grouped((arg215_1, arg214_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf260 = buf235; del buf235  # reuse
            # Topologically Sorted Source Nodes: [linear_72], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg215_1, reinterpret_tensor(buf259, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg214_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf260)
            del arg214_1
            del arg215_1
            assert_size_stride_grouped((arg217_1, arg216_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf261 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_73], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg217_1, reinterpret_tensor(buf259, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg216_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf261)
            del arg216_1
            del arg217_1
            buf262 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_15, sin_15, linear_73, view_37, key_states_12, mul_114, x2_25, neg_25, x1_25, cat_74, mul_115, k_embed_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf261, arg4_1, arg3_1, arg5_1.item(), buf262, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg219_1, arg218_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf263 = buf261; del buf261  # reuse
            # Topologically Sorted Source Nodes: [linear_74], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg219_1, reinterpret_tensor(buf259, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg218_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf263)
            del arg218_1
            del arg219_1
            buf264 = reinterpret_tensor(buf259, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf259  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_72, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, linear_74, view_38, value_states_12, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf260, arg4_1, arg3_1, arg5_1.item(), buf264, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg222_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg222_1 = copy_if_misaligned(arg222_1)
            buf265 = buf244; del buf244  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_72, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, linear_74, view_38, value_states_12, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg222_1, buf262, buf265, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg222_1
            assert_size_stride(arg223_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg223_1 = copy_if_misaligned(arg223_1)
            buf266 = buf243; del buf243  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_72, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, linear_74, view_38, value_states_12, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg223_1, buf263, buf266, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg223_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_72, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, linear_74, view_38, value_states_12, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf267 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf264, buf265, buf266, None, False, scale=0.08838834764831845)
            buf268 = buf267[0]
            assert_tensor_metadata(buf268, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf268, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf267
            buf272 = buf264; del buf264  # reuse
            # Topologically Sorted Source Nodes: [attn_output_48], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf268, buf272, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg224_1, (1536, 1536), (1536, 1), 'input')
            buf273 = reinterpret_tensor(buf268, (s16, 1536), (1536, 1), 0); del buf268  # reuse
            # Topologically Sorted Source Nodes: [attn_output_48, transpose_52, reshape_38, attn_output_51], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf272, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg224_1, (1536, 1536), (1, 1536), 0), out=buf273)
            del arg224_1
            assert_size_stride_grouped((arg226_1, arg225_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf275 = reinterpret_tensor(buf272, (s16, 1, 1536), (1536, 1536, 1), 0); del buf272  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_106, hidden_states_107, attn_output_51, hidden_states_111, pow_26, variance_25, rsqrt_25, hidden_states_113, hidden_states_114], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf252, buf257, buf273, arg226_1, arg225_1.item(), buf275, s16, 1536, stream=raw_stream0)
            del arg225_1
            del arg226_1
            assert_size_stride(arg227_1, (17920, 1536), (1536, 1), 'input')
            buf276 = buf255; del buf255  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_106, hidden_states_107, attn_output_51, hidden_states_111, pow_26, variance_25, rsqrt_25, hidden_states_113, hidden_states_114, linear_76], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf275, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg227_1, (1536, 17920), (1, 1536), 0), out=buf276)
            del arg227_1
            buf277 = buf256; del buf256  # reuse
            # Topologically Sorted Source Nodes: [linear_76, split_12, silu_12, mul_118], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf276, buf277, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg228_1, (1536, 8960), (8960, 1), 'input')
            buf278 = reinterpret_tensor(buf275, (s16, 1536), (1536, 1), 0); del buf275  # reuse
            # Topologically Sorted Source Nodes: [linear_76, split_12, silu_12, mul_118, hidden_states_115], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf277, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg228_1, (8960, 1536), (1, 8960), 0), out=buf278)
            del arg228_1
            assert_size_stride_grouped((arg230_1, arg229_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf280 = reinterpret_tensor(buf260, (s16, 1, 1536), (1536, 1536, 1), 0); del buf260  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_106, hidden_states_107, attn_output_51, hidden_states_111, hidden_states_115, hidden_states_116, pow_27, variance_26, rsqrt_26, hidden_states_118, hidden_states_119], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf252, buf257, buf273, buf278, arg230_1, arg229_1.item(), buf280, s16, 1536, stream=raw_stream0)
            del arg229_1
            del arg230_1
            assert_size_stride_grouped((arg232_1, arg231_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf281 = buf230; del buf230  # reuse
            # Topologically Sorted Source Nodes: [linear_78], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg232_1, reinterpret_tensor(buf280, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg231_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf281)
            del arg231_1
            del arg232_1
            assert_size_stride_grouped((arg234_1, arg233_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf282 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_79], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg234_1, reinterpret_tensor(buf280, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg233_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf282)
            del arg233_1
            del arg234_1
            buf283 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_16, sin_16, linear_79, view_40, key_states_13, mul_123, x2_27, neg_27, x1_27, cat_80, mul_124, k_embed_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf282, arg4_1, arg3_1, arg5_1.item(), buf283, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg236_1, arg235_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf284 = buf282; del buf282  # reuse
            # Topologically Sorted Source Nodes: [linear_80], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg236_1, reinterpret_tensor(buf280, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg235_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf284)
            del arg235_1
            del arg236_1
            buf285 = reinterpret_tensor(buf280, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf280  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_78, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, linear_80, view_41, value_states_13, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf281, arg4_1, arg3_1, arg5_1.item(), buf285, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf281
            assert_size_stride(arg239_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg239_1 = copy_if_misaligned(arg239_1)
            buf286 = buf266; del buf266  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_78, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, linear_80, view_41, value_states_13, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg239_1, buf283, buf286, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg239_1
            assert_size_stride(arg240_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg240_1 = copy_if_misaligned(arg240_1)
            buf287 = buf265; del buf265  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_78, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, linear_80, view_41, value_states_13, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg240_1, buf284, buf287, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg240_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_78, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, linear_80, view_41, value_states_13, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf288 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf285, buf286, buf287, None, False, scale=0.08838834764831845)
            buf289 = buf288[0]
            assert_tensor_metadata(buf289, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf289, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf288
            buf293 = buf285; del buf285  # reuse
            # Topologically Sorted Source Nodes: [attn_output_52], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf289, buf293, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg241_1, (1536, 1536), (1536, 1), 'input')
            buf294 = reinterpret_tensor(buf289, (s16, 1536), (1536, 1), 0); del buf289  # reuse
            # Topologically Sorted Source Nodes: [attn_output_52, transpose_56, reshape_41, attn_output_55], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf293, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg241_1, (1536, 1536), (1, 1536), 0), out=buf294)
            del arg241_1
            assert_size_stride_grouped((arg243_1, arg242_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf295 = buf252; del buf252  # reuse
            buf297 = reinterpret_tensor(buf293, (s16, 1, 1536), (1536, 1536, 1), 0); del buf293  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_106, hidden_states_107, attn_output_51, hidden_states_111, hidden_states_115, hidden_states_116, attn_output_55, hidden_states_120, pow_28, variance_27, rsqrt_27, hidden_states_122, hidden_states_123], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf295, buf257, buf273, buf278, buf294, arg243_1, arg242_1.item(), buf297, s16, 1536, stream=raw_stream0)
            del arg242_1
            del arg243_1
            del buf257
            assert_size_stride(arg244_1, (17920, 1536), (1536, 1), 'input')
            buf298 = buf276; del buf276  # reuse
            # Topologically Sorted Source Nodes: [pow_28, variance_27, rsqrt_27, hidden_states_122, hidden_states_123, linear_82], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf297, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg244_1, (1536, 17920), (1, 1536), 0), out=buf298)
            del arg244_1
            buf299 = buf277; del buf277  # reuse
            # Topologically Sorted Source Nodes: [linear_82, split_13, silu_13, mul_127], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf298, buf299, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg245_1, (1536, 8960), (8960, 1), 'input')
            buf300 = reinterpret_tensor(buf297, (s16, 1536), (1536, 1), 0); del buf297  # reuse
            # Topologically Sorted Source Nodes: [linear_82, split_13, silu_13, mul_127, hidden_states_124], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf299, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg245_1, (8960, 1536), (1, 8960), 0), out=buf300)
            del arg245_1
            assert_size_stride_grouped((arg247_1, arg246_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf302 = reinterpret_tensor(buf294, (s16, 1, 1536), (1536, 1536, 1), 0); del buf294  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, pow_29, variance_28, rsqrt_28, hidden_states_127, hidden_states_128], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf295, buf300, arg247_1, arg246_1.item(), buf302, s16, 1536, stream=raw_stream0)
            del arg246_1
            del arg247_1
            assert_size_stride_grouped((arg249_1, arg248_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf303 = buf278; del buf278  # reuse
            # Topologically Sorted Source Nodes: [linear_84], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg249_1, reinterpret_tensor(buf302, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg248_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf303)
            del arg248_1
            del arg249_1
            assert_size_stride_grouped((arg251_1, arg250_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf304 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_85], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg251_1, reinterpret_tensor(buf302, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg250_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf304)
            del arg250_1
            del arg251_1
            buf305 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_17, sin_17, linear_85, view_43, key_states_14, mul_132, x2_29, neg_29, x1_29, cat_86, mul_133, k_embed_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf304, arg4_1, arg3_1, arg5_1.item(), buf305, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg253_1, arg252_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf306 = buf304; del buf304  # reuse
            # Topologically Sorted Source Nodes: [linear_86], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg253_1, reinterpret_tensor(buf302, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg252_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf306)
            del arg252_1
            del arg253_1
            buf307 = reinterpret_tensor(buf302, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf302  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, linear_86, view_44, value_states_14, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf303, arg4_1, arg3_1, arg5_1.item(), buf307, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg256_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg256_1 = copy_if_misaligned(arg256_1)
            buf308 = buf287; del buf287  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, linear_86, view_44, value_states_14, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg256_1, buf305, buf308, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg256_1
            assert_size_stride(arg257_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg257_1 = copy_if_misaligned(arg257_1)
            buf309 = buf286; del buf286  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, linear_86, view_44, value_states_14, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg257_1, buf306, buf309, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg257_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, linear_86, view_44, value_states_14, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf310 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf307, buf308, buf309, None, False, scale=0.08838834764831845)
            buf311 = buf310[0]
            assert_tensor_metadata(buf311, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf311, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf310
            buf315 = buf307; del buf307  # reuse
            # Topologically Sorted Source Nodes: [attn_output_56], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf311, buf315, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg258_1, (1536, 1536), (1536, 1), 'input')
            buf316 = reinterpret_tensor(buf311, (s16, 1536), (1536, 1), 0); del buf311  # reuse
            # Topologically Sorted Source Nodes: [attn_output_56, transpose_60, reshape_44, attn_output_59], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf315, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg258_1, (1536, 1536), (1, 1536), 0), out=buf316)
            del arg258_1
            assert_size_stride_grouped((arg260_1, arg259_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf318 = reinterpret_tensor(buf315, (s16, 1, 1536), (1536, 1536, 1), 0); del buf315  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, attn_output_59, hidden_states_129, pow_30, variance_29, rsqrt_29, hidden_states_131, hidden_states_132], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf295, buf300, buf316, arg260_1, arg259_1.item(), buf318, s16, 1536, stream=raw_stream0)
            del arg259_1
            del arg260_1
            assert_size_stride(arg261_1, (17920, 1536), (1536, 1), 'input')
            buf319 = buf298; del buf298  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, attn_output_59, hidden_states_129, pow_30, variance_29, rsqrt_29, hidden_states_131, hidden_states_132, linear_88], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf318, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg261_1, (1536, 17920), (1, 1536), 0), out=buf319)
            del arg261_1
            buf320 = buf299; del buf299  # reuse
            # Topologically Sorted Source Nodes: [linear_88, split_14, silu_14, mul_136], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf319, buf320, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg262_1, (1536, 8960), (8960, 1), 'input')
            buf321 = reinterpret_tensor(buf318, (s16, 1536), (1536, 1), 0); del buf318  # reuse
            # Topologically Sorted Source Nodes: [linear_88, split_14, silu_14, mul_136, hidden_states_133], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf320, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg262_1, (8960, 1536), (1, 8960), 0), out=buf321)
            del arg262_1
            assert_size_stride(arg263_1, (1536, ), (1, ), 'input')
            buf323 = reinterpret_tensor(buf303, (s16, 1, 1536), (1536, 1536, 1), 0); del buf303  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, attn_output_59, hidden_states_129, hidden_states_133, hidden_states_134, pow_31, variance_30, add_90, rsqrt_30, hidden_states_136, hidden_states_137], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf295, buf300, buf316, buf321, arg263_1, buf323, s16, 1536, stream=raw_stream0)
            del arg263_1
            assert_size_stride_grouped((arg265_1, arg264_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf324 = buf273; del buf273  # reuse
            # Topologically Sorted Source Nodes: [linear_90], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg265_1, reinterpret_tensor(buf323, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg264_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf324)
            del arg264_1
            del arg265_1
            assert_size_stride_grouped((arg267_1, arg266_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf325 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_91], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg267_1, reinterpret_tensor(buf323, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg266_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf325)
            del arg266_1
            del arg267_1
            buf326 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_18, sin_18, linear_91, view_46, key_states_15, mul_141, x2_31, neg_31, x1_31, cat_92, mul_142, k_embed_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf325, arg4_1, arg3_1, arg5_1.item(), buf326, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg269_1, arg268_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf327 = buf325; del buf325  # reuse
            # Topologically Sorted Source Nodes: [linear_92], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg269_1, reinterpret_tensor(buf323, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg268_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf327)
            del arg268_1
            del arg269_1
            buf328 = reinterpret_tensor(buf323, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf323  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_90, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, linear_92, view_47, value_states_15, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf324, arg4_1, arg3_1, arg5_1.item(), buf328, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf324
            assert_size_stride(arg272_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg272_1 = copy_if_misaligned(arg272_1)
            buf329 = buf309; del buf309  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_90, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, linear_92, view_47, value_states_15, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg272_1, buf326, buf329, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg272_1
            assert_size_stride(arg273_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg273_1 = copy_if_misaligned(arg273_1)
            buf330 = buf308; del buf308  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_90, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, linear_92, view_47, value_states_15, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg273_1, buf327, buf330, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg273_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_90, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, linear_92, view_47, value_states_15, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf331 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf328, buf329, buf330, None, False, scale=0.08838834764831845)
            buf332 = buf331[0]
            assert_tensor_metadata(buf332, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf332, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf331
            buf336 = buf328; del buf328  # reuse
            # Topologically Sorted Source Nodes: [attn_output_60], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf332, buf336, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg274_1, (1536, 1536), (1536, 1), 'input')
            buf337 = reinterpret_tensor(buf332, (s16, 1536), (1536, 1), 0); del buf332  # reuse
            # Topologically Sorted Source Nodes: [attn_output_60, transpose_64, reshape_47, attn_output_63], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf336, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg274_1, (1536, 1536), (1, 1536), 0), out=buf337)
            del arg274_1
            assert_size_stride_grouped((arg276_1, arg275_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf338 = buf295; del buf295  # reuse
            buf340 = reinterpret_tensor(buf336, (s16, 1, 1536), (1536, 1536, 1), 0); del buf336  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, attn_output_59, hidden_states_129, hidden_states_133, hidden_states_134, attn_output_63, hidden_states_138, pow_32, variance_31, rsqrt_31, hidden_states_140, hidden_states_141], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf338, buf300, buf316, buf321, buf337, arg276_1, arg275_1.item(), buf340, s16, 1536, stream=raw_stream0)
            del arg275_1
            del arg276_1
            del buf300
            assert_size_stride(arg277_1, (17920, 1536), (1536, 1), 'input')
            buf341 = buf319; del buf319  # reuse
            # Topologically Sorted Source Nodes: [pow_32, variance_31, rsqrt_31, hidden_states_140, hidden_states_141, linear_94], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf340, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg277_1, (1536, 17920), (1, 1536), 0), out=buf341)
            del arg277_1
            buf342 = buf320; del buf320  # reuse
            # Topologically Sorted Source Nodes: [linear_94, split_15, silu_15, mul_145], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf341, buf342, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg278_1, (1536, 8960), (8960, 1), 'input')
            buf343 = reinterpret_tensor(buf340, (s16, 1536), (1536, 1), 0); del buf340  # reuse
            # Topologically Sorted Source Nodes: [linear_94, split_15, silu_15, mul_145, hidden_states_142], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf342, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg278_1, (8960, 1536), (1, 8960), 0), out=buf343)
            del arg278_1
            assert_size_stride_grouped((arg280_1, arg279_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf345 = reinterpret_tensor(buf337, (s16, 1, 1536), (1536, 1536, 1), 0); del buf337  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_142, hidden_states_143, pow_33, variance_32, rsqrt_32, hidden_states_145, hidden_states_146], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf338, buf343, arg280_1, arg279_1.item(), buf345, s16, 1536, stream=raw_stream0)
            del arg279_1
            del arg280_1
            assert_size_stride_grouped((arg282_1, arg281_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf346 = buf321; del buf321  # reuse
            # Topologically Sorted Source Nodes: [linear_96], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg282_1, reinterpret_tensor(buf345, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg281_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf346)
            del arg281_1
            del arg282_1
            assert_size_stride_grouped((arg284_1, arg283_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf347 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_97], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg284_1, reinterpret_tensor(buf345, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg283_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf347)
            del arg283_1
            del arg284_1
            buf348 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_19, sin_19, linear_97, view_49, key_states_16, mul_150, x2_33, neg_33, x1_33, cat_98, mul_151, k_embed_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf347, arg4_1, arg3_1, arg5_1.item(), buf348, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg286_1, arg285_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf349 = buf347; del buf347  # reuse
            # Topologically Sorted Source Nodes: [linear_98], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg286_1, reinterpret_tensor(buf345, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg285_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf349)
            del arg285_1
            del arg286_1
            buf350 = reinterpret_tensor(buf345, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf345  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_96, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, linear_98, view_50, value_states_16, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf346, arg4_1, arg3_1, arg5_1.item(), buf350, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg289_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg289_1 = copy_if_misaligned(arg289_1)
            buf351 = buf330; del buf330  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_96, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, linear_98, view_50, value_states_16, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg289_1, buf348, buf351, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg289_1
            assert_size_stride(arg290_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg290_1 = copy_if_misaligned(arg290_1)
            buf352 = buf329; del buf329  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_96, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, linear_98, view_50, value_states_16, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg290_1, buf349, buf352, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg290_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_96, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, linear_98, view_50, value_states_16, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf353 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf350, buf351, buf352, None, False, scale=0.08838834764831845)
            buf354 = buf353[0]
            assert_tensor_metadata(buf354, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf354, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf353
            buf358 = buf350; del buf350  # reuse
            # Topologically Sorted Source Nodes: [attn_output_64], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf354, buf358, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg291_1, (1536, 1536), (1536, 1), 'input')
            buf359 = reinterpret_tensor(buf354, (s16, 1536), (1536, 1), 0); del buf354  # reuse
            # Topologically Sorted Source Nodes: [attn_output_64, transpose_68, reshape_50, attn_output_67], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf358, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg291_1, (1536, 1536), (1, 1536), 0), out=buf359)
            del arg291_1
            assert_size_stride_grouped((arg293_1, arg292_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf361 = reinterpret_tensor(buf358, (s16, 1, 1536), (1536, 1536, 1), 0); del buf358  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_142, hidden_states_143, attn_output_67, hidden_states_147, pow_34, variance_33, rsqrt_33, hidden_states_149, hidden_states_150], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf338, buf343, buf359, arg293_1, arg292_1.item(), buf361, s16, 1536, stream=raw_stream0)
            del arg292_1
            del arg293_1
            assert_size_stride(arg294_1, (17920, 1536), (1536, 1), 'input')
            buf362 = buf341; del buf341  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_142, hidden_states_143, attn_output_67, hidden_states_147, pow_34, variance_33, rsqrt_33, hidden_states_149, hidden_states_150, linear_100], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf361, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg294_1, (1536, 17920), (1, 1536), 0), out=buf362)
            del arg294_1
            buf363 = buf342; del buf342  # reuse
            # Topologically Sorted Source Nodes: [linear_100, split_16, silu_16, mul_154], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf362, buf363, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg295_1, (1536, 8960), (8960, 1), 'input')
            buf364 = reinterpret_tensor(buf361, (s16, 1536), (1536, 1), 0); del buf361  # reuse
            # Topologically Sorted Source Nodes: [linear_100, split_16, silu_16, mul_154, hidden_states_151], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf363, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg295_1, (8960, 1536), (1, 8960), 0), out=buf364)
            del arg295_1
            assert_size_stride_grouped((arg297_1, arg296_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf366 = reinterpret_tensor(buf346, (s16, 1, 1536), (1536, 1536, 1), 0); del buf346  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_142, hidden_states_143, attn_output_67, hidden_states_147, hidden_states_151, hidden_states_152, pow_35, variance_34, rsqrt_34, hidden_states_154, hidden_states_155], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf338, buf343, buf359, buf364, arg297_1, arg296_1.item(), buf366, s16, 1536, stream=raw_stream0)
            del arg296_1
            del arg297_1
            assert_size_stride_grouped((arg299_1, arg298_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf367 = buf316; del buf316  # reuse
            # Topologically Sorted Source Nodes: [linear_102], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg299_1, reinterpret_tensor(buf366, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg298_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf367)
            del arg298_1
            del arg299_1
            assert_size_stride_grouped((arg301_1, arg300_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf368 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_103], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg301_1, reinterpret_tensor(buf366, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg300_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf368)
            del arg300_1
            del arg301_1
            buf369 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_20, sin_20, linear_103, view_52, key_states_17, mul_159, x2_35, neg_35, x1_35, cat_104, mul_160, k_embed_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf368, arg4_1, arg3_1, arg5_1.item(), buf369, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg303_1, arg302_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf370 = buf368; del buf368  # reuse
            # Topologically Sorted Source Nodes: [linear_104], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg303_1, reinterpret_tensor(buf366, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg302_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf370)
            del arg302_1
            del arg303_1
            buf371 = reinterpret_tensor(buf366, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf366  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_102, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, linear_104, view_53, value_states_17, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf367, arg4_1, arg3_1, arg5_1.item(), buf371, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf367
            assert_size_stride(arg306_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg306_1 = copy_if_misaligned(arg306_1)
            buf372 = buf352; del buf352  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_102, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, linear_104, view_53, value_states_17, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg306_1, buf369, buf372, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg306_1
            assert_size_stride(arg307_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg307_1 = copy_if_misaligned(arg307_1)
            buf373 = buf351; del buf351  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_102, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, linear_104, view_53, value_states_17, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg307_1, buf370, buf373, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg307_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_102, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, linear_104, view_53, value_states_17, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf374 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf371, buf372, buf373, None, False, scale=0.08838834764831845)
            buf375 = buf374[0]
            assert_tensor_metadata(buf375, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf375, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf374
            buf379 = buf371; del buf371  # reuse
            # Topologically Sorted Source Nodes: [attn_output_68], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf375, buf379, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg308_1, (1536, 1536), (1536, 1), 'input')
            buf380 = reinterpret_tensor(buf375, (s16, 1536), (1536, 1), 0); del buf375  # reuse
            # Topologically Sorted Source Nodes: [attn_output_68, transpose_72, reshape_53, attn_output_71], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf379, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg308_1, (1536, 1536), (1, 1536), 0), out=buf380)
            del arg308_1
            assert_size_stride_grouped((arg310_1, arg309_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf381 = buf338; del buf338  # reuse
            buf383 = reinterpret_tensor(buf379, (s16, 1, 1536), (1536, 1536, 1), 0); del buf379  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_142, hidden_states_143, attn_output_67, hidden_states_147, hidden_states_151, hidden_states_152, attn_output_71, hidden_states_156, pow_36, variance_35, rsqrt_35, hidden_states_158, hidden_states_159], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf381, buf343, buf359, buf364, buf380, arg310_1, arg309_1.item(), buf383, s16, 1536, stream=raw_stream0)
            del arg309_1
            del arg310_1
            del buf343
            assert_size_stride(arg311_1, (17920, 1536), (1536, 1), 'input')
            buf384 = buf362; del buf362  # reuse
            # Topologically Sorted Source Nodes: [pow_36, variance_35, rsqrt_35, hidden_states_158, hidden_states_159, linear_106], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf383, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg311_1, (1536, 17920), (1, 1536), 0), out=buf384)
            del arg311_1
            buf385 = buf363; del buf363  # reuse
            # Topologically Sorted Source Nodes: [linear_106, split_17, silu_17, mul_163], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf384, buf385, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg312_1, (1536, 8960), (8960, 1), 'input')
            buf386 = reinterpret_tensor(buf383, (s16, 1536), (1536, 1), 0); del buf383  # reuse
            # Topologically Sorted Source Nodes: [linear_106, split_17, silu_17, mul_163, hidden_states_160], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf385, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg312_1, (8960, 1536), (1, 8960), 0), out=buf386)
            del arg312_1
            assert_size_stride_grouped((arg314_1, arg313_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf388 = reinterpret_tensor(buf380, (s16, 1, 1536), (1536, 1536, 1), 0); del buf380  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_160, hidden_states_161, pow_37, variance_36, rsqrt_36, hidden_states_163, hidden_states_164], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf381, buf386, arg314_1, arg313_1.item(), buf388, s16, 1536, stream=raw_stream0)
            del arg313_1
            del arg314_1
            assert_size_stride_grouped((arg316_1, arg315_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf389 = buf364; del buf364  # reuse
            # Topologically Sorted Source Nodes: [linear_108], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg316_1, reinterpret_tensor(buf388, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg315_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf389)
            del arg315_1
            del arg316_1
            assert_size_stride_grouped((arg318_1, arg317_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf390 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_109], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg318_1, reinterpret_tensor(buf388, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg317_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf390)
            del arg317_1
            del arg318_1
            buf391 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_21, sin_21, linear_109, view_55, key_states_18, mul_168, x2_37, neg_37, x1_37, cat_110, mul_169, k_embed_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf390, arg4_1, arg3_1, arg5_1.item(), buf391, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg320_1, arg319_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf392 = buf390; del buf390  # reuse
            # Topologically Sorted Source Nodes: [linear_110], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg320_1, reinterpret_tensor(buf388, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg319_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf392)
            del arg319_1
            del arg320_1
            buf393 = reinterpret_tensor(buf388, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf388  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_108, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, linear_110, view_56, value_states_18, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf389, arg4_1, arg3_1, arg5_1.item(), buf393, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg323_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg323_1 = copy_if_misaligned(arg323_1)
            buf394 = buf373; del buf373  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_108, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, linear_110, view_56, value_states_18, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg323_1, buf391, buf394, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg323_1
            assert_size_stride(arg324_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg324_1 = copy_if_misaligned(arg324_1)
            buf395 = buf372; del buf372  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_108, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, linear_110, view_56, value_states_18, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg324_1, buf392, buf395, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg324_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_108, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, linear_110, view_56, value_states_18, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf396 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf393, buf394, buf395, None, False, scale=0.08838834764831845)
            buf397 = buf396[0]
            assert_tensor_metadata(buf397, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf397, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf396
            buf401 = buf393; del buf393  # reuse
            # Topologically Sorted Source Nodes: [attn_output_72], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf397, buf401, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg325_1, (1536, 1536), (1536, 1), 'input')
            buf402 = reinterpret_tensor(buf397, (s16, 1536), (1536, 1), 0); del buf397  # reuse
            # Topologically Sorted Source Nodes: [attn_output_72, transpose_76, reshape_56, attn_output_75], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf401, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg325_1, (1536, 1536), (1, 1536), 0), out=buf402)
            del arg325_1
            assert_size_stride_grouped((arg327_1, arg326_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf404 = reinterpret_tensor(buf401, (s16, 1, 1536), (1536, 1536, 1), 0); del buf401  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_160, hidden_states_161, attn_output_75, hidden_states_165, pow_38, variance_37, rsqrt_37, hidden_states_167, hidden_states_168], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf381, buf386, buf402, arg327_1, arg326_1.item(), buf404, s16, 1536, stream=raw_stream0)
            del arg326_1
            del arg327_1
            assert_size_stride(arg328_1, (17920, 1536), (1536, 1), 'input')
            buf405 = buf384; del buf384  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_160, hidden_states_161, attn_output_75, hidden_states_165, pow_38, variance_37, rsqrt_37, hidden_states_167, hidden_states_168, linear_112], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf404, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg328_1, (1536, 17920), (1, 1536), 0), out=buf405)
            del arg328_1
            buf406 = buf385; del buf385  # reuse
            # Topologically Sorted Source Nodes: [linear_112, split_18, silu_18, mul_172], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf405, buf406, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg329_1, (1536, 8960), (8960, 1), 'input')
            buf407 = reinterpret_tensor(buf404, (s16, 1536), (1536, 1), 0); del buf404  # reuse
            # Topologically Sorted Source Nodes: [linear_112, split_18, silu_18, mul_172, hidden_states_169], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf406, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg329_1, (8960, 1536), (1, 8960), 0), out=buf407)
            del arg329_1
            assert_size_stride_grouped((arg331_1, arg330_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf409 = reinterpret_tensor(buf389, (s16, 1, 1536), (1536, 1536, 1), 0); del buf389  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_160, hidden_states_161, attn_output_75, hidden_states_165, hidden_states_169, hidden_states_170, pow_39, variance_38, rsqrt_38, hidden_states_172, hidden_states_173], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf381, buf386, buf402, buf407, arg331_1, arg330_1.item(), buf409, s16, 1536, stream=raw_stream0)
            del arg330_1
            del arg331_1
            assert_size_stride_grouped((arg333_1, arg332_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf410 = buf359; del buf359  # reuse
            # Topologically Sorted Source Nodes: [linear_114], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg333_1, reinterpret_tensor(buf409, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg332_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf410)
            del arg332_1
            del arg333_1
            assert_size_stride_grouped((arg335_1, arg334_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf411 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_115], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg335_1, reinterpret_tensor(buf409, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg334_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf411)
            del arg334_1
            del arg335_1
            buf412 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_22, sin_22, linear_115, view_58, key_states_19, mul_177, x2_39, neg_39, x1_39, cat_116, mul_178, k_embed_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf411, arg4_1, arg3_1, arg5_1.item(), buf412, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg337_1, arg336_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf413 = buf411; del buf411  # reuse
            # Topologically Sorted Source Nodes: [linear_116], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg337_1, reinterpret_tensor(buf409, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg336_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf413)
            del arg336_1
            del arg337_1
            buf414 = reinterpret_tensor(buf409, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf409  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_114, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, linear_116, view_59, value_states_19, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf410, arg4_1, arg3_1, arg5_1.item(), buf414, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf410
            assert_size_stride(arg340_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg340_1 = copy_if_misaligned(arg340_1)
            buf415 = buf395; del buf395  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_114, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, linear_116, view_59, value_states_19, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg340_1, buf412, buf415, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg340_1
            assert_size_stride(arg341_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg341_1 = copy_if_misaligned(arg341_1)
            buf416 = buf394; del buf394  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_114, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, linear_116, view_59, value_states_19, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg341_1, buf413, buf416, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg341_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_114, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, linear_116, view_59, value_states_19, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf417 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf414, buf415, buf416, None, False, scale=0.08838834764831845)
            buf418 = buf417[0]
            assert_tensor_metadata(buf418, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf418, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf417
            buf422 = buf414; del buf414  # reuse
            # Topologically Sorted Source Nodes: [attn_output_76], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf418, buf422, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg342_1, (1536, 1536), (1536, 1), 'input')
            buf423 = reinterpret_tensor(buf418, (s16, 1536), (1536, 1), 0); del buf418  # reuse
            # Topologically Sorted Source Nodes: [attn_output_76, transpose_80, reshape_59, attn_output_79], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf422, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg342_1, (1536, 1536), (1, 1536), 0), out=buf423)
            del arg342_1
            assert_size_stride_grouped((arg344_1, arg343_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf424 = buf381; del buf381  # reuse
            buf426 = reinterpret_tensor(buf422, (s16, 1, 1536), (1536, 1536, 1), 0); del buf422  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_160, hidden_states_161, attn_output_75, hidden_states_165, hidden_states_169, hidden_states_170, attn_output_79, hidden_states_174, pow_40, variance_39, rsqrt_39, hidden_states_176, hidden_states_177], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf424, buf386, buf402, buf407, buf423, arg344_1, arg343_1.item(), buf426, s16, 1536, stream=raw_stream0)
            del arg343_1
            del arg344_1
            del buf386
            assert_size_stride(arg345_1, (17920, 1536), (1536, 1), 'input')
            buf427 = buf405; del buf405  # reuse
            # Topologically Sorted Source Nodes: [pow_40, variance_39, rsqrt_39, hidden_states_176, hidden_states_177, linear_118], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf426, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg345_1, (1536, 17920), (1, 1536), 0), out=buf427)
            del arg345_1
            buf428 = buf406; del buf406  # reuse
            # Topologically Sorted Source Nodes: [linear_118, split_19, silu_19, mul_181], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf427, buf428, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg346_1, (1536, 8960), (8960, 1), 'input')
            buf429 = reinterpret_tensor(buf426, (s16, 1536), (1536, 1), 0); del buf426  # reuse
            # Topologically Sorted Source Nodes: [linear_118, split_19, silu_19, mul_181, hidden_states_178], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf428, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg346_1, (8960, 1536), (1, 8960), 0), out=buf429)
            del arg346_1
            assert_size_stride_grouped((arg348_1, arg347_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf431 = reinterpret_tensor(buf423, (s16, 1, 1536), (1536, 1536, 1), 0); del buf423  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_178, hidden_states_179, pow_41, variance_40, rsqrt_40, hidden_states_181, hidden_states_182], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf424, buf429, arg348_1, arg347_1.item(), buf431, s16, 1536, stream=raw_stream0)
            del arg347_1
            del arg348_1
            assert_size_stride_grouped((arg350_1, arg349_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf432 = buf407; del buf407  # reuse
            # Topologically Sorted Source Nodes: [linear_120], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg350_1, reinterpret_tensor(buf431, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg349_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf432)
            del arg349_1
            del arg350_1
            assert_size_stride_grouped((arg352_1, arg351_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf433 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_121], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg352_1, reinterpret_tensor(buf431, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg351_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf433)
            del arg351_1
            del arg352_1
            buf434 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_23, sin_23, linear_121, view_61, key_states_20, mul_186, x2_41, neg_41, x1_41, cat_122, mul_187, k_embed_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf433, arg4_1, arg3_1, arg5_1.item(), buf434, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg354_1, arg353_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf435 = buf433; del buf433  # reuse
            # Topologically Sorted Source Nodes: [linear_122], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg354_1, reinterpret_tensor(buf431, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg353_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf435)
            del arg353_1
            del arg354_1
            buf436 = reinterpret_tensor(buf431, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf431  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_120, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, linear_122, view_62, value_states_20, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf432, arg4_1, arg3_1, arg5_1.item(), buf436, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg357_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg357_1 = copy_if_misaligned(arg357_1)
            buf437 = buf416; del buf416  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_120, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, linear_122, view_62, value_states_20, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg357_1, buf434, buf437, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg357_1
            assert_size_stride(arg358_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg358_1 = copy_if_misaligned(arg358_1)
            buf438 = buf415; del buf415  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_120, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, linear_122, view_62, value_states_20, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg358_1, buf435, buf438, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg358_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_120, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, linear_122, view_62, value_states_20, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf439 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf436, buf437, buf438, None, False, scale=0.08838834764831845)
            buf440 = buf439[0]
            assert_tensor_metadata(buf440, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf440, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf439
            buf444 = buf436; del buf436  # reuse
            # Topologically Sorted Source Nodes: [attn_output_80], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf440, buf444, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg359_1, (1536, 1536), (1536, 1), 'input')
            buf445 = reinterpret_tensor(buf440, (s16, 1536), (1536, 1), 0); del buf440  # reuse
            # Topologically Sorted Source Nodes: [attn_output_80, transpose_84, reshape_62, attn_output_83], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf444, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg359_1, (1536, 1536), (1, 1536), 0), out=buf445)
            del arg359_1
            assert_size_stride_grouped((arg361_1, arg360_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf447 = reinterpret_tensor(buf444, (s16, 1, 1536), (1536, 1536, 1), 0); del buf444  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_178, hidden_states_179, attn_output_83, hidden_states_183, pow_42, variance_41, rsqrt_41, hidden_states_185, hidden_states_186], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf424, buf429, buf445, arg361_1, arg360_1.item(), buf447, s16, 1536, stream=raw_stream0)
            del arg360_1
            del arg361_1
            assert_size_stride(arg362_1, (17920, 1536), (1536, 1), 'input')
            buf448 = buf427; del buf427  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_178, hidden_states_179, attn_output_83, hidden_states_183, pow_42, variance_41, rsqrt_41, hidden_states_185, hidden_states_186, linear_124], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf447, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg362_1, (1536, 17920), (1, 1536), 0), out=buf448)
            del arg362_1
            buf449 = buf428; del buf428  # reuse
            # Topologically Sorted Source Nodes: [linear_124, split_20, silu_20, mul_190], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf448, buf449, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg363_1, (1536, 8960), (8960, 1), 'input')
            buf450 = reinterpret_tensor(buf447, (s16, 1536), (1536, 1), 0); del buf447  # reuse
            # Topologically Sorted Source Nodes: [linear_124, split_20, silu_20, mul_190, hidden_states_187], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf449, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg363_1, (8960, 1536), (1, 8960), 0), out=buf450)
            del arg363_1
            assert_size_stride_grouped((arg365_1, arg364_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf452 = reinterpret_tensor(buf432, (s16, 1, 1536), (1536, 1536, 1), 0); del buf432  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_178, hidden_states_179, attn_output_83, hidden_states_183, hidden_states_187, hidden_states_188, pow_43, variance_42, rsqrt_42, hidden_states_190, hidden_states_191], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf424, buf429, buf445, buf450, arg365_1, arg364_1.item(), buf452, s16, 1536, stream=raw_stream0)
            del arg364_1
            del arg365_1
            assert_size_stride_grouped((arg367_1, arg366_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf453 = buf402; del buf402  # reuse
            # Topologically Sorted Source Nodes: [linear_126], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg367_1, reinterpret_tensor(buf452, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg366_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf453)
            del arg366_1
            del arg367_1
            assert_size_stride_grouped((arg369_1, arg368_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf454 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_127], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg369_1, reinterpret_tensor(buf452, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg368_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf454)
            del arg368_1
            del arg369_1
            buf455 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_24, sin_24, linear_127, view_64, key_states_21, mul_195, x2_43, neg_43, x1_43, cat_128, mul_196, k_embed_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf454, arg4_1, arg3_1, arg5_1.item(), buf455, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg371_1, arg370_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf456 = buf454; del buf454  # reuse
            # Topologically Sorted Source Nodes: [linear_128], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg371_1, reinterpret_tensor(buf452, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg370_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf456)
            del arg370_1
            del arg371_1
            buf457 = reinterpret_tensor(buf452, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf452  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, linear_128, view_65, value_states_21, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf453, arg4_1, arg3_1, arg5_1.item(), buf457, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf453
            assert_size_stride(arg374_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg374_1 = copy_if_misaligned(arg374_1)
            buf458 = buf438; del buf438  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, linear_128, view_65, value_states_21, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg374_1, buf455, buf458, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg374_1
            assert_size_stride(arg375_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg375_1 = copy_if_misaligned(arg375_1)
            buf459 = buf437; del buf437  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, linear_128, view_65, value_states_21, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg375_1, buf456, buf459, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg375_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, linear_128, view_65, value_states_21, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf460 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf457, buf458, buf459, None, False, scale=0.08838834764831845)
            buf461 = buf460[0]
            assert_tensor_metadata(buf461, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf461, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf460
            buf465 = buf457; del buf457  # reuse
            # Topologically Sorted Source Nodes: [attn_output_84], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf461, buf465, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg376_1, (1536, 1536), (1536, 1), 'input')
            buf466 = reinterpret_tensor(buf461, (s16, 1536), (1536, 1), 0); del buf461  # reuse
            # Topologically Sorted Source Nodes: [attn_output_84, transpose_88, reshape_65, attn_output_87], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf465, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg376_1, (1536, 1536), (1, 1536), 0), out=buf466)
            del arg376_1
            assert_size_stride_grouped((arg378_1, arg377_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf467 = buf424; del buf424  # reuse
            buf469 = reinterpret_tensor(buf465, (s16, 1, 1536), (1536, 1536, 1), 0); del buf465  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_178, hidden_states_179, attn_output_83, hidden_states_183, hidden_states_187, hidden_states_188, attn_output_87, hidden_states_192, pow_44, variance_43, rsqrt_43, hidden_states_194, hidden_states_195], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf467, buf429, buf445, buf450, buf466, arg378_1, arg377_1.item(), buf469, s16, 1536, stream=raw_stream0)
            del arg377_1
            del arg378_1
            del buf429
            assert_size_stride(arg379_1, (17920, 1536), (1536, 1), 'input')
            buf470 = buf448; del buf448  # reuse
            # Topologically Sorted Source Nodes: [pow_44, variance_43, rsqrt_43, hidden_states_194, hidden_states_195, linear_130], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf469, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg379_1, (1536, 17920), (1, 1536), 0), out=buf470)
            del arg379_1
            buf471 = buf449; del buf449  # reuse
            # Topologically Sorted Source Nodes: [linear_130, split_21, silu_21, mul_199], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf470, buf471, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg380_1, (1536, 8960), (8960, 1), 'input')
            buf472 = reinterpret_tensor(buf469, (s16, 1536), (1536, 1), 0); del buf469  # reuse
            # Topologically Sorted Source Nodes: [linear_130, split_21, silu_21, mul_199, hidden_states_196], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf471, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg380_1, (8960, 1536), (1, 8960), 0), out=buf472)
            del arg380_1
            assert_size_stride_grouped((arg382_1, arg381_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf474 = reinterpret_tensor(buf466, (s16, 1, 1536), (1536, 1536, 1), 0); del buf466  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, pow_45, variance_44, rsqrt_44, hidden_states_199, hidden_states_200], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf467, buf472, arg382_1, arg381_1.item(), buf474, s16, 1536, stream=raw_stream0)
            del arg381_1
            del arg382_1
            assert_size_stride_grouped((arg384_1, arg383_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf475 = buf450; del buf450  # reuse
            # Topologically Sorted Source Nodes: [linear_132], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg384_1, reinterpret_tensor(buf474, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg383_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf475)
            del arg383_1
            del arg384_1
            assert_size_stride_grouped((arg386_1, arg385_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf476 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_133], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg386_1, reinterpret_tensor(buf474, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg385_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf476)
            del arg385_1
            del arg386_1
            buf477 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_25, sin_25, linear_133, view_67, key_states_22, mul_204, x2_45, neg_45, x1_45, cat_134, mul_205, k_embed_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf476, arg4_1, arg3_1, arg5_1.item(), buf477, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg388_1, arg387_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf478 = buf476; del buf476  # reuse
            # Topologically Sorted Source Nodes: [linear_134], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg388_1, reinterpret_tensor(buf474, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg387_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf478)
            del arg387_1
            del arg388_1
            buf479 = reinterpret_tensor(buf474, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf474  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_132, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, linear_134, view_68, value_states_22, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf475, arg4_1, arg3_1, arg5_1.item(), buf479, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg391_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg391_1 = copy_if_misaligned(arg391_1)
            buf480 = buf459; del buf459  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_132, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, linear_134, view_68, value_states_22, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg391_1, buf477, buf480, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg391_1
            assert_size_stride(arg392_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg392_1 = copy_if_misaligned(arg392_1)
            buf481 = buf458; del buf458  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_132, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, linear_134, view_68, value_states_22, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg392_1, buf478, buf481, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg392_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_132, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, linear_134, view_68, value_states_22, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf482 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf479, buf480, buf481, None, False, scale=0.08838834764831845)
            buf483 = buf482[0]
            assert_tensor_metadata(buf483, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf483, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf482
            buf487 = buf479; del buf479  # reuse
            # Topologically Sorted Source Nodes: [attn_output_88], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf483, buf487, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg393_1, (1536, 1536), (1536, 1), 'input')
            buf488 = reinterpret_tensor(buf483, (s16, 1536), (1536, 1), 0); del buf483  # reuse
            # Topologically Sorted Source Nodes: [attn_output_88, transpose_92, reshape_68, attn_output_91], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf487, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg393_1, (1536, 1536), (1, 1536), 0), out=buf488)
            del arg393_1
            assert_size_stride(arg394_1, (1536, ), (1, ), 'input')
            buf490 = reinterpret_tensor(buf487, (s16, 1, 1536), (1536, 1536, 1), 0); del buf487  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, attn_output_91, hidden_states_201, pow_46, variance_45, add_136, rsqrt_45, hidden_states_203, hidden_states_204], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14.run(buf467, buf472, buf488, arg394_1, buf490, s16, 1536, stream=raw_stream0)
            del arg394_1
            assert_size_stride(arg395_1, (17920, 1536), (1536, 1), 'input')
            buf491 = buf470; del buf470  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, attn_output_91, hidden_states_201, pow_46, variance_45, add_136, rsqrt_45, hidden_states_203, hidden_states_204, linear_136], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf490, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg395_1, (1536, 17920), (1, 1536), 0), out=buf491)
            del arg395_1
            buf492 = buf471; del buf471  # reuse
            # Topologically Sorted Source Nodes: [linear_136, split_22, silu_22, mul_208], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf491, buf492, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg396_1, (1536, 8960), (8960, 1), 'input')
            buf493 = reinterpret_tensor(buf490, (s16, 1536), (1536, 1), 0); del buf490  # reuse
            # Topologically Sorted Source Nodes: [linear_136, split_22, silu_22, mul_208, hidden_states_205], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf492, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg396_1, (8960, 1536), (1, 8960), 0), out=buf493)
            del arg396_1
            assert_size_stride_grouped((arg398_1, arg397_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf495 = reinterpret_tensor(buf475, (s16, 1, 1536), (1536, 1536, 1), 0); del buf475  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, attn_output_91, hidden_states_201, hidden_states_205, hidden_states_206, pow_47, variance_46, rsqrt_46, hidden_states_208, hidden_states_209], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf467, buf472, buf488, buf493, arg398_1, arg397_1.item(), buf495, s16, 1536, stream=raw_stream0)
            del arg397_1
            del arg398_1
            assert_size_stride_grouped((arg400_1, arg399_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf496 = buf445; del buf445  # reuse
            # Topologically Sorted Source Nodes: [linear_138], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg400_1, reinterpret_tensor(buf495, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg399_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf496)
            del arg399_1
            del arg400_1
            assert_size_stride_grouped((arg402_1, arg401_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf497 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_139], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg402_1, reinterpret_tensor(buf495, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg401_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf497)
            del arg401_1
            del arg402_1
            buf498 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_26, sin_26, linear_139, view_70, key_states_23, mul_213, x2_47, neg_47, x1_47, cat_140, mul_214, k_embed_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf497, arg4_1, arg3_1, arg5_1.item(), buf498, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg404_1, arg403_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf499 = buf497; del buf497  # reuse
            # Topologically Sorted Source Nodes: [linear_140], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg404_1, reinterpret_tensor(buf495, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg403_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf499)
            del arg403_1
            del arg404_1
            buf500 = reinterpret_tensor(buf495, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf495  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_138, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, linear_140, view_71, value_states_23, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf496, arg4_1, arg3_1, arg5_1.item(), buf500, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf496
            assert_size_stride(arg407_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg407_1 = copy_if_misaligned(arg407_1)
            buf501 = buf481; del buf481  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_138, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, linear_140, view_71, value_states_23, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg407_1, buf498, buf501, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg407_1
            assert_size_stride(arg408_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg408_1 = copy_if_misaligned(arg408_1)
            buf502 = buf480; del buf480  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_138, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, linear_140, view_71, value_states_23, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg408_1, buf499, buf502, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg408_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_138, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, linear_140, view_71, value_states_23, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf503 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf500, buf501, buf502, None, False, scale=0.08838834764831845)
            buf504 = buf503[0]
            assert_tensor_metadata(buf504, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf504, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf503
            buf508 = buf500; del buf500  # reuse
            # Topologically Sorted Source Nodes: [attn_output_92], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf504, buf508, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg409_1, (1536, 1536), (1536, 1), 'input')
            buf509 = reinterpret_tensor(buf504, (s16, 1536), (1536, 1), 0); del buf504  # reuse
            # Topologically Sorted Source Nodes: [attn_output_92, transpose_96, reshape_71, attn_output_95], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf508, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg409_1, (1536, 1536), (1, 1536), 0), out=buf509)
            del arg409_1
            assert_size_stride_grouped((arg411_1, arg410_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf510 = buf467; del buf467  # reuse
            buf512 = reinterpret_tensor(buf508, (s16, 1, 1536), (1536, 1536, 1), 0); del buf508  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, attn_output_91, hidden_states_201, hidden_states_205, hidden_states_206, attn_output_95, hidden_states_210, pow_48, variance_47, rsqrt_47, hidden_states_212, hidden_states_213], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf510, buf472, buf488, buf493, buf509, arg411_1, arg410_1.item(), buf512, s16, 1536, stream=raw_stream0)
            del arg410_1
            del arg411_1
            del buf472
            assert_size_stride(arg412_1, (17920, 1536), (1536, 1), 'input')
            buf513 = buf491; del buf491  # reuse
            # Topologically Sorted Source Nodes: [pow_48, variance_47, rsqrt_47, hidden_states_212, hidden_states_213, linear_142], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf512, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg412_1, (1536, 17920), (1, 1536), 0), out=buf513)
            del arg412_1
            buf514 = buf492; del buf492  # reuse
            # Topologically Sorted Source Nodes: [linear_142, split_23, silu_23, mul_217], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf513, buf514, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg413_1, (1536, 8960), (8960, 1), 'input')
            buf515 = reinterpret_tensor(buf512, (s16, 1536), (1536, 1), 0); del buf512  # reuse
            # Topologically Sorted Source Nodes: [linear_142, split_23, silu_23, mul_217, hidden_states_214], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf514, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg413_1, (8960, 1536), (1, 8960), 0), out=buf515)
            del arg413_1
            assert_size_stride_grouped((arg415_1, arg414_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf517 = reinterpret_tensor(buf509, (s16, 1, 1536), (1536, 1536, 1), 0); del buf509  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_214, hidden_states_215, pow_49, variance_48, rsqrt_48, hidden_states_217, hidden_states_218], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf510, buf515, arg415_1, arg414_1.item(), buf517, s16, 1536, stream=raw_stream0)
            del arg414_1
            del arg415_1
            assert_size_stride_grouped((arg417_1, arg416_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf518 = buf493; del buf493  # reuse
            # Topologically Sorted Source Nodes: [linear_144], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg417_1, reinterpret_tensor(buf517, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg416_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf518)
            del arg416_1
            del arg417_1
            assert_size_stride_grouped((arg419_1, arg418_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf519 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_145], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg419_1, reinterpret_tensor(buf517, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg418_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf519)
            del arg418_1
            del arg419_1
            buf520 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_27, sin_27, linear_145, view_73, key_states_24, mul_222, x2_49, neg_49, x1_49, cat_146, mul_223, k_embed_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf519, arg4_1, arg3_1, arg5_1.item(), buf520, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg421_1, arg420_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf521 = buf519; del buf519  # reuse
            # Topologically Sorted Source Nodes: [linear_146], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg421_1, reinterpret_tensor(buf517, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg420_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf521)
            del arg420_1
            del arg421_1
            buf522 = reinterpret_tensor(buf517, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf517  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_144, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, linear_146, view_74, value_states_24, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf518, arg4_1, arg3_1, arg5_1.item(), buf522, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg424_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg424_1 = copy_if_misaligned(arg424_1)
            buf523 = buf502; del buf502  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_144, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, linear_146, view_74, value_states_24, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg424_1, buf520, buf523, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg424_1
            assert_size_stride(arg425_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg425_1 = copy_if_misaligned(arg425_1)
            buf524 = buf501; del buf501  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_144, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, linear_146, view_74, value_states_24, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg425_1, buf521, buf524, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg425_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_144, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, linear_146, view_74, value_states_24, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf525 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf522, buf523, buf524, None, False, scale=0.08838834764831845)
            buf526 = buf525[0]
            assert_tensor_metadata(buf526, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf526, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf525
            buf530 = buf522; del buf522  # reuse
            # Topologically Sorted Source Nodes: [attn_output_96], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf526, buf530, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg426_1, (1536, 1536), (1536, 1), 'input')
            buf531 = reinterpret_tensor(buf526, (s16, 1536), (1536, 1), 0); del buf526  # reuse
            # Topologically Sorted Source Nodes: [attn_output_96, transpose_100, reshape_74, attn_output_99], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf530, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg426_1, (1536, 1536), (1, 1536), 0), out=buf531)
            del arg426_1
            assert_size_stride_grouped((arg428_1, arg427_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf533 = reinterpret_tensor(buf530, (s16, 1, 1536), (1536, 1536, 1), 0); del buf530  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_214, hidden_states_215, attn_output_99, hidden_states_219, pow_50, variance_49, rsqrt_49, hidden_states_221, hidden_states_222], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf510, buf515, buf531, arg428_1, arg427_1.item(), buf533, s16, 1536, stream=raw_stream0)
            del arg427_1
            del arg428_1
            assert_size_stride(arg429_1, (17920, 1536), (1536, 1), 'input')
            buf534 = buf513; del buf513  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_214, hidden_states_215, attn_output_99, hidden_states_219, pow_50, variance_49, rsqrt_49, hidden_states_221, hidden_states_222, linear_148], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf533, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg429_1, (1536, 17920), (1, 1536), 0), out=buf534)
            del arg429_1
            buf535 = buf514; del buf514  # reuse
            # Topologically Sorted Source Nodes: [linear_148, split_24, silu_24, mul_226], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf534, buf535, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg430_1, (1536, 8960), (8960, 1), 'input')
            buf536 = reinterpret_tensor(buf533, (s16, 1536), (1536, 1), 0); del buf533  # reuse
            # Topologically Sorted Source Nodes: [linear_148, split_24, silu_24, mul_226, hidden_states_223], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf535, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg430_1, (8960, 1536), (1, 8960), 0), out=buf536)
            del arg430_1
            assert_size_stride_grouped((arg432_1, arg431_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf538 = reinterpret_tensor(buf518, (s16, 1, 1536), (1536, 1536, 1), 0); del buf518  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_214, hidden_states_215, attn_output_99, hidden_states_219, hidden_states_223, hidden_states_224, pow_51, variance_50, rsqrt_50, hidden_states_226, hidden_states_227], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf510, buf515, buf531, buf536, arg432_1, arg431_1.item(), buf538, s16, 1536, stream=raw_stream0)
            del arg431_1
            del arg432_1
            assert_size_stride_grouped((arg434_1, arg433_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf539 = buf488; del buf488  # reuse
            # Topologically Sorted Source Nodes: [linear_150], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg434_1, reinterpret_tensor(buf538, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg433_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf539)
            del arg433_1
            del arg434_1
            assert_size_stride_grouped((arg436_1, arg435_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf540 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_151], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg436_1, reinterpret_tensor(buf538, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg435_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf540)
            del arg435_1
            del arg436_1
            buf541 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_28, sin_28, linear_151, view_76, key_states_25, mul_231, x2_51, neg_51, x1_51, cat_152, mul_232, k_embed_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf540, arg4_1, arg3_1, arg5_1.item(), buf541, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg438_1, arg437_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf542 = buf540; del buf540  # reuse
            # Topologically Sorted Source Nodes: [linear_152], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg438_1, reinterpret_tensor(buf538, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg437_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf542)
            del arg437_1
            del arg438_1
            buf543 = reinterpret_tensor(buf538, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf538  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_150, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, linear_152, view_77, value_states_25, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf539, arg4_1, arg3_1, arg5_1.item(), buf543, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf539
            assert_size_stride(arg441_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg441_1 = copy_if_misaligned(arg441_1)
            buf544 = buf524; del buf524  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_150, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, linear_152, view_77, value_states_25, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg441_1, buf541, buf544, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg441_1
            assert_size_stride(arg442_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg442_1 = copy_if_misaligned(arg442_1)
            buf545 = buf523; del buf523  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_150, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, linear_152, view_77, value_states_25, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg442_1, buf542, buf545, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg442_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_150, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, linear_152, view_77, value_states_25, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf546 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf543, buf544, buf545, None, False, scale=0.08838834764831845)
            buf547 = buf546[0]
            assert_tensor_metadata(buf547, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf547, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf546
            buf551 = buf543; del buf543  # reuse
            # Topologically Sorted Source Nodes: [attn_output_100], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf547, buf551, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg443_1, (1536, 1536), (1536, 1), 'input')
            buf552 = reinterpret_tensor(buf547, (s16, 1536), (1536, 1), 0); del buf547  # reuse
            # Topologically Sorted Source Nodes: [attn_output_100, transpose_104, reshape_77, attn_output_103], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf551, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg443_1, (1536, 1536), (1, 1536), 0), out=buf552)
            del arg443_1
            assert_size_stride_grouped((arg445_1, arg444_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf553 = buf510; del buf510  # reuse
            buf555 = reinterpret_tensor(buf551, (s16, 1, 1536), (1536, 1536, 1), 0); del buf551  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_214, hidden_states_215, attn_output_99, hidden_states_219, hidden_states_223, hidden_states_224, attn_output_103, hidden_states_228, pow_52, variance_51, rsqrt_51, hidden_states_230, hidden_states_231], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf553, buf515, buf531, buf536, buf552, arg445_1, arg444_1.item(), buf555, s16, 1536, stream=raw_stream0)
            del arg444_1
            del arg445_1
            del buf515
            assert_size_stride(arg446_1, (17920, 1536), (1536, 1), 'input')
            buf556 = buf534; del buf534  # reuse
            # Topologically Sorted Source Nodes: [pow_52, variance_51, rsqrt_51, hidden_states_230, hidden_states_231, linear_154], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf555, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg446_1, (1536, 17920), (1, 1536), 0), out=buf556)
            del arg446_1
            buf557 = buf535; del buf535  # reuse
            # Topologically Sorted Source Nodes: [linear_154, split_25, silu_25, mul_235], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf556, buf557, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg447_1, (1536, 8960), (8960, 1), 'input')
            buf558 = reinterpret_tensor(buf555, (s16, 1536), (1536, 1), 0); del buf555  # reuse
            # Topologically Sorted Source Nodes: [linear_154, split_25, silu_25, mul_235, hidden_states_232], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf557, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg447_1, (8960, 1536), (1, 8960), 0), out=buf558)
            del arg447_1
            assert_size_stride_grouped((arg449_1, arg448_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf560 = reinterpret_tensor(buf552, (s16, 1, 1536), (1536, 1536, 1), 0); del buf552  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_232, hidden_states_233, pow_53, variance_52, rsqrt_52, hidden_states_235, hidden_states_236], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf553, buf558, arg449_1, arg448_1.item(), buf560, s16, 1536, stream=raw_stream0)
            del arg448_1
            del arg449_1
            assert_size_stride_grouped((arg451_1, arg450_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf561 = buf536; del buf536  # reuse
            # Topologically Sorted Source Nodes: [linear_156], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg451_1, reinterpret_tensor(buf560, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg450_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf561)
            del arg450_1
            del arg451_1
            assert_size_stride_grouped((arg453_1, arg452_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf562 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_157], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg453_1, reinterpret_tensor(buf560, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg452_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf562)
            del arg452_1
            del arg453_1
            buf563 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_29, sin_29, linear_157, view_79, key_states_26, mul_240, x2_53, neg_53, x1_53, cat_158, mul_241, k_embed_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf562, arg4_1, arg3_1, arg5_1.item(), buf563, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg455_1, arg454_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf564 = buf562; del buf562  # reuse
            # Topologically Sorted Source Nodes: [linear_158], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg455_1, reinterpret_tensor(buf560, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg454_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf564)
            del arg454_1
            del arg455_1
            buf565 = reinterpret_tensor(buf560, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf560  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_156, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, linear_158, view_80, value_states_26, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf561, arg4_1, arg3_1, arg5_1.item(), buf565, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg458_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg458_1 = copy_if_misaligned(arg458_1)
            buf566 = buf545; del buf545  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_156, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, linear_158, view_80, value_states_26, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg458_1, buf563, buf566, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg458_1
            assert_size_stride(arg459_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg459_1 = copy_if_misaligned(arg459_1)
            buf567 = buf544; del buf544  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_156, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, linear_158, view_80, value_states_26, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg459_1, buf564, buf567, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg459_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_156, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, linear_158, view_80, value_states_26, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf568 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf565, buf566, buf567, None, False, scale=0.08838834764831845)
            buf569 = buf568[0]
            assert_tensor_metadata(buf569, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf569, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf568
            buf573 = buf565; del buf565  # reuse
            # Topologically Sorted Source Nodes: [attn_output_104], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf569, buf573, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg460_1, (1536, 1536), (1536, 1), 'input')
            buf574 = reinterpret_tensor(buf569, (s16, 1536), (1536, 1), 0); del buf569  # reuse
            # Topologically Sorted Source Nodes: [attn_output_104, transpose_108, reshape_80, attn_output_107], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf573, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg460_1, (1536, 1536), (1, 1536), 0), out=buf574)
            del arg460_1
            assert_size_stride_grouped((arg462_1, arg461_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf576 = reinterpret_tensor(buf573, (s16, 1, 1536), (1536, 1536, 1), 0); del buf573  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_232, hidden_states_233, attn_output_107, hidden_states_237, pow_54, variance_53, rsqrt_53, hidden_states_239, hidden_states_240], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf553, buf558, buf574, arg462_1, arg461_1.item(), buf576, s16, 1536, stream=raw_stream0)
            del arg461_1
            del arg462_1
            assert_size_stride(arg463_1, (17920, 1536), (1536, 1), 'input')
            buf577 = buf556; del buf556  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_232, hidden_states_233, attn_output_107, hidden_states_237, pow_54, variance_53, rsqrt_53, hidden_states_239, hidden_states_240, linear_160], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf576, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg463_1, (1536, 17920), (1, 1536), 0), out=buf577)
            del arg463_1
            buf578 = buf557; del buf557  # reuse
            # Topologically Sorted Source Nodes: [linear_160, split_26, silu_26, mul_244], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf577, buf578, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg464_1, (1536, 8960), (8960, 1), 'input')
            buf579 = reinterpret_tensor(buf576, (s16, 1536), (1536, 1), 0); del buf576  # reuse
            # Topologically Sorted Source Nodes: [linear_160, split_26, silu_26, mul_244, hidden_states_241], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf578, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg464_1, (8960, 1536), (1, 8960), 0), out=buf579)
            del arg464_1
            assert_size_stride_grouped((arg466_1, arg465_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf581 = reinterpret_tensor(buf561, (s16, 1, 1536), (1536, 1536, 1), 0); del buf561  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_232, hidden_states_233, attn_output_107, hidden_states_237, hidden_states_241, hidden_states_242, pow_55, variance_54, rsqrt_54, hidden_states_244, hidden_states_245], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf553, buf558, buf574, buf579, arg466_1, arg465_1.item(), buf581, s16, 1536, stream=raw_stream0)
            del arg465_1
            del arg466_1
            assert_size_stride_grouped((arg468_1, arg467_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf582 = buf531; del buf531  # reuse
            # Topologically Sorted Source Nodes: [linear_162], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg468_1, reinterpret_tensor(buf581, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg467_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf582)
            del arg467_1
            del arg468_1
            assert_size_stride_grouped((arg470_1, arg469_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf583 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_163], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg470_1, reinterpret_tensor(buf581, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg469_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf583)
            del arg469_1
            del arg470_1
            buf584 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_30, sin_30, linear_163, view_82, key_states_27, mul_249, x2_55, neg_55, x1_55, cat_164, mul_250, k_embed_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf583, arg4_1, arg3_1, arg5_1.item(), buf584, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg472_1, arg471_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf585 = buf583; del buf583  # reuse
            # Topologically Sorted Source Nodes: [linear_164], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg472_1, reinterpret_tensor(buf581, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg471_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf585)
            del arg471_1
            del arg472_1
            buf586 = reinterpret_tensor(buf581, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf581  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_162, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, linear_164, view_83, value_states_27, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf582, arg4_1, arg3_1, arg5_1.item(), buf586, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del arg3_1
            del arg4_1
            del arg5_1
            del buf582
            assert_size_stride(arg475_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg475_1 = copy_if_misaligned(arg475_1)
            buf587 = buf567; del buf567  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_162, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, linear_164, view_83, value_states_27, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg475_1, buf584, buf587, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg475_1
            assert_size_stride(arg476_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg476_1 = copy_if_misaligned(arg476_1)
            buf588 = buf566; del buf566  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_162, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, linear_164, view_83, value_states_27, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg476_1, buf585, buf588, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg476_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_162, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, linear_164, view_83, value_states_27, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf589 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf586, buf587, buf588, None, False, scale=0.08838834764831845)
            del buf587
            del buf588
            buf590 = buf589[0]
            assert_tensor_metadata(buf590, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf590, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf589
            buf594 = buf586; del buf586  # reuse
            # Topologically Sorted Source Nodes: [attn_output_108], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf590, buf594, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg477_1, (1536, 1536), (1536, 1), 'input')
            buf595 = reinterpret_tensor(buf590, (s16, 1536), (1536, 1), 0); del buf590  # reuse
            # Topologically Sorted Source Nodes: [attn_output_108, transpose_112, reshape_83, attn_output_111], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf594, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg477_1, (1536, 1536), (1, 1536), 0), out=buf595)
            del arg477_1
            assert_size_stride_grouped((arg479_1, arg478_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf596 = buf553; del buf553  # reuse
            buf598 = reinterpret_tensor(buf594, (s16, 1, 1536), (1536, 1536, 1), 0); del buf594  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_232, hidden_states_233, attn_output_107, hidden_states_237, hidden_states_241, hidden_states_242, attn_output_111, hidden_states_246, pow_56, variance_55, rsqrt_55, hidden_states_248, hidden_states_249], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf596, buf558, buf574, buf579, buf595, arg479_1, arg478_1.item(), buf598, s16, 1536, stream=raw_stream0)
            del arg478_1
            del arg479_1
            del buf558
            del buf574
            del buf579
            del buf595
            assert_size_stride(arg480_1, (17920, 1536), (1536, 1), 'input')
            buf599 = buf577; del buf577  # reuse
            # Topologically Sorted Source Nodes: [pow_56, variance_55, rsqrt_55, hidden_states_248, hidden_states_249, linear_166], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf598, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg480_1, (1536, 17920), (1, 1536), 0), out=buf599)
            del arg480_1
            buf600 = buf578; del buf578  # reuse
            # Topologically Sorted Source Nodes: [linear_166, split_27, silu_27, mul_253], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf599, buf600, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            del buf599
            assert_size_stride(arg481_1, (1536, 8960), (8960, 1), 'input')
            buf601 = reinterpret_tensor(buf598, (s16, 1536), (1536, 1), 0); del buf598  # reuse
            # Topologically Sorted Source Nodes: [linear_166, split_27, silu_27, mul_253, hidden_states_250], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf600, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg481_1, (8960, 1536), (1, 8960), 0), out=buf601)
            del arg481_1
            del buf600
            assert_size_stride(arg482_1, (1536, ), (1, ), 'input')
            buf603 = reinterpret_tensor(buf596, (s16, 1, 1536), (1536, 1536, 1), 0); del buf596  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_250, hidden_states_251, pow_57, variance_56, add_168, rsqrt_56, hidden_states_253, hidden_states_254], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15.run(buf603, buf601, arg482_1, s16, 1536, stream=raw_stream0)
            del arg482_1
            del buf601
            buf604 = empty_strided_cuda((s16, 152265), (152265, 1), torch.float32)
            # Topologically Sorted Source Nodes: [hidden_states_250, hidden_states_251, pow_57, variance_56, add_168, rsqrt_56, hidden_states_253, hidden_states_254, getitem_2020, logits], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.slice, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf603, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg2_1, (1536, 152265), (1, 1536), 0), out=buf604)
            del arg2_1
            del buf603
        return (reinterpret_tensor(buf5, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf4, reinterpret_tensor(buf26, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf25, reinterpret_tensor(buf48, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf47, reinterpret_tensor(buf69, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf68, reinterpret_tensor(buf91, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf90, reinterpret_tensor(buf112, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf111, reinterpret_tensor(buf134, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf133, reinterpret_tensor(buf155, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf154, reinterpret_tensor(buf177, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf176, reinterpret_tensor(buf198, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf197, reinterpret_tensor(buf220, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf219, reinterpret_tensor(buf241, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf240, reinterpret_tensor(buf263, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf262, reinterpret_tensor(buf284, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf283, reinterpret_tensor(buf306, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf305, reinterpret_tensor(buf327, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf326, reinterpret_tensor(buf349, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf348, reinterpret_tensor(buf370, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf369, reinterpret_tensor(buf392, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf391, reinterpret_tensor(buf413, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf412, reinterpret_tensor(buf435, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf434, reinterpret_tensor(buf456, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf455, reinterpret_tensor(buf478, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf477, reinterpret_tensor(buf499, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf498, reinterpret_tensor(buf521, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf520, reinterpret_tensor(buf542, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf541, reinterpret_tensor(buf564, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf563, reinterpret_tensor(buf585, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf584, reinterpret_tensor(buf604, (s16, 1, 152265), (152265, 152265, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = 50
    arg1_1 = rand_strided((50, 1), (1, 1), device='cuda:0', dtype=torch.int64)
    arg2_1 = rand_strided((152265, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg3_1 = rand_strided((50, 1), (1, 1), device='cuda:0', dtype=torch.int64)
    arg4_1 = rand_strided((64, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg5_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg6_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg7_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg8_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg9_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg10_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg11_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg12_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg13_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg14_1 = 50
    arg15_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg16_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg17_1 = 76
    arg18_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg19_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg20_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg21_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg22_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg23_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg24_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg25_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg26_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg27_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg28_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg29_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg30_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg31_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg32_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg33_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg34_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg35_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg36_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg37_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg38_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg39_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg40_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg41_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg42_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg43_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg44_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg45_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg46_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg47_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg48_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg49_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg50_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg51_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg52_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg53_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg54_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg55_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg56_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg57_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg58_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg59_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg60_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg61_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg62_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg63_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg64_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg65_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg66_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg67_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg68_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg69_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg70_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg71_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg72_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg73_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg74_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg75_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg76_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg77_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg78_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg79_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg80_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg81_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg82_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg83_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg84_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg85_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg86_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg87_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg88_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg89_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg90_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg91_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg92_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg93_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg94_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg95_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg96_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg97_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg98_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg99_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg100_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg101_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg102_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg103_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg104_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg105_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg106_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg107_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg108_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg109_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg110_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg111_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg112_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg113_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg114_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg115_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg116_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg117_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg118_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg119_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg120_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg121_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg122_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg123_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg124_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg125_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg126_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg127_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg128_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg129_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg130_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg131_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg132_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg133_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg134_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg135_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg136_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg137_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg138_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg139_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg140_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg141_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg142_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg143_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg144_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg145_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg146_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg147_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg148_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg149_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg150_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg151_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg152_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg153_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg154_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg155_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg156_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg157_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg158_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg159_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg160_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg161_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg162_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg163_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg164_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg165_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg166_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg167_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg168_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg169_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg170_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg171_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg172_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg173_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg174_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg175_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg176_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg177_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg178_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg179_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg180_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg181_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg182_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg183_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg184_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg185_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg186_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg187_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg188_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg189_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg190_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg191_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg192_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg193_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg194_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg195_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg196_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg197_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg198_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg199_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg200_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg201_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg202_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg203_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg204_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg205_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg206_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg207_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg208_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg209_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg210_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg211_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg212_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg213_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg214_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg215_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg216_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg217_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg218_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg219_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg220_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg221_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg222_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg223_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg224_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg225_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg226_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg227_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg228_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg229_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg230_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg231_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg232_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg233_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg234_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg235_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg236_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg237_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg238_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg239_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg240_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg241_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg242_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg243_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg244_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg245_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg246_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg247_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg248_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg249_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg250_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg251_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg252_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg253_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg254_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg255_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg256_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg257_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg258_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg259_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg260_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg261_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg262_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg263_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg264_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg265_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg266_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg267_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg268_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg269_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg270_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg271_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg272_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg273_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg274_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg275_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg276_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg277_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg278_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg279_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg280_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg281_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg282_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg283_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg284_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg285_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg286_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg287_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg288_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg289_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg290_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg291_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg292_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg293_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg294_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg295_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg296_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg297_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg298_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg299_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg300_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg301_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg302_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg303_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg304_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg305_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg306_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg307_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg308_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg309_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg310_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg311_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg312_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg313_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg314_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg315_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg316_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg317_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg318_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg319_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg320_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg321_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg322_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg323_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg324_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg325_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg326_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg327_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg328_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg329_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg330_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg331_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg332_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg333_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg334_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg335_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg336_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg337_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg338_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg339_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg340_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg341_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg342_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg343_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg344_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg345_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg346_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg347_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg348_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg349_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg350_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg351_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg352_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg353_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg354_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg355_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg356_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg357_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg358_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg359_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg360_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg361_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg362_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg363_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg364_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg365_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg366_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg367_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg368_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg369_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg370_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg371_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg372_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg373_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg374_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg375_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg376_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg377_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg378_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg379_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg380_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg381_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg382_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg383_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg384_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg385_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg386_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg387_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg388_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg389_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg390_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg391_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg392_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg393_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg394_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg395_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg396_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg397_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg398_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg399_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg400_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg401_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg402_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg403_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg404_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg405_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg406_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg407_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg408_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg409_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg410_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg411_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg412_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg413_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg414_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg415_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg416_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg417_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg418_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg419_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg420_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg421_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg422_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg423_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg424_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg425_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg426_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg427_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg428_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg429_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg430_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg431_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg432_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg433_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg434_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg435_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg436_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg437_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg438_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg439_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg440_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg441_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg442_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg443_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg444_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg445_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg446_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg447_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg448_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg449_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg450_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg451_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg452_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg453_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg454_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg455_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg456_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg457_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg458_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg459_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg460_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg461_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg462_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg463_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg464_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg465_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg466_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg467_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg468_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg469_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg470_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg471_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg472_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg473_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg474_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg475_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg476_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg477_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg478_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg479_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg480_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg481_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg482_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg483_1 = 1
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1, arg458_1, arg459_1, arg460_1, arg461_1, arg462_1, arg463_1, arg464_1, arg465_1, arg466_1, arg467_1, arg468_1, arg469_1, arg470_1, arg471_1, arg472_1, arg473_1, arg474_1, arg475_1, arg476_1, arg477_1, arg478_1, arg479_1, arg480_1, arg481_1, arg482_1, arg483_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
