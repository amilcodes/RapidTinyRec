# AOT ID: ['6_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
from torch._inductor.runtime.runtime_utils import assert_tensor_metadata

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/ck/cckvoeogtkik3fvabh6wpahgnd7vvfo7wgbirhk4tknbhnscvv2v.py
# Topologically Sorted Source Nodes: [inputs_embeds, pow_1, variance, rsqrt, hidden_states_1, hidden_states_2], Original ATen: [aten.embedding, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   hidden_states_1 => mul_44
#   hidden_states_2 => mul_47
#   inputs_embeds => embedding
#   pow_1 => pow_1
#   rsqrt => rsqrt
#   variance => mean
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %arg7_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg7_1]
#   %buf0 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf0]
#   %arg6_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg6_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %pow_1 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%embedding, 2), kwargs = {})
#   %mean : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %convert_element_type_default_4 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg6_1, torch.float32), kwargs = {})
#   %add_tensor : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, %convert_element_type_default_4), kwargs = {})
#   %rsqrt : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor,), kwargs = {})
#   %mul_44 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%embedding, %rsqrt), kwargs = {})
#   %mul_47 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg7_1, %mul_44), kwargs = {})
#   return %buf0,%mul_47
triton_red_fused_embedding_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_red_fused_embedding_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_embedding_mean_mul_pow_rsqrt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 620544}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_embedding_mean_mul_pow_rsqrt_0(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    tmp12 = in_ptr3
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp9 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tl.full([1, 1], 1536.0, tl.float32)
        tmp11 = (tmp5 / tmp10)
        tmp13 = tmp12.to(tl.float32)
        tmp14 = tmp11 + tmp13
        tmp15 = libdevice.rsqrt(tmp14)
        tmp16 = tmp9 * tmp15
        tmp17 = tmp7 * tmp16
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp17, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/d2/cd2drm2k6oqwth6xytmri2qz2qecl2rpzx33ylkymug22fudmiff.py
# Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, sin, sin_3, linear_1, view_1, key_states, mul_6, x2_1, neg_1, x1_1, cat_2, mul_7, k_embed, cat_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
# Source node to ATen node mapping:
#   cat_2 => cat_1
#   cat_3 => cat_2
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   k_embed => add_216
#   key_states => permute_4
#   linear_1 => view_8
#   matmul => mul_14
#   mul_6 => mul_103
#   mul_7 => mul_114
#   neg_1 => neg_1
#   position_ids_expanded => convert_element_type
#   sin => sin
#   sin_3 => unsqueeze_5
#   view_1 => view_9
#   x1_1 => slice_4
#   x2_1 => slice_5
# Graph fragment:
#   %arg15_1 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0" = PlaceHolder[target=arg15_1]
#   %addmm_1 : Tensor "f32[s16, 256][256, 1]cuda:0" = PlaceHolder[target=addmm_1]
#   %arg4_1 : Tensor "f32[64][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %arg3_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg3_1]
#   %arg5_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg5_1]
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %view_8 : Tensor "f32[s16, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_1, [%arg14_1, 1, 256]), kwargs = {})
#   %view_9 : Tensor "f32[s16, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_8, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_4 : Tensor "f32[s16, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_9, [0, 2, 1, 3]), kwargs = {})
#   %mul_103 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_4, %unsqueeze_4), kwargs = {})
#   %slice_5 : Tensor "f32[s16, 2, 1, 64][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_4, 3, 64, 9223372036854775807), kwargs = {})
#   %neg_1 : Tensor "f32[s16, 2, 1, 64][128, 64, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_5,), kwargs = {})
#   %slice_4 : Tensor "f32[s16, 2, 1, 64][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_4, 3, 0, 64), kwargs = {})
#   %cat_1 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %slice_4], -1), kwargs = {})
#   %mul_114 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %unsqueeze_5), kwargs = {})
#   %add_216 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_103, %mul_114), kwargs = {})
#   %cat_2 : Tensor "f32[s16, 2, 2, 128][512, 256, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.cat.default](args = ([%arg15_1, %add_216], -2), kwargs = {})
#   return %cat_2
triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1 = async_compile.triton('triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32768}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*i64', 'in_ptr4': 'fp64', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 410256}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = ((xindex // 128) % 2)
    x0 = (xindex % 128)
    x4 = xindex // 256
    x6 = xindex
    x3 = xindex // 512
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x1).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 1, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tl.load(in_ptr0 + (x0 + 128*x4), tmp6 & xmask, eviction_policy='evict_last', other=0.0)
    tmp8 = tmp0 >= tmp5
    tmp9 = tl.full([1], 2, tl.int64)
    tmp10 = tmp0 < tmp9
    tmp11 = tl.load(in_ptr1 + (x0 + 128*x4), tmp8 & xmask, eviction_policy='evict_last', other=0.0)
    tmp12 = tl.load(in_ptr2 + ((x6 % 64)), tmp8 & xmask, eviction_policy='evict_last', other=0.0)
    tmp13 = tl.load(in_ptr3 + (x3), tmp8 & xmask, eviction_policy='evict_last', other=0.0)
    tmp14 = tmp13.to(tl.float32)
    tmp15 = tmp12 * tmp14
    tmp16 = tl_math.cos(tmp15)
    tmp17 = in_ptr4
    tmp18 = tmp17.to(tl.float32)
    tmp19 = tmp16 * tmp18
    tmp20 = tmp11 * tmp19
    tmp21 = (x0).to(tl.int32)
    tmp22 = tl.full([1], 0, tl.int64)
    tmp23 = tmp21 >= tmp22
    tmp24 = (x0).to(tl.int64)
    tmp25 = (tmp24).to(tl.int64)
    tmp26 = tl.full([1], 64, tl.int64)
    tmp27 = tmp25 < tmp26
    tmp28 = tmp27 & tmp8
    tmp29 = tl.load(in_ptr1 + (64 + 128*x4 + (x0)), tmp28 & xmask, eviction_policy='evict_last', other=0.0)
    tmp30 = -tmp29
    tmp31 = tl.full(tmp30.shape, 0.0, tmp30.dtype)
    tmp32 = tl.where(tmp28, tmp30, tmp31)
    tmp33 = tmp21 >= tmp26
    tmp34 = tl.full([1], 128, tl.int64)
    tmp35 = tmp21 < tmp34
    tmp36 = tmp33 & tmp8
    tmp37 = tl.load(in_ptr1 + (128*x4 + ((-64) + x0)), tmp36 & xmask, eviction_policy='evict_last', other=0.0)
    tmp38 = tl.where(tmp27, tmp32, tmp37)
    tmp39 = tl_math.sin(tmp15)
    tmp40 = tmp39 * tmp18
    tmp41 = tmp38 * tmp40
    tmp42 = tmp20 + tmp41
    tmp43 = tl.full(tmp42.shape, 0.0, tmp42.dtype)
    tmp44 = tl.where(tmp8, tmp42, tmp43)
    tmp45 = tl.where(tmp6, tmp7, tmp44)
    tl.store(out_ptr0 + (x6), tmp45, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/xn/cxnqcfbxxkcxvvseadkecwmk3yg3mkykl6ivx73u6jiehub5pghn.py
# Topologically Sorted Source Nodes: [linear_2, view_2, value_states, cat_4], Original ATen: [aten.view, aten.transpose, aten.cat]
# Source node to ATen node mapping:
#   cat_4 => cat_3
#   linear_2 => view_11
#   value_states => permute_6
#   view_2 => view_12
# Graph fragment:
#   %arg16_1 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0" = PlaceHolder[target=arg16_1]
#   %addmm_2 : Tensor "f32[s16, 256][256, 1]cuda:0" = PlaceHolder[target=addmm_2]
#   %view_11 : Tensor "f32[s16, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_2, [%arg14_1, 1, 256]), kwargs = {})
#   %view_12 : Tensor "f32[s16, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_11, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_6 : Tensor "f32[s16, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_12, [0, 2, 1, 3]), kwargs = {})
#   %cat_3 : Tensor "f32[s16, 2, 2, 128][512, 256, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.cat.default](args = ([%arg16_1, %permute_6], -2), kwargs = {})
#   return %cat_3
triton_poi_fused_cat_transpose_view_2 = async_compile.triton('triton_poi_fused_cat_transpose_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32768}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_cat_transpose_view_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 307200}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_cat_transpose_view_2(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = ((xindex // 128) % 2)
    x0 = (xindex % 128)
    x2 = xindex // 256
    x3 = xindex
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x1).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 1, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tl.load(in_ptr0 + (x0 + 128*x2), tmp6 & xmask, eviction_policy='evict_last', other=0.0)
    tmp8 = tmp0 >= tmp5
    tmp9 = tl.full([1], 2, tl.int64)
    tmp10 = tmp0 < tmp9
    tmp11 = tl.load(in_ptr1 + (x0 + 128*x2), tmp8 & xmask, eviction_policy='evict_last', other=0.0)
    tmp12 = tl.where(tmp6, tmp7, tmp11)
    tl.store(out_ptr0 + (x3), tmp12, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/5k/c5kfpjgvc6lyueokx6kd24ubyrjmimazrfbt54w3yvguh73ln34k.py
# Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
# Source node to ATen node mapping:
#   cat_1 => cat
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   expand_1 => expand_4
#   expand_2 => expand_5
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   key_tensors => cat_4
#   linear => view_5
#   matmul => mul_14
#   mul_4 => mul_87
#   mul_5 => mul_98
#   neg => neg
#   output => _scaled_dot_product_efficient_attention
#   packed => view_13
#   position_ids_expanded => convert_element_type
#   q_embed => add_180
#   query_states => permute_2
#   sin => sin
#   sin_3 => unsqueeze_5
#   value_tensors => cat_5
#   view => view_6
#   x1 => slice_2
#   x2 => slice_3
# Graph fragment:
#   %addmm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=addmm]
#   %arg4_1 : Tensor "f32[64][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %arg3_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg3_1]
#   %arg5_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg5_1]
#   %view_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [%arg14_1, 1, 1536]), kwargs = {})
#   %view_6 : Tensor "f32[s16, 1, 12, 128][1536, 1536, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_5, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_2 : Tensor "f32[s16, 12, 1, 128][1536, 128, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_6, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %mul_87 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_2, %unsqueeze_4), kwargs = {})
#   %slice_3 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "f32[s16, 12, 1, 64][768, 64, 768, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_3,), kwargs = {})
#   %slice_2 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 0, 64), kwargs = {})
#   %cat : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_2], -1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %mul_98 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_5), kwargs = {})
#   %add_180 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_87, %mul_98), kwargs = {})
#   %view_13 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add_180, [%arg14_1, 2, 6, 128]), kwargs = {})
#   %expand_4 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg18_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %cat_4 : Tensor "f32[s16, 2, s91 + 2, 128][256*s91 + 512, 128*s91 + 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_4, %cat_2], -2), kwargs = {})
#   %expand_5 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg19_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %cat_5 : Tensor "f32[s16, 2, s91 + 2, 128][256*s91 + 512, 128*s91 + 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_5, %cat_3], -2), kwargs = {})
#   %_scaled_dot_product_efficient_attention : [num_users=1] = call_function[target=torch.ops.aten._scaled_dot_product_efficient_attention.default](args = (%view_13, %cat_4, %cat_5, None, False), kwargs = {scale: 0.08838834764831845})
#   return %buf7
triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3 = async_compile.triton('triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*i64', 'in_ptr3': 'fp64', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1536656}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x3 = xindex
    x2 = xindex // 1536
    x0 = (xindex % 128)
    x4 = xindex // 128
    tmp0 = tl.load(in_ptr0 + (x3), xmask)
    tmp1 = tl.load(in_ptr1 + ((x3 % 64)), xmask, eviction_policy='evict_last')
    tmp2 = tl.load(in_ptr2 + (x2), xmask, eviction_policy='evict_last')
    tmp6 = in_ptr3
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp1 * tmp3
    tmp5 = tl_math.cos(tmp4)
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tmp5 * tmp7
    tmp9 = tmp0 * tmp8
    tmp10 = (x0).to(tl.int32)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 >= tmp11
    tmp13 = (x0).to(tl.int64)
    tmp14 = (tmp13).to(tl.int64)
    tmp15 = tl.full([1], 64, tl.int64)
    tmp16 = tmp14 < tmp15
    tmp17 = tl.load(in_ptr0 + (64 + 128*x4 + (x0)), tmp16 & xmask, eviction_policy='evict_last', other=0.0)
    tmp18 = -tmp17
    tmp19 = tl.full(tmp18.shape, 0.0, tmp18.dtype)
    tmp20 = tl.where(tmp16, tmp18, tmp19)
    tmp21 = tmp10 >= tmp15
    tmp22 = tl.full([1], 128, tl.int64)
    tmp23 = tmp10 < tmp22
    tmp24 = tl.load(in_ptr0 + (128*x4 + ((-64) + x0)), tmp21 & xmask, eviction_policy='evict_last', other=0.0)
    tmp25 = tl.where(tmp16, tmp20, tmp24)
    tmp26 = tl_math.sin(tmp4)
    tmp27 = tmp26 * tmp7
    tmp28 = tmp25 * tmp27
    tmp29 = tmp9 + tmp28
    tl.store(out_ptr0 + (x3), tmp29, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/yl/cylsfctphs6fcgraxvn4w4nc3zbemkdxnpvaxm2x4hb4vxkmlhwb.py
# Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
# Source node to ATen node mapping:
#   cat_1 => cat
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   expand_1 => expand_4
#   expand_2 => expand_5
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   key_tensors => cat_4
#   linear => view_5
#   matmul => mul_14
#   mul_4 => mul_87
#   mul_5 => mul_98
#   neg => neg
#   output => _scaled_dot_product_efficient_attention
#   packed => view_13
#   position_ids_expanded => convert_element_type
#   q_embed => add_180
#   query_states => permute_2
#   sin => sin
#   sin_3 => unsqueeze_5
#   value_tensors => cat_5
#   view => view_6
#   x1 => slice_2
#   x2 => slice_3
# Graph fragment:
#   %arg18_1 : Tensor "f32[1, 2, s91, 128][256*s91, 128*s91, 128, 1]cuda:0" = PlaceHolder[target=arg18_1]
#   %cat_2 : Tensor "f32[s16, 2, 2, 128][512, 256, 128, 1]cuda:0" = PlaceHolder[target=cat_2]
#   %view_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [%arg14_1, 1, 1536]), kwargs = {})
#   %view_6 : Tensor "f32[s16, 1, 12, 128][1536, 1536, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_5, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_2 : Tensor "f32[s16, 12, 1, 128][1536, 128, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_6, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %mul_87 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_2, %unsqueeze_4), kwargs = {})
#   %slice_3 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "f32[s16, 12, 1, 64][768, 64, 768, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_3,), kwargs = {})
#   %slice_2 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 0, 64), kwargs = {})
#   %cat : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_2], -1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %mul_98 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_5), kwargs = {})
#   %add_180 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_87, %mul_98), kwargs = {})
#   %view_13 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add_180, [%arg14_1, 2, 6, 128]), kwargs = {})
#   %expand_4 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg18_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %cat_4 : Tensor "f32[s16, 2, s91 + 2, 128][256*s91 + 512, 128*s91 + 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_4, %cat_2], -2), kwargs = {})
#   %expand_5 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg19_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %cat_5 : Tensor "f32[s16, 2, s91 + 2, 128][256*s91 + 512, 128*s91 + 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_5, %cat_3], -2), kwargs = {})
#   %_scaled_dot_product_efficient_attention : [num_users=1] = call_function[target=torch.ops.aten._scaled_dot_product_efficient_attention.default](args = (%view_13, %cat_4, %cat_5, None, False), kwargs = {scale: 0.08838834764831845})
#   return %buf8
triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4 = async_compile.triton('triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'ks0': 'i64', 'ks1': 'i64', 'ks2': 'i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 8167424}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4(in_ptr0, in_ptr1, out_ptr0, ks0, ks1, ks2, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = ((xindex // 128) % ks0)
    x0 = (xindex % 128)
    x2 = ((xindex // ks2) % 2)
    x5 = xindex // ks2
    x4 = xindex
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x1).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = (ks1).to(tl.int64)
    tmp6 = (tmp5).to(tl.int64)
    tmp7 = tmp4 < tmp6
    tmp8 = tl.load(in_ptr0 + (x0 + 128*(x1) + 128*ks1*x2), tmp7 & xmask, eviction_policy='evict_last', other=0.0)
    tmp9 = (ks1).to(tl.int32)
    tmp10 = tmp0 >= tmp9
    tmp11 = (ks0).to(tl.int32)
    tmp12 = tmp0 < tmp11
    tmp13 = tl.load(in_ptr1 + (x0 + 128*(x1 + ((-1)*ks1)) + 256*x5), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp14 = tl.where(tmp7, tmp8, tmp13)
    tl.store(out_ptr0 + (x4), tmp14, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/iw/ciwkwmmixzr334lo4ivkti4bpvzw3xidzt3ihb3i25gyqbz3qi7l.py
# Topologically Sorted Source Nodes: [attn_output], Original ATen: [aten.clone]
# Source node to ATen node mapping:
#   attn_output => clone_2
# Graph fragment:
#   %getitem : Tensor "f32[s16, 2, 6, 128][1536, 128, 256, 1]cuda:0" = PlaceHolder[target=getitem]
#   %clone_2 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%getitem,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone_2
triton_poi_fused_clone_5 = async_compile.triton('triton_poi_fused_clone_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_clone_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 921600}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_clone_5(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 6)
    x2 = ((xindex // 768) % 2)
    x3 = xindex // 1536
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 128*x2 + 256*x1 + 1536*x3), xmask)
    tl.store(out_ptr0 + (x4), tmp0, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/yf/cyffau64v7kjfr6zy7eqxmno63t4zpvwdsfej5jsb2osqatkwv3p.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, pow_2, variance_1, rsqrt_1, hidden_states_5, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   hidden_states_3 => add_291
#   hidden_states_5 => mul_217
#   hidden_states_6 => mul_220
#   inputs_embeds => embedding
#   pow_2 => pow_2
#   rsqrt_1 => rsqrt_1
#   variance_1 => mean_1
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %arg22_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg22_1]
#   %buf17 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf17]
#   %arg21_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg21_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_291 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %pow_2 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_291, 2), kwargs = {})
#   %mean_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %convert_element_type_default_6 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg21_1, torch.float32), kwargs = {})
#   %add_tensor_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, %convert_element_type_default_6), kwargs = {})
#   %rsqrt_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_1,), kwargs = {})
#   %mul_217 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_291, %rsqrt_1), kwargs = {})
#   %mul_220 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg22_1, %mul_217), kwargs = {})
#   return %buf17,%mul_220
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_6 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 927744}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_6(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    tmp16 = in_ptr4
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tmp11 + tmp12
        tmp14 = tl.full([1, 1], 1536.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tmp15 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp13 * tmp19
        tmp21 = tmp9 * tmp20
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp21, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/c2/cc244cdy4zkztlweralhc3kwd77xsz6s3ck5vrtp4znoc7ysi2tg.py
# Topologically Sorted Source Nodes: [linear_4, split, silu, mul_10], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
# Source node to ATen node mapping:
#   linear_4 => view_19
#   mul_10 => mul_244
#   silu => add_339, div, exp, neg_2
#   split => split
# Graph fragment:
#   %mm_1 : Tensor "f32[s16, 17920][17920, 1]cuda:0" = PlaceHolder[target=mm_1]
#   %view_19 : Tensor "f32[s16, 1, 17920][17920, 17920, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [%arg14_1, 1, 17920]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_19, 8960, -1), kwargs = {})
#   %neg_2 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_4,), kwargs = {})
#   %exp : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_339 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%getitem_4, %add_339), kwargs = {})
#   %mul_244 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%div, %getitem_5), kwargs = {})
#   return %mul_244
triton_poi_fused__unsafe_view_mul_silu_split_7 = async_compile.triton('triton_poi_fused__unsafe_view_mul_silu_split_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_mul_silu_split_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 7168000}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_mul_silu_split_7(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 8960)
    x1 = xindex // 8960
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 17920*x1), xmask)
    tmp6 = tl.load(in_ptr0 + (8960 + x0 + 17920*x1), xmask)
    tmp1 = -tmp0
    tmp2 = libdevice.exp(tmp1)
    tmp3 = tl.full([1], 1.0, tl.float32)
    tmp4 = tmp2 + tmp3
    tmp5 = (tmp0 / tmp4)
    tmp7 = tmp5 * tmp6
    tl.store(out_ptr0 + (x2), tmp7, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/bn/cbn64eneoji3e7z3nujvp4rbjh5i7qilxrscdts4cz5q3qjoyx7q.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, hidden_states_7, hidden_states_8, pow_3, variance_2, rsqrt_2, hidden_states_10, hidden_states_11], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   hidden_states_10 => mul_268
#   hidden_states_11 => mul_271
#   hidden_states_3 => add_291
#   hidden_states_7 => view_21
#   hidden_states_8 => add_358
#   inputs_embeds => embedding
#   pow_3 => pow_3
#   rsqrt_2 => rsqrt_2
#   variance_2 => mean_2
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %mm_2 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_2]
#   %arg26_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg26_1]
#   %buf22 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf22]
#   %arg25_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg25_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_291 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %view_21 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_358 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_291, %view_21), kwargs = {})
#   %pow_3 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_358, 2), kwargs = {})
#   %mean_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %convert_element_type_default_8 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg25_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, %convert_element_type_default_8), kwargs = {})
#   %rsqrt_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_2,), kwargs = {})
#   %mul_268 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_358, %rsqrt_2), kwargs = {})
#   %mul_271 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg26_1, %mul_268), kwargs = {})
#   return %buf22,%mul_271
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    tmp20 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp14 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp16 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tmp13 + tmp14
        tmp17 = tmp15 + tmp16
        tmp18 = tl.full([1, 1], 1536.0, tl.float32)
        tmp19 = (tmp9 / tmp18)
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp19 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp17 * tmp23
        tmp25 = tmp11 * tmp24
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp25, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/t4/ct4horfwvwlfid54p2pifpmwxntxs42n7jjtdtqgpwomhp6sm7d6.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, hidden_states_7, hidden_states_8, attn_output_7, hidden_states_12, pow_4, variance_3, rsqrt_3, hidden_states_14, hidden_states_15], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   attn_output_7 => view_35
#   hidden_states_12 => add_599
#   hidden_states_14 => mul_441
#   hidden_states_15 => mul_444
#   hidden_states_3 => add_291
#   hidden_states_7 => view_21
#   hidden_states_8 => add_358
#   inputs_embeds => embedding
#   pow_4 => pow_4
#   rsqrt_3 => rsqrt_3
#   variance_3 => mean_3
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %mm_2 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_2]
#   %mm_3 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_3]
#   %add_599 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_599]
#   %arg39_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg39_1]
#   %buf40 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf40]
#   %arg38_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg38_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_291 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %view_21 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_358 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_291, %view_21), kwargs = {})
#   %view_35 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_599 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_358, %view_35), kwargs = {})
#   %pow_4 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_599, 2), kwargs = {})
#   %mean_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %convert_element_type_default_10 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg38_1, torch.float32), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, %convert_element_type_default_10), kwargs = {})
#   %rsqrt_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_441 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_599, %rsqrt_3), kwargs = {})
#   %mul_444 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg39_1, %mul_441), kwargs = {})
#   return %add_599,%buf40,%mul_444
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_9 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_9', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 2156544}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_9(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp11 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp5 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp7 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask & xmask, tmp12, _tmp11)
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp8, r0_mask & xmask)
    tmp11 = tl.sum(_tmp11, 1)[:, None]
    tmp17 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.debug_barrier()
        tmp14 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp11 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp13 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/3g/c3g6fxdlivrn4hptiu6a7nx3xfzawhfzghg5xqwck2ehdg7qkmae.py
# Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, pow_5, variance_4, rsqrt_4, hidden_states_19, hidden_states_20], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   hidden_states_16 => view_39
#   hidden_states_17 => add_666
#   hidden_states_19 => mul_492
#   hidden_states_20 => mul_495
#   pow_5 => pow_5
#   rsqrt_4 => rsqrt_4
#   variance_4 => mean_4
# Graph fragment:
#   %add_599 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_599]
#   %mm_5 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_5]
#   %arg43_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg43_1]
#   %buf45 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf45]
#   %arg42_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg42_1]
#   %view_39 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_666 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_599, %view_39), kwargs = {})
#   %pow_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_666, 2), kwargs = {})
#   %mean_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [-1], True), kwargs = {})
#   %convert_element_type_default_12 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg42_1, torch.float32), kwargs = {})
#   %add_tensor_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_4, %convert_element_type_default_12), kwargs = {})
#   %rsqrt_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_4,), kwargs = {})
#   %mul_492 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_666, %rsqrt_4), kwargs = {})
#   %mul_495 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg43_1, %mul_492), kwargs = {})
#   return %buf45,%mul_495
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    tmp13 = in_ptr3
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp8 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp9 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tmp8 + tmp9
        tmp11 = tl.full([1, 1], 1536.0, tl.float32)
        tmp12 = (tmp5 / tmp11)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tmp12 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp10 * tmp16
        tmp18 = tmp7 * tmp17
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp18, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/nk/cnkrfu6v4k7hakxgj5drggbcexoc7qw4ajhpzojbsajzryvfra3q.py
# Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, pow_6, variance_5, rsqrt_5, hidden_states_23, hidden_states_24], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_53
#   hidden_states_16 => view_39
#   hidden_states_17 => add_666
#   hidden_states_21 => add_907
#   hidden_states_23 => mul_665
#   hidden_states_24 => mul_668
#   pow_6 => pow_6
#   rsqrt_5 => rsqrt_5
#   variance_5 => mean_5
# Graph fragment:
#   %add_599 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_599]
#   %mm_5 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_5]
#   %mm_6 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_6]
#   %arg56_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg56_1]
#   %buf62 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf62]
#   %arg55_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg55_1]
#   %view_39 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_666 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_599, %view_39), kwargs = {})
#   %view_53 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_907 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_666, %view_53), kwargs = {})
#   %pow_6 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_907, 2), kwargs = {})
#   %mean_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %convert_element_type_default_14 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg55_1, torch.float32), kwargs = {})
#   %add_tensor_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, %convert_element_type_default_14), kwargs = {})
#   %rsqrt_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_5,), kwargs = {})
#   %mul_665 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_907, %rsqrt_5), kwargs = {})
#   %mul_668 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg56_1, %mul_665), kwargs = {})
#   return %buf62,%mul_668
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1542144}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    tmp17 = in_ptr4
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp10 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp7 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp9 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/o4/co4b32g7wwsflrsuozu4x5wexxil7qzgx7yrccvrq2nassboayxm.py
# Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, hidden_states_25, hidden_states_26, pow_7, variance_6, rsqrt_6, hidden_states_28, hidden_states_29], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_53
#   hidden_states_16 => view_39
#   hidden_states_17 => add_666
#   hidden_states_21 => add_907
#   hidden_states_25 => view_57
#   hidden_states_26 => add_974
#   hidden_states_28 => mul_716
#   hidden_states_29 => mul_719
#   pow_7 => pow_7
#   rsqrt_6 => rsqrt_6
#   variance_6 => mean_6
# Graph fragment:
#   %add_599 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_599]
#   %mm_5 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_5]
#   %mm_6 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_6]
#   %mm_8 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %arg60_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg60_1]
#   %buf67 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf67]
#   %arg59_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg59_1]
#   %view_39 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_666 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_599, %view_39), kwargs = {})
#   %view_53 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_907 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_666, %view_53), kwargs = {})
#   %view_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_974 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_907, %view_57), kwargs = {})
#   %pow_7 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_974, 2), kwargs = {})
#   %mean_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [-1], True), kwargs = {})
#   %convert_element_type_default_16 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg59_1, torch.float32), kwargs = {})
#   %add_tensor_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_6, %convert_element_type_default_16), kwargs = {})
#   %rsqrt_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_6,), kwargs = {})
#   %mul_716 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_974, %rsqrt_6), kwargs = {})
#   %mul_719 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg60_1, %mul_716), kwargs = {})
#   return %buf67,%mul_719
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 10, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1849344}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    tmp21 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp17 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tl.full([1, 1], 1536.0, tl.float32)
        tmp20 = (tmp9 / tmp19)
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tmp20 + tmp22
        tmp24 = libdevice.rsqrt(tmp23)
        tmp25 = tmp18 * tmp24
        tmp26 = tmp11 * tmp25
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp26, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/yr/cyry5apvzafb5cyx2dhzun6gegd3fw5suwb22fhwknn4mtvb35ov.py
# Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, hidden_states_25, hidden_states_26, attn_output_15, hidden_states_30, pow_8, variance_7, rsqrt_7, hidden_states_32, hidden_states_33], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_53
#   attn_output_15 => view_71
#   hidden_states_16 => view_39
#   hidden_states_17 => add_666
#   hidden_states_21 => add_907
#   hidden_states_25 => view_57
#   hidden_states_26 => add_974
#   hidden_states_30 => add_1215
#   hidden_states_32 => mul_889
#   hidden_states_33 => mul_892
#   pow_8 => pow_8
#   rsqrt_7 => rsqrt_7
#   variance_7 => mean_7
# Graph fragment:
#   %add_599 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_599]
#   %mm_5 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_5]
#   %mm_6 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_6]
#   %mm_8 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %mm_9 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_9]
#   %add_1215 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_1215]
#   %arg73_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg73_1]
#   %buf85 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf85]
#   %arg72_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg72_1]
#   %view_39 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_666 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_599, %view_39), kwargs = {})
#   %view_53 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_907 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_666, %view_53), kwargs = {})
#   %view_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_974 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_907, %view_57), kwargs = {})
#   %view_71 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_9, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_1215 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_974, %view_71), kwargs = {})
#   %pow_8 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_1215, 2), kwargs = {})
#   %mean_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_8, [-1], True), kwargs = {})
#   %convert_element_type_default_18 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg72_1, torch.float32), kwargs = {})
#   %add_tensor_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_7, %convert_element_type_default_18), kwargs = {})
#   %rsqrt_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_7,), kwargs = {})
#   %mul_889 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_1215, %rsqrt_7), kwargs = {})
#   %mul_892 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg73_1, %mul_889), kwargs = {})
#   return %add_1215,%buf85,%mul_892
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 2770944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp11 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp3 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp5 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp7 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask & xmask, tmp12, _tmp11)
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp8, r0_mask & xmask)
    tmp11 = tl.sum(_tmp11, 1)[:, None]
    tmp17 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.debug_barrier()
        tmp14 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp11 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp13 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/dy/cdysc4qqr3y7lqkj66n767n7264us7oygrd5qhquhfs6aymyjz6a.py
# Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, attn_output_59, hidden_states_129, hidden_states_133, hidden_states_134, pow_31, variance_30, add_90, rsqrt_30, hidden_states_136, hidden_states_137], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_90 => add_4683
#   attn_output_59 => view_269
#   hidden_states_124 => view_255
#   hidden_states_125 => add_4362
#   hidden_states_129 => add_4603
#   hidden_states_133 => view_273
#   hidden_states_134 => add_4670
#   hidden_states_136 => mul_3404
#   hidden_states_137 => mul_3407
#   pow_31 => pow_31
#   rsqrt_30 => rsqrt_30
#   variance_30 => mean_30
# Graph fragment:
#   %add_4295 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_4295]
#   %mm_41 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_41]
#   %mm_42 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_42]
#   %mm_44 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_44]
#   %arg263_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg263_1]
#   %buf337 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf337]
#   %view_255 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_41, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4362 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4295, %view_255), kwargs = {})
#   %view_269 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_42, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4603 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4362, %view_269), kwargs = {})
#   %view_273 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_44, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4670 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4603, %view_273), kwargs = {})
#   %pow_31 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_4670, 2), kwargs = {})
#   %mean_30 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_31, [-1], True), kwargs = {})
#   %add_4683 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_30, 1e-06), kwargs = {})
#   %rsqrt_30 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4683,), kwargs = {})
#   %mul_3404 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_4670, %rsqrt_30), kwargs = {})
#   %mul_3407 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg263_1, %mul_3404), kwargs = {})
#   return %buf337,%mul_3407
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1849344}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp17 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tl.full([1, 1], 1536.0, tl.float32)
        tmp20 = (tmp9 / tmp19)
        tmp21 = tl.full([1, 1], 1e-06, tl.float32)
        tmp22 = tmp20 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp18 * tmp23
        tmp25 = tmp11 * tmp24
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp25, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/ct/cct5oxzlz6yteeunblnfwfujeq4tazy2yzsfgyoiaoutw37ainbx.py
# Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, attn_output_91, hidden_states_201, pow_46, variance_45, add_136, rsqrt_45, hidden_states_203, hidden_states_204], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_136 => add_7080
#   attn_output_91 => view_413
#   hidden_states_196 => view_399
#   hidden_states_197 => add_6826
#   hidden_states_201 => add_7067
#   hidden_states_203 => mul_5145
#   hidden_states_204 => mul_5148
#   pow_46 => pow_46
#   rsqrt_45 => rsqrt_45
#   variance_45 => mean_45
# Graph fragment:
#   %add_6759 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_6759]
#   %mm_65 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_65]
#   %mm_66 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_66]
#   %arg394_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg394_1]
#   %buf512 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf512]
#   %view_399 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_65, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_6826 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_6759, %view_399), kwargs = {})
#   %view_413 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_66, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_7067 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_6826, %view_413), kwargs = {})
#   %pow_46 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_7067, 2), kwargs = {})
#   %mean_45 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_46, [-1], True), kwargs = {})
#   %add_7080 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_45, 1e-06), kwargs = {})
#   %rsqrt_45 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7080,), kwargs = {})
#   %mul_5145 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_7067, %rsqrt_45), kwargs = {})
#   %mul_5148 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg394_1, %mul_5145), kwargs = {})
#   return %buf512,%mul_5148
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1542144}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp10 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp7 / tmp15)
        tmp17 = tl.full([1, 1], 1e-06, tl.float32)
        tmp18 = tmp16 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp14 * tmp19
        tmp21 = tmp9 * tmp20
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp21, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/6p/c6pjs245u3nk7wce7h6q6ufcqkw7s7m7j3xrnxqgivqv4o4gwbuw.py
# Topologically Sorted Source Nodes: [hidden_states_250, hidden_states_251, pow_57, variance_56, add_168, rsqrt_56, hidden_states_253, hidden_states_254], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_168 => add_8687
#   hidden_states_250 => view_507
#   hidden_states_251 => add_8674
#   hidden_states_253 => mul_6316
#   hidden_states_254 => mul_6319
#   pow_57 => pow_57
#   rsqrt_56 => rsqrt_56
#   variance_56 => mean_56
# Graph fragment:
#   %add_8607 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_8607]
#   %mm_83 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_83]
#   %arg482_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg482_1]
#   %buf630 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf630]
#   %view_507 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_83, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_8674 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_8607, %view_507), kwargs = {})
#   %pow_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_8674, 2), kwargs = {})
#   %mean_56 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_57, [-1], True), kwargs = {})
#   %add_8687 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_56, 1e-06), kwargs = {})
#   %rsqrt_56 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_8687,), kwargs = {})
#   %mul_6316 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_8674, %rsqrt_56), kwargs = {})
#   %mul_6319 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg482_1, %mul_6316), kwargs = {})
#   return %buf630,%mul_6319
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_16 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_16', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_16', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_16(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr1 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp8 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp9 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tmp8 + tmp9
        tmp11 = tl.full([1, 1], 1536.0, tl.float32)
        tmp12 = (tmp5 / tmp11)
        tmp13 = tl.full([1, 1], 1e-06, tl.float32)
        tmp14 = tmp12 + tmp13
        tmp15 = libdevice.rsqrt(tmp14)
        tmp16 = tmp10 * tmp15
        tmp17 = tmp7 * tmp16
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp17, r0_mask & xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1, arg458_1, arg459_1, arg460_1, arg461_1, arg462_1, arg463_1, arg464_1, arg465_1, arg466_1, arg467_1, arg468_1, arg469_1, arg470_1, arg471_1, arg472_1, arg473_1, arg474_1, arg475_1, arg476_1, arg477_1, arg478_1, arg479_1, arg480_1, arg481_1, arg482_1, arg483_1 = args
        args.clear()
        s16 = arg0_1
        s74 = s16
        s52 = s16
        s91 = arg17_1
        s35 = arg483_1
        assert_size_stride_grouped((arg1_1, arg2_1, arg7_1, arg6_1), ((s16, 1), (152265, 1536), (1536, ), ()), ((1, 1), (1536, 1), (1, ), ()), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg1_1 = copy_if_misaligned(arg1_1)
            buf1 = empty_strided_cuda((s16, 1, 1536), (1536, 1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [inputs_embeds, pow_1, variance, rsqrt, hidden_states_1, hidden_states_2], Original ATen: [aten.embedding, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_embedding_mean_mul_pow_rsqrt_0.run(arg1_1, arg2_1, arg7_1, arg6_1.item(), buf1, s16, 1536, stream=raw_stream0)
            del arg6_1
            del arg7_1
            assert_size_stride_grouped((arg9_1, arg8_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf2 = empty_strided_cuda((s16, 1536), (1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg9_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg8_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf2)
            del arg8_1
            del arg9_1
            assert_size_stride_grouped((arg11_1, arg10_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf3 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg11_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg10_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf3)
            del arg10_1
            del arg11_1
            assert_size_stride_grouped((arg15_1, arg4_1, arg3_1, arg5_1), ((s16, 2, 1, 128), (64, ), (s16, 1), ()), ((256, 128, 128, 1), (1, ), (1, 1), ()), 'input')
            arg15_1 = copy_if_misaligned(arg15_1)
            arg3_1 = copy_if_misaligned(arg3_1)
            buf4 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, sin, sin_3, linear_1, view_1, key_states, mul_6, x2_1, neg_1, x1_1, cat_2, mul_7, k_embed, cat_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg15_1, buf3, arg4_1, arg3_1, arg5_1.item(), buf4, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg15_1
            assert_size_stride_grouped((arg13_1, arg12_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf5 = buf3; del buf3  # reuse
            # Topologically Sorted Source Nodes: [linear_2], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg13_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg12_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf5)
            del arg12_1
            del arg13_1
            assert_size_stride(arg16_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg16_1 = copy_if_misaligned(arg16_1)
            buf6 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_2, view_2, value_states, cat_4], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg16_1, buf5, buf6, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg16_1
            buf7 = reinterpret_tensor(buf1, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf1  # reuse
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf2, arg4_1, arg3_1, arg5_1.item(), buf7, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg18_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg18_1 = copy_if_misaligned(arg18_1)
            ps0 = 2 + s91
            ps1 = 256 + 128*s91
            buf8 = empty_strided_cuda((s16, 2, 2 + s91, 128), (512 + 256*s91, 256 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg18_1, buf4, buf8, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg18_1
            assert_size_stride(arg19_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg19_1 = copy_if_misaligned(arg19_1)
            buf9 = empty_strided_cuda((s16, 2, 2 + s91, 128), (512 + 256*s91, 256 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg19_1, buf6, buf9, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg19_1
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            buf10 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf7, buf8, buf9, None, False, scale=0.08838834764831845)
            buf11 = buf10[0]
            assert_tensor_metadata(buf11, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf11, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf10
            buf15 = buf7; del buf7  # reuse
            # Topologically Sorted Source Nodes: [attn_output], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf11, buf15, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg20_1, (1536, 1536), (1536, 1), 'input')
            buf16 = reinterpret_tensor(buf11, (s16, 1536), (1536, 1), 0); del buf11  # reuse
            # Topologically Sorted Source Nodes: [attn_output, transpose_4, reshape_2, attn_output_3], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf15, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg20_1, (1536, 1536), (1, 1536), 0), out=buf16)
            del arg20_1
            assert_size_stride_grouped((arg22_1, arg21_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf18 = reinterpret_tensor(buf15, (s16, 1, 1536), (1536, 1536, 1), 0); del buf15  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, pow_2, variance_1, rsqrt_1, hidden_states_5, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_6.run(arg1_1, arg2_1, buf16, arg22_1, arg21_1.item(), buf18, s16, 1536, stream=raw_stream0)
            del arg21_1
            del arg22_1
            assert_size_stride(arg23_1, (17920, 1536), (1536, 1), 'input')
            buf19 = empty_strided_cuda((s16, 17920), (17920, 1), torch.float32)
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, pow_2, variance_1, rsqrt_1, hidden_states_5, hidden_states_6, linear_4], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf18, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg23_1, (1536, 17920), (1, 1536), 0), out=buf19)
            del arg23_1
            buf20 = empty_strided_cuda((s16, 1, 8960), (8960, 8960, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_4, split, silu, mul_10], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf19, buf20, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg24_1, (1536, 8960), (8960, 1), 'input')
            buf21 = reinterpret_tensor(buf18, (s16, 1536), (1536, 1), 0); del buf18  # reuse
            # Topologically Sorted Source Nodes: [linear_4, split, silu, mul_10, hidden_states_7], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf20, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg24_1, (8960, 1536), (1, 8960), 0), out=buf21)
            del arg24_1
            assert_size_stride_grouped((arg26_1, arg25_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf23 = reinterpret_tensor(buf2, (s16, 1, 1536), (1536, 1536, 1), 0); del buf2  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, hidden_states_7, hidden_states_8, pow_3, variance_2, rsqrt_2, hidden_states_10, hidden_states_11], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8.run(arg1_1, arg2_1, buf16, buf21, arg26_1, arg25_1.item(), buf23, s16, 1536, stream=raw_stream0)
            del arg25_1
            del arg26_1
            assert_size_stride_grouped((arg28_1, arg27_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf24 = empty_strided_cuda((s16, 1536), (1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_6], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg28_1, reinterpret_tensor(buf23, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg27_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf24)
            del arg27_1
            del arg28_1
            assert_size_stride_grouped((arg30_1, arg29_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf25 = buf5; del buf5  # reuse
            # Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg30_1, reinterpret_tensor(buf23, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg29_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf25)
            del arg29_1
            del arg30_1
            assert_size_stride(arg33_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg33_1 = copy_if_misaligned(arg33_1)
            buf26 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_4, sin_4, linear_7, view_4, key_states_1, mul_15, x2_3, neg_3, x1_3, cat_8, mul_16, k_embed_1, cat_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg33_1, buf25, arg4_1, arg3_1, arg5_1.item(), buf26, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg33_1
            assert_size_stride_grouped((arg32_1, arg31_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf27 = buf25; del buf25  # reuse
            # Topologically Sorted Source Nodes: [linear_8], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg32_1, reinterpret_tensor(buf23, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg31_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf27)
            del arg31_1
            del arg32_1
            assert_size_stride(arg34_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg34_1 = copy_if_misaligned(arg34_1)
            buf28 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_8, view_5, value_states_1, cat_10], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg34_1, buf27, buf28, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg34_1
            buf29 = reinterpret_tensor(buf23, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf23  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_6, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf24, arg4_1, arg3_1, arg5_1.item(), buf29, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg35_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg35_1 = copy_if_misaligned(arg35_1)
            buf30 = buf9; del buf9  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_6, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg35_1, buf26, buf30, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg35_1
            assert_size_stride(arg36_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg36_1 = copy_if_misaligned(arg36_1)
            buf31 = buf8; del buf8  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_6, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg36_1, buf28, buf31, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg36_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_6, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf32 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf29, buf30, buf31, None, False, scale=0.08838834764831845)
            buf33 = buf32[0]
            assert_tensor_metadata(buf33, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf33, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf32
            buf37 = buf29; del buf29  # reuse
            # Topologically Sorted Source Nodes: [attn_output_4], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf33, buf37, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg37_1, (1536, 1536), (1536, 1), 'input')
            buf38 = reinterpret_tensor(buf33, (s16, 1536), (1536, 1), 0); del buf33  # reuse
            # Topologically Sorted Source Nodes: [attn_output_4, transpose_8, reshape_5, attn_output_7], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf37, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg37_1, (1536, 1536), (1, 1536), 0), out=buf38)
            del arg37_1
            assert_size_stride_grouped((arg39_1, arg38_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf39 = reinterpret_tensor(buf16, (s16, 1, 1536), (1536, 1536*s16, 1), 0); del buf16  # reuse
            buf41 = reinterpret_tensor(buf37, (s16, 1, 1536), (1536, 1536, 1), 0); del buf37  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, hidden_states_7, hidden_states_8, attn_output_7, hidden_states_12, pow_4, variance_3, rsqrt_3, hidden_states_14, hidden_states_15], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_9.run(buf39, arg1_1, arg2_1, buf21, buf38, arg39_1, arg38_1.item(), buf41, s16, 1536, stream=raw_stream0)
            del arg1_1
            del arg38_1
            del arg39_1
            assert_size_stride(arg40_1, (17920, 1536), (1536, 1), 'input')
            buf42 = buf19; del buf19  # reuse
            # Topologically Sorted Source Nodes: [pow_4, variance_3, rsqrt_3, hidden_states_14, hidden_states_15, linear_10], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf41, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg40_1, (1536, 17920), (1, 1536), 0), out=buf42)
            del arg40_1
            buf43 = buf20; del buf20  # reuse
            # Topologically Sorted Source Nodes: [linear_10, split_1, silu_1, mul_19], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf42, buf43, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg41_1, (1536, 8960), (8960, 1), 'input')
            buf44 = reinterpret_tensor(buf41, (s16, 1536), (1536, 1), 0); del buf41  # reuse
            # Topologically Sorted Source Nodes: [linear_10, split_1, silu_1, mul_19, hidden_states_16], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf43, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg41_1, (8960, 1536), (1, 8960), 0), out=buf44)
            del arg41_1
            assert_size_stride_grouped((arg43_1, arg42_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf46 = reinterpret_tensor(buf38, (s16, 1, 1536), (1536, 1536, 1), 0); del buf38  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, pow_5, variance_4, rsqrt_4, hidden_states_19, hidden_states_20], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf39, buf44, arg43_1, arg42_1.item(), buf46, s16, 1536, stream=raw_stream0)
            del arg42_1
            del arg43_1
            assert_size_stride_grouped((arg45_1, arg44_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf47 = buf21; del buf21  # reuse
            # Topologically Sorted Source Nodes: [linear_12], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg45_1, reinterpret_tensor(buf46, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg44_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf47)
            del arg44_1
            del arg45_1
            assert_size_stride_grouped((arg47_1, arg46_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf48 = buf27; del buf27  # reuse
            # Topologically Sorted Source Nodes: [linear_13], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg47_1, reinterpret_tensor(buf46, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg46_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf48)
            del arg46_1
            del arg47_1
            assert_size_stride(arg50_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg50_1 = copy_if_misaligned(arg50_1)
            buf49 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_5, sin_5, linear_13, view_7, key_states_2, mul_24, x2_5, neg_5, x1_5, cat_14, mul_25, k_embed_2, cat_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg50_1, buf48, arg4_1, arg3_1, arg5_1.item(), buf49, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg50_1
            assert_size_stride_grouped((arg49_1, arg48_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf50 = buf48; del buf48  # reuse
            # Topologically Sorted Source Nodes: [linear_14], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg49_1, reinterpret_tensor(buf46, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg48_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf50)
            del arg48_1
            del arg49_1
            assert_size_stride(arg51_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg51_1 = copy_if_misaligned(arg51_1)
            buf51 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_14, view_8, value_states_2, cat_16], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg51_1, buf50, buf51, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg51_1
            buf52 = reinterpret_tensor(buf46, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf46  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_12, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf47, arg4_1, arg3_1, arg5_1.item(), buf52, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg52_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg52_1 = copy_if_misaligned(arg52_1)
            buf53 = buf31; del buf31  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_12, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg52_1, buf49, buf53, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg52_1
            assert_size_stride(arg53_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg53_1 = copy_if_misaligned(arg53_1)
            buf54 = buf30; del buf30  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_12, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg53_1, buf51, buf54, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg53_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_12, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf55 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf52, buf53, buf54, None, False, scale=0.08838834764831845)
            buf56 = buf55[0]
            assert_tensor_metadata(buf56, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf56, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf55
            buf60 = buf52; del buf52  # reuse
            # Topologically Sorted Source Nodes: [attn_output_8], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf56, buf60, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg54_1, (1536, 1536), (1536, 1), 'input')
            buf61 = reinterpret_tensor(buf56, (s16, 1536), (1536, 1), 0); del buf56  # reuse
            # Topologically Sorted Source Nodes: [attn_output_8, transpose_12, reshape_8, attn_output_11], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf60, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg54_1, (1536, 1536), (1, 1536), 0), out=buf61)
            del arg54_1
            assert_size_stride_grouped((arg56_1, arg55_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf63 = reinterpret_tensor(buf60, (s16, 1, 1536), (1536, 1536, 1), 0); del buf60  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, pow_6, variance_5, rsqrt_5, hidden_states_23, hidden_states_24], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf39, buf44, buf61, arg56_1, arg55_1.item(), buf63, s16, 1536, stream=raw_stream0)
            del arg55_1
            del arg56_1
            assert_size_stride(arg57_1, (17920, 1536), (1536, 1), 'input')
            buf64 = buf42; del buf42  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, pow_6, variance_5, rsqrt_5, hidden_states_23, hidden_states_24, linear_16], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf63, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg57_1, (1536, 17920), (1, 1536), 0), out=buf64)
            del arg57_1
            buf65 = buf43; del buf43  # reuse
            # Topologically Sorted Source Nodes: [linear_16, split_2, silu_2, mul_28], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf64, buf65, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg58_1, (1536, 8960), (8960, 1), 'input')
            buf66 = reinterpret_tensor(buf63, (s16, 1536), (1536, 1), 0); del buf63  # reuse
            # Topologically Sorted Source Nodes: [linear_16, split_2, silu_2, mul_28, hidden_states_25], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf65, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg58_1, (8960, 1536), (1, 8960), 0), out=buf66)
            del arg58_1
            assert_size_stride_grouped((arg60_1, arg59_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf68 = reinterpret_tensor(buf47, (s16, 1, 1536), (1536, 1536, 1), 0); del buf47  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, hidden_states_25, hidden_states_26, pow_7, variance_6, rsqrt_6, hidden_states_28, hidden_states_29], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf39, buf44, buf61, buf66, arg60_1, arg59_1.item(), buf68, s16, 1536, stream=raw_stream0)
            del arg59_1
            del arg60_1
            assert_size_stride_grouped((arg62_1, arg61_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf69 = buf24; del buf24  # reuse
            # Topologically Sorted Source Nodes: [linear_18], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg62_1, reinterpret_tensor(buf68, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg61_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf69)
            del arg61_1
            del arg62_1
            assert_size_stride_grouped((arg64_1, arg63_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf70 = buf50; del buf50  # reuse
            # Topologically Sorted Source Nodes: [linear_19], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg64_1, reinterpret_tensor(buf68, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg63_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf70)
            del arg63_1
            del arg64_1
            assert_size_stride(arg67_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg67_1 = copy_if_misaligned(arg67_1)
            buf71 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_6, sin_6, linear_19, view_10, key_states_3, mul_33, x2_7, neg_7, x1_7, cat_20, mul_34, k_embed_3, cat_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg67_1, buf70, arg4_1, arg3_1, arg5_1.item(), buf71, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg67_1
            assert_size_stride_grouped((arg66_1, arg65_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf72 = buf70; del buf70  # reuse
            # Topologically Sorted Source Nodes: [linear_20], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg66_1, reinterpret_tensor(buf68, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg65_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf72)
            del arg65_1
            del arg66_1
            assert_size_stride(arg68_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg68_1 = copy_if_misaligned(arg68_1)
            buf73 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_20, view_11, value_states_3, cat_22], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg68_1, buf72, buf73, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg68_1
            buf74 = reinterpret_tensor(buf68, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf68  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_18, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf69, arg4_1, arg3_1, arg5_1.item(), buf74, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf69
            assert_size_stride(arg69_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg69_1 = copy_if_misaligned(arg69_1)
            buf75 = buf54; del buf54  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_18, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg69_1, buf71, buf75, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg69_1
            assert_size_stride(arg70_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg70_1 = copy_if_misaligned(arg70_1)
            buf76 = buf53; del buf53  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_18, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg70_1, buf73, buf76, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg70_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_18, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf77 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf74, buf75, buf76, None, False, scale=0.08838834764831845)
            buf78 = buf77[0]
            assert_tensor_metadata(buf78, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf78, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf77
            buf82 = buf74; del buf74  # reuse
            # Topologically Sorted Source Nodes: [attn_output_12], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf78, buf82, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg71_1, (1536, 1536), (1536, 1), 'input')
            buf83 = reinterpret_tensor(buf78, (s16, 1536), (1536, 1), 0); del buf78  # reuse
            # Topologically Sorted Source Nodes: [attn_output_12, transpose_16, reshape_11, attn_output_15], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf82, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg71_1, (1536, 1536), (1, 1536), 0), out=buf83)
            del arg71_1
            assert_size_stride_grouped((arg73_1, arg72_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf84 = buf39; del buf39  # reuse
            buf86 = reinterpret_tensor(buf82, (s16, 1, 1536), (1536, 1536, 1), 0); del buf82  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, hidden_states_25, hidden_states_26, attn_output_15, hidden_states_30, pow_8, variance_7, rsqrt_7, hidden_states_32, hidden_states_33], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf84, buf44, buf61, buf66, buf83, arg73_1, arg72_1.item(), buf86, s16, 1536, stream=raw_stream0)
            del arg72_1
            del arg73_1
            del buf44
            assert_size_stride(arg74_1, (17920, 1536), (1536, 1), 'input')
            buf87 = buf64; del buf64  # reuse
            # Topologically Sorted Source Nodes: [pow_8, variance_7, rsqrt_7, hidden_states_32, hidden_states_33, linear_22], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf86, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg74_1, (1536, 17920), (1, 1536), 0), out=buf87)
            del arg74_1
            buf88 = buf65; del buf65  # reuse
            # Topologically Sorted Source Nodes: [linear_22, split_3, silu_3, mul_37], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf87, buf88, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg75_1, (1536, 8960), (8960, 1), 'input')
            buf89 = reinterpret_tensor(buf86, (s16, 1536), (1536, 1), 0); del buf86  # reuse
            # Topologically Sorted Source Nodes: [linear_22, split_3, silu_3, mul_37, hidden_states_34], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf88, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg75_1, (8960, 1536), (1, 8960), 0), out=buf89)
            del arg75_1
            assert_size_stride_grouped((arg77_1, arg76_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf91 = reinterpret_tensor(buf83, (s16, 1, 1536), (1536, 1536, 1), 0); del buf83  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_34, hidden_states_35, pow_9, variance_8, rsqrt_8, hidden_states_37, hidden_states_38], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf84, buf89, arg77_1, arg76_1.item(), buf91, s16, 1536, stream=raw_stream0)
            del arg76_1
            del arg77_1
            assert_size_stride_grouped((arg79_1, arg78_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf92 = buf66; del buf66  # reuse
            # Topologically Sorted Source Nodes: [linear_24], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg79_1, reinterpret_tensor(buf91, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg78_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf92)
            del arg78_1
            del arg79_1
            assert_size_stride_grouped((arg81_1, arg80_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf93 = buf72; del buf72  # reuse
            # Topologically Sorted Source Nodes: [linear_25], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg81_1, reinterpret_tensor(buf91, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg80_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf93)
            del arg80_1
            del arg81_1
            assert_size_stride(arg84_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg84_1 = copy_if_misaligned(arg84_1)
            buf94 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_7, sin_7, linear_25, view_13, key_states_4, mul_42, x2_9, neg_9, x1_9, cat_26, mul_43, k_embed_4, cat_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg84_1, buf93, arg4_1, arg3_1, arg5_1.item(), buf94, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg84_1
            assert_size_stride_grouped((arg83_1, arg82_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf95 = buf93; del buf93  # reuse
            # Topologically Sorted Source Nodes: [linear_26], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg83_1, reinterpret_tensor(buf91, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg82_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf95)
            del arg82_1
            del arg83_1
            assert_size_stride(arg85_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg85_1 = copy_if_misaligned(arg85_1)
            buf96 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_26, view_14, value_states_4, cat_28], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg85_1, buf95, buf96, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg85_1
            buf97 = reinterpret_tensor(buf91, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf91  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_24, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf92, arg4_1, arg3_1, arg5_1.item(), buf97, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg86_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg86_1 = copy_if_misaligned(arg86_1)
            buf98 = buf76; del buf76  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_24, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg86_1, buf94, buf98, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg86_1
            assert_size_stride(arg87_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg87_1 = copy_if_misaligned(arg87_1)
            buf99 = buf75; del buf75  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_24, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg87_1, buf96, buf99, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg87_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_24, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf100 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf97, buf98, buf99, None, False, scale=0.08838834764831845)
            buf101 = buf100[0]
            assert_tensor_metadata(buf101, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf101, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf100
            buf105 = buf97; del buf97  # reuse
            # Topologically Sorted Source Nodes: [attn_output_16], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf101, buf105, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg88_1, (1536, 1536), (1536, 1), 'input')
            buf106 = reinterpret_tensor(buf101, (s16, 1536), (1536, 1), 0); del buf101  # reuse
            # Topologically Sorted Source Nodes: [attn_output_16, transpose_20, reshape_14, attn_output_19], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf105, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg88_1, (1536, 1536), (1, 1536), 0), out=buf106)
            del arg88_1
            assert_size_stride_grouped((arg90_1, arg89_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf108 = reinterpret_tensor(buf105, (s16, 1, 1536), (1536, 1536, 1), 0); del buf105  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_34, hidden_states_35, attn_output_19, hidden_states_39, pow_10, variance_9, rsqrt_9, hidden_states_41, hidden_states_42], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf84, buf89, buf106, arg90_1, arg89_1.item(), buf108, s16, 1536, stream=raw_stream0)
            del arg89_1
            del arg90_1
            assert_size_stride(arg91_1, (17920, 1536), (1536, 1), 'input')
            buf109 = buf87; del buf87  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_34, hidden_states_35, attn_output_19, hidden_states_39, pow_10, variance_9, rsqrt_9, hidden_states_41, hidden_states_42, linear_28], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf108, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg91_1, (1536, 17920), (1, 1536), 0), out=buf109)
            del arg91_1
            buf110 = buf88; del buf88  # reuse
            # Topologically Sorted Source Nodes: [linear_28, split_4, silu_4, mul_46], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf109, buf110, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg92_1, (1536, 8960), (8960, 1), 'input')
            buf111 = reinterpret_tensor(buf108, (s16, 1536), (1536, 1), 0); del buf108  # reuse
            # Topologically Sorted Source Nodes: [linear_28, split_4, silu_4, mul_46, hidden_states_43], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf110, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg92_1, (8960, 1536), (1, 8960), 0), out=buf111)
            del arg92_1
            assert_size_stride_grouped((arg94_1, arg93_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf113 = reinterpret_tensor(buf92, (s16, 1, 1536), (1536, 1536, 1), 0); del buf92  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_34, hidden_states_35, attn_output_19, hidden_states_39, hidden_states_43, hidden_states_44, pow_11, variance_10, rsqrt_10, hidden_states_46, hidden_states_47], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf84, buf89, buf106, buf111, arg94_1, arg93_1.item(), buf113, s16, 1536, stream=raw_stream0)
            del arg93_1
            del arg94_1
            assert_size_stride_grouped((arg96_1, arg95_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf114 = buf61; del buf61  # reuse
            # Topologically Sorted Source Nodes: [linear_30], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg96_1, reinterpret_tensor(buf113, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg95_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf114)
            del arg95_1
            del arg96_1
            assert_size_stride_grouped((arg98_1, arg97_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf115 = buf95; del buf95  # reuse
            # Topologically Sorted Source Nodes: [linear_31], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg98_1, reinterpret_tensor(buf113, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg97_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf115)
            del arg97_1
            del arg98_1
            assert_size_stride(arg101_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg101_1 = copy_if_misaligned(arg101_1)
            buf116 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_8, sin_8, linear_31, view_16, key_states_5, mul_51, x2_11, neg_11, x1_11, cat_32, mul_52, k_embed_5, cat_33], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg101_1, buf115, arg4_1, arg3_1, arg5_1.item(), buf116, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg101_1
            assert_size_stride_grouped((arg100_1, arg99_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf117 = buf115; del buf115  # reuse
            # Topologically Sorted Source Nodes: [linear_32], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg100_1, reinterpret_tensor(buf113, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg99_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf117)
            del arg100_1
            del arg99_1
            assert_size_stride(arg102_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg102_1 = copy_if_misaligned(arg102_1)
            buf118 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_32, view_17, value_states_5, cat_34], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg102_1, buf117, buf118, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg102_1
            buf119 = reinterpret_tensor(buf113, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf113  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_30, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf114, arg4_1, arg3_1, arg5_1.item(), buf119, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf114
            assert_size_stride(arg103_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg103_1 = copy_if_misaligned(arg103_1)
            buf120 = buf99; del buf99  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_30, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg103_1, buf116, buf120, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg103_1
            assert_size_stride(arg104_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg104_1 = copy_if_misaligned(arg104_1)
            buf121 = buf98; del buf98  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_30, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg104_1, buf118, buf121, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg104_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_30, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf122 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf119, buf120, buf121, None, False, scale=0.08838834764831845)
            buf123 = buf122[0]
            assert_tensor_metadata(buf123, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf123, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf122
            buf127 = buf119; del buf119  # reuse
            # Topologically Sorted Source Nodes: [attn_output_20], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf123, buf127, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg105_1, (1536, 1536), (1536, 1), 'input')
            buf128 = reinterpret_tensor(buf123, (s16, 1536), (1536, 1), 0); del buf123  # reuse
            # Topologically Sorted Source Nodes: [attn_output_20, transpose_24, reshape_17, attn_output_23], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf127, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg105_1, (1536, 1536), (1, 1536), 0), out=buf128)
            del arg105_1
            assert_size_stride_grouped((arg107_1, arg106_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf129 = buf84; del buf84  # reuse
            buf131 = reinterpret_tensor(buf127, (s16, 1, 1536), (1536, 1536, 1), 0); del buf127  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_34, hidden_states_35, attn_output_19, hidden_states_39, hidden_states_43, hidden_states_44, attn_output_23, hidden_states_48, pow_12, variance_11, rsqrt_11, hidden_states_50, hidden_states_51], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf129, buf89, buf106, buf111, buf128, arg107_1, arg106_1.item(), buf131, s16, 1536, stream=raw_stream0)
            del arg106_1
            del arg107_1
            del buf106
            assert_size_stride(arg108_1, (17920, 1536), (1536, 1), 'input')
            buf132 = buf109; del buf109  # reuse
            # Topologically Sorted Source Nodes: [pow_12, variance_11, rsqrt_11, hidden_states_50, hidden_states_51, linear_34], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf131, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg108_1, (1536, 17920), (1, 1536), 0), out=buf132)
            del arg108_1
            buf133 = buf110; del buf110  # reuse
            # Topologically Sorted Source Nodes: [linear_34, split_5, silu_5, mul_55], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf132, buf133, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg109_1, (1536, 8960), (8960, 1), 'input')
            buf134 = reinterpret_tensor(buf131, (s16, 1536), (1536, 1), 0); del buf131  # reuse
            # Topologically Sorted Source Nodes: [linear_34, split_5, silu_5, mul_55, hidden_states_52], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf133, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg109_1, (8960, 1536), (1, 8960), 0), out=buf134)
            del arg109_1
            assert_size_stride_grouped((arg111_1, arg110_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf136 = reinterpret_tensor(buf89, (s16, 1, 1536), (1536, 1536, 1), 0); del buf89  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_52, hidden_states_53, pow_13, variance_12, rsqrt_12, hidden_states_55, hidden_states_56], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf129, buf134, arg111_1, arg110_1.item(), buf136, s16, 1536, stream=raw_stream0)
            del arg110_1
            del arg111_1
            assert_size_stride_grouped((arg113_1, arg112_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf137 = buf128; del buf128  # reuse
            # Topologically Sorted Source Nodes: [linear_36], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg113_1, reinterpret_tensor(buf136, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg112_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf137)
            del arg112_1
            del arg113_1
            assert_size_stride_grouped((arg115_1, arg114_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf138 = buf117; del buf117  # reuse
            # Topologically Sorted Source Nodes: [linear_37], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg115_1, reinterpret_tensor(buf136, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg114_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf138)
            del arg114_1
            del arg115_1
            assert_size_stride(arg118_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg118_1 = copy_if_misaligned(arg118_1)
            buf139 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_9, sin_9, linear_37, view_19, key_states_6, mul_60, x2_13, neg_13, x1_13, cat_38, mul_61, k_embed_6, cat_39], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg118_1, buf138, arg4_1, arg3_1, arg5_1.item(), buf139, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg118_1
            assert_size_stride_grouped((arg117_1, arg116_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf140 = buf138; del buf138  # reuse
            # Topologically Sorted Source Nodes: [linear_38], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg117_1, reinterpret_tensor(buf136, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg116_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf140)
            del arg116_1
            del arg117_1
            assert_size_stride(arg119_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg119_1 = copy_if_misaligned(arg119_1)
            buf141 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_38, view_20, value_states_6, cat_40], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg119_1, buf140, buf141, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg119_1
            buf142 = reinterpret_tensor(buf136, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf136  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_36, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf137, arg4_1, arg3_1, arg5_1.item(), buf142, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg120_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg120_1 = copy_if_misaligned(arg120_1)
            buf143 = buf121; del buf121  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_36, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg120_1, buf139, buf143, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg120_1
            assert_size_stride(arg121_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg121_1 = copy_if_misaligned(arg121_1)
            buf144 = buf120; del buf120  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_36, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg121_1, buf141, buf144, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg121_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_36, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf145 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf142, buf143, buf144, None, False, scale=0.08838834764831845)
            buf146 = buf145[0]
            assert_tensor_metadata(buf146, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf146, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf145
            buf150 = buf142; del buf142  # reuse
            # Topologically Sorted Source Nodes: [attn_output_24], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf146, buf150, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg122_1, (1536, 1536), (1536, 1), 'input')
            buf151 = reinterpret_tensor(buf146, (s16, 1536), (1536, 1), 0); del buf146  # reuse
            # Topologically Sorted Source Nodes: [attn_output_24, transpose_28, reshape_20, attn_output_27], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf150, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg122_1, (1536, 1536), (1, 1536), 0), out=buf151)
            del arg122_1
            assert_size_stride_grouped((arg124_1, arg123_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf153 = reinterpret_tensor(buf150, (s16, 1, 1536), (1536, 1536, 1), 0); del buf150  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_52, hidden_states_53, attn_output_27, hidden_states_57, pow_14, variance_13, rsqrt_13, hidden_states_59, hidden_states_60], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf129, buf134, buf151, arg124_1, arg123_1.item(), buf153, s16, 1536, stream=raw_stream0)
            del arg123_1
            del arg124_1
            assert_size_stride(arg125_1, (17920, 1536), (1536, 1), 'input')
            buf154 = buf132; del buf132  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_52, hidden_states_53, attn_output_27, hidden_states_57, pow_14, variance_13, rsqrt_13, hidden_states_59, hidden_states_60, linear_40], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf153, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg125_1, (1536, 17920), (1, 1536), 0), out=buf154)
            del arg125_1
            buf155 = buf133; del buf133  # reuse
            # Topologically Sorted Source Nodes: [linear_40, split_6, silu_6, mul_64], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf154, buf155, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg126_1, (1536, 8960), (8960, 1), 'input')
            buf156 = reinterpret_tensor(buf153, (s16, 1536), (1536, 1), 0); del buf153  # reuse
            # Topologically Sorted Source Nodes: [linear_40, split_6, silu_6, mul_64, hidden_states_61], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf155, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg126_1, (8960, 1536), (1, 8960), 0), out=buf156)
            del arg126_1
            assert_size_stride_grouped((arg128_1, arg127_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf158 = reinterpret_tensor(buf137, (s16, 1, 1536), (1536, 1536, 1), 0); del buf137  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_52, hidden_states_53, attn_output_27, hidden_states_57, hidden_states_61, hidden_states_62, pow_15, variance_14, rsqrt_14, hidden_states_64, hidden_states_65], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf129, buf134, buf151, buf156, arg128_1, arg127_1.item(), buf158, s16, 1536, stream=raw_stream0)
            del arg127_1
            del arg128_1
            assert_size_stride_grouped((arg130_1, arg129_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf159 = buf111; del buf111  # reuse
            # Topologically Sorted Source Nodes: [linear_42], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg130_1, reinterpret_tensor(buf158, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg129_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf159)
            del arg129_1
            del arg130_1
            assert_size_stride_grouped((arg132_1, arg131_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf160 = buf140; del buf140  # reuse
            # Topologically Sorted Source Nodes: [linear_43], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg132_1, reinterpret_tensor(buf158, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg131_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf160)
            del arg131_1
            del arg132_1
            assert_size_stride(arg135_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg135_1 = copy_if_misaligned(arg135_1)
            buf161 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_10, sin_10, linear_43, view_22, key_states_7, mul_69, x2_15, neg_15, x1_15, cat_44, mul_70, k_embed_7, cat_45], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg135_1, buf160, arg4_1, arg3_1, arg5_1.item(), buf161, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg135_1
            assert_size_stride_grouped((arg134_1, arg133_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf162 = buf160; del buf160  # reuse
            # Topologically Sorted Source Nodes: [linear_44], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg134_1, reinterpret_tensor(buf158, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg133_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf162)
            del arg133_1
            del arg134_1
            assert_size_stride(arg136_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg136_1 = copy_if_misaligned(arg136_1)
            buf163 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_44, view_23, value_states_7, cat_46], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg136_1, buf162, buf163, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg136_1
            buf164 = reinterpret_tensor(buf158, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf158  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf159, arg4_1, arg3_1, arg5_1.item(), buf164, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf159
            assert_size_stride(arg137_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg137_1 = copy_if_misaligned(arg137_1)
            buf165 = buf144; del buf144  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg137_1, buf161, buf165, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg137_1
            assert_size_stride(arg138_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg138_1 = copy_if_misaligned(arg138_1)
            buf166 = buf143; del buf143  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg138_1, buf163, buf166, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg138_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf167 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf164, buf165, buf166, None, False, scale=0.08838834764831845)
            buf168 = buf167[0]
            assert_tensor_metadata(buf168, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf168, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf167
            buf172 = buf164; del buf164  # reuse
            # Topologically Sorted Source Nodes: [attn_output_28], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf168, buf172, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg139_1, (1536, 1536), (1536, 1), 'input')
            buf173 = reinterpret_tensor(buf168, (s16, 1536), (1536, 1), 0); del buf168  # reuse
            # Topologically Sorted Source Nodes: [attn_output_28, transpose_32, reshape_23, attn_output_31], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf172, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg139_1, (1536, 1536), (1, 1536), 0), out=buf173)
            del arg139_1
            assert_size_stride_grouped((arg141_1, arg140_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf174 = buf129; del buf129  # reuse
            buf176 = reinterpret_tensor(buf172, (s16, 1, 1536), (1536, 1536, 1), 0); del buf172  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_52, hidden_states_53, attn_output_27, hidden_states_57, hidden_states_61, hidden_states_62, attn_output_31, hidden_states_66, pow_16, variance_15, rsqrt_15, hidden_states_68, hidden_states_69], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf174, buf134, buf151, buf156, buf173, arg141_1, arg140_1.item(), buf176, s16, 1536, stream=raw_stream0)
            del arg140_1
            del arg141_1
            del buf134
            assert_size_stride(arg142_1, (17920, 1536), (1536, 1), 'input')
            buf177 = buf154; del buf154  # reuse
            # Topologically Sorted Source Nodes: [pow_16, variance_15, rsqrt_15, hidden_states_68, hidden_states_69, linear_46], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf176, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg142_1, (1536, 17920), (1, 1536), 0), out=buf177)
            del arg142_1
            buf178 = buf155; del buf155  # reuse
            # Topologically Sorted Source Nodes: [linear_46, split_7, silu_7, mul_73], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf177, buf178, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg143_1, (1536, 8960), (8960, 1), 'input')
            buf179 = reinterpret_tensor(buf176, (s16, 1536), (1536, 1), 0); del buf176  # reuse
            # Topologically Sorted Source Nodes: [linear_46, split_7, silu_7, mul_73, hidden_states_70], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf178, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg143_1, (8960, 1536), (1, 8960), 0), out=buf179)
            del arg143_1
            assert_size_stride_grouped((arg145_1, arg144_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf181 = reinterpret_tensor(buf173, (s16, 1, 1536), (1536, 1536, 1), 0); del buf173  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_70, hidden_states_71, pow_17, variance_16, rsqrt_16, hidden_states_73, hidden_states_74], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf174, buf179, arg145_1, arg144_1.item(), buf181, s16, 1536, stream=raw_stream0)
            del arg144_1
            del arg145_1
            assert_size_stride_grouped((arg147_1, arg146_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf182 = buf156; del buf156  # reuse
            # Topologically Sorted Source Nodes: [linear_48], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg147_1, reinterpret_tensor(buf181, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg146_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf182)
            del arg146_1
            del arg147_1
            assert_size_stride_grouped((arg149_1, arg148_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf183 = buf162; del buf162  # reuse
            # Topologically Sorted Source Nodes: [linear_49], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg149_1, reinterpret_tensor(buf181, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg148_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf183)
            del arg148_1
            del arg149_1
            assert_size_stride(arg152_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg152_1 = copy_if_misaligned(arg152_1)
            buf184 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_11, sin_11, linear_49, view_25, key_states_8, mul_78, x2_17, neg_17, x1_17, cat_50, mul_79, k_embed_8, cat_51], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg152_1, buf183, arg4_1, arg3_1, arg5_1.item(), buf184, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg152_1
            assert_size_stride_grouped((arg151_1, arg150_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf185 = buf183; del buf183  # reuse
            # Topologically Sorted Source Nodes: [linear_50], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg151_1, reinterpret_tensor(buf181, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg150_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf185)
            del arg150_1
            del arg151_1
            assert_size_stride(arg153_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg153_1 = copy_if_misaligned(arg153_1)
            buf186 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_50, view_26, value_states_8, cat_52], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg153_1, buf185, buf186, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg153_1
            buf187 = reinterpret_tensor(buf181, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf181  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_48, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf182, arg4_1, arg3_1, arg5_1.item(), buf187, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg154_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg154_1 = copy_if_misaligned(arg154_1)
            buf188 = buf166; del buf166  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_48, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg154_1, buf184, buf188, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg154_1
            assert_size_stride(arg155_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg155_1 = copy_if_misaligned(arg155_1)
            buf189 = buf165; del buf165  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_48, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg155_1, buf186, buf189, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg155_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_48, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf190 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf187, buf188, buf189, None, False, scale=0.08838834764831845)
            buf191 = buf190[0]
            assert_tensor_metadata(buf191, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf191, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf190
            buf195 = buf187; del buf187  # reuse
            # Topologically Sorted Source Nodes: [attn_output_32], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf191, buf195, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg156_1, (1536, 1536), (1536, 1), 'input')
            buf196 = reinterpret_tensor(buf191, (s16, 1536), (1536, 1), 0); del buf191  # reuse
            # Topologically Sorted Source Nodes: [attn_output_32, transpose_36, reshape_26, attn_output_35], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf195, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg156_1, (1536, 1536), (1, 1536), 0), out=buf196)
            del arg156_1
            assert_size_stride_grouped((arg158_1, arg157_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf198 = reinterpret_tensor(buf195, (s16, 1, 1536), (1536, 1536, 1), 0); del buf195  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_70, hidden_states_71, attn_output_35, hidden_states_75, pow_18, variance_17, rsqrt_17, hidden_states_77, hidden_states_78], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf174, buf179, buf196, arg158_1, arg157_1.item(), buf198, s16, 1536, stream=raw_stream0)
            del arg157_1
            del arg158_1
            assert_size_stride(arg159_1, (17920, 1536), (1536, 1), 'input')
            buf199 = buf177; del buf177  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_70, hidden_states_71, attn_output_35, hidden_states_75, pow_18, variance_17, rsqrt_17, hidden_states_77, hidden_states_78, linear_52], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf198, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg159_1, (1536, 17920), (1, 1536), 0), out=buf199)
            del arg159_1
            buf200 = buf178; del buf178  # reuse
            # Topologically Sorted Source Nodes: [linear_52, split_8, silu_8, mul_82], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf199, buf200, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg160_1, (1536, 8960), (8960, 1), 'input')
            buf201 = reinterpret_tensor(buf198, (s16, 1536), (1536, 1), 0); del buf198  # reuse
            # Topologically Sorted Source Nodes: [linear_52, split_8, silu_8, mul_82, hidden_states_79], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf200, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg160_1, (8960, 1536), (1, 8960), 0), out=buf201)
            del arg160_1
            assert_size_stride_grouped((arg162_1, arg161_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf203 = reinterpret_tensor(buf182, (s16, 1, 1536), (1536, 1536, 1), 0); del buf182  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_70, hidden_states_71, attn_output_35, hidden_states_75, hidden_states_79, hidden_states_80, pow_19, variance_18, rsqrt_18, hidden_states_82, hidden_states_83], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf174, buf179, buf196, buf201, arg162_1, arg161_1.item(), buf203, s16, 1536, stream=raw_stream0)
            del arg161_1
            del arg162_1
            assert_size_stride_grouped((arg164_1, arg163_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf204 = buf151; del buf151  # reuse
            # Topologically Sorted Source Nodes: [linear_54], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg164_1, reinterpret_tensor(buf203, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg163_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf204)
            del arg163_1
            del arg164_1
            assert_size_stride_grouped((arg166_1, arg165_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf205 = buf185; del buf185  # reuse
            # Topologically Sorted Source Nodes: [linear_55], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg166_1, reinterpret_tensor(buf203, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg165_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf205)
            del arg165_1
            del arg166_1
            assert_size_stride(arg169_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg169_1 = copy_if_misaligned(arg169_1)
            buf206 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_12, sin_12, linear_55, view_28, key_states_9, mul_87, x2_19, neg_19, x1_19, cat_56, mul_88, k_embed_9, cat_57], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg169_1, buf205, arg4_1, arg3_1, arg5_1.item(), buf206, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg169_1
            assert_size_stride_grouped((arg168_1, arg167_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf207 = buf205; del buf205  # reuse
            # Topologically Sorted Source Nodes: [linear_56], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg168_1, reinterpret_tensor(buf203, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg167_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf207)
            del arg167_1
            del arg168_1
            assert_size_stride(arg170_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg170_1 = copy_if_misaligned(arg170_1)
            buf208 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_56, view_29, value_states_9, cat_58], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg170_1, buf207, buf208, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg170_1
            buf209 = reinterpret_tensor(buf203, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf203  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_54, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf204, arg4_1, arg3_1, arg5_1.item(), buf209, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf204
            assert_size_stride(arg171_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg171_1 = copy_if_misaligned(arg171_1)
            buf210 = buf189; del buf189  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_54, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg171_1, buf206, buf210, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg171_1
            assert_size_stride(arg172_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg172_1 = copy_if_misaligned(arg172_1)
            buf211 = buf188; del buf188  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_54, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg172_1, buf208, buf211, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg172_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_54, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf212 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf209, buf210, buf211, None, False, scale=0.08838834764831845)
            buf213 = buf212[0]
            assert_tensor_metadata(buf213, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf213, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf212
            buf217 = buf209; del buf209  # reuse
            # Topologically Sorted Source Nodes: [attn_output_36], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf213, buf217, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg173_1, (1536, 1536), (1536, 1), 'input')
            buf218 = reinterpret_tensor(buf213, (s16, 1536), (1536, 1), 0); del buf213  # reuse
            # Topologically Sorted Source Nodes: [attn_output_36, transpose_40, reshape_29, attn_output_39], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf217, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg173_1, (1536, 1536), (1, 1536), 0), out=buf218)
            del arg173_1
            assert_size_stride_grouped((arg175_1, arg174_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf219 = buf174; del buf174  # reuse
            buf221 = reinterpret_tensor(buf217, (s16, 1, 1536), (1536, 1536, 1), 0); del buf217  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_70, hidden_states_71, attn_output_35, hidden_states_75, hidden_states_79, hidden_states_80, attn_output_39, hidden_states_84, pow_20, variance_19, rsqrt_19, hidden_states_86, hidden_states_87], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf219, buf179, buf196, buf201, buf218, arg175_1, arg174_1.item(), buf221, s16, 1536, stream=raw_stream0)
            del arg174_1
            del arg175_1
            del buf179
            assert_size_stride(arg176_1, (17920, 1536), (1536, 1), 'input')
            buf222 = buf199; del buf199  # reuse
            # Topologically Sorted Source Nodes: [pow_20, variance_19, rsqrt_19, hidden_states_86, hidden_states_87, linear_58], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf221, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg176_1, (1536, 17920), (1, 1536), 0), out=buf222)
            del arg176_1
            buf223 = buf200; del buf200  # reuse
            # Topologically Sorted Source Nodes: [linear_58, split_9, silu_9, mul_91], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf222, buf223, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg177_1, (1536, 8960), (8960, 1), 'input')
            buf224 = reinterpret_tensor(buf221, (s16, 1536), (1536, 1), 0); del buf221  # reuse
            # Topologically Sorted Source Nodes: [linear_58, split_9, silu_9, mul_91, hidden_states_88], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf223, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg177_1, (8960, 1536), (1, 8960), 0), out=buf224)
            del arg177_1
            assert_size_stride_grouped((arg179_1, arg178_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf226 = reinterpret_tensor(buf218, (s16, 1, 1536), (1536, 1536, 1), 0); del buf218  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_88, hidden_states_89, pow_21, variance_20, rsqrt_20, hidden_states_91, hidden_states_92], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf219, buf224, arg179_1, arg178_1.item(), buf226, s16, 1536, stream=raw_stream0)
            del arg178_1
            del arg179_1
            assert_size_stride_grouped((arg181_1, arg180_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf227 = buf201; del buf201  # reuse
            # Topologically Sorted Source Nodes: [linear_60], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg181_1, reinterpret_tensor(buf226, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg180_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf227)
            del arg180_1
            del arg181_1
            assert_size_stride_grouped((arg183_1, arg182_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf228 = buf207; del buf207  # reuse
            # Topologically Sorted Source Nodes: [linear_61], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg183_1, reinterpret_tensor(buf226, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg182_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf228)
            del arg182_1
            del arg183_1
            assert_size_stride(arg186_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg186_1 = copy_if_misaligned(arg186_1)
            buf229 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_13, sin_13, linear_61, view_31, key_states_10, mul_96, x2_21, neg_21, x1_21, cat_62, mul_97, k_embed_10, cat_63], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg186_1, buf228, arg4_1, arg3_1, arg5_1.item(), buf229, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg186_1
            assert_size_stride_grouped((arg185_1, arg184_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf230 = buf228; del buf228  # reuse
            # Topologically Sorted Source Nodes: [linear_62], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg185_1, reinterpret_tensor(buf226, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg184_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf230)
            del arg184_1
            del arg185_1
            assert_size_stride(arg187_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg187_1 = copy_if_misaligned(arg187_1)
            buf231 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_62, view_32, value_states_10, cat_64], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg187_1, buf230, buf231, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg187_1
            buf232 = reinterpret_tensor(buf226, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf226  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_60, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf227, arg4_1, arg3_1, arg5_1.item(), buf232, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg188_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg188_1 = copy_if_misaligned(arg188_1)
            buf233 = buf211; del buf211  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_60, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg188_1, buf229, buf233, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg188_1
            assert_size_stride(arg189_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg189_1 = copy_if_misaligned(arg189_1)
            buf234 = buf210; del buf210  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_60, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg189_1, buf231, buf234, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg189_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_60, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf235 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf232, buf233, buf234, None, False, scale=0.08838834764831845)
            buf236 = buf235[0]
            assert_tensor_metadata(buf236, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf236, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf235
            buf240 = buf232; del buf232  # reuse
            # Topologically Sorted Source Nodes: [attn_output_40], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf236, buf240, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg190_1, (1536, 1536), (1536, 1), 'input')
            buf241 = reinterpret_tensor(buf236, (s16, 1536), (1536, 1), 0); del buf236  # reuse
            # Topologically Sorted Source Nodes: [attn_output_40, transpose_44, reshape_32, attn_output_43], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf240, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg190_1, (1536, 1536), (1, 1536), 0), out=buf241)
            del arg190_1
            assert_size_stride_grouped((arg192_1, arg191_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf243 = reinterpret_tensor(buf240, (s16, 1, 1536), (1536, 1536, 1), 0); del buf240  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_88, hidden_states_89, attn_output_43, hidden_states_93, pow_22, variance_21, rsqrt_21, hidden_states_95, hidden_states_96], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf219, buf224, buf241, arg192_1, arg191_1.item(), buf243, s16, 1536, stream=raw_stream0)
            del arg191_1
            del arg192_1
            assert_size_stride(arg193_1, (17920, 1536), (1536, 1), 'input')
            buf244 = buf222; del buf222  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_88, hidden_states_89, attn_output_43, hidden_states_93, pow_22, variance_21, rsqrt_21, hidden_states_95, hidden_states_96, linear_64], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf243, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg193_1, (1536, 17920), (1, 1536), 0), out=buf244)
            del arg193_1
            buf245 = buf223; del buf223  # reuse
            # Topologically Sorted Source Nodes: [linear_64, split_10, silu_10, mul_100], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf244, buf245, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg194_1, (1536, 8960), (8960, 1), 'input')
            buf246 = reinterpret_tensor(buf243, (s16, 1536), (1536, 1), 0); del buf243  # reuse
            # Topologically Sorted Source Nodes: [linear_64, split_10, silu_10, mul_100, hidden_states_97], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf245, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg194_1, (8960, 1536), (1, 8960), 0), out=buf246)
            del arg194_1
            assert_size_stride_grouped((arg196_1, arg195_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf248 = reinterpret_tensor(buf227, (s16, 1, 1536), (1536, 1536, 1), 0); del buf227  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_88, hidden_states_89, attn_output_43, hidden_states_93, hidden_states_97, hidden_states_98, pow_23, variance_22, rsqrt_22, hidden_states_100, hidden_states_101], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf219, buf224, buf241, buf246, arg196_1, arg195_1.item(), buf248, s16, 1536, stream=raw_stream0)
            del arg195_1
            del arg196_1
            assert_size_stride_grouped((arg198_1, arg197_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf249 = buf196; del buf196  # reuse
            # Topologically Sorted Source Nodes: [linear_66], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg198_1, reinterpret_tensor(buf248, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg197_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf249)
            del arg197_1
            del arg198_1
            assert_size_stride_grouped((arg200_1, arg199_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf250 = buf230; del buf230  # reuse
            # Topologically Sorted Source Nodes: [linear_67], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg200_1, reinterpret_tensor(buf248, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg199_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf250)
            del arg199_1
            del arg200_1
            assert_size_stride(arg203_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg203_1 = copy_if_misaligned(arg203_1)
            buf251 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_14, sin_14, linear_67, view_34, key_states_11, mul_105, x2_23, neg_23, x1_23, cat_68, mul_106, k_embed_11, cat_69], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg203_1, buf250, arg4_1, arg3_1, arg5_1.item(), buf251, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg203_1
            assert_size_stride_grouped((arg202_1, arg201_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf252 = buf250; del buf250  # reuse
            # Topologically Sorted Source Nodes: [linear_68], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg202_1, reinterpret_tensor(buf248, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg201_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf252)
            del arg201_1
            del arg202_1
            assert_size_stride(arg204_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg204_1 = copy_if_misaligned(arg204_1)
            buf253 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_68, view_35, value_states_11, cat_70], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg204_1, buf252, buf253, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg204_1
            buf254 = reinterpret_tensor(buf248, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf248  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_66, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf249, arg4_1, arg3_1, arg5_1.item(), buf254, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf249
            assert_size_stride(arg205_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg205_1 = copy_if_misaligned(arg205_1)
            buf255 = buf234; del buf234  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_66, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg205_1, buf251, buf255, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg205_1
            assert_size_stride(arg206_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg206_1 = copy_if_misaligned(arg206_1)
            buf256 = buf233; del buf233  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_66, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg206_1, buf253, buf256, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg206_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_66, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf257 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf254, buf255, buf256, None, False, scale=0.08838834764831845)
            buf258 = buf257[0]
            assert_tensor_metadata(buf258, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf258, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf257
            buf262 = buf254; del buf254  # reuse
            # Topologically Sorted Source Nodes: [attn_output_44], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf258, buf262, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg207_1, (1536, 1536), (1536, 1), 'input')
            buf263 = reinterpret_tensor(buf258, (s16, 1536), (1536, 1), 0); del buf258  # reuse
            # Topologically Sorted Source Nodes: [attn_output_44, transpose_48, reshape_35, attn_output_47], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf262, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg207_1, (1536, 1536), (1, 1536), 0), out=buf263)
            del arg207_1
            assert_size_stride_grouped((arg209_1, arg208_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf264 = buf219; del buf219  # reuse
            buf266 = reinterpret_tensor(buf262, (s16, 1, 1536), (1536, 1536, 1), 0); del buf262  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_88, hidden_states_89, attn_output_43, hidden_states_93, hidden_states_97, hidden_states_98, attn_output_47, hidden_states_102, pow_24, variance_23, rsqrt_23, hidden_states_104, hidden_states_105], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf264, buf224, buf241, buf246, buf263, arg209_1, arg208_1.item(), buf266, s16, 1536, stream=raw_stream0)
            del arg208_1
            del arg209_1
            del buf224
            assert_size_stride(arg210_1, (17920, 1536), (1536, 1), 'input')
            buf267 = buf244; del buf244  # reuse
            # Topologically Sorted Source Nodes: [pow_24, variance_23, rsqrt_23, hidden_states_104, hidden_states_105, linear_70], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf266, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg210_1, (1536, 17920), (1, 1536), 0), out=buf267)
            del arg210_1
            buf268 = buf245; del buf245  # reuse
            # Topologically Sorted Source Nodes: [linear_70, split_11, silu_11, mul_109], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf267, buf268, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg211_1, (1536, 8960), (8960, 1), 'input')
            buf269 = reinterpret_tensor(buf266, (s16, 1536), (1536, 1), 0); del buf266  # reuse
            # Topologically Sorted Source Nodes: [linear_70, split_11, silu_11, mul_109, hidden_states_106], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf268, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg211_1, (8960, 1536), (1, 8960), 0), out=buf269)
            del arg211_1
            assert_size_stride_grouped((arg213_1, arg212_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf271 = reinterpret_tensor(buf263, (s16, 1, 1536), (1536, 1536, 1), 0); del buf263  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_106, hidden_states_107, pow_25, variance_24, rsqrt_24, hidden_states_109, hidden_states_110], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf264, buf269, arg213_1, arg212_1.item(), buf271, s16, 1536, stream=raw_stream0)
            del arg212_1
            del arg213_1
            assert_size_stride_grouped((arg215_1, arg214_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf272 = buf246; del buf246  # reuse
            # Topologically Sorted Source Nodes: [linear_72], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg215_1, reinterpret_tensor(buf271, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg214_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf272)
            del arg214_1
            del arg215_1
            assert_size_stride_grouped((arg217_1, arg216_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf273 = buf252; del buf252  # reuse
            # Topologically Sorted Source Nodes: [linear_73], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg217_1, reinterpret_tensor(buf271, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg216_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf273)
            del arg216_1
            del arg217_1
            assert_size_stride(arg220_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg220_1 = copy_if_misaligned(arg220_1)
            buf274 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_15, sin_15, linear_73, view_37, key_states_12, mul_114, x2_25, neg_25, x1_25, cat_74, mul_115, k_embed_12, cat_75], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg220_1, buf273, arg4_1, arg3_1, arg5_1.item(), buf274, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg220_1
            assert_size_stride_grouped((arg219_1, arg218_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf275 = buf273; del buf273  # reuse
            # Topologically Sorted Source Nodes: [linear_74], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg219_1, reinterpret_tensor(buf271, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg218_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf275)
            del arg218_1
            del arg219_1
            assert_size_stride(arg221_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg221_1 = copy_if_misaligned(arg221_1)
            buf276 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_74, view_38, value_states_12, cat_76], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg221_1, buf275, buf276, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg221_1
            buf277 = reinterpret_tensor(buf271, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf271  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_72, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf272, arg4_1, arg3_1, arg5_1.item(), buf277, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg222_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg222_1 = copy_if_misaligned(arg222_1)
            buf278 = buf256; del buf256  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_72, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg222_1, buf274, buf278, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg222_1
            assert_size_stride(arg223_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg223_1 = copy_if_misaligned(arg223_1)
            buf279 = buf255; del buf255  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_72, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg223_1, buf276, buf279, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg223_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_72, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf280 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf277, buf278, buf279, None, False, scale=0.08838834764831845)
            buf281 = buf280[0]
            assert_tensor_metadata(buf281, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf281, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf280
            buf285 = buf277; del buf277  # reuse
            # Topologically Sorted Source Nodes: [attn_output_48], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf281, buf285, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg224_1, (1536, 1536), (1536, 1), 'input')
            buf286 = reinterpret_tensor(buf281, (s16, 1536), (1536, 1), 0); del buf281  # reuse
            # Topologically Sorted Source Nodes: [attn_output_48, transpose_52, reshape_38, attn_output_51], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf285, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg224_1, (1536, 1536), (1, 1536), 0), out=buf286)
            del arg224_1
            assert_size_stride_grouped((arg226_1, arg225_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf288 = reinterpret_tensor(buf285, (s16, 1, 1536), (1536, 1536, 1), 0); del buf285  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_106, hidden_states_107, attn_output_51, hidden_states_111, pow_26, variance_25, rsqrt_25, hidden_states_113, hidden_states_114], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf264, buf269, buf286, arg226_1, arg225_1.item(), buf288, s16, 1536, stream=raw_stream0)
            del arg225_1
            del arg226_1
            assert_size_stride(arg227_1, (17920, 1536), (1536, 1), 'input')
            buf289 = buf267; del buf267  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_106, hidden_states_107, attn_output_51, hidden_states_111, pow_26, variance_25, rsqrt_25, hidden_states_113, hidden_states_114, linear_76], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf288, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg227_1, (1536, 17920), (1, 1536), 0), out=buf289)
            del arg227_1
            buf290 = buf268; del buf268  # reuse
            # Topologically Sorted Source Nodes: [linear_76, split_12, silu_12, mul_118], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf289, buf290, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg228_1, (1536, 8960), (8960, 1), 'input')
            buf291 = reinterpret_tensor(buf288, (s16, 1536), (1536, 1), 0); del buf288  # reuse
            # Topologically Sorted Source Nodes: [linear_76, split_12, silu_12, mul_118, hidden_states_115], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf290, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg228_1, (8960, 1536), (1, 8960), 0), out=buf291)
            del arg228_1
            assert_size_stride_grouped((arg230_1, arg229_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf293 = reinterpret_tensor(buf272, (s16, 1, 1536), (1536, 1536, 1), 0); del buf272  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_106, hidden_states_107, attn_output_51, hidden_states_111, hidden_states_115, hidden_states_116, pow_27, variance_26, rsqrt_26, hidden_states_118, hidden_states_119], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf264, buf269, buf286, buf291, arg230_1, arg229_1.item(), buf293, s16, 1536, stream=raw_stream0)
            del arg229_1
            del arg230_1
            assert_size_stride_grouped((arg232_1, arg231_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf294 = buf241; del buf241  # reuse
            # Topologically Sorted Source Nodes: [linear_78], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg232_1, reinterpret_tensor(buf293, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg231_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf294)
            del arg231_1
            del arg232_1
            assert_size_stride_grouped((arg234_1, arg233_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf295 = buf275; del buf275  # reuse
            # Topologically Sorted Source Nodes: [linear_79], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg234_1, reinterpret_tensor(buf293, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg233_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf295)
            del arg233_1
            del arg234_1
            assert_size_stride(arg237_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg237_1 = copy_if_misaligned(arg237_1)
            buf296 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_16, sin_16, linear_79, view_40, key_states_13, mul_123, x2_27, neg_27, x1_27, cat_80, mul_124, k_embed_13, cat_81], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg237_1, buf295, arg4_1, arg3_1, arg5_1.item(), buf296, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg237_1
            assert_size_stride_grouped((arg236_1, arg235_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf297 = buf295; del buf295  # reuse
            # Topologically Sorted Source Nodes: [linear_80], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg236_1, reinterpret_tensor(buf293, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg235_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf297)
            del arg235_1
            del arg236_1
            assert_size_stride(arg238_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg238_1 = copy_if_misaligned(arg238_1)
            buf298 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_80, view_41, value_states_13, cat_82], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg238_1, buf297, buf298, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg238_1
            buf299 = reinterpret_tensor(buf293, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf293  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_78, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf294, arg4_1, arg3_1, arg5_1.item(), buf299, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf294
            assert_size_stride(arg239_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg239_1 = copy_if_misaligned(arg239_1)
            buf300 = buf279; del buf279  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_78, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg239_1, buf296, buf300, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg239_1
            assert_size_stride(arg240_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg240_1 = copy_if_misaligned(arg240_1)
            buf301 = buf278; del buf278  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_78, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg240_1, buf298, buf301, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg240_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_78, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf302 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf299, buf300, buf301, None, False, scale=0.08838834764831845)
            buf303 = buf302[0]
            assert_tensor_metadata(buf303, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf303, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf302
            buf307 = buf299; del buf299  # reuse
            # Topologically Sorted Source Nodes: [attn_output_52], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf303, buf307, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg241_1, (1536, 1536), (1536, 1), 'input')
            buf308 = reinterpret_tensor(buf303, (s16, 1536), (1536, 1), 0); del buf303  # reuse
            # Topologically Sorted Source Nodes: [attn_output_52, transpose_56, reshape_41, attn_output_55], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf307, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg241_1, (1536, 1536), (1, 1536), 0), out=buf308)
            del arg241_1
            assert_size_stride_grouped((arg243_1, arg242_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf309 = buf264; del buf264  # reuse
            buf311 = reinterpret_tensor(buf307, (s16, 1, 1536), (1536, 1536, 1), 0); del buf307  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_106, hidden_states_107, attn_output_51, hidden_states_111, hidden_states_115, hidden_states_116, attn_output_55, hidden_states_120, pow_28, variance_27, rsqrt_27, hidden_states_122, hidden_states_123], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf309, buf269, buf286, buf291, buf308, arg243_1, arg242_1.item(), buf311, s16, 1536, stream=raw_stream0)
            del arg242_1
            del arg243_1
            del buf269
            assert_size_stride(arg244_1, (17920, 1536), (1536, 1), 'input')
            buf312 = buf289; del buf289  # reuse
            # Topologically Sorted Source Nodes: [pow_28, variance_27, rsqrt_27, hidden_states_122, hidden_states_123, linear_82], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf311, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg244_1, (1536, 17920), (1, 1536), 0), out=buf312)
            del arg244_1
            buf313 = buf290; del buf290  # reuse
            # Topologically Sorted Source Nodes: [linear_82, split_13, silu_13, mul_127], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf312, buf313, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg245_1, (1536, 8960), (8960, 1), 'input')
            buf314 = reinterpret_tensor(buf311, (s16, 1536), (1536, 1), 0); del buf311  # reuse
            # Topologically Sorted Source Nodes: [linear_82, split_13, silu_13, mul_127, hidden_states_124], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf313, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg245_1, (8960, 1536), (1, 8960), 0), out=buf314)
            del arg245_1
            assert_size_stride_grouped((arg247_1, arg246_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf316 = reinterpret_tensor(buf308, (s16, 1, 1536), (1536, 1536, 1), 0); del buf308  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, pow_29, variance_28, rsqrt_28, hidden_states_127, hidden_states_128], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf309, buf314, arg247_1, arg246_1.item(), buf316, s16, 1536, stream=raw_stream0)
            del arg246_1
            del arg247_1
            assert_size_stride_grouped((arg249_1, arg248_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf317 = buf291; del buf291  # reuse
            # Topologically Sorted Source Nodes: [linear_84], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg249_1, reinterpret_tensor(buf316, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg248_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf317)
            del arg248_1
            del arg249_1
            assert_size_stride_grouped((arg251_1, arg250_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf318 = buf297; del buf297  # reuse
            # Topologically Sorted Source Nodes: [linear_85], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg251_1, reinterpret_tensor(buf316, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg250_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf318)
            del arg250_1
            del arg251_1
            assert_size_stride(arg254_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg254_1 = copy_if_misaligned(arg254_1)
            buf319 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_17, sin_17, linear_85, view_43, key_states_14, mul_132, x2_29, neg_29, x1_29, cat_86, mul_133, k_embed_14, cat_87], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg254_1, buf318, arg4_1, arg3_1, arg5_1.item(), buf319, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg254_1
            assert_size_stride_grouped((arg253_1, arg252_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf320 = buf318; del buf318  # reuse
            # Topologically Sorted Source Nodes: [linear_86], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg253_1, reinterpret_tensor(buf316, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg252_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf320)
            del arg252_1
            del arg253_1
            assert_size_stride(arg255_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg255_1 = copy_if_misaligned(arg255_1)
            buf321 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_86, view_44, value_states_14, cat_88], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg255_1, buf320, buf321, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg255_1
            buf322 = reinterpret_tensor(buf316, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf316  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf317, arg4_1, arg3_1, arg5_1.item(), buf322, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg256_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg256_1 = copy_if_misaligned(arg256_1)
            buf323 = buf301; del buf301  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg256_1, buf319, buf323, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg256_1
            assert_size_stride(arg257_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg257_1 = copy_if_misaligned(arg257_1)
            buf324 = buf300; del buf300  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg257_1, buf321, buf324, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg257_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf325 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf322, buf323, buf324, None, False, scale=0.08838834764831845)
            buf326 = buf325[0]
            assert_tensor_metadata(buf326, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf326, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf325
            buf330 = buf322; del buf322  # reuse
            # Topologically Sorted Source Nodes: [attn_output_56], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf326, buf330, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg258_1, (1536, 1536), (1536, 1), 'input')
            buf331 = reinterpret_tensor(buf326, (s16, 1536), (1536, 1), 0); del buf326  # reuse
            # Topologically Sorted Source Nodes: [attn_output_56, transpose_60, reshape_44, attn_output_59], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf330, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg258_1, (1536, 1536), (1, 1536), 0), out=buf331)
            del arg258_1
            assert_size_stride_grouped((arg260_1, arg259_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf333 = reinterpret_tensor(buf330, (s16, 1, 1536), (1536, 1536, 1), 0); del buf330  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, attn_output_59, hidden_states_129, pow_30, variance_29, rsqrt_29, hidden_states_131, hidden_states_132], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf309, buf314, buf331, arg260_1, arg259_1.item(), buf333, s16, 1536, stream=raw_stream0)
            del arg259_1
            del arg260_1
            assert_size_stride(arg261_1, (17920, 1536), (1536, 1), 'input')
            buf334 = buf312; del buf312  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, attn_output_59, hidden_states_129, pow_30, variance_29, rsqrt_29, hidden_states_131, hidden_states_132, linear_88], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf333, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg261_1, (1536, 17920), (1, 1536), 0), out=buf334)
            del arg261_1
            buf335 = buf313; del buf313  # reuse
            # Topologically Sorted Source Nodes: [linear_88, split_14, silu_14, mul_136], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf334, buf335, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg262_1, (1536, 8960), (8960, 1), 'input')
            buf336 = reinterpret_tensor(buf333, (s16, 1536), (1536, 1), 0); del buf333  # reuse
            # Topologically Sorted Source Nodes: [linear_88, split_14, silu_14, mul_136, hidden_states_133], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf335, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg262_1, (8960, 1536), (1, 8960), 0), out=buf336)
            del arg262_1
            assert_size_stride(arg263_1, (1536, ), (1, ), 'input')
            buf338 = reinterpret_tensor(buf317, (s16, 1, 1536), (1536, 1536, 1), 0); del buf317  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, attn_output_59, hidden_states_129, hidden_states_133, hidden_states_134, pow_31, variance_30, add_90, rsqrt_30, hidden_states_136, hidden_states_137], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14.run(buf309, buf314, buf331, buf336, arg263_1, buf338, s16, 1536, stream=raw_stream0)
            del arg263_1
            assert_size_stride_grouped((arg265_1, arg264_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf339 = buf286; del buf286  # reuse
            # Topologically Sorted Source Nodes: [linear_90], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg265_1, reinterpret_tensor(buf338, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg264_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf339)
            del arg264_1
            del arg265_1
            assert_size_stride_grouped((arg267_1, arg266_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf340 = buf320; del buf320  # reuse
            # Topologically Sorted Source Nodes: [linear_91], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg267_1, reinterpret_tensor(buf338, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg266_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf340)
            del arg266_1
            del arg267_1
            assert_size_stride(arg270_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg270_1 = copy_if_misaligned(arg270_1)
            buf341 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_18, sin_18, linear_91, view_46, key_states_15, mul_141, x2_31, neg_31, x1_31, cat_92, mul_142, k_embed_15, cat_93], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg270_1, buf340, arg4_1, arg3_1, arg5_1.item(), buf341, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg270_1
            assert_size_stride_grouped((arg269_1, arg268_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf342 = buf340; del buf340  # reuse
            # Topologically Sorted Source Nodes: [linear_92], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg269_1, reinterpret_tensor(buf338, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg268_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf342)
            del arg268_1
            del arg269_1
            assert_size_stride(arg271_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg271_1 = copy_if_misaligned(arg271_1)
            buf343 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_92, view_47, value_states_15, cat_94], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg271_1, buf342, buf343, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg271_1
            buf344 = reinterpret_tensor(buf338, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf338  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_90, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf339, arg4_1, arg3_1, arg5_1.item(), buf344, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf339
            assert_size_stride(arg272_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg272_1 = copy_if_misaligned(arg272_1)
            buf345 = buf324; del buf324  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_90, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg272_1, buf341, buf345, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg272_1
            assert_size_stride(arg273_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg273_1 = copy_if_misaligned(arg273_1)
            buf346 = buf323; del buf323  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_90, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg273_1, buf343, buf346, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg273_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_90, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf347 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf344, buf345, buf346, None, False, scale=0.08838834764831845)
            buf348 = buf347[0]
            assert_tensor_metadata(buf348, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf348, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf347
            buf352 = buf344; del buf344  # reuse
            # Topologically Sorted Source Nodes: [attn_output_60], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf348, buf352, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg274_1, (1536, 1536), (1536, 1), 'input')
            buf353 = reinterpret_tensor(buf348, (s16, 1536), (1536, 1), 0); del buf348  # reuse
            # Topologically Sorted Source Nodes: [attn_output_60, transpose_64, reshape_47, attn_output_63], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf352, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg274_1, (1536, 1536), (1, 1536), 0), out=buf353)
            del arg274_1
            assert_size_stride_grouped((arg276_1, arg275_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf354 = buf309; del buf309  # reuse
            buf356 = reinterpret_tensor(buf352, (s16, 1, 1536), (1536, 1536, 1), 0); del buf352  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, attn_output_59, hidden_states_129, hidden_states_133, hidden_states_134, attn_output_63, hidden_states_138, pow_32, variance_31, rsqrt_31, hidden_states_140, hidden_states_141], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf354, buf314, buf331, buf336, buf353, arg276_1, arg275_1.item(), buf356, s16, 1536, stream=raw_stream0)
            del arg275_1
            del arg276_1
            del buf314
            assert_size_stride(arg277_1, (17920, 1536), (1536, 1), 'input')
            buf357 = buf334; del buf334  # reuse
            # Topologically Sorted Source Nodes: [pow_32, variance_31, rsqrt_31, hidden_states_140, hidden_states_141, linear_94], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf356, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg277_1, (1536, 17920), (1, 1536), 0), out=buf357)
            del arg277_1
            buf358 = buf335; del buf335  # reuse
            # Topologically Sorted Source Nodes: [linear_94, split_15, silu_15, mul_145], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf357, buf358, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg278_1, (1536, 8960), (8960, 1), 'input')
            buf359 = reinterpret_tensor(buf356, (s16, 1536), (1536, 1), 0); del buf356  # reuse
            # Topologically Sorted Source Nodes: [linear_94, split_15, silu_15, mul_145, hidden_states_142], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf358, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg278_1, (8960, 1536), (1, 8960), 0), out=buf359)
            del arg278_1
            assert_size_stride_grouped((arg280_1, arg279_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf361 = reinterpret_tensor(buf353, (s16, 1, 1536), (1536, 1536, 1), 0); del buf353  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_142, hidden_states_143, pow_33, variance_32, rsqrt_32, hidden_states_145, hidden_states_146], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf354, buf359, arg280_1, arg279_1.item(), buf361, s16, 1536, stream=raw_stream0)
            del arg279_1
            del arg280_1
            assert_size_stride_grouped((arg282_1, arg281_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf362 = buf336; del buf336  # reuse
            # Topologically Sorted Source Nodes: [linear_96], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg282_1, reinterpret_tensor(buf361, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg281_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf362)
            del arg281_1
            del arg282_1
            assert_size_stride_grouped((arg284_1, arg283_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf363 = buf342; del buf342  # reuse
            # Topologically Sorted Source Nodes: [linear_97], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg284_1, reinterpret_tensor(buf361, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg283_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf363)
            del arg283_1
            del arg284_1
            assert_size_stride(arg287_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg287_1 = copy_if_misaligned(arg287_1)
            buf364 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_19, sin_19, linear_97, view_49, key_states_16, mul_150, x2_33, neg_33, x1_33, cat_98, mul_151, k_embed_16, cat_99], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg287_1, buf363, arg4_1, arg3_1, arg5_1.item(), buf364, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg287_1
            assert_size_stride_grouped((arg286_1, arg285_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf365 = buf363; del buf363  # reuse
            # Topologically Sorted Source Nodes: [linear_98], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg286_1, reinterpret_tensor(buf361, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg285_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf365)
            del arg285_1
            del arg286_1
            assert_size_stride(arg288_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg288_1 = copy_if_misaligned(arg288_1)
            buf366 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_98, view_50, value_states_16, cat_100], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg288_1, buf365, buf366, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg288_1
            buf367 = reinterpret_tensor(buf361, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf361  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_96, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf362, arg4_1, arg3_1, arg5_1.item(), buf367, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg289_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg289_1 = copy_if_misaligned(arg289_1)
            buf368 = buf346; del buf346  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_96, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg289_1, buf364, buf368, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg289_1
            assert_size_stride(arg290_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg290_1 = copy_if_misaligned(arg290_1)
            buf369 = buf345; del buf345  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_96, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg290_1, buf366, buf369, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg290_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_96, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf370 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf367, buf368, buf369, None, False, scale=0.08838834764831845)
            buf371 = buf370[0]
            assert_tensor_metadata(buf371, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf371, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf370
            buf375 = buf367; del buf367  # reuse
            # Topologically Sorted Source Nodes: [attn_output_64], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf371, buf375, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg291_1, (1536, 1536), (1536, 1), 'input')
            buf376 = reinterpret_tensor(buf371, (s16, 1536), (1536, 1), 0); del buf371  # reuse
            # Topologically Sorted Source Nodes: [attn_output_64, transpose_68, reshape_50, attn_output_67], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf375, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg291_1, (1536, 1536), (1, 1536), 0), out=buf376)
            del arg291_1
            assert_size_stride_grouped((arg293_1, arg292_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf378 = reinterpret_tensor(buf375, (s16, 1, 1536), (1536, 1536, 1), 0); del buf375  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_142, hidden_states_143, attn_output_67, hidden_states_147, pow_34, variance_33, rsqrt_33, hidden_states_149, hidden_states_150], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf354, buf359, buf376, arg293_1, arg292_1.item(), buf378, s16, 1536, stream=raw_stream0)
            del arg292_1
            del arg293_1
            assert_size_stride(arg294_1, (17920, 1536), (1536, 1), 'input')
            buf379 = buf357; del buf357  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_142, hidden_states_143, attn_output_67, hidden_states_147, pow_34, variance_33, rsqrt_33, hidden_states_149, hidden_states_150, linear_100], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf378, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg294_1, (1536, 17920), (1, 1536), 0), out=buf379)
            del arg294_1
            buf380 = buf358; del buf358  # reuse
            # Topologically Sorted Source Nodes: [linear_100, split_16, silu_16, mul_154], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf379, buf380, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg295_1, (1536, 8960), (8960, 1), 'input')
            buf381 = reinterpret_tensor(buf378, (s16, 1536), (1536, 1), 0); del buf378  # reuse
            # Topologically Sorted Source Nodes: [linear_100, split_16, silu_16, mul_154, hidden_states_151], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf380, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg295_1, (8960, 1536), (1, 8960), 0), out=buf381)
            del arg295_1
            assert_size_stride_grouped((arg297_1, arg296_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf383 = reinterpret_tensor(buf362, (s16, 1, 1536), (1536, 1536, 1), 0); del buf362  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_142, hidden_states_143, attn_output_67, hidden_states_147, hidden_states_151, hidden_states_152, pow_35, variance_34, rsqrt_34, hidden_states_154, hidden_states_155], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf354, buf359, buf376, buf381, arg297_1, arg296_1.item(), buf383, s16, 1536, stream=raw_stream0)
            del arg296_1
            del arg297_1
            assert_size_stride_grouped((arg299_1, arg298_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf384 = buf331; del buf331  # reuse
            # Topologically Sorted Source Nodes: [linear_102], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg299_1, reinterpret_tensor(buf383, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg298_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf384)
            del arg298_1
            del arg299_1
            assert_size_stride_grouped((arg301_1, arg300_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf385 = buf365; del buf365  # reuse
            # Topologically Sorted Source Nodes: [linear_103], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg301_1, reinterpret_tensor(buf383, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg300_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf385)
            del arg300_1
            del arg301_1
            assert_size_stride(arg304_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg304_1 = copy_if_misaligned(arg304_1)
            buf386 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_20, sin_20, linear_103, view_52, key_states_17, mul_159, x2_35, neg_35, x1_35, cat_104, mul_160, k_embed_17, cat_105], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg304_1, buf385, arg4_1, arg3_1, arg5_1.item(), buf386, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg304_1
            assert_size_stride_grouped((arg303_1, arg302_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf387 = buf385; del buf385  # reuse
            # Topologically Sorted Source Nodes: [linear_104], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg303_1, reinterpret_tensor(buf383, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg302_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf387)
            del arg302_1
            del arg303_1
            assert_size_stride(arg305_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg305_1 = copy_if_misaligned(arg305_1)
            buf388 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_104, view_53, value_states_17, cat_106], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg305_1, buf387, buf388, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg305_1
            buf389 = reinterpret_tensor(buf383, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf383  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_102, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf384, arg4_1, arg3_1, arg5_1.item(), buf389, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf384
            assert_size_stride(arg306_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg306_1 = copy_if_misaligned(arg306_1)
            buf390 = buf369; del buf369  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_102, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg306_1, buf386, buf390, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg306_1
            assert_size_stride(arg307_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg307_1 = copy_if_misaligned(arg307_1)
            buf391 = buf368; del buf368  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_102, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg307_1, buf388, buf391, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg307_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_102, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf392 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf389, buf390, buf391, None, False, scale=0.08838834764831845)
            buf393 = buf392[0]
            assert_tensor_metadata(buf393, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf393, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf392
            buf397 = buf389; del buf389  # reuse
            # Topologically Sorted Source Nodes: [attn_output_68], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf393, buf397, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg308_1, (1536, 1536), (1536, 1), 'input')
            buf398 = reinterpret_tensor(buf393, (s16, 1536), (1536, 1), 0); del buf393  # reuse
            # Topologically Sorted Source Nodes: [attn_output_68, transpose_72, reshape_53, attn_output_71], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf397, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg308_1, (1536, 1536), (1, 1536), 0), out=buf398)
            del arg308_1
            assert_size_stride_grouped((arg310_1, arg309_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf399 = buf354; del buf354  # reuse
            buf401 = reinterpret_tensor(buf397, (s16, 1, 1536), (1536, 1536, 1), 0); del buf397  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_142, hidden_states_143, attn_output_67, hidden_states_147, hidden_states_151, hidden_states_152, attn_output_71, hidden_states_156, pow_36, variance_35, rsqrt_35, hidden_states_158, hidden_states_159], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf399, buf359, buf376, buf381, buf398, arg310_1, arg309_1.item(), buf401, s16, 1536, stream=raw_stream0)
            del arg309_1
            del arg310_1
            del buf359
            assert_size_stride(arg311_1, (17920, 1536), (1536, 1), 'input')
            buf402 = buf379; del buf379  # reuse
            # Topologically Sorted Source Nodes: [pow_36, variance_35, rsqrt_35, hidden_states_158, hidden_states_159, linear_106], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf401, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg311_1, (1536, 17920), (1, 1536), 0), out=buf402)
            del arg311_1
            buf403 = buf380; del buf380  # reuse
            # Topologically Sorted Source Nodes: [linear_106, split_17, silu_17, mul_163], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf402, buf403, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg312_1, (1536, 8960), (8960, 1), 'input')
            buf404 = reinterpret_tensor(buf401, (s16, 1536), (1536, 1), 0); del buf401  # reuse
            # Topologically Sorted Source Nodes: [linear_106, split_17, silu_17, mul_163, hidden_states_160], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf403, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg312_1, (8960, 1536), (1, 8960), 0), out=buf404)
            del arg312_1
            assert_size_stride_grouped((arg314_1, arg313_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf406 = reinterpret_tensor(buf398, (s16, 1, 1536), (1536, 1536, 1), 0); del buf398  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_160, hidden_states_161, pow_37, variance_36, rsqrt_36, hidden_states_163, hidden_states_164], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf399, buf404, arg314_1, arg313_1.item(), buf406, s16, 1536, stream=raw_stream0)
            del arg313_1
            del arg314_1
            assert_size_stride_grouped((arg316_1, arg315_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf407 = buf381; del buf381  # reuse
            # Topologically Sorted Source Nodes: [linear_108], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg316_1, reinterpret_tensor(buf406, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg315_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf407)
            del arg315_1
            del arg316_1
            assert_size_stride_grouped((arg318_1, arg317_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf408 = buf387; del buf387  # reuse
            # Topologically Sorted Source Nodes: [linear_109], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg318_1, reinterpret_tensor(buf406, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg317_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf408)
            del arg317_1
            del arg318_1
            assert_size_stride(arg321_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg321_1 = copy_if_misaligned(arg321_1)
            buf409 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_21, sin_21, linear_109, view_55, key_states_18, mul_168, x2_37, neg_37, x1_37, cat_110, mul_169, k_embed_18, cat_111], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg321_1, buf408, arg4_1, arg3_1, arg5_1.item(), buf409, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg321_1
            assert_size_stride_grouped((arg320_1, arg319_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf410 = buf408; del buf408  # reuse
            # Topologically Sorted Source Nodes: [linear_110], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg320_1, reinterpret_tensor(buf406, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg319_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf410)
            del arg319_1
            del arg320_1
            assert_size_stride(arg322_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg322_1 = copy_if_misaligned(arg322_1)
            buf411 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_110, view_56, value_states_18, cat_112], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg322_1, buf410, buf411, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg322_1
            buf412 = reinterpret_tensor(buf406, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf406  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_108, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf407, arg4_1, arg3_1, arg5_1.item(), buf412, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg323_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg323_1 = copy_if_misaligned(arg323_1)
            buf413 = buf391; del buf391  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_108, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg323_1, buf409, buf413, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg323_1
            assert_size_stride(arg324_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg324_1 = copy_if_misaligned(arg324_1)
            buf414 = buf390; del buf390  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_108, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg324_1, buf411, buf414, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg324_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_108, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf415 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf412, buf413, buf414, None, False, scale=0.08838834764831845)
            buf416 = buf415[0]
            assert_tensor_metadata(buf416, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf416, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf415
            buf420 = buf412; del buf412  # reuse
            # Topologically Sorted Source Nodes: [attn_output_72], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf416, buf420, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg325_1, (1536, 1536), (1536, 1), 'input')
            buf421 = reinterpret_tensor(buf416, (s16, 1536), (1536, 1), 0); del buf416  # reuse
            # Topologically Sorted Source Nodes: [attn_output_72, transpose_76, reshape_56, attn_output_75], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf420, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg325_1, (1536, 1536), (1, 1536), 0), out=buf421)
            del arg325_1
            assert_size_stride_grouped((arg327_1, arg326_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf423 = reinterpret_tensor(buf420, (s16, 1, 1536), (1536, 1536, 1), 0); del buf420  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_160, hidden_states_161, attn_output_75, hidden_states_165, pow_38, variance_37, rsqrt_37, hidden_states_167, hidden_states_168], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf399, buf404, buf421, arg327_1, arg326_1.item(), buf423, s16, 1536, stream=raw_stream0)
            del arg326_1
            del arg327_1
            assert_size_stride(arg328_1, (17920, 1536), (1536, 1), 'input')
            buf424 = buf402; del buf402  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_160, hidden_states_161, attn_output_75, hidden_states_165, pow_38, variance_37, rsqrt_37, hidden_states_167, hidden_states_168, linear_112], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf423, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg328_1, (1536, 17920), (1, 1536), 0), out=buf424)
            del arg328_1
            buf425 = buf403; del buf403  # reuse
            # Topologically Sorted Source Nodes: [linear_112, split_18, silu_18, mul_172], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf424, buf425, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg329_1, (1536, 8960), (8960, 1), 'input')
            buf426 = reinterpret_tensor(buf423, (s16, 1536), (1536, 1), 0); del buf423  # reuse
            # Topologically Sorted Source Nodes: [linear_112, split_18, silu_18, mul_172, hidden_states_169], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf425, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg329_1, (8960, 1536), (1, 8960), 0), out=buf426)
            del arg329_1
            assert_size_stride_grouped((arg331_1, arg330_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf428 = reinterpret_tensor(buf407, (s16, 1, 1536), (1536, 1536, 1), 0); del buf407  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_160, hidden_states_161, attn_output_75, hidden_states_165, hidden_states_169, hidden_states_170, pow_39, variance_38, rsqrt_38, hidden_states_172, hidden_states_173], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf399, buf404, buf421, buf426, arg331_1, arg330_1.item(), buf428, s16, 1536, stream=raw_stream0)
            del arg330_1
            del arg331_1
            assert_size_stride_grouped((arg333_1, arg332_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf429 = buf376; del buf376  # reuse
            # Topologically Sorted Source Nodes: [linear_114], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg333_1, reinterpret_tensor(buf428, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg332_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf429)
            del arg332_1
            del arg333_1
            assert_size_stride_grouped((arg335_1, arg334_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf430 = buf410; del buf410  # reuse
            # Topologically Sorted Source Nodes: [linear_115], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg335_1, reinterpret_tensor(buf428, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg334_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf430)
            del arg334_1
            del arg335_1
            assert_size_stride(arg338_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg338_1 = copy_if_misaligned(arg338_1)
            buf431 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_22, sin_22, linear_115, view_58, key_states_19, mul_177, x2_39, neg_39, x1_39, cat_116, mul_178, k_embed_19, cat_117], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg338_1, buf430, arg4_1, arg3_1, arg5_1.item(), buf431, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg338_1
            assert_size_stride_grouped((arg337_1, arg336_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf432 = buf430; del buf430  # reuse
            # Topologically Sorted Source Nodes: [linear_116], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg337_1, reinterpret_tensor(buf428, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg336_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf432)
            del arg336_1
            del arg337_1
            assert_size_stride(arg339_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg339_1 = copy_if_misaligned(arg339_1)
            buf433 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_116, view_59, value_states_19, cat_118], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg339_1, buf432, buf433, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg339_1
            buf434 = reinterpret_tensor(buf428, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf428  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_114, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf429, arg4_1, arg3_1, arg5_1.item(), buf434, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf429
            assert_size_stride(arg340_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg340_1 = copy_if_misaligned(arg340_1)
            buf435 = buf414; del buf414  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_114, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg340_1, buf431, buf435, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg340_1
            assert_size_stride(arg341_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg341_1 = copy_if_misaligned(arg341_1)
            buf436 = buf413; del buf413  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_114, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg341_1, buf433, buf436, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg341_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_114, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf437 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf434, buf435, buf436, None, False, scale=0.08838834764831845)
            buf438 = buf437[0]
            assert_tensor_metadata(buf438, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf438, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf437
            buf442 = buf434; del buf434  # reuse
            # Topologically Sorted Source Nodes: [attn_output_76], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf438, buf442, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg342_1, (1536, 1536), (1536, 1), 'input')
            buf443 = reinterpret_tensor(buf438, (s16, 1536), (1536, 1), 0); del buf438  # reuse
            # Topologically Sorted Source Nodes: [attn_output_76, transpose_80, reshape_59, attn_output_79], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf442, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg342_1, (1536, 1536), (1, 1536), 0), out=buf443)
            del arg342_1
            assert_size_stride_grouped((arg344_1, arg343_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf444 = buf399; del buf399  # reuse
            buf446 = reinterpret_tensor(buf442, (s16, 1, 1536), (1536, 1536, 1), 0); del buf442  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_160, hidden_states_161, attn_output_75, hidden_states_165, hidden_states_169, hidden_states_170, attn_output_79, hidden_states_174, pow_40, variance_39, rsqrt_39, hidden_states_176, hidden_states_177], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf444, buf404, buf421, buf426, buf443, arg344_1, arg343_1.item(), buf446, s16, 1536, stream=raw_stream0)
            del arg343_1
            del arg344_1
            del buf404
            assert_size_stride(arg345_1, (17920, 1536), (1536, 1), 'input')
            buf447 = buf424; del buf424  # reuse
            # Topologically Sorted Source Nodes: [pow_40, variance_39, rsqrt_39, hidden_states_176, hidden_states_177, linear_118], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf446, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg345_1, (1536, 17920), (1, 1536), 0), out=buf447)
            del arg345_1
            buf448 = buf425; del buf425  # reuse
            # Topologically Sorted Source Nodes: [linear_118, split_19, silu_19, mul_181], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf447, buf448, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg346_1, (1536, 8960), (8960, 1), 'input')
            buf449 = reinterpret_tensor(buf446, (s16, 1536), (1536, 1), 0); del buf446  # reuse
            # Topologically Sorted Source Nodes: [linear_118, split_19, silu_19, mul_181, hidden_states_178], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf448, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg346_1, (8960, 1536), (1, 8960), 0), out=buf449)
            del arg346_1
            assert_size_stride_grouped((arg348_1, arg347_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf451 = reinterpret_tensor(buf443, (s16, 1, 1536), (1536, 1536, 1), 0); del buf443  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_178, hidden_states_179, pow_41, variance_40, rsqrt_40, hidden_states_181, hidden_states_182], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf444, buf449, arg348_1, arg347_1.item(), buf451, s16, 1536, stream=raw_stream0)
            del arg347_1
            del arg348_1
            assert_size_stride_grouped((arg350_1, arg349_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf452 = buf426; del buf426  # reuse
            # Topologically Sorted Source Nodes: [linear_120], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg350_1, reinterpret_tensor(buf451, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg349_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf452)
            del arg349_1
            del arg350_1
            assert_size_stride_grouped((arg352_1, arg351_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf453 = buf432; del buf432  # reuse
            # Topologically Sorted Source Nodes: [linear_121], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg352_1, reinterpret_tensor(buf451, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg351_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf453)
            del arg351_1
            del arg352_1
            assert_size_stride(arg355_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg355_1 = copy_if_misaligned(arg355_1)
            buf454 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_23, sin_23, linear_121, view_61, key_states_20, mul_186, x2_41, neg_41, x1_41, cat_122, mul_187, k_embed_20, cat_123], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg355_1, buf453, arg4_1, arg3_1, arg5_1.item(), buf454, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg355_1
            assert_size_stride_grouped((arg354_1, arg353_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf455 = buf453; del buf453  # reuse
            # Topologically Sorted Source Nodes: [linear_122], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg354_1, reinterpret_tensor(buf451, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg353_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf455)
            del arg353_1
            del arg354_1
            assert_size_stride(arg356_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg356_1 = copy_if_misaligned(arg356_1)
            buf456 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_122, view_62, value_states_20, cat_124], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg356_1, buf455, buf456, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg356_1
            buf457 = reinterpret_tensor(buf451, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf451  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_120, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf452, arg4_1, arg3_1, arg5_1.item(), buf457, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg357_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg357_1 = copy_if_misaligned(arg357_1)
            buf458 = buf436; del buf436  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_120, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg357_1, buf454, buf458, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg357_1
            assert_size_stride(arg358_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg358_1 = copy_if_misaligned(arg358_1)
            buf459 = buf435; del buf435  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_120, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg358_1, buf456, buf459, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg358_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_120, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf460 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf457, buf458, buf459, None, False, scale=0.08838834764831845)
            buf461 = buf460[0]
            assert_tensor_metadata(buf461, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf461, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf460
            buf465 = buf457; del buf457  # reuse
            # Topologically Sorted Source Nodes: [attn_output_80], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf461, buf465, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg359_1, (1536, 1536), (1536, 1), 'input')
            buf466 = reinterpret_tensor(buf461, (s16, 1536), (1536, 1), 0); del buf461  # reuse
            # Topologically Sorted Source Nodes: [attn_output_80, transpose_84, reshape_62, attn_output_83], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf465, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg359_1, (1536, 1536), (1, 1536), 0), out=buf466)
            del arg359_1
            assert_size_stride_grouped((arg361_1, arg360_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf468 = reinterpret_tensor(buf465, (s16, 1, 1536), (1536, 1536, 1), 0); del buf465  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_178, hidden_states_179, attn_output_83, hidden_states_183, pow_42, variance_41, rsqrt_41, hidden_states_185, hidden_states_186], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf444, buf449, buf466, arg361_1, arg360_1.item(), buf468, s16, 1536, stream=raw_stream0)
            del arg360_1
            del arg361_1
            assert_size_stride(arg362_1, (17920, 1536), (1536, 1), 'input')
            buf469 = buf447; del buf447  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_178, hidden_states_179, attn_output_83, hidden_states_183, pow_42, variance_41, rsqrt_41, hidden_states_185, hidden_states_186, linear_124], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf468, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg362_1, (1536, 17920), (1, 1536), 0), out=buf469)
            del arg362_1
            buf470 = buf448; del buf448  # reuse
            # Topologically Sorted Source Nodes: [linear_124, split_20, silu_20, mul_190], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf469, buf470, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg363_1, (1536, 8960), (8960, 1), 'input')
            buf471 = reinterpret_tensor(buf468, (s16, 1536), (1536, 1), 0); del buf468  # reuse
            # Topologically Sorted Source Nodes: [linear_124, split_20, silu_20, mul_190, hidden_states_187], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf470, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg363_1, (8960, 1536), (1, 8960), 0), out=buf471)
            del arg363_1
            assert_size_stride_grouped((arg365_1, arg364_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf473 = reinterpret_tensor(buf452, (s16, 1, 1536), (1536, 1536, 1), 0); del buf452  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_178, hidden_states_179, attn_output_83, hidden_states_183, hidden_states_187, hidden_states_188, pow_43, variance_42, rsqrt_42, hidden_states_190, hidden_states_191], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf444, buf449, buf466, buf471, arg365_1, arg364_1.item(), buf473, s16, 1536, stream=raw_stream0)
            del arg364_1
            del arg365_1
            assert_size_stride_grouped((arg367_1, arg366_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf474 = buf421; del buf421  # reuse
            # Topologically Sorted Source Nodes: [linear_126], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg367_1, reinterpret_tensor(buf473, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg366_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf474)
            del arg366_1
            del arg367_1
            assert_size_stride_grouped((arg369_1, arg368_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf475 = buf455; del buf455  # reuse
            # Topologically Sorted Source Nodes: [linear_127], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg369_1, reinterpret_tensor(buf473, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg368_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf475)
            del arg368_1
            del arg369_1
            assert_size_stride(arg372_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg372_1 = copy_if_misaligned(arg372_1)
            buf476 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_24, sin_24, linear_127, view_64, key_states_21, mul_195, x2_43, neg_43, x1_43, cat_128, mul_196, k_embed_21, cat_129], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg372_1, buf475, arg4_1, arg3_1, arg5_1.item(), buf476, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg372_1
            assert_size_stride_grouped((arg371_1, arg370_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf477 = buf475; del buf475  # reuse
            # Topologically Sorted Source Nodes: [linear_128], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg371_1, reinterpret_tensor(buf473, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg370_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf477)
            del arg370_1
            del arg371_1
            assert_size_stride(arg373_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg373_1 = copy_if_misaligned(arg373_1)
            buf478 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_128, view_65, value_states_21, cat_130], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg373_1, buf477, buf478, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg373_1
            buf479 = reinterpret_tensor(buf473, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf473  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf474, arg4_1, arg3_1, arg5_1.item(), buf479, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf474
            assert_size_stride(arg374_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg374_1 = copy_if_misaligned(arg374_1)
            buf480 = buf459; del buf459  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg374_1, buf476, buf480, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg374_1
            assert_size_stride(arg375_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg375_1 = copy_if_misaligned(arg375_1)
            buf481 = buf458; del buf458  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg375_1, buf478, buf481, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg375_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf482 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf479, buf480, buf481, None, False, scale=0.08838834764831845)
            buf483 = buf482[0]
            assert_tensor_metadata(buf483, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf483, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf482
            buf487 = buf479; del buf479  # reuse
            # Topologically Sorted Source Nodes: [attn_output_84], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf483, buf487, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg376_1, (1536, 1536), (1536, 1), 'input')
            buf488 = reinterpret_tensor(buf483, (s16, 1536), (1536, 1), 0); del buf483  # reuse
            # Topologically Sorted Source Nodes: [attn_output_84, transpose_88, reshape_65, attn_output_87], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf487, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg376_1, (1536, 1536), (1, 1536), 0), out=buf488)
            del arg376_1
            assert_size_stride_grouped((arg378_1, arg377_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf489 = buf444; del buf444  # reuse
            buf491 = reinterpret_tensor(buf487, (s16, 1, 1536), (1536, 1536, 1), 0); del buf487  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_178, hidden_states_179, attn_output_83, hidden_states_183, hidden_states_187, hidden_states_188, attn_output_87, hidden_states_192, pow_44, variance_43, rsqrt_43, hidden_states_194, hidden_states_195], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf489, buf449, buf466, buf471, buf488, arg378_1, arg377_1.item(), buf491, s16, 1536, stream=raw_stream0)
            del arg377_1
            del arg378_1
            del buf449
            assert_size_stride(arg379_1, (17920, 1536), (1536, 1), 'input')
            buf492 = buf469; del buf469  # reuse
            # Topologically Sorted Source Nodes: [pow_44, variance_43, rsqrt_43, hidden_states_194, hidden_states_195, linear_130], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf491, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg379_1, (1536, 17920), (1, 1536), 0), out=buf492)
            del arg379_1
            buf493 = buf470; del buf470  # reuse
            # Topologically Sorted Source Nodes: [linear_130, split_21, silu_21, mul_199], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf492, buf493, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg380_1, (1536, 8960), (8960, 1), 'input')
            buf494 = reinterpret_tensor(buf491, (s16, 1536), (1536, 1), 0); del buf491  # reuse
            # Topologically Sorted Source Nodes: [linear_130, split_21, silu_21, mul_199, hidden_states_196], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf493, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg380_1, (8960, 1536), (1, 8960), 0), out=buf494)
            del arg380_1
            assert_size_stride_grouped((arg382_1, arg381_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf496 = reinterpret_tensor(buf488, (s16, 1, 1536), (1536, 1536, 1), 0); del buf488  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, pow_45, variance_44, rsqrt_44, hidden_states_199, hidden_states_200], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf489, buf494, arg382_1, arg381_1.item(), buf496, s16, 1536, stream=raw_stream0)
            del arg381_1
            del arg382_1
            assert_size_stride_grouped((arg384_1, arg383_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf497 = buf471; del buf471  # reuse
            # Topologically Sorted Source Nodes: [linear_132], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg384_1, reinterpret_tensor(buf496, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg383_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf497)
            del arg383_1
            del arg384_1
            assert_size_stride_grouped((arg386_1, arg385_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf498 = buf477; del buf477  # reuse
            # Topologically Sorted Source Nodes: [linear_133], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg386_1, reinterpret_tensor(buf496, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg385_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf498)
            del arg385_1
            del arg386_1
            assert_size_stride(arg389_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg389_1 = copy_if_misaligned(arg389_1)
            buf499 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_25, sin_25, linear_133, view_67, key_states_22, mul_204, x2_45, neg_45, x1_45, cat_134, mul_205, k_embed_22, cat_135], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg389_1, buf498, arg4_1, arg3_1, arg5_1.item(), buf499, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg389_1
            assert_size_stride_grouped((arg388_1, arg387_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf500 = buf498; del buf498  # reuse
            # Topologically Sorted Source Nodes: [linear_134], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg388_1, reinterpret_tensor(buf496, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg387_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf500)
            del arg387_1
            del arg388_1
            assert_size_stride(arg390_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg390_1 = copy_if_misaligned(arg390_1)
            buf501 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_134, view_68, value_states_22, cat_136], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg390_1, buf500, buf501, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg390_1
            buf502 = reinterpret_tensor(buf496, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf496  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_132, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf497, arg4_1, arg3_1, arg5_1.item(), buf502, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg391_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg391_1 = copy_if_misaligned(arg391_1)
            buf503 = buf481; del buf481  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_132, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg391_1, buf499, buf503, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg391_1
            assert_size_stride(arg392_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg392_1 = copy_if_misaligned(arg392_1)
            buf504 = buf480; del buf480  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_132, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg392_1, buf501, buf504, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg392_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_132, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf505 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf502, buf503, buf504, None, False, scale=0.08838834764831845)
            buf506 = buf505[0]
            assert_tensor_metadata(buf506, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf506, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf505
            buf510 = buf502; del buf502  # reuse
            # Topologically Sorted Source Nodes: [attn_output_88], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf506, buf510, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg393_1, (1536, 1536), (1536, 1), 'input')
            buf511 = reinterpret_tensor(buf506, (s16, 1536), (1536, 1), 0); del buf506  # reuse
            # Topologically Sorted Source Nodes: [attn_output_88, transpose_92, reshape_68, attn_output_91], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf510, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg393_1, (1536, 1536), (1, 1536), 0), out=buf511)
            del arg393_1
            assert_size_stride(arg394_1, (1536, ), (1, ), 'input')
            buf513 = reinterpret_tensor(buf510, (s16, 1, 1536), (1536, 1536, 1), 0); del buf510  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, attn_output_91, hidden_states_201, pow_46, variance_45, add_136, rsqrt_45, hidden_states_203, hidden_states_204], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15.run(buf489, buf494, buf511, arg394_1, buf513, s16, 1536, stream=raw_stream0)
            del arg394_1
            assert_size_stride(arg395_1, (17920, 1536), (1536, 1), 'input')
            buf514 = buf492; del buf492  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, attn_output_91, hidden_states_201, pow_46, variance_45, add_136, rsqrt_45, hidden_states_203, hidden_states_204, linear_136], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf513, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg395_1, (1536, 17920), (1, 1536), 0), out=buf514)
            del arg395_1
            buf515 = buf493; del buf493  # reuse
            # Topologically Sorted Source Nodes: [linear_136, split_22, silu_22, mul_208], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf514, buf515, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg396_1, (1536, 8960), (8960, 1), 'input')
            buf516 = reinterpret_tensor(buf513, (s16, 1536), (1536, 1), 0); del buf513  # reuse
            # Topologically Sorted Source Nodes: [linear_136, split_22, silu_22, mul_208, hidden_states_205], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf515, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg396_1, (8960, 1536), (1, 8960), 0), out=buf516)
            del arg396_1
            assert_size_stride_grouped((arg398_1, arg397_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf518 = reinterpret_tensor(buf497, (s16, 1, 1536), (1536, 1536, 1), 0); del buf497  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, attn_output_91, hidden_states_201, hidden_states_205, hidden_states_206, pow_47, variance_46, rsqrt_46, hidden_states_208, hidden_states_209], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf489, buf494, buf511, buf516, arg398_1, arg397_1.item(), buf518, s16, 1536, stream=raw_stream0)
            del arg397_1
            del arg398_1
            assert_size_stride_grouped((arg400_1, arg399_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf519 = buf466; del buf466  # reuse
            # Topologically Sorted Source Nodes: [linear_138], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg400_1, reinterpret_tensor(buf518, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg399_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf519)
            del arg399_1
            del arg400_1
            assert_size_stride_grouped((arg402_1, arg401_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf520 = buf500; del buf500  # reuse
            # Topologically Sorted Source Nodes: [linear_139], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg402_1, reinterpret_tensor(buf518, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg401_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf520)
            del arg401_1
            del arg402_1
            assert_size_stride(arg405_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg405_1 = copy_if_misaligned(arg405_1)
            buf521 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_26, sin_26, linear_139, view_70, key_states_23, mul_213, x2_47, neg_47, x1_47, cat_140, mul_214, k_embed_23, cat_141], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg405_1, buf520, arg4_1, arg3_1, arg5_1.item(), buf521, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg405_1
            assert_size_stride_grouped((arg404_1, arg403_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf522 = buf520; del buf520  # reuse
            # Topologically Sorted Source Nodes: [linear_140], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg404_1, reinterpret_tensor(buf518, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg403_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf522)
            del arg403_1
            del arg404_1
            assert_size_stride(arg406_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg406_1 = copy_if_misaligned(arg406_1)
            buf523 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_140, view_71, value_states_23, cat_142], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg406_1, buf522, buf523, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg406_1
            buf524 = reinterpret_tensor(buf518, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf518  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_138, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf519, arg4_1, arg3_1, arg5_1.item(), buf524, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf519
            assert_size_stride(arg407_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg407_1 = copy_if_misaligned(arg407_1)
            buf525 = buf504; del buf504  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_138, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg407_1, buf521, buf525, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg407_1
            assert_size_stride(arg408_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg408_1 = copy_if_misaligned(arg408_1)
            buf526 = buf503; del buf503  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_138, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg408_1, buf523, buf526, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg408_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_138, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf527 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf524, buf525, buf526, None, False, scale=0.08838834764831845)
            buf528 = buf527[0]
            assert_tensor_metadata(buf528, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf528, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf527
            buf532 = buf524; del buf524  # reuse
            # Topologically Sorted Source Nodes: [attn_output_92], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf528, buf532, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg409_1, (1536, 1536), (1536, 1), 'input')
            buf533 = reinterpret_tensor(buf528, (s16, 1536), (1536, 1), 0); del buf528  # reuse
            # Topologically Sorted Source Nodes: [attn_output_92, transpose_96, reshape_71, attn_output_95], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf532, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg409_1, (1536, 1536), (1, 1536), 0), out=buf533)
            del arg409_1
            assert_size_stride_grouped((arg411_1, arg410_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf534 = buf489; del buf489  # reuse
            buf536 = reinterpret_tensor(buf532, (s16, 1, 1536), (1536, 1536, 1), 0); del buf532  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, attn_output_91, hidden_states_201, hidden_states_205, hidden_states_206, attn_output_95, hidden_states_210, pow_48, variance_47, rsqrt_47, hidden_states_212, hidden_states_213], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf534, buf494, buf511, buf516, buf533, arg411_1, arg410_1.item(), buf536, s16, 1536, stream=raw_stream0)
            del arg410_1
            del arg411_1
            del buf494
            assert_size_stride(arg412_1, (17920, 1536), (1536, 1), 'input')
            buf537 = buf514; del buf514  # reuse
            # Topologically Sorted Source Nodes: [pow_48, variance_47, rsqrt_47, hidden_states_212, hidden_states_213, linear_142], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf536, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg412_1, (1536, 17920), (1, 1536), 0), out=buf537)
            del arg412_1
            buf538 = buf515; del buf515  # reuse
            # Topologically Sorted Source Nodes: [linear_142, split_23, silu_23, mul_217], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf537, buf538, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg413_1, (1536, 8960), (8960, 1), 'input')
            buf539 = reinterpret_tensor(buf536, (s16, 1536), (1536, 1), 0); del buf536  # reuse
            # Topologically Sorted Source Nodes: [linear_142, split_23, silu_23, mul_217, hidden_states_214], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf538, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg413_1, (8960, 1536), (1, 8960), 0), out=buf539)
            del arg413_1
            assert_size_stride_grouped((arg415_1, arg414_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf541 = reinterpret_tensor(buf533, (s16, 1, 1536), (1536, 1536, 1), 0); del buf533  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_214, hidden_states_215, pow_49, variance_48, rsqrt_48, hidden_states_217, hidden_states_218], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf534, buf539, arg415_1, arg414_1.item(), buf541, s16, 1536, stream=raw_stream0)
            del arg414_1
            del arg415_1
            assert_size_stride_grouped((arg417_1, arg416_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf542 = buf516; del buf516  # reuse
            # Topologically Sorted Source Nodes: [linear_144], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg417_1, reinterpret_tensor(buf541, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg416_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf542)
            del arg416_1
            del arg417_1
            assert_size_stride_grouped((arg419_1, arg418_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf543 = buf522; del buf522  # reuse
            # Topologically Sorted Source Nodes: [linear_145], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg419_1, reinterpret_tensor(buf541, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg418_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf543)
            del arg418_1
            del arg419_1
            assert_size_stride(arg422_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg422_1 = copy_if_misaligned(arg422_1)
            buf544 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_27, sin_27, linear_145, view_73, key_states_24, mul_222, x2_49, neg_49, x1_49, cat_146, mul_223, k_embed_24, cat_147], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg422_1, buf543, arg4_1, arg3_1, arg5_1.item(), buf544, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg422_1
            assert_size_stride_grouped((arg421_1, arg420_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf545 = buf543; del buf543  # reuse
            # Topologically Sorted Source Nodes: [linear_146], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg421_1, reinterpret_tensor(buf541, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg420_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf545)
            del arg420_1
            del arg421_1
            assert_size_stride(arg423_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg423_1 = copy_if_misaligned(arg423_1)
            buf546 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_146, view_74, value_states_24, cat_148], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg423_1, buf545, buf546, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg423_1
            buf547 = reinterpret_tensor(buf541, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf541  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_144, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf542, arg4_1, arg3_1, arg5_1.item(), buf547, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg424_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg424_1 = copy_if_misaligned(arg424_1)
            buf548 = buf526; del buf526  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_144, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg424_1, buf544, buf548, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg424_1
            assert_size_stride(arg425_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg425_1 = copy_if_misaligned(arg425_1)
            buf549 = buf525; del buf525  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_144, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg425_1, buf546, buf549, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg425_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_144, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf550 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf547, buf548, buf549, None, False, scale=0.08838834764831845)
            buf551 = buf550[0]
            assert_tensor_metadata(buf551, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf551, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf550
            buf555 = buf547; del buf547  # reuse
            # Topologically Sorted Source Nodes: [attn_output_96], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf551, buf555, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg426_1, (1536, 1536), (1536, 1), 'input')
            buf556 = reinterpret_tensor(buf551, (s16, 1536), (1536, 1), 0); del buf551  # reuse
            # Topologically Sorted Source Nodes: [attn_output_96, transpose_100, reshape_74, attn_output_99], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf555, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg426_1, (1536, 1536), (1, 1536), 0), out=buf556)
            del arg426_1
            assert_size_stride_grouped((arg428_1, arg427_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf558 = reinterpret_tensor(buf555, (s16, 1, 1536), (1536, 1536, 1), 0); del buf555  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_214, hidden_states_215, attn_output_99, hidden_states_219, pow_50, variance_49, rsqrt_49, hidden_states_221, hidden_states_222], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf534, buf539, buf556, arg428_1, arg427_1.item(), buf558, s16, 1536, stream=raw_stream0)
            del arg427_1
            del arg428_1
            assert_size_stride(arg429_1, (17920, 1536), (1536, 1), 'input')
            buf559 = buf537; del buf537  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_214, hidden_states_215, attn_output_99, hidden_states_219, pow_50, variance_49, rsqrt_49, hidden_states_221, hidden_states_222, linear_148], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf558, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg429_1, (1536, 17920), (1, 1536), 0), out=buf559)
            del arg429_1
            buf560 = buf538; del buf538  # reuse
            # Topologically Sorted Source Nodes: [linear_148, split_24, silu_24, mul_226], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf559, buf560, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg430_1, (1536, 8960), (8960, 1), 'input')
            buf561 = reinterpret_tensor(buf558, (s16, 1536), (1536, 1), 0); del buf558  # reuse
            # Topologically Sorted Source Nodes: [linear_148, split_24, silu_24, mul_226, hidden_states_223], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf560, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg430_1, (8960, 1536), (1, 8960), 0), out=buf561)
            del arg430_1
            assert_size_stride_grouped((arg432_1, arg431_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf563 = reinterpret_tensor(buf542, (s16, 1, 1536), (1536, 1536, 1), 0); del buf542  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_214, hidden_states_215, attn_output_99, hidden_states_219, hidden_states_223, hidden_states_224, pow_51, variance_50, rsqrt_50, hidden_states_226, hidden_states_227], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf534, buf539, buf556, buf561, arg432_1, arg431_1.item(), buf563, s16, 1536, stream=raw_stream0)
            del arg431_1
            del arg432_1
            assert_size_stride_grouped((arg434_1, arg433_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf564 = buf511; del buf511  # reuse
            # Topologically Sorted Source Nodes: [linear_150], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg434_1, reinterpret_tensor(buf563, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg433_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf564)
            del arg433_1
            del arg434_1
            assert_size_stride_grouped((arg436_1, arg435_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf565 = buf545; del buf545  # reuse
            # Topologically Sorted Source Nodes: [linear_151], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg436_1, reinterpret_tensor(buf563, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg435_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf565)
            del arg435_1
            del arg436_1
            assert_size_stride(arg439_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg439_1 = copy_if_misaligned(arg439_1)
            buf566 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_28, sin_28, linear_151, view_76, key_states_25, mul_231, x2_51, neg_51, x1_51, cat_152, mul_232, k_embed_25, cat_153], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg439_1, buf565, arg4_1, arg3_1, arg5_1.item(), buf566, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg439_1
            assert_size_stride_grouped((arg438_1, arg437_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf567 = buf565; del buf565  # reuse
            # Topologically Sorted Source Nodes: [linear_152], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg438_1, reinterpret_tensor(buf563, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg437_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf567)
            del arg437_1
            del arg438_1
            assert_size_stride(arg440_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg440_1 = copy_if_misaligned(arg440_1)
            buf568 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_152, view_77, value_states_25, cat_154], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg440_1, buf567, buf568, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg440_1
            buf569 = reinterpret_tensor(buf563, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf563  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_150, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf564, arg4_1, arg3_1, arg5_1.item(), buf569, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf564
            assert_size_stride(arg441_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg441_1 = copy_if_misaligned(arg441_1)
            buf570 = buf549; del buf549  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_150, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg441_1, buf566, buf570, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg441_1
            assert_size_stride(arg442_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg442_1 = copy_if_misaligned(arg442_1)
            buf571 = buf548; del buf548  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_150, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg442_1, buf568, buf571, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg442_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_150, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf572 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf569, buf570, buf571, None, False, scale=0.08838834764831845)
            buf573 = buf572[0]
            assert_tensor_metadata(buf573, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf573, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf572
            buf577 = buf569; del buf569  # reuse
            # Topologically Sorted Source Nodes: [attn_output_100], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf573, buf577, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg443_1, (1536, 1536), (1536, 1), 'input')
            buf578 = reinterpret_tensor(buf573, (s16, 1536), (1536, 1), 0); del buf573  # reuse
            # Topologically Sorted Source Nodes: [attn_output_100, transpose_104, reshape_77, attn_output_103], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf577, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg443_1, (1536, 1536), (1, 1536), 0), out=buf578)
            del arg443_1
            assert_size_stride_grouped((arg445_1, arg444_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf579 = buf534; del buf534  # reuse
            buf581 = reinterpret_tensor(buf577, (s16, 1, 1536), (1536, 1536, 1), 0); del buf577  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_214, hidden_states_215, attn_output_99, hidden_states_219, hidden_states_223, hidden_states_224, attn_output_103, hidden_states_228, pow_52, variance_51, rsqrt_51, hidden_states_230, hidden_states_231], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf579, buf539, buf556, buf561, buf578, arg445_1, arg444_1.item(), buf581, s16, 1536, stream=raw_stream0)
            del arg444_1
            del arg445_1
            del buf539
            assert_size_stride(arg446_1, (17920, 1536), (1536, 1), 'input')
            buf582 = buf559; del buf559  # reuse
            # Topologically Sorted Source Nodes: [pow_52, variance_51, rsqrt_51, hidden_states_230, hidden_states_231, linear_154], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf581, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg446_1, (1536, 17920), (1, 1536), 0), out=buf582)
            del arg446_1
            buf583 = buf560; del buf560  # reuse
            # Topologically Sorted Source Nodes: [linear_154, split_25, silu_25, mul_235], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf582, buf583, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg447_1, (1536, 8960), (8960, 1), 'input')
            buf584 = reinterpret_tensor(buf581, (s16, 1536), (1536, 1), 0); del buf581  # reuse
            # Topologically Sorted Source Nodes: [linear_154, split_25, silu_25, mul_235, hidden_states_232], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf583, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg447_1, (8960, 1536), (1, 8960), 0), out=buf584)
            del arg447_1
            assert_size_stride_grouped((arg449_1, arg448_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf586 = reinterpret_tensor(buf578, (s16, 1, 1536), (1536, 1536, 1), 0); del buf578  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_232, hidden_states_233, pow_53, variance_52, rsqrt_52, hidden_states_235, hidden_states_236], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf579, buf584, arg449_1, arg448_1.item(), buf586, s16, 1536, stream=raw_stream0)
            del arg448_1
            del arg449_1
            assert_size_stride_grouped((arg451_1, arg450_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf587 = buf561; del buf561  # reuse
            # Topologically Sorted Source Nodes: [linear_156], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg451_1, reinterpret_tensor(buf586, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg450_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf587)
            del arg450_1
            del arg451_1
            assert_size_stride_grouped((arg453_1, arg452_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf588 = buf567; del buf567  # reuse
            # Topologically Sorted Source Nodes: [linear_157], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg453_1, reinterpret_tensor(buf586, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg452_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf588)
            del arg452_1
            del arg453_1
            assert_size_stride(arg456_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg456_1 = copy_if_misaligned(arg456_1)
            buf589 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_29, sin_29, linear_157, view_79, key_states_26, mul_240, x2_53, neg_53, x1_53, cat_158, mul_241, k_embed_26, cat_159], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg456_1, buf588, arg4_1, arg3_1, arg5_1.item(), buf589, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg456_1
            assert_size_stride_grouped((arg455_1, arg454_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf590 = buf588; del buf588  # reuse
            # Topologically Sorted Source Nodes: [linear_158], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg455_1, reinterpret_tensor(buf586, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg454_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf590)
            del arg454_1
            del arg455_1
            assert_size_stride(arg457_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg457_1 = copy_if_misaligned(arg457_1)
            buf591 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_158, view_80, value_states_26, cat_160], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg457_1, buf590, buf591, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg457_1
            buf592 = reinterpret_tensor(buf586, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf586  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_156, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf587, arg4_1, arg3_1, arg5_1.item(), buf592, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg458_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg458_1 = copy_if_misaligned(arg458_1)
            buf593 = buf571; del buf571  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_156, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg458_1, buf589, buf593, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg458_1
            assert_size_stride(arg459_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg459_1 = copy_if_misaligned(arg459_1)
            buf594 = buf570; del buf570  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_156, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg459_1, buf591, buf594, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg459_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_156, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf595 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf592, buf593, buf594, None, False, scale=0.08838834764831845)
            buf596 = buf595[0]
            assert_tensor_metadata(buf596, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf596, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf595
            buf600 = buf592; del buf592  # reuse
            # Topologically Sorted Source Nodes: [attn_output_104], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf596, buf600, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg460_1, (1536, 1536), (1536, 1), 'input')
            buf601 = reinterpret_tensor(buf596, (s16, 1536), (1536, 1), 0); del buf596  # reuse
            # Topologically Sorted Source Nodes: [attn_output_104, transpose_108, reshape_80, attn_output_107], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf600, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg460_1, (1536, 1536), (1, 1536), 0), out=buf601)
            del arg460_1
            assert_size_stride_grouped((arg462_1, arg461_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf603 = reinterpret_tensor(buf600, (s16, 1, 1536), (1536, 1536, 1), 0); del buf600  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_232, hidden_states_233, attn_output_107, hidden_states_237, pow_54, variance_53, rsqrt_53, hidden_states_239, hidden_states_240], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf579, buf584, buf601, arg462_1, arg461_1.item(), buf603, s16, 1536, stream=raw_stream0)
            del arg461_1
            del arg462_1
            assert_size_stride(arg463_1, (17920, 1536), (1536, 1), 'input')
            buf604 = buf582; del buf582  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_232, hidden_states_233, attn_output_107, hidden_states_237, pow_54, variance_53, rsqrt_53, hidden_states_239, hidden_states_240, linear_160], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf603, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg463_1, (1536, 17920), (1, 1536), 0), out=buf604)
            del arg463_1
            buf605 = buf583; del buf583  # reuse
            # Topologically Sorted Source Nodes: [linear_160, split_26, silu_26, mul_244], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf604, buf605, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg464_1, (1536, 8960), (8960, 1), 'input')
            buf606 = reinterpret_tensor(buf603, (s16, 1536), (1536, 1), 0); del buf603  # reuse
            # Topologically Sorted Source Nodes: [linear_160, split_26, silu_26, mul_244, hidden_states_241], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf605, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg464_1, (8960, 1536), (1, 8960), 0), out=buf606)
            del arg464_1
            assert_size_stride_grouped((arg466_1, arg465_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf608 = reinterpret_tensor(buf587, (s16, 1, 1536), (1536, 1536, 1), 0); del buf587  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_232, hidden_states_233, attn_output_107, hidden_states_237, hidden_states_241, hidden_states_242, pow_55, variance_54, rsqrt_54, hidden_states_244, hidden_states_245], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf579, buf584, buf601, buf606, arg466_1, arg465_1.item(), buf608, s16, 1536, stream=raw_stream0)
            del arg465_1
            del arg466_1
            assert_size_stride_grouped((arg468_1, arg467_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf609 = buf556; del buf556  # reuse
            # Topologically Sorted Source Nodes: [linear_162], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg468_1, reinterpret_tensor(buf608, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg467_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf609)
            del arg467_1
            del arg468_1
            assert_size_stride_grouped((arg470_1, arg469_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf610 = buf590; del buf590  # reuse
            # Topologically Sorted Source Nodes: [linear_163], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg470_1, reinterpret_tensor(buf608, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg469_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf610)
            del arg469_1
            del arg470_1
            assert_size_stride(arg473_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg473_1 = copy_if_misaligned(arg473_1)
            buf611 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_30, sin_30, linear_163, view_82, key_states_27, mul_249, x2_55, neg_55, x1_55, cat_164, mul_250, k_embed_27, cat_165], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg473_1, buf610, arg4_1, arg3_1, arg5_1.item(), buf611, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg473_1
            assert_size_stride_grouped((arg472_1, arg471_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf612 = buf610; del buf610  # reuse
            # Topologically Sorted Source Nodes: [linear_164], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg472_1, reinterpret_tensor(buf608, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg471_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf612)
            del arg471_1
            del arg472_1
            assert_size_stride(arg474_1, (s16, 2, 1, 128), (256, 128, 128, 1), 'input')
            arg474_1 = copy_if_misaligned(arg474_1)
            buf613 = empty_strided_cuda((s16, 2, 2, 128), (512, 256, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_164, view_83, value_states_27, cat_166], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 512*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg474_1, buf612, buf613, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg474_1
            del buf612
            buf614 = reinterpret_tensor(buf608, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf608  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_162, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf609, arg4_1, arg3_1, arg5_1.item(), buf614, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg3_1
            del arg4_1
            del arg5_1
            del buf609
            assert_size_stride(arg475_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg475_1 = copy_if_misaligned(arg475_1)
            buf615 = buf594; del buf594  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_162, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg475_1, buf611, buf615, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg475_1
            assert_size_stride(arg476_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg476_1 = copy_if_misaligned(arg476_1)
            buf616 = buf593; del buf593  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_162, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 512*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg476_1, buf613, buf616, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg476_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_162, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf617 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf614, buf615, buf616, None, False, scale=0.08838834764831845)
            del buf615
            del buf616
            buf618 = buf617[0]
            assert_tensor_metadata(buf618, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf618, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf617
            buf622 = buf614; del buf614  # reuse
            # Topologically Sorted Source Nodes: [attn_output_108], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf618, buf622, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg477_1, (1536, 1536), (1536, 1), 'input')
            buf623 = reinterpret_tensor(buf618, (s16, 1536), (1536, 1), 0); del buf618  # reuse
            # Topologically Sorted Source Nodes: [attn_output_108, transpose_112, reshape_83, attn_output_111], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf622, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg477_1, (1536, 1536), (1, 1536), 0), out=buf623)
            del arg477_1
            assert_size_stride_grouped((arg479_1, arg478_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf624 = buf579; del buf579  # reuse
            buf626 = reinterpret_tensor(buf622, (s16, 1, 1536), (1536, 1536, 1), 0); del buf622  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_232, hidden_states_233, attn_output_107, hidden_states_237, hidden_states_241, hidden_states_242, attn_output_111, hidden_states_246, pow_56, variance_55, rsqrt_55, hidden_states_248, hidden_states_249], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf624, buf584, buf601, buf606, buf623, arg479_1, arg478_1.item(), buf626, s16, 1536, stream=raw_stream0)
            del arg478_1
            del arg479_1
            del buf584
            del buf601
            del buf606
            del buf623
            assert_size_stride(arg480_1, (17920, 1536), (1536, 1), 'input')
            buf627 = buf604; del buf604  # reuse
            # Topologically Sorted Source Nodes: [pow_56, variance_55, rsqrt_55, hidden_states_248, hidden_states_249, linear_166], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf626, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg480_1, (1536, 17920), (1, 1536), 0), out=buf627)
            del arg480_1
            buf628 = buf605; del buf605  # reuse
            # Topologically Sorted Source Nodes: [linear_166, split_27, silu_27, mul_253], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_7.run(buf627, buf628, triton_poi_fused__unsafe_view_mul_silu_split_7_xnumel, stream=raw_stream0)
            del buf627
            assert_size_stride(arg481_1, (1536, 8960), (8960, 1), 'input')
            buf629 = reinterpret_tensor(buf626, (s16, 1536), (1536, 1), 0); del buf626  # reuse
            # Topologically Sorted Source Nodes: [linear_166, split_27, silu_27, mul_253, hidden_states_250], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf628, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg481_1, (8960, 1536), (1, 8960), 0), out=buf629)
            del arg481_1
            del buf628
            assert_size_stride(arg482_1, (1536, ), (1, ), 'input')
            buf631 = reinterpret_tensor(buf624, (s16, 1, 1536), (1536, 1536, 1), 0); del buf624  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_250, hidden_states_251, pow_57, variance_56, add_168, rsqrt_56, hidden_states_253, hidden_states_254], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_16.run(buf631, buf629, arg482_1, s16, 1536, stream=raw_stream0)
            del arg482_1
            del buf629
            buf632 = empty_strided_cuda((s16, 152265), (152265, 1), torch.float32)
            # Topologically Sorted Source Nodes: [hidden_states_250, hidden_states_251, pow_57, variance_56, add_168, rsqrt_56, hidden_states_253, hidden_states_254, getitem_2020, logits], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.slice, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf631, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg2_1, (1536, 152265), (1, 1536), 0), out=buf632)
            del arg2_1
            del buf631
        return (buf6, buf4, buf28, buf26, buf51, buf49, buf73, buf71, buf96, buf94, buf118, buf116, buf141, buf139, buf163, buf161, buf186, buf184, buf208, buf206, buf231, buf229, buf253, buf251, buf276, buf274, buf298, buf296, buf321, buf319, buf343, buf341, buf366, buf364, buf388, buf386, buf411, buf409, buf433, buf431, buf456, buf454, buf478, buf476, buf501, buf499, buf523, buf521, buf546, buf544, buf568, buf566, buf591, buf589, buf613, buf611, reinterpret_tensor(buf632, (s16, 1, 152265), (152265, 152265, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = 50
    arg1_1 = rand_strided((50, 1), (1, 1), device='cuda:0', dtype=torch.int64)
    arg2_1 = rand_strided((152265, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg3_1 = rand_strided((50, 1), (1, 1), device='cuda:0', dtype=torch.int64)
    arg4_1 = rand_strided((64, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg5_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg6_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg7_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg8_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg9_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg10_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg11_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg12_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg13_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg14_1 = 50
    arg15_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg16_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg17_1 = 76
    arg18_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg19_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg20_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg21_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg22_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg23_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg24_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg25_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg26_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg27_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg28_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg29_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg30_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg31_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg32_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg33_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg34_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg35_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg36_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg37_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg38_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg39_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg40_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg41_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg42_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg43_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg44_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg45_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg46_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg47_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg48_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg49_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg50_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg51_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg52_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg53_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg54_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg55_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg56_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg57_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg58_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg59_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg60_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg61_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg62_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg63_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg64_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg65_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg66_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg67_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg68_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg69_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg70_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg71_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg72_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg73_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg74_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg75_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg76_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg77_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg78_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg79_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg80_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg81_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg82_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg83_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg84_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg85_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg86_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg87_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg88_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg89_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg90_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg91_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg92_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg93_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg94_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg95_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg96_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg97_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg98_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg99_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg100_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg101_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg102_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg103_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg104_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg105_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg106_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg107_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg108_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg109_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg110_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg111_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg112_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg113_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg114_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg115_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg116_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg117_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg118_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg119_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg120_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg121_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg122_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg123_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg124_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg125_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg126_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg127_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg128_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg129_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg130_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg131_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg132_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg133_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg134_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg135_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg136_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg137_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg138_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg139_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg140_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg141_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg142_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg143_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg144_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg145_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg146_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg147_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg148_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg149_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg150_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg151_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg152_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg153_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg154_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg155_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg156_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg157_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg158_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg159_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg160_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg161_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg162_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg163_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg164_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg165_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg166_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg167_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg168_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg169_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg170_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg171_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg172_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg173_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg174_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg175_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg176_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg177_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg178_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg179_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg180_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg181_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg182_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg183_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg184_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg185_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg186_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg187_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg188_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg189_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg190_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg191_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg192_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg193_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg194_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg195_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg196_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg197_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg198_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg199_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg200_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg201_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg202_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg203_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg204_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg205_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg206_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg207_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg208_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg209_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg210_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg211_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg212_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg213_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg214_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg215_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg216_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg217_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg218_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg219_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg220_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg221_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg222_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg223_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg224_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg225_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg226_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg227_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg228_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg229_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg230_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg231_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg232_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg233_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg234_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg235_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg236_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg237_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg238_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg239_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg240_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg241_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg242_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg243_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg244_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg245_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg246_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg247_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg248_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg249_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg250_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg251_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg252_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg253_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg254_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg255_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg256_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg257_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg258_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg259_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg260_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg261_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg262_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg263_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg264_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg265_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg266_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg267_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg268_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg269_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg270_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg271_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg272_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg273_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg274_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg275_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg276_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg277_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg278_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg279_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg280_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg281_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg282_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg283_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg284_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg285_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg286_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg287_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg288_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg289_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg290_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg291_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg292_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg293_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg294_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg295_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg296_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg297_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg298_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg299_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg300_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg301_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg302_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg303_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg304_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg305_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg306_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg307_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg308_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg309_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg310_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg311_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg312_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg313_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg314_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg315_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg316_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg317_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg318_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg319_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg320_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg321_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg322_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg323_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg324_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg325_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg326_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg327_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg328_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg329_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg330_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg331_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg332_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg333_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg334_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg335_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg336_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg337_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg338_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg339_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg340_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg341_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg342_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg343_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg344_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg345_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg346_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg347_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg348_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg349_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg350_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg351_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg352_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg353_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg354_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg355_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg356_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg357_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg358_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg359_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg360_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg361_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg362_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg363_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg364_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg365_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg366_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg367_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg368_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg369_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg370_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg371_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg372_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg373_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg374_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg375_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg376_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg377_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg378_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg379_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg380_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg381_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg382_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg383_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg384_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg385_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg386_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg387_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg388_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg389_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg390_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg391_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg392_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg393_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg394_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg395_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg396_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg397_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg398_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg399_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg400_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg401_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg402_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg403_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg404_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg405_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg406_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg407_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg408_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg409_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg410_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg411_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg412_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg413_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg414_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg415_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg416_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg417_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg418_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg419_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg420_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg421_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg422_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg423_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg424_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg425_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg426_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg427_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg428_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg429_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg430_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg431_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg432_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg433_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg434_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg435_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg436_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg437_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg438_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg439_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg440_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg441_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg442_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg443_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg444_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg445_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg446_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg447_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg448_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg449_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg450_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg451_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg452_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg453_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg454_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg455_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg456_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg457_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg458_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg459_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg460_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg461_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg462_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg463_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg464_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg465_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg466_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg467_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg468_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg469_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg470_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg471_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg472_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg473_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg474_1 = rand_strided((50, 2, 1, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg475_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg476_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg477_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg478_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg479_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg480_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg481_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg482_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg483_1 = 1
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1, arg458_1, arg459_1, arg460_1, arg461_1, arg462_1, arg463_1, arg464_1, arg465_1, arg466_1, arg467_1, arg468_1, arg469_1, arg470_1, arg471_1, arg472_1, arg473_1, arg474_1, arg475_1, arg476_1, arg477_1, arg478_1, arg479_1, arg480_1, arg481_1, arg482_1, arg483_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
