# AOT ID: ['3_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
from torch._inductor.runtime.runtime_utils import assert_tensor_metadata

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/ck/cckvoeogtkik3fvabh6wpahgnd7vvfo7wgbirhk4tknbhnscvv2v.py
# Topologically Sorted Source Nodes: [inputs_embeds, pow_1, variance, rsqrt, hidden_states_1, hidden_states_2], Original ATen: [aten.embedding, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   hidden_states_1 => mul_44
#   hidden_states_2 => mul_47
#   inputs_embeds => embedding
#   pow_1 => pow_1
#   rsqrt => rsqrt
#   variance => mean
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %arg7_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg7_1]
#   %buf0 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf0]
#   %arg6_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg6_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %pow_1 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%embedding, 2), kwargs = {})
#   %mean : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %convert_element_type_default_4 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg6_1, torch.float32), kwargs = {})
#   %add_tensor : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, %convert_element_type_default_4), kwargs = {})
#   %rsqrt : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor,), kwargs = {})
#   %mul_44 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%embedding, %rsqrt), kwargs = {})
#   %mul_47 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg7_1, %mul_44), kwargs = {})
#   return %buf0,%mul_47
triton_red_fused_embedding_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_red_fused_embedding_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_embedding_mean_mul_pow_rsqrt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 620544}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_embedding_mean_mul_pow_rsqrt_0(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    tmp12 = in_ptr3
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp9 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tl.full([1, 1], 1536.0, tl.float32)
        tmp11 = (tmp5 / tmp10)
        tmp13 = tmp12.to(tl.float32)
        tmp14 = tmp11 + tmp13
        tmp15 = libdevice.rsqrt(tmp14)
        tmp16 = tmp9 * tmp15
        tmp17 = tmp7 * tmp16
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp17, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/5t/c5tuhgcddtxbn4pmzr4bf6uhzcvfm5yqygs3tudhruibp2wasd7x.py
# Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, sin, sin_3, linear_1, view_1, key_states, mul_6, x2_1, neg_1, x1_1, cat_2, mul_7, k_embed, key_tensors], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
# Source node to ATen node mapping:
#   cat_2 => cat_1
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   k_embed => add_216
#   key_states => permute_4
#   key_tensors => cat_2
#   linear_1 => view_8
#   matmul => mul_14
#   mul_6 => mul_103
#   mul_7 => mul_114
#   neg_1 => neg_1
#   position_ids_expanded => convert_element_type
#   sin => sin
#   sin_3 => unsqueeze_5
#   view_1 => view_9
#   x1_1 => slice_4
#   x2_1 => slice_5
# Graph fragment:
#   %arg16_1 : Tensor "f32[s16, 2, s53, 128][256*s53, 128*s53, 128, 1]cuda:0" = PlaceHolder[target=arg16_1]
#   %addmm_1 : Tensor "f32[s16, 256][256, 1]cuda:0" = PlaceHolder[target=addmm_1]
#   %arg4_1 : Tensor "f32[64][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %arg3_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg3_1]
#   %arg5_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg5_1]
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %view_8 : Tensor "f32[s16, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_1, [%arg14_1, 1, 256]), kwargs = {})
#   %view_9 : Tensor "f32[s16, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_8, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_4 : Tensor "f32[s16, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_9, [0, 2, 1, 3]), kwargs = {})
#   %mul_103 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_4, %unsqueeze_4), kwargs = {})
#   %slice_5 : Tensor "f32[s16, 2, 1, 64][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_4, 3, 64, 9223372036854775807), kwargs = {})
#   %neg_1 : Tensor "f32[s16, 2, 1, 64][128, 64, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_5,), kwargs = {})
#   %slice_4 : Tensor "f32[s16, 2, 1, 64][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_4, 3, 0, 64), kwargs = {})
#   %cat_1 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %slice_4], -1), kwargs = {})
#   %mul_114 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %unsqueeze_5), kwargs = {})
#   %add_216 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_103, %mul_114), kwargs = {})
#   %cat_2 : Tensor "f32[s16, 2, s53 + 1, 128][256*s53 + 256, 128*s53 + 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.cat.default](args = ([%arg16_1, %add_216], -2), kwargs = {})
#   return %cat_2
triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1 = async_compile.triton('triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*i64', 'in_ptr4': 'fp64', 'out_ptr0': '*fp32', 'ks0': 'i64', 'ks1': 'i64', 'ks2': 'i64', 'ks3': 'i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 11930256}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr0, ks0, ks1, ks2, ks3, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = ((xindex // 128) % ks0)
    x0 = (xindex % 128)
    x4 = xindex // ks2
    x5 = xindex
    x3 = xindex // ks3
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x1).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = (ks1).to(tl.int64)
    tmp6 = (tmp5).to(tl.int64)
    tmp7 = tmp4 < tmp6
    tmp8 = tl.load(in_ptr0 + (x0 + 128*(x1) + 128*ks1*x4), tmp7 & xmask, eviction_policy='evict_last', other=0.0)
    tmp9 = (ks1).to(tl.int32)
    tmp10 = tmp0 >= tmp9
    tmp11 = (ks0).to(tl.int32)
    tmp12 = tmp0 < tmp11
    tmp13 = tl.load(in_ptr1 + (x0 + 128*x4), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp14 = tl.load(in_ptr2 + ((x5 % 64)), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp15 = tl.load(in_ptr3 + (x3), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp16 = tmp15.to(tl.float32)
    tmp17 = tmp14 * tmp16
    tmp18 = tl_math.cos(tmp17)
    tmp19 = in_ptr4
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp18 * tmp20
    tmp22 = tmp13 * tmp21
    tmp23 = (x0).to(tl.int32)
    tmp24 = tl.full([1], 0, tl.int64)
    tmp25 = tmp23 >= tmp24
    tmp26 = (x0).to(tl.int64)
    tmp27 = (tmp26).to(tl.int64)
    tmp28 = tl.full([1], 64, tl.int64)
    tmp29 = tmp27 < tmp28
    tmp30 = tmp29 & tmp10
    tmp31 = tl.load(in_ptr1 + (64 + 128*x4 + (x0)), tmp30 & xmask, eviction_policy='evict_last', other=0.0)
    tmp32 = -tmp31
    tmp33 = tl.full(tmp32.shape, 0.0, tmp32.dtype)
    tmp34 = tl.where(tmp30, tmp32, tmp33)
    tmp35 = tmp23 >= tmp28
    tmp36 = tl.full([1], 128, tl.int64)
    tmp37 = tmp23 < tmp36
    tmp38 = tmp35 & tmp10
    tmp39 = tl.load(in_ptr1 + (128*x4 + ((-64) + x0)), tmp38 & xmask, eviction_policy='evict_last', other=0.0)
    tmp40 = tl.where(tmp29, tmp34, tmp39)
    tmp41 = tl_math.sin(tmp17)
    tmp42 = tmp41 * tmp20
    tmp43 = tmp40 * tmp42
    tmp44 = tmp22 + tmp43
    tmp45 = tl.full(tmp44.shape, 0.0, tmp44.dtype)
    tmp46 = tl.where(tmp10, tmp44, tmp45)
    tmp47 = tl.where(tmp7, tmp8, tmp46)
    tl.store(out_ptr0 + (x5), tmp47, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/in/cin25vt2uf2cafg6u4nlozrb3f4dutv7fj55fi6ecjxdcg7kpzez.py
# Topologically Sorted Source Nodes: [linear_2, view_2, value_states, value_tensors], Original ATen: [aten.view, aten.transpose, aten.cat]
# Source node to ATen node mapping:
#   linear_2 => view_11
#   value_states => permute_6
#   value_tensors => cat_3
#   view_2 => view_12
# Graph fragment:
#   %arg17_1 : Tensor "f32[s16, 2, s53, 128][256*s53, 128*s53, 128, 1]cuda:0" = PlaceHolder[target=arg17_1]
#   %addmm_2 : Tensor "f32[s16, 256][256, 1]cuda:0" = PlaceHolder[target=addmm_2]
#   %view_11 : Tensor "f32[s16, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_2, [%arg14_1, 1, 256]), kwargs = {})
#   %view_12 : Tensor "f32[s16, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_11, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_6 : Tensor "f32[s16, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_12, [0, 2, 1, 3]), kwargs = {})
#   %cat_3 : Tensor "f32[s16, 2, s53 + 1, 128][256*s53 + 256, 128*s53 + 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.cat.default](args = ([%arg17_1, %permute_6], -2), kwargs = {})
#   return %cat_3
triton_poi_fused_cat_transpose_view_2 = async_compile.triton('triton_poi_fused_cat_transpose_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'ks0': 'i64', 'ks1': 'i64', 'ks2': 'i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_cat_transpose_view_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 11827200}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_cat_transpose_view_2(in_ptr0, in_ptr1, out_ptr0, ks0, ks1, ks2, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = ((xindex // 128) % ks0)
    x0 = (xindex % 128)
    x2 = xindex // ks2
    x3 = xindex
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x1).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = (ks1).to(tl.int64)
    tmp6 = (tmp5).to(tl.int64)
    tmp7 = tmp4 < tmp6
    tmp8 = tl.load(in_ptr0 + (x0 + 128*(x1) + 128*ks1*x2), tmp7 & xmask, eviction_policy='evict_last', other=0.0)
    tmp9 = (ks1).to(tl.int32)
    tmp10 = tmp0 >= tmp9
    tmp11 = (ks0).to(tl.int32)
    tmp12 = tmp0 < tmp11
    tmp13 = tl.load(in_ptr1 + (x0 + 128*x2), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp14 = tl.where(tmp7, tmp8, tmp13)
    tl.store(out_ptr0 + (x3), tmp14, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/5k/c5kfpjgvc6lyueokx6kd24ubyrjmimazrfbt54w3yvguh73ln34k.py
# Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
# Source node to ATen node mapping:
#   cat_1 => cat
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   linear => view_5
#   matmul => mul_14
#   mul_4 => mul_87
#   mul_5 => mul_98
#   neg => neg
#   output => _scaled_dot_product_efficient_attention
#   packed => view_13
#   position_ids_expanded => convert_element_type
#   q_embed => add_180
#   query_states => permute_2
#   sin => sin
#   sin_3 => unsqueeze_5
#   view => view_6
#   x1 => slice_2
#   x2 => slice_3
# Graph fragment:
#   %addmm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=addmm]
#   %arg4_1 : Tensor "f32[64][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %arg3_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg3_1]
#   %arg5_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg5_1]
#   %view_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [%arg14_1, 1, 1536]), kwargs = {})
#   %view_6 : Tensor "f32[s16, 1, 12, 128][1536, 1536, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_5, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_2 : Tensor "f32[s16, 12, 1, 128][1536, 128, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_6, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %mul_87 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_2, %unsqueeze_4), kwargs = {})
#   %slice_3 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "f32[s16, 12, 1, 64][768, 64, 768, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_3,), kwargs = {})
#   %slice_2 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 0, 64), kwargs = {})
#   %cat : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_2], -1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %mul_98 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_5), kwargs = {})
#   %add_180 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_87, %mul_98), kwargs = {})
#   %view_13 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add_180, [%arg14_1, 2, 6, 128]), kwargs = {})
#   %_scaled_dot_product_efficient_attention : [num_users=1] = call_function[target=torch.ops.aten._scaled_dot_product_efficient_attention.default](args = (%view_13, %cat_2, %cat_3, None, False), kwargs = {scale: 0.08838834764831845})
#   return %buf7
triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3 = async_compile.triton('triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*i64', 'in_ptr3': 'fp64', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1536656}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x3 = xindex
    x2 = xindex // 1536
    x0 = (xindex % 128)
    x4 = xindex // 128
    tmp0 = tl.load(in_ptr0 + (x3), xmask)
    tmp1 = tl.load(in_ptr1 + ((x3 % 64)), xmask, eviction_policy='evict_last')
    tmp2 = tl.load(in_ptr2 + (x2), xmask, eviction_policy='evict_last')
    tmp6 = in_ptr3
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp1 * tmp3
    tmp5 = tl_math.cos(tmp4)
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tmp5 * tmp7
    tmp9 = tmp0 * tmp8
    tmp10 = (x0).to(tl.int32)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 >= tmp11
    tmp13 = (x0).to(tl.int64)
    tmp14 = (tmp13).to(tl.int64)
    tmp15 = tl.full([1], 64, tl.int64)
    tmp16 = tmp14 < tmp15
    tmp17 = tl.load(in_ptr0 + (64 + 128*x4 + (x0)), tmp16 & xmask, eviction_policy='evict_last', other=0.0)
    tmp18 = -tmp17
    tmp19 = tl.full(tmp18.shape, 0.0, tmp18.dtype)
    tmp20 = tl.where(tmp16, tmp18, tmp19)
    tmp21 = tmp10 >= tmp15
    tmp22 = tl.full([1], 128, tl.int64)
    tmp23 = tmp10 < tmp22
    tmp24 = tl.load(in_ptr0 + (128*x4 + ((-64) + x0)), tmp21 & xmask, eviction_policy='evict_last', other=0.0)
    tmp25 = tl.where(tmp16, tmp20, tmp24)
    tmp26 = tl_math.sin(tmp4)
    tmp27 = tmp26 * tmp7
    tmp28 = tmp25 * tmp27
    tmp29 = tmp9 + tmp28
    tl.store(out_ptr0 + (x3), tmp29, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/hr/chrjjprrivuviusbims7kprdvank2wjgmz7x52lmec3v6cd4yg56.py
# Topologically Sorted Source Nodes: [attn_output], Original ATen: [aten.clone]
# Source node to ATen node mapping:
#   attn_output => clone_2
# Graph fragment:
#   %getitem : Tensor "f32[s16, 2, 6, 128][1536, 128, 256, 1]cuda:0" = PlaceHolder[target=getitem]
#   %clone_2 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%getitem,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone_2
triton_poi_fused_clone_4 = async_compile.triton('triton_poi_fused_clone_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_clone_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 921600}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_clone_4(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 6)
    x2 = ((xindex // 768) % 2)
    x3 = xindex // 1536
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 128*x2 + 256*x1 + 1536*x3), xmask)
    tl.store(out_ptr0 + (x4), tmp0, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/yu/cyuadoqeapbd2t34bycowlx4e4odu3litthbwlkmmyknikc5p5zf.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, pow_2, variance_1, rsqrt_1, hidden_states_5, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   hidden_states_3 => add_273
#   hidden_states_5 => mul_207
#   hidden_states_6 => mul_210
#   inputs_embeds => embedding
#   pow_2 => pow_2
#   rsqrt_1 => rsqrt_1
#   variance_1 => mean_1
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %arg20_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg20_1]
#   %buf15 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf15]
#   %arg19_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg19_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_273 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %pow_2 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_273, 2), kwargs = {})
#   %mean_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %convert_element_type_default_6 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg19_1, torch.float32), kwargs = {})
#   %add_tensor_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, %convert_element_type_default_6), kwargs = {})
#   %rsqrt_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_1,), kwargs = {})
#   %mul_207 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_273, %rsqrt_1), kwargs = {})
#   %mul_210 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg20_1, %mul_207), kwargs = {})
#   return %buf15,%mul_210
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 927744}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    tmp16 = in_ptr4
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tmp11 + tmp12
        tmp14 = tl.full([1, 1], 1536.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tmp15 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp13 * tmp19
        tmp21 = tmp9 * tmp20
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp21, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/sb/csb5ohivem2gxn4easponmidqbw3v6dqsipebvwyhymbwavesgg7.py
# Topologically Sorted Source Nodes: [linear_4, split, silu, mul_10], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
# Source node to ATen node mapping:
#   linear_4 => view_19
#   mul_10 => mul_234
#   silu => add_321, div, exp, neg_2
#   split => split
# Graph fragment:
#   %mm_1 : Tensor "f32[s16, 17920][17920, 1]cuda:0" = PlaceHolder[target=mm_1]
#   %view_19 : Tensor "f32[s16, 1, 17920][17920, 17920, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [%arg14_1, 1, 17920]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_19, 8960, -1), kwargs = {})
#   %neg_2 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_4,), kwargs = {})
#   %exp : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_321 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%getitem_4, %add_321), kwargs = {})
#   %mul_234 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%div, %getitem_5), kwargs = {})
#   return %mul_234
triton_poi_fused__unsafe_view_mul_silu_split_6 = async_compile.triton('triton_poi_fused__unsafe_view_mul_silu_split_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_mul_silu_split_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 7168000}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_mul_silu_split_6(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 8960)
    x1 = xindex // 8960
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 17920*x1), xmask)
    tmp6 = tl.load(in_ptr0 + (8960 + x0 + 17920*x1), xmask)
    tmp1 = -tmp0
    tmp2 = libdevice.exp(tmp1)
    tmp3 = tl.full([1], 1.0, tl.float32)
    tmp4 = tmp2 + tmp3
    tmp5 = (tmp0 / tmp4)
    tmp7 = tmp5 * tmp6
    tl.store(out_ptr0 + (x2), tmp7, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/3n/c3n4p53u2b5ksqygihm5ukzkzve35a42ian3rmgaalbiujudwqah.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, hidden_states_7, hidden_states_8, pow_3, variance_2, rsqrt_2, hidden_states_10, hidden_states_11], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   hidden_states_10 => mul_258
#   hidden_states_11 => mul_261
#   hidden_states_3 => add_273
#   hidden_states_7 => view_21
#   hidden_states_8 => add_340
#   inputs_embeds => embedding
#   pow_3 => pow_3
#   rsqrt_2 => rsqrt_2
#   variance_2 => mean_2
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %mm_2 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_2]
#   %arg24_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg24_1]
#   %buf20 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf20]
#   %arg23_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg23_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_273 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %view_21 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_340 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_273, %view_21), kwargs = {})
#   %pow_3 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_340, 2), kwargs = {})
#   %mean_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %convert_element_type_default_8 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg23_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, %convert_element_type_default_8), kwargs = {})
#   %rsqrt_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_2,), kwargs = {})
#   %mul_258 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_340, %rsqrt_2), kwargs = {})
#   %mul_261 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg24_1, %mul_258), kwargs = {})
#   return %buf20,%mul_261
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    tmp20 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp14 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp16 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tmp13 + tmp14
        tmp17 = tmp15 + tmp16
        tmp18 = tl.full([1, 1], 1536.0, tl.float32)
        tmp19 = (tmp9 / tmp18)
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp19 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp17 * tmp23
        tmp25 = tmp11 * tmp24
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp25, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/sn/csn6ccor6ary7eqpdezyaaq4ntwang2mm355374s2sv46v6rp7fh.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, hidden_states_7, hidden_states_8, attn_output_7, hidden_states_12, pow_4, variance_3, rsqrt_3, hidden_states_14, hidden_states_15], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   attn_output_7 => view_35
#   hidden_states_12 => add_563
#   hidden_states_14 => mul_421
#   hidden_states_15 => mul_424
#   hidden_states_3 => add_273
#   hidden_states_7 => view_21
#   hidden_states_8 => add_340
#   inputs_embeds => embedding
#   pow_4 => pow_4
#   rsqrt_3 => rsqrt_3
#   variance_3 => mean_3
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %mm_2 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_2]
#   %mm_3 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_3]
#   %add_563 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_563]
#   %arg35_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg35_1]
#   %buf36 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf36]
#   %arg34_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg34_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_273 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %view_21 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_340 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_273, %view_21), kwargs = {})
#   %view_35 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_563 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_340, %view_35), kwargs = {})
#   %pow_4 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_563, 2), kwargs = {})
#   %mean_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %convert_element_type_default_10 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg34_1, torch.float32), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, %convert_element_type_default_10), kwargs = {})
#   %rsqrt_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_421 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_563, %rsqrt_3), kwargs = {})
#   %mul_424 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg35_1, %mul_421), kwargs = {})
#   return %add_563,%buf36,%mul_424
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 2156544}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp11 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp5 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp7 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask & xmask, tmp12, _tmp11)
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp8, r0_mask & xmask)
    tmp11 = tl.sum(_tmp11, 1)[:, None]
    tmp17 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.debug_barrier()
        tmp14 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp11 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp13 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/5l/c5llxk643ulqbekz24lcsa2sz6kwkig7mnhzxrdnnuldedvttsju.py
# Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, pow_5, variance_4, rsqrt_4, hidden_states_19, hidden_states_20], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   hidden_states_16 => view_39
#   hidden_states_17 => add_630
#   hidden_states_19 => mul_472
#   hidden_states_20 => mul_475
#   pow_5 => pow_5
#   rsqrt_4 => rsqrt_4
#   variance_4 => mean_4
# Graph fragment:
#   %add_563 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_563]
#   %mm_5 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_5]
#   %arg39_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg39_1]
#   %buf41 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf41]
#   %arg38_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg38_1]
#   %view_39 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_630 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_563, %view_39), kwargs = {})
#   %pow_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_630, 2), kwargs = {})
#   %mean_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [-1], True), kwargs = {})
#   %convert_element_type_default_12 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg38_1, torch.float32), kwargs = {})
#   %add_tensor_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_4, %convert_element_type_default_12), kwargs = {})
#   %rsqrt_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_4,), kwargs = {})
#   %mul_472 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_630, %rsqrt_4), kwargs = {})
#   %mul_475 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg39_1, %mul_472), kwargs = {})
#   return %buf41,%mul_475
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    tmp13 = in_ptr3
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp8 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp9 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tmp8 + tmp9
        tmp11 = tl.full([1, 1], 1536.0, tl.float32)
        tmp12 = (tmp5 / tmp11)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tmp12 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp10 * tmp16
        tmp18 = tmp7 * tmp17
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp18, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/7a/c7aklu4fbiemns3ltg3c54mrcudd2a7nyscig7bkcvaywbl72f5d.py
# Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, pow_6, variance_5, rsqrt_5, hidden_states_23, hidden_states_24], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_53
#   hidden_states_16 => view_39
#   hidden_states_17 => add_630
#   hidden_states_21 => add_853
#   hidden_states_23 => mul_635
#   hidden_states_24 => mul_638
#   pow_6 => pow_6
#   rsqrt_5 => rsqrt_5
#   variance_5 => mean_5
# Graph fragment:
#   %add_563 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_563]
#   %mm_5 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_5]
#   %mm_6 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_6]
#   %arg50_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg50_1]
#   %buf56 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf56]
#   %arg49_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg49_1]
#   %view_39 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_630 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_563, %view_39), kwargs = {})
#   %view_53 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_853 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_630, %view_53), kwargs = {})
#   %pow_6 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_853, 2), kwargs = {})
#   %mean_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %convert_element_type_default_14 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg49_1, torch.float32), kwargs = {})
#   %add_tensor_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, %convert_element_type_default_14), kwargs = {})
#   %rsqrt_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_5,), kwargs = {})
#   %mul_635 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_853, %rsqrt_5), kwargs = {})
#   %mul_638 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg50_1, %mul_635), kwargs = {})
#   return %buf56,%mul_638
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1542144}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    tmp17 = in_ptr4
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp10 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp7 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp9 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/sk/cskx4kb6fpqafmn3f6xhgtoz5ohz2rfyt3rnqnmrmmwximkffpn5.py
# Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, hidden_states_25, hidden_states_26, pow_7, variance_6, rsqrt_6, hidden_states_28, hidden_states_29], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_53
#   hidden_states_16 => view_39
#   hidden_states_17 => add_630
#   hidden_states_21 => add_853
#   hidden_states_25 => view_57
#   hidden_states_26 => add_920
#   hidden_states_28 => mul_686
#   hidden_states_29 => mul_689
#   pow_7 => pow_7
#   rsqrt_6 => rsqrt_6
#   variance_6 => mean_6
# Graph fragment:
#   %add_563 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_563]
#   %mm_5 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_5]
#   %mm_6 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_6]
#   %mm_8 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %arg54_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg54_1]
#   %buf61 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf61]
#   %arg53_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg53_1]
#   %view_39 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_630 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_563, %view_39), kwargs = {})
#   %view_53 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_853 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_630, %view_53), kwargs = {})
#   %view_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_920 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_853, %view_57), kwargs = {})
#   %pow_7 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_920, 2), kwargs = {})
#   %mean_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [-1], True), kwargs = {})
#   %convert_element_type_default_16 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg53_1, torch.float32), kwargs = {})
#   %add_tensor_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_6, %convert_element_type_default_16), kwargs = {})
#   %rsqrt_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_6,), kwargs = {})
#   %mul_686 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_920, %rsqrt_6), kwargs = {})
#   %mul_689 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg54_1, %mul_686), kwargs = {})
#   return %buf61,%mul_689
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 10, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1849344}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    tmp21 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp17 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tl.full([1, 1], 1536.0, tl.float32)
        tmp20 = (tmp9 / tmp19)
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tmp20 + tmp22
        tmp24 = libdevice.rsqrt(tmp23)
        tmp25 = tmp18 * tmp24
        tmp26 = tmp11 * tmp25
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp26, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/ca/ccakktfdoy2u7gzyqufh3ofs6ubj4cxdwh34rylvw24c4wkukic5.py
# Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, hidden_states_25, hidden_states_26, attn_output_15, hidden_states_30, pow_8, variance_7, rsqrt_7, hidden_states_32, hidden_states_33], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_53
#   attn_output_15 => view_71
#   hidden_states_16 => view_39
#   hidden_states_17 => add_630
#   hidden_states_21 => add_853
#   hidden_states_25 => view_57
#   hidden_states_26 => add_920
#   hidden_states_30 => add_1143
#   hidden_states_32 => mul_849
#   hidden_states_33 => mul_852
#   pow_8 => pow_8
#   rsqrt_7 => rsqrt_7
#   variance_7 => mean_7
# Graph fragment:
#   %add_563 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_563]
#   %mm_5 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_5]
#   %mm_6 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_6]
#   %mm_8 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %mm_9 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_9]
#   %add_1143 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_1143]
#   %arg65_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg65_1]
#   %buf77 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf77]
#   %arg64_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg64_1]
#   %view_39 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_630 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_563, %view_39), kwargs = {})
#   %view_53 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_853 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_630, %view_53), kwargs = {})
#   %view_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_920 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_853, %view_57), kwargs = {})
#   %view_71 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_9, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_1143 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_920, %view_71), kwargs = {})
#   %pow_8 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_1143, 2), kwargs = {})
#   %mean_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_8, [-1], True), kwargs = {})
#   %convert_element_type_default_18 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg64_1, torch.float32), kwargs = {})
#   %add_tensor_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_7, %convert_element_type_default_18), kwargs = {})
#   %rsqrt_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_7,), kwargs = {})
#   %mul_849 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_1143, %rsqrt_7), kwargs = {})
#   %mul_852 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg65_1, %mul_849), kwargs = {})
#   return %add_1143,%buf77,%mul_852
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 2770944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp11 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp3 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp5 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp7 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask & xmask, tmp12, _tmp11)
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp8, r0_mask & xmask)
    tmp11 = tl.sum(_tmp11, 1)[:, None]
    tmp17 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.debug_barrier()
        tmp14 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp11 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp13 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/cb/ccbefgmbd7oj7qu6z62xiurvt56fgv7um3maaspmw4ykilbgq55g.py
# Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, attn_output_59, hidden_states_129, hidden_states_133, hidden_states_134, pow_31, variance_30, add_90, rsqrt_30, hidden_states_136, hidden_states_137], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_90 => add_4413
#   attn_output_59 => view_269
#   hidden_states_124 => view_255
#   hidden_states_125 => add_4110
#   hidden_states_129 => add_4333
#   hidden_states_133 => view_273
#   hidden_states_134 => add_4400
#   hidden_states_136 => mul_3254
#   hidden_states_137 => mul_3257
#   pow_31 => pow_31
#   rsqrt_30 => rsqrt_30
#   variance_30 => mean_30
# Graph fragment:
#   %add_4043 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_4043]
#   %mm_41 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_41]
#   %mm_42 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_42]
#   %mm_44 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_44]
#   %arg233_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg233_1]
#   %buf307 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf307]
#   %view_255 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_41, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4110 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4043, %view_255), kwargs = {})
#   %view_269 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_42, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4333 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4110, %view_269), kwargs = {})
#   %view_273 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_44, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4400 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4333, %view_273), kwargs = {})
#   %pow_31 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_4400, 2), kwargs = {})
#   %mean_30 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_31, [-1], True), kwargs = {})
#   %add_4413 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_30, 1e-06), kwargs = {})
#   %rsqrt_30 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4413,), kwargs = {})
#   %mul_3254 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_4400, %rsqrt_30), kwargs = {})
#   %mul_3257 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg233_1, %mul_3254), kwargs = {})
#   return %buf307,%mul_3257
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1849344}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp17 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tl.full([1, 1], 1536.0, tl.float32)
        tmp20 = (tmp9 / tmp19)
        tmp21 = tl.full([1, 1], 1e-06, tl.float32)
        tmp22 = tmp20 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp18 * tmp23
        tmp25 = tmp11 * tmp24
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp25, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/packed/inductor/hj/chjnrbfp6yki7eo43kbyqf56sfwh675uxditltthptlfnfa7jrcp.py
# Topologically Sorted Source Nodes: [hidden_states_250, hidden_states_251, pow_57, variance_56, rsqrt_56, hidden_states_253, hidden_states_254], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   hidden_states_250 => view_507
#   hidden_states_251 => add_8170
#   hidden_states_253 => mul_6036
#   hidden_states_254 => mul_6039
#   pow_57 => pow_57
#   rsqrt_56 => rsqrt_56
#   variance_56 => mean_56
# Graph fragment:
#   %add_8103 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_8103]
#   %mm_83 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_83]
#   %arg428_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg428_1]
#   %buf574 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf574]
#   %arg427_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg427_1]
#   %view_507 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_83, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_8170 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_8103, %view_507), kwargs = {})
#   %pow_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_8170, 2), kwargs = {})
#   %mean_56 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_57, [-1], True), kwargs = {})
#   %convert_element_type_default_114 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg427_1, torch.float32), kwargs = {})
#   %add_tensor_55 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_56, %convert_element_type_default_114), kwargs = {})
#   %rsqrt_56 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_55,), kwargs = {})
#   %mul_6036 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_8170, %rsqrt_56), kwargs = {})
#   %mul_6039 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg428_1, %mul_6036), kwargs = {})
#   return %buf574,%mul_6039
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': 'fp64', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    tmp13 = in_ptr2
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr1 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp8 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp9 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tmp8 + tmp9
        tmp11 = tl.full([1, 1], 1536.0, tl.float32)
        tmp12 = (tmp5 / tmp11)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tmp12 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp10 * tmp16
        tmp18 = tmp7 * tmp17
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp18, r0_mask & xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1 = args
        args.clear()
        s16 = arg0_1
        s74 = s16
        s52 = s16
        s53 = arg15_1
        s35 = arg429_1
        assert_size_stride_grouped((arg1_1, arg2_1, arg7_1, arg6_1), ((s16, 1), (152265, 1536), (1536, ), ()), ((1, 1), (1536, 1), (1, ), ()), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg1_1 = copy_if_misaligned(arg1_1)
            buf1 = empty_strided_cuda((s16, 1, 1536), (1536, 1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [inputs_embeds, pow_1, variance, rsqrt, hidden_states_1, hidden_states_2], Original ATen: [aten.embedding, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_embedding_mean_mul_pow_rsqrt_0.run(arg1_1, arg2_1, arg7_1, arg6_1.item(), buf1, s16, 1536, stream=raw_stream0)
            del arg6_1
            del arg7_1
            assert_size_stride_grouped((arg9_1, arg8_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf2 = empty_strided_cuda((s16, 1536), (1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg9_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg8_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf2)
            del arg8_1
            del arg9_1
            assert_size_stride_grouped((arg11_1, arg10_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf3 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg11_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg10_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf3)
            del arg10_1
            del arg11_1
            assert_size_stride_grouped((arg16_1, arg4_1, arg3_1, arg5_1), ((s16, 2, s53, 128), (64, ), (s16, 1), ()), ((256*s53, 128*s53, 128, 1), (1, ), (1, 1), ()), 'input')
            arg16_1 = copy_if_misaligned(arg16_1)
            arg3_1 = copy_if_misaligned(arg3_1)
            ps0 = 1 + s53
            ps1 = 128 + 128*s53
            ps2 = 256 + 256*s53
            buf4 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, sin, sin_3, linear_1, view_1, key_states, mul_6, x2_1, neg_1, x1_1, cat_2, mul_7, k_embed, key_tensors], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg16_1, buf3, arg4_1, arg3_1, arg5_1.item(), buf4, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg16_1
            assert_size_stride_grouped((arg13_1, arg12_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf5 = buf3; del buf3  # reuse
            # Topologically Sorted Source Nodes: [linear_2], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg13_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg12_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf5)
            del arg12_1
            del arg13_1
            assert_size_stride(arg17_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg17_1 = copy_if_misaligned(arg17_1)
            buf6 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_2, view_2, value_states, value_tensors], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg17_1, buf5, buf6, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg17_1
            buf7 = reinterpret_tensor(buf1, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf1  # reuse
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf2, arg4_1, arg3_1, arg5_1.item(), buf7, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            buf8 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf7, buf4, buf6, None, False, scale=0.08838834764831845)
            buf9 = buf8[0]
            assert_tensor_metadata(buf9, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf9, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf8
            buf13 = buf7; del buf7  # reuse
            # Topologically Sorted Source Nodes: [attn_output], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf9, buf13, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg18_1, (1536, 1536), (1536, 1), 'input')
            buf14 = reinterpret_tensor(buf9, (s16, 1536), (1536, 1), 0); del buf9  # reuse
            # Topologically Sorted Source Nodes: [attn_output, transpose_4, reshape_2, attn_output_3], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf13, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg18_1, (1536, 1536), (1, 1536), 0), out=buf14)
            del arg18_1
            assert_size_stride_grouped((arg20_1, arg19_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf16 = reinterpret_tensor(buf13, (s16, 1, 1536), (1536, 1536, 1), 0); del buf13  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, pow_2, variance_1, rsqrt_1, hidden_states_5, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5.run(arg1_1, arg2_1, buf14, arg20_1, arg19_1.item(), buf16, s16, 1536, stream=raw_stream0)
            del arg19_1
            del arg20_1
            assert_size_stride(arg21_1, (17920, 1536), (1536, 1), 'input')
            buf17 = empty_strided_cuda((s16, 17920), (17920, 1), torch.float32)
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, pow_2, variance_1, rsqrt_1, hidden_states_5, hidden_states_6, linear_4], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf16, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg21_1, (1536, 17920), (1, 1536), 0), out=buf17)
            del arg21_1
            buf18 = empty_strided_cuda((s16, 1, 8960), (8960, 8960, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_4, split, silu, mul_10], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf17, buf18, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg22_1, (1536, 8960), (8960, 1), 'input')
            buf19 = reinterpret_tensor(buf16, (s16, 1536), (1536, 1), 0); del buf16  # reuse
            # Topologically Sorted Source Nodes: [linear_4, split, silu, mul_10, hidden_states_7], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf18, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg22_1, (8960, 1536), (1, 8960), 0), out=buf19)
            del arg22_1
            assert_size_stride_grouped((arg24_1, arg23_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf21 = reinterpret_tensor(buf2, (s16, 1, 1536), (1536, 1536, 1), 0); del buf2  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, hidden_states_7, hidden_states_8, pow_3, variance_2, rsqrt_2, hidden_states_10, hidden_states_11], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7.run(arg1_1, arg2_1, buf14, buf19, arg24_1, arg23_1.item(), buf21, s16, 1536, stream=raw_stream0)
            del arg23_1
            del arg24_1
            assert_size_stride_grouped((arg26_1, arg25_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf22 = empty_strided_cuda((s16, 1536), (1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_6], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg26_1, reinterpret_tensor(buf21, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg25_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf22)
            del arg25_1
            del arg26_1
            assert_size_stride_grouped((arg28_1, arg27_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf23 = buf5; del buf5  # reuse
            # Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg28_1, reinterpret_tensor(buf21, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg27_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf23)
            del arg27_1
            del arg28_1
            assert_size_stride(arg31_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg31_1 = copy_if_misaligned(arg31_1)
            buf24 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_4, sin_4, linear_7, view_4, key_states_1, mul_15, x2_3, neg_3, x1_3, cat_6, mul_16, k_embed_1, key_tensors_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg31_1, buf23, arg4_1, arg3_1, arg5_1.item(), buf24, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg31_1
            assert_size_stride_grouped((arg30_1, arg29_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf25 = buf23; del buf23  # reuse
            # Topologically Sorted Source Nodes: [linear_8], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg30_1, reinterpret_tensor(buf21, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg29_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf25)
            del arg29_1
            del arg30_1
            assert_size_stride(arg32_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg32_1 = copy_if_misaligned(arg32_1)
            buf26 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_8, view_5, value_states_1, value_tensors_1], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg32_1, buf25, buf26, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg32_1
            buf27 = reinterpret_tensor(buf21, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf21  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_6, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_5, sin_4, mul_14, q_embed_1, packed_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf22, arg4_1, arg3_1, arg5_1.item(), buf27, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_6, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_5, sin_4, mul_14, q_embed_1, packed_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf28 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf27, buf24, buf26, None, False, scale=0.08838834764831845)
            buf29 = buf28[0]
            assert_tensor_metadata(buf29, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf29, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf28
            buf33 = buf27; del buf27  # reuse
            # Topologically Sorted Source Nodes: [attn_output_4], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf29, buf33, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg33_1, (1536, 1536), (1536, 1), 'input')
            buf34 = reinterpret_tensor(buf29, (s16, 1536), (1536, 1), 0); del buf29  # reuse
            # Topologically Sorted Source Nodes: [attn_output_4, transpose_8, reshape_5, attn_output_7], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf33, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg33_1, (1536, 1536), (1, 1536), 0), out=buf34)
            del arg33_1
            assert_size_stride_grouped((arg35_1, arg34_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf35 = reinterpret_tensor(buf14, (s16, 1, 1536), (1536, 1536*s16, 1), 0); del buf14  # reuse
            buf37 = reinterpret_tensor(buf33, (s16, 1, 1536), (1536, 1536, 1), 0); del buf33  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, hidden_states_7, hidden_states_8, attn_output_7, hidden_states_12, pow_4, variance_3, rsqrt_3, hidden_states_14, hidden_states_15], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8.run(buf35, arg1_1, arg2_1, buf19, buf34, arg35_1, arg34_1.item(), buf37, s16, 1536, stream=raw_stream0)
            del arg1_1
            del arg34_1
            del arg35_1
            assert_size_stride(arg36_1, (17920, 1536), (1536, 1), 'input')
            buf38 = buf17; del buf17  # reuse
            # Topologically Sorted Source Nodes: [pow_4, variance_3, rsqrt_3, hidden_states_14, hidden_states_15, linear_10], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf37, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg36_1, (1536, 17920), (1, 1536), 0), out=buf38)
            del arg36_1
            buf39 = buf18; del buf18  # reuse
            # Topologically Sorted Source Nodes: [linear_10, split_1, silu_1, mul_19], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf38, buf39, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg37_1, (1536, 8960), (8960, 1), 'input')
            buf40 = reinterpret_tensor(buf37, (s16, 1536), (1536, 1), 0); del buf37  # reuse
            # Topologically Sorted Source Nodes: [linear_10, split_1, silu_1, mul_19, hidden_states_16], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf39, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg37_1, (8960, 1536), (1, 8960), 0), out=buf40)
            del arg37_1
            assert_size_stride_grouped((arg39_1, arg38_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf42 = reinterpret_tensor(buf34, (s16, 1, 1536), (1536, 1536, 1), 0); del buf34  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, pow_5, variance_4, rsqrt_4, hidden_states_19, hidden_states_20], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf35, buf40, arg39_1, arg38_1.item(), buf42, s16, 1536, stream=raw_stream0)
            del arg38_1
            del arg39_1
            assert_size_stride_grouped((arg41_1, arg40_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf43 = buf19; del buf19  # reuse
            # Topologically Sorted Source Nodes: [linear_12], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg41_1, reinterpret_tensor(buf42, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg40_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf43)
            del arg40_1
            del arg41_1
            assert_size_stride_grouped((arg43_1, arg42_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf44 = buf25; del buf25  # reuse
            # Topologically Sorted Source Nodes: [linear_13], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg43_1, reinterpret_tensor(buf42, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg42_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf44)
            del arg42_1
            del arg43_1
            assert_size_stride(arg46_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg46_1 = copy_if_misaligned(arg46_1)
            buf45 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_5, sin_5, linear_13, view_7, key_states_2, mul_24, x2_5, neg_5, x1_5, cat_10, mul_25, k_embed_2, key_tensors_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg46_1, buf44, arg4_1, arg3_1, arg5_1.item(), buf45, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg46_1
            assert_size_stride_grouped((arg45_1, arg44_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf46 = buf44; del buf44  # reuse
            # Topologically Sorted Source Nodes: [linear_14], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg45_1, reinterpret_tensor(buf42, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg44_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf46)
            del arg44_1
            del arg45_1
            assert_size_stride(arg47_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg47_1 = copy_if_misaligned(arg47_1)
            buf47 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_14, view_8, value_states_2, value_tensors_2], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg47_1, buf46, buf47, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg47_1
            buf48 = reinterpret_tensor(buf42, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf42  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_12, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_9, sin_5, mul_23, q_embed_2, packed_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf43, arg4_1, arg3_1, arg5_1.item(), buf48, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_12, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_9, sin_5, mul_23, q_embed_2, packed_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf49 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf48, buf45, buf47, None, False, scale=0.08838834764831845)
            buf50 = buf49[0]
            assert_tensor_metadata(buf50, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf50, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf49
            buf54 = buf48; del buf48  # reuse
            # Topologically Sorted Source Nodes: [attn_output_8], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf50, buf54, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg48_1, (1536, 1536), (1536, 1), 'input')
            buf55 = reinterpret_tensor(buf50, (s16, 1536), (1536, 1), 0); del buf50  # reuse
            # Topologically Sorted Source Nodes: [attn_output_8, transpose_12, reshape_8, attn_output_11], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf54, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg48_1, (1536, 1536), (1, 1536), 0), out=buf55)
            del arg48_1
            assert_size_stride_grouped((arg50_1, arg49_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf57 = reinterpret_tensor(buf54, (s16, 1, 1536), (1536, 1536, 1), 0); del buf54  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, pow_6, variance_5, rsqrt_5, hidden_states_23, hidden_states_24], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf35, buf40, buf55, arg50_1, arg49_1.item(), buf57, s16, 1536, stream=raw_stream0)
            del arg49_1
            del arg50_1
            assert_size_stride(arg51_1, (17920, 1536), (1536, 1), 'input')
            buf58 = buf38; del buf38  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, pow_6, variance_5, rsqrt_5, hidden_states_23, hidden_states_24, linear_16], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf57, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg51_1, (1536, 17920), (1, 1536), 0), out=buf58)
            del arg51_1
            buf59 = buf39; del buf39  # reuse
            # Topologically Sorted Source Nodes: [linear_16, split_2, silu_2, mul_28], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf58, buf59, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg52_1, (1536, 8960), (8960, 1), 'input')
            buf60 = reinterpret_tensor(buf57, (s16, 1536), (1536, 1), 0); del buf57  # reuse
            # Topologically Sorted Source Nodes: [linear_16, split_2, silu_2, mul_28, hidden_states_25], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf59, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg52_1, (8960, 1536), (1, 8960), 0), out=buf60)
            del arg52_1
            assert_size_stride_grouped((arg54_1, arg53_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf62 = reinterpret_tensor(buf43, (s16, 1, 1536), (1536, 1536, 1), 0); del buf43  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, hidden_states_25, hidden_states_26, pow_7, variance_6, rsqrt_6, hidden_states_28, hidden_states_29], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf35, buf40, buf55, buf60, arg54_1, arg53_1.item(), buf62, s16, 1536, stream=raw_stream0)
            del arg53_1
            del arg54_1
            assert_size_stride_grouped((arg56_1, arg55_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf63 = buf22; del buf22  # reuse
            # Topologically Sorted Source Nodes: [linear_18], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg56_1, reinterpret_tensor(buf62, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg55_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf63)
            del arg55_1
            del arg56_1
            assert_size_stride_grouped((arg58_1, arg57_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf64 = buf46; del buf46  # reuse
            # Topologically Sorted Source Nodes: [linear_19], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg58_1, reinterpret_tensor(buf62, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg57_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf64)
            del arg57_1
            del arg58_1
            assert_size_stride(arg61_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg61_1 = copy_if_misaligned(arg61_1)
            buf65 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_6, sin_6, linear_19, view_10, key_states_3, mul_33, x2_7, neg_7, x1_7, cat_14, mul_34, k_embed_3, key_tensors_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg61_1, buf64, arg4_1, arg3_1, arg5_1.item(), buf65, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg61_1
            assert_size_stride_grouped((arg60_1, arg59_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf66 = buf64; del buf64  # reuse
            # Topologically Sorted Source Nodes: [linear_20], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg60_1, reinterpret_tensor(buf62, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg59_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf66)
            del arg59_1
            del arg60_1
            assert_size_stride(arg62_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg62_1 = copy_if_misaligned(arg62_1)
            buf67 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_20, view_11, value_states_3, value_tensors_3], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg62_1, buf66, buf67, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg62_1
            buf68 = reinterpret_tensor(buf62, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf62  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_18, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_13, sin_6, mul_32, q_embed_3, packed_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf63, arg4_1, arg3_1, arg5_1.item(), buf68, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf63
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_18, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_13, sin_6, mul_32, q_embed_3, packed_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf69 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf68, buf65, buf67, None, False, scale=0.08838834764831845)
            buf70 = buf69[0]
            assert_tensor_metadata(buf70, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf70, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf69
            buf74 = buf68; del buf68  # reuse
            # Topologically Sorted Source Nodes: [attn_output_12], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf70, buf74, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg63_1, (1536, 1536), (1536, 1), 'input')
            buf75 = reinterpret_tensor(buf70, (s16, 1536), (1536, 1), 0); del buf70  # reuse
            # Topologically Sorted Source Nodes: [attn_output_12, transpose_16, reshape_11, attn_output_15], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf74, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg63_1, (1536, 1536), (1, 1536), 0), out=buf75)
            del arg63_1
            assert_size_stride_grouped((arg65_1, arg64_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf76 = buf35; del buf35  # reuse
            buf78 = reinterpret_tensor(buf74, (s16, 1, 1536), (1536, 1536, 1), 0); del buf74  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_16, hidden_states_17, attn_output_11, hidden_states_21, hidden_states_25, hidden_states_26, attn_output_15, hidden_states_30, pow_8, variance_7, rsqrt_7, hidden_states_32, hidden_states_33], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf76, buf40, buf55, buf60, buf75, arg65_1, arg64_1.item(), buf78, s16, 1536, stream=raw_stream0)
            del arg64_1
            del arg65_1
            del buf40
            assert_size_stride(arg66_1, (17920, 1536), (1536, 1), 'input')
            buf79 = buf58; del buf58  # reuse
            # Topologically Sorted Source Nodes: [pow_8, variance_7, rsqrt_7, hidden_states_32, hidden_states_33, linear_22], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf78, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg66_1, (1536, 17920), (1, 1536), 0), out=buf79)
            del arg66_1
            buf80 = buf59; del buf59  # reuse
            # Topologically Sorted Source Nodes: [linear_22, split_3, silu_3, mul_37], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf79, buf80, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg67_1, (1536, 8960), (8960, 1), 'input')
            buf81 = reinterpret_tensor(buf78, (s16, 1536), (1536, 1), 0); del buf78  # reuse
            # Topologically Sorted Source Nodes: [linear_22, split_3, silu_3, mul_37, hidden_states_34], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf80, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg67_1, (8960, 1536), (1, 8960), 0), out=buf81)
            del arg67_1
            assert_size_stride_grouped((arg69_1, arg68_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf83 = reinterpret_tensor(buf75, (s16, 1, 1536), (1536, 1536, 1), 0); del buf75  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_34, hidden_states_35, pow_9, variance_8, rsqrt_8, hidden_states_37, hidden_states_38], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf76, buf81, arg69_1, arg68_1.item(), buf83, s16, 1536, stream=raw_stream0)
            del arg68_1
            del arg69_1
            assert_size_stride_grouped((arg71_1, arg70_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf84 = buf60; del buf60  # reuse
            # Topologically Sorted Source Nodes: [linear_24], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg71_1, reinterpret_tensor(buf83, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg70_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf84)
            del arg70_1
            del arg71_1
            assert_size_stride_grouped((arg73_1, arg72_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf85 = buf66; del buf66  # reuse
            # Topologically Sorted Source Nodes: [linear_25], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg73_1, reinterpret_tensor(buf83, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg72_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf85)
            del arg72_1
            del arg73_1
            assert_size_stride(arg76_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg76_1 = copy_if_misaligned(arg76_1)
            buf86 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_7, sin_7, linear_25, view_13, key_states_4, mul_42, x2_9, neg_9, x1_9, cat_18, mul_43, k_embed_4, key_tensors_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg76_1, buf85, arg4_1, arg3_1, arg5_1.item(), buf86, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg76_1
            assert_size_stride_grouped((arg75_1, arg74_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf87 = buf85; del buf85  # reuse
            # Topologically Sorted Source Nodes: [linear_26], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg75_1, reinterpret_tensor(buf83, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg74_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf87)
            del arg74_1
            del arg75_1
            assert_size_stride(arg77_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg77_1 = copy_if_misaligned(arg77_1)
            buf88 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_26, view_14, value_states_4, value_tensors_4], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg77_1, buf87, buf88, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg77_1
            buf89 = reinterpret_tensor(buf83, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf83  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_24, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_17, sin_7, mul_41, q_embed_4, packed_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf84, arg4_1, arg3_1, arg5_1.item(), buf89, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_24, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_17, sin_7, mul_41, q_embed_4, packed_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf90 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf89, buf86, buf88, None, False, scale=0.08838834764831845)
            buf91 = buf90[0]
            assert_tensor_metadata(buf91, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf91, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf90
            buf95 = buf89; del buf89  # reuse
            # Topologically Sorted Source Nodes: [attn_output_16], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf91, buf95, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg78_1, (1536, 1536), (1536, 1), 'input')
            buf96 = reinterpret_tensor(buf91, (s16, 1536), (1536, 1), 0); del buf91  # reuse
            # Topologically Sorted Source Nodes: [attn_output_16, transpose_20, reshape_14, attn_output_19], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf95, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg78_1, (1536, 1536), (1, 1536), 0), out=buf96)
            del arg78_1
            assert_size_stride_grouped((arg80_1, arg79_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf98 = reinterpret_tensor(buf95, (s16, 1, 1536), (1536, 1536, 1), 0); del buf95  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_34, hidden_states_35, attn_output_19, hidden_states_39, pow_10, variance_9, rsqrt_9, hidden_states_41, hidden_states_42], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf76, buf81, buf96, arg80_1, arg79_1.item(), buf98, s16, 1536, stream=raw_stream0)
            del arg79_1
            del arg80_1
            assert_size_stride(arg81_1, (17920, 1536), (1536, 1), 'input')
            buf99 = buf79; del buf79  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_34, hidden_states_35, attn_output_19, hidden_states_39, pow_10, variance_9, rsqrt_9, hidden_states_41, hidden_states_42, linear_28], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf98, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg81_1, (1536, 17920), (1, 1536), 0), out=buf99)
            del arg81_1
            buf100 = buf80; del buf80  # reuse
            # Topologically Sorted Source Nodes: [linear_28, split_4, silu_4, mul_46], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf99, buf100, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg82_1, (1536, 8960), (8960, 1), 'input')
            buf101 = reinterpret_tensor(buf98, (s16, 1536), (1536, 1), 0); del buf98  # reuse
            # Topologically Sorted Source Nodes: [linear_28, split_4, silu_4, mul_46, hidden_states_43], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf100, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg82_1, (8960, 1536), (1, 8960), 0), out=buf101)
            del arg82_1
            assert_size_stride_grouped((arg84_1, arg83_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf103 = reinterpret_tensor(buf84, (s16, 1, 1536), (1536, 1536, 1), 0); del buf84  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_34, hidden_states_35, attn_output_19, hidden_states_39, hidden_states_43, hidden_states_44, pow_11, variance_10, rsqrt_10, hidden_states_46, hidden_states_47], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf76, buf81, buf96, buf101, arg84_1, arg83_1.item(), buf103, s16, 1536, stream=raw_stream0)
            del arg83_1
            del arg84_1
            assert_size_stride_grouped((arg86_1, arg85_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf104 = buf55; del buf55  # reuse
            # Topologically Sorted Source Nodes: [linear_30], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg86_1, reinterpret_tensor(buf103, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg85_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf104)
            del arg85_1
            del arg86_1
            assert_size_stride_grouped((arg88_1, arg87_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf105 = buf87; del buf87  # reuse
            # Topologically Sorted Source Nodes: [linear_31], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg88_1, reinterpret_tensor(buf103, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg87_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf105)
            del arg87_1
            del arg88_1
            assert_size_stride(arg91_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg91_1 = copy_if_misaligned(arg91_1)
            buf106 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_8, sin_8, linear_31, view_16, key_states_5, mul_51, x2_11, neg_11, x1_11, cat_22, mul_52, k_embed_5, key_tensors_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg91_1, buf105, arg4_1, arg3_1, arg5_1.item(), buf106, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg91_1
            assert_size_stride_grouped((arg90_1, arg89_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf107 = buf105; del buf105  # reuse
            # Topologically Sorted Source Nodes: [linear_32], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg90_1, reinterpret_tensor(buf103, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg89_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf107)
            del arg89_1
            del arg90_1
            assert_size_stride(arg92_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg92_1 = copy_if_misaligned(arg92_1)
            buf108 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_32, view_17, value_states_5, value_tensors_5], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg92_1, buf107, buf108, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg92_1
            buf109 = reinterpret_tensor(buf103, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf103  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_30, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_21, sin_8, mul_50, q_embed_5, packed_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf104, arg4_1, arg3_1, arg5_1.item(), buf109, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf104
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_30, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_21, sin_8, mul_50, q_embed_5, packed_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf110 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf109, buf106, buf108, None, False, scale=0.08838834764831845)
            buf111 = buf110[0]
            assert_tensor_metadata(buf111, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf111, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf110
            buf115 = buf109; del buf109  # reuse
            # Topologically Sorted Source Nodes: [attn_output_20], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf111, buf115, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg93_1, (1536, 1536), (1536, 1), 'input')
            buf116 = reinterpret_tensor(buf111, (s16, 1536), (1536, 1), 0); del buf111  # reuse
            # Topologically Sorted Source Nodes: [attn_output_20, transpose_24, reshape_17, attn_output_23], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf115, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg93_1, (1536, 1536), (1, 1536), 0), out=buf116)
            del arg93_1
            assert_size_stride_grouped((arg95_1, arg94_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf117 = buf76; del buf76  # reuse
            buf119 = reinterpret_tensor(buf115, (s16, 1, 1536), (1536, 1536, 1), 0); del buf115  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_34, hidden_states_35, attn_output_19, hidden_states_39, hidden_states_43, hidden_states_44, attn_output_23, hidden_states_48, pow_12, variance_11, rsqrt_11, hidden_states_50, hidden_states_51], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf117, buf81, buf96, buf101, buf116, arg95_1, arg94_1.item(), buf119, s16, 1536, stream=raw_stream0)
            del arg94_1
            del arg95_1
            del buf101
            assert_size_stride(arg96_1, (17920, 1536), (1536, 1), 'input')
            buf120 = buf99; del buf99  # reuse
            # Topologically Sorted Source Nodes: [pow_12, variance_11, rsqrt_11, hidden_states_50, hidden_states_51, linear_34], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf119, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg96_1, (1536, 17920), (1, 1536), 0), out=buf120)
            del arg96_1
            buf121 = buf100; del buf100  # reuse
            # Topologically Sorted Source Nodes: [linear_34, split_5, silu_5, mul_55], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf120, buf121, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg97_1, (1536, 8960), (8960, 1), 'input')
            buf122 = reinterpret_tensor(buf119, (s16, 1536), (1536, 1), 0); del buf119  # reuse
            # Topologically Sorted Source Nodes: [linear_34, split_5, silu_5, mul_55, hidden_states_52], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf121, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg97_1, (8960, 1536), (1, 8960), 0), out=buf122)
            del arg97_1
            assert_size_stride_grouped((arg99_1, arg98_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf124 = reinterpret_tensor(buf96, (s16, 1, 1536), (1536, 1536, 1), 0); del buf96  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_52, hidden_states_53, pow_13, variance_12, rsqrt_12, hidden_states_55, hidden_states_56], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf117, buf122, arg99_1, arg98_1.item(), buf124, s16, 1536, stream=raw_stream0)
            del arg98_1
            del arg99_1
            assert_size_stride_grouped((arg101_1, arg100_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf125 = buf81; del buf81  # reuse
            # Topologically Sorted Source Nodes: [linear_36], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg101_1, reinterpret_tensor(buf124, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg100_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf125)
            del arg100_1
            del arg101_1
            assert_size_stride_grouped((arg103_1, arg102_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf126 = buf107; del buf107  # reuse
            # Topologically Sorted Source Nodes: [linear_37], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg103_1, reinterpret_tensor(buf124, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg102_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf126)
            del arg102_1
            del arg103_1
            assert_size_stride(arg106_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg106_1 = copy_if_misaligned(arg106_1)
            buf127 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_9, sin_9, linear_37, view_19, key_states_6, mul_60, x2_13, neg_13, x1_13, cat_26, mul_61, k_embed_6, key_tensors_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg106_1, buf126, arg4_1, arg3_1, arg5_1.item(), buf127, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg106_1
            assert_size_stride_grouped((arg105_1, arg104_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf128 = buf126; del buf126  # reuse
            # Topologically Sorted Source Nodes: [linear_38], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg105_1, reinterpret_tensor(buf124, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg104_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf128)
            del arg104_1
            del arg105_1
            assert_size_stride(arg107_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg107_1 = copy_if_misaligned(arg107_1)
            buf129 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_38, view_20, value_states_6, value_tensors_6], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg107_1, buf128, buf129, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg107_1
            buf130 = reinterpret_tensor(buf124, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf124  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_36, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_25, sin_9, mul_59, q_embed_6, packed_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf125, arg4_1, arg3_1, arg5_1.item(), buf130, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_36, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_25, sin_9, mul_59, q_embed_6, packed_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf131 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf130, buf127, buf129, None, False, scale=0.08838834764831845)
            buf132 = buf131[0]
            assert_tensor_metadata(buf132, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf132, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf131
            buf136 = buf130; del buf130  # reuse
            # Topologically Sorted Source Nodes: [attn_output_24], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf132, buf136, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg108_1, (1536, 1536), (1536, 1), 'input')
            buf137 = reinterpret_tensor(buf132, (s16, 1536), (1536, 1), 0); del buf132  # reuse
            # Topologically Sorted Source Nodes: [attn_output_24, transpose_28, reshape_20, attn_output_27], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf136, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg108_1, (1536, 1536), (1, 1536), 0), out=buf137)
            del arg108_1
            assert_size_stride_grouped((arg110_1, arg109_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf139 = reinterpret_tensor(buf136, (s16, 1, 1536), (1536, 1536, 1), 0); del buf136  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_52, hidden_states_53, attn_output_27, hidden_states_57, pow_14, variance_13, rsqrt_13, hidden_states_59, hidden_states_60], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf117, buf122, buf137, arg110_1, arg109_1.item(), buf139, s16, 1536, stream=raw_stream0)
            del arg109_1
            del arg110_1
            assert_size_stride(arg111_1, (17920, 1536), (1536, 1), 'input')
            buf140 = buf120; del buf120  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_52, hidden_states_53, attn_output_27, hidden_states_57, pow_14, variance_13, rsqrt_13, hidden_states_59, hidden_states_60, linear_40], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf139, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg111_1, (1536, 17920), (1, 1536), 0), out=buf140)
            del arg111_1
            buf141 = buf121; del buf121  # reuse
            # Topologically Sorted Source Nodes: [linear_40, split_6, silu_6, mul_64], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf140, buf141, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg112_1, (1536, 8960), (8960, 1), 'input')
            buf142 = reinterpret_tensor(buf139, (s16, 1536), (1536, 1), 0); del buf139  # reuse
            # Topologically Sorted Source Nodes: [linear_40, split_6, silu_6, mul_64, hidden_states_61], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf141, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg112_1, (8960, 1536), (1, 8960), 0), out=buf142)
            del arg112_1
            assert_size_stride_grouped((arg114_1, arg113_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf144 = reinterpret_tensor(buf125, (s16, 1, 1536), (1536, 1536, 1), 0); del buf125  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_52, hidden_states_53, attn_output_27, hidden_states_57, hidden_states_61, hidden_states_62, pow_15, variance_14, rsqrt_14, hidden_states_64, hidden_states_65], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf117, buf122, buf137, buf142, arg114_1, arg113_1.item(), buf144, s16, 1536, stream=raw_stream0)
            del arg113_1
            del arg114_1
            assert_size_stride_grouped((arg116_1, arg115_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf145 = buf116; del buf116  # reuse
            # Topologically Sorted Source Nodes: [linear_42], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg116_1, reinterpret_tensor(buf144, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg115_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf145)
            del arg115_1
            del arg116_1
            assert_size_stride_grouped((arg118_1, arg117_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf146 = buf128; del buf128  # reuse
            # Topologically Sorted Source Nodes: [linear_43], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg118_1, reinterpret_tensor(buf144, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg117_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf146)
            del arg117_1
            del arg118_1
            assert_size_stride(arg121_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg121_1 = copy_if_misaligned(arg121_1)
            buf147 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_10, sin_10, linear_43, view_22, key_states_7, mul_69, x2_15, neg_15, x1_15, cat_30, mul_70, k_embed_7, key_tensors_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg121_1, buf146, arg4_1, arg3_1, arg5_1.item(), buf147, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg121_1
            assert_size_stride_grouped((arg120_1, arg119_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf148 = buf146; del buf146  # reuse
            # Topologically Sorted Source Nodes: [linear_44], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg120_1, reinterpret_tensor(buf144, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg119_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf148)
            del arg119_1
            del arg120_1
            assert_size_stride(arg122_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg122_1 = copy_if_misaligned(arg122_1)
            buf149 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_44, view_23, value_states_7, value_tensors_7], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg122_1, buf148, buf149, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg122_1
            buf150 = reinterpret_tensor(buf144, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf144  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_29, sin_10, mul_68, q_embed_7, packed_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf145, arg4_1, arg3_1, arg5_1.item(), buf150, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf145
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_29, sin_10, mul_68, q_embed_7, packed_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf151 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf150, buf147, buf149, None, False, scale=0.08838834764831845)
            buf152 = buf151[0]
            assert_tensor_metadata(buf152, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf152, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf151
            buf156 = buf150; del buf150  # reuse
            # Topologically Sorted Source Nodes: [attn_output_28], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf152, buf156, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg123_1, (1536, 1536), (1536, 1), 'input')
            buf157 = reinterpret_tensor(buf152, (s16, 1536), (1536, 1), 0); del buf152  # reuse
            # Topologically Sorted Source Nodes: [attn_output_28, transpose_32, reshape_23, attn_output_31], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf156, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg123_1, (1536, 1536), (1, 1536), 0), out=buf157)
            del arg123_1
            assert_size_stride_grouped((arg125_1, arg124_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf158 = buf117; del buf117  # reuse
            buf160 = reinterpret_tensor(buf156, (s16, 1, 1536), (1536, 1536, 1), 0); del buf156  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_52, hidden_states_53, attn_output_27, hidden_states_57, hidden_states_61, hidden_states_62, attn_output_31, hidden_states_66, pow_16, variance_15, rsqrt_15, hidden_states_68, hidden_states_69], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf158, buf122, buf137, buf142, buf157, arg125_1, arg124_1.item(), buf160, s16, 1536, stream=raw_stream0)
            del arg124_1
            del arg125_1
            del buf122
            assert_size_stride(arg126_1, (17920, 1536), (1536, 1), 'input')
            buf161 = buf140; del buf140  # reuse
            # Topologically Sorted Source Nodes: [pow_16, variance_15, rsqrt_15, hidden_states_68, hidden_states_69, linear_46], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf160, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg126_1, (1536, 17920), (1, 1536), 0), out=buf161)
            del arg126_1
            buf162 = buf141; del buf141  # reuse
            # Topologically Sorted Source Nodes: [linear_46, split_7, silu_7, mul_73], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf161, buf162, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg127_1, (1536, 8960), (8960, 1), 'input')
            buf163 = reinterpret_tensor(buf160, (s16, 1536), (1536, 1), 0); del buf160  # reuse
            # Topologically Sorted Source Nodes: [linear_46, split_7, silu_7, mul_73, hidden_states_70], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf162, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg127_1, (8960, 1536), (1, 8960), 0), out=buf163)
            del arg127_1
            assert_size_stride_grouped((arg129_1, arg128_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf165 = reinterpret_tensor(buf157, (s16, 1, 1536), (1536, 1536, 1), 0); del buf157  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_70, hidden_states_71, pow_17, variance_16, rsqrt_16, hidden_states_73, hidden_states_74], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf158, buf163, arg129_1, arg128_1.item(), buf165, s16, 1536, stream=raw_stream0)
            del arg128_1
            del arg129_1
            assert_size_stride_grouped((arg131_1, arg130_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf166 = buf142; del buf142  # reuse
            # Topologically Sorted Source Nodes: [linear_48], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg131_1, reinterpret_tensor(buf165, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg130_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf166)
            del arg130_1
            del arg131_1
            assert_size_stride_grouped((arg133_1, arg132_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf167 = buf148; del buf148  # reuse
            # Topologically Sorted Source Nodes: [linear_49], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg133_1, reinterpret_tensor(buf165, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg132_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf167)
            del arg132_1
            del arg133_1
            assert_size_stride(arg136_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg136_1 = copy_if_misaligned(arg136_1)
            buf168 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_11, sin_11, linear_49, view_25, key_states_8, mul_78, x2_17, neg_17, x1_17, cat_34, mul_79, k_embed_8, key_tensors_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg136_1, buf167, arg4_1, arg3_1, arg5_1.item(), buf168, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg136_1
            assert_size_stride_grouped((arg135_1, arg134_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf169 = buf167; del buf167  # reuse
            # Topologically Sorted Source Nodes: [linear_50], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg135_1, reinterpret_tensor(buf165, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg134_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf169)
            del arg134_1
            del arg135_1
            assert_size_stride(arg137_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg137_1 = copy_if_misaligned(arg137_1)
            buf170 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_50, view_26, value_states_8, value_tensors_8], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg137_1, buf169, buf170, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg137_1
            buf171 = reinterpret_tensor(buf165, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf165  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_48, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_33, sin_11, mul_77, q_embed_8, packed_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf166, arg4_1, arg3_1, arg5_1.item(), buf171, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_48, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_33, sin_11, mul_77, q_embed_8, packed_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf172 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf171, buf168, buf170, None, False, scale=0.08838834764831845)
            buf173 = buf172[0]
            assert_tensor_metadata(buf173, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf173, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf172
            buf177 = buf171; del buf171  # reuse
            # Topologically Sorted Source Nodes: [attn_output_32], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf173, buf177, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg138_1, (1536, 1536), (1536, 1), 'input')
            buf178 = reinterpret_tensor(buf173, (s16, 1536), (1536, 1), 0); del buf173  # reuse
            # Topologically Sorted Source Nodes: [attn_output_32, transpose_36, reshape_26, attn_output_35], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf177, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg138_1, (1536, 1536), (1, 1536), 0), out=buf178)
            del arg138_1
            assert_size_stride_grouped((arg140_1, arg139_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf180 = reinterpret_tensor(buf177, (s16, 1, 1536), (1536, 1536, 1), 0); del buf177  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_70, hidden_states_71, attn_output_35, hidden_states_75, pow_18, variance_17, rsqrt_17, hidden_states_77, hidden_states_78], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf158, buf163, buf178, arg140_1, arg139_1.item(), buf180, s16, 1536, stream=raw_stream0)
            del arg139_1
            del arg140_1
            assert_size_stride(arg141_1, (17920, 1536), (1536, 1), 'input')
            buf181 = buf161; del buf161  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_70, hidden_states_71, attn_output_35, hidden_states_75, pow_18, variance_17, rsqrt_17, hidden_states_77, hidden_states_78, linear_52], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf180, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg141_1, (1536, 17920), (1, 1536), 0), out=buf181)
            del arg141_1
            buf182 = buf162; del buf162  # reuse
            # Topologically Sorted Source Nodes: [linear_52, split_8, silu_8, mul_82], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf181, buf182, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg142_1, (1536, 8960), (8960, 1), 'input')
            buf183 = reinterpret_tensor(buf180, (s16, 1536), (1536, 1), 0); del buf180  # reuse
            # Topologically Sorted Source Nodes: [linear_52, split_8, silu_8, mul_82, hidden_states_79], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf182, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg142_1, (8960, 1536), (1, 8960), 0), out=buf183)
            del arg142_1
            assert_size_stride_grouped((arg144_1, arg143_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf185 = reinterpret_tensor(buf166, (s16, 1, 1536), (1536, 1536, 1), 0); del buf166  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_70, hidden_states_71, attn_output_35, hidden_states_75, hidden_states_79, hidden_states_80, pow_19, variance_18, rsqrt_18, hidden_states_82, hidden_states_83], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf158, buf163, buf178, buf183, arg144_1, arg143_1.item(), buf185, s16, 1536, stream=raw_stream0)
            del arg143_1
            del arg144_1
            assert_size_stride_grouped((arg146_1, arg145_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf186 = buf137; del buf137  # reuse
            # Topologically Sorted Source Nodes: [linear_54], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg146_1, reinterpret_tensor(buf185, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg145_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf186)
            del arg145_1
            del arg146_1
            assert_size_stride_grouped((arg148_1, arg147_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf187 = buf169; del buf169  # reuse
            # Topologically Sorted Source Nodes: [linear_55], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg148_1, reinterpret_tensor(buf185, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg147_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf187)
            del arg147_1
            del arg148_1
            assert_size_stride(arg151_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg151_1 = copy_if_misaligned(arg151_1)
            buf188 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_12, sin_12, linear_55, view_28, key_states_9, mul_87, x2_19, neg_19, x1_19, cat_38, mul_88, k_embed_9, key_tensors_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg151_1, buf187, arg4_1, arg3_1, arg5_1.item(), buf188, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg151_1
            assert_size_stride_grouped((arg150_1, arg149_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf189 = buf187; del buf187  # reuse
            # Topologically Sorted Source Nodes: [linear_56], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg150_1, reinterpret_tensor(buf185, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg149_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf189)
            del arg149_1
            del arg150_1
            assert_size_stride(arg152_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg152_1 = copy_if_misaligned(arg152_1)
            buf190 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_56, view_29, value_states_9, value_tensors_9], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg152_1, buf189, buf190, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg152_1
            buf191 = reinterpret_tensor(buf185, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf185  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_54, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_37, sin_12, mul_86, q_embed_9, packed_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf186, arg4_1, arg3_1, arg5_1.item(), buf191, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf186
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_54, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_37, sin_12, mul_86, q_embed_9, packed_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf192 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf191, buf188, buf190, None, False, scale=0.08838834764831845)
            buf193 = buf192[0]
            assert_tensor_metadata(buf193, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf193, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf192
            buf197 = buf191; del buf191  # reuse
            # Topologically Sorted Source Nodes: [attn_output_36], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf193, buf197, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg153_1, (1536, 1536), (1536, 1), 'input')
            buf198 = reinterpret_tensor(buf193, (s16, 1536), (1536, 1), 0); del buf193  # reuse
            # Topologically Sorted Source Nodes: [attn_output_36, transpose_40, reshape_29, attn_output_39], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf197, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg153_1, (1536, 1536), (1, 1536), 0), out=buf198)
            del arg153_1
            assert_size_stride_grouped((arg155_1, arg154_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf199 = buf158; del buf158  # reuse
            buf201 = reinterpret_tensor(buf197, (s16, 1, 1536), (1536, 1536, 1), 0); del buf197  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_70, hidden_states_71, attn_output_35, hidden_states_75, hidden_states_79, hidden_states_80, attn_output_39, hidden_states_84, pow_20, variance_19, rsqrt_19, hidden_states_86, hidden_states_87], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf199, buf163, buf178, buf183, buf198, arg155_1, arg154_1.item(), buf201, s16, 1536, stream=raw_stream0)
            del arg154_1
            del arg155_1
            del buf163
            assert_size_stride(arg156_1, (17920, 1536), (1536, 1), 'input')
            buf202 = buf181; del buf181  # reuse
            # Topologically Sorted Source Nodes: [pow_20, variance_19, rsqrt_19, hidden_states_86, hidden_states_87, linear_58], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf201, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg156_1, (1536, 17920), (1, 1536), 0), out=buf202)
            del arg156_1
            buf203 = buf182; del buf182  # reuse
            # Topologically Sorted Source Nodes: [linear_58, split_9, silu_9, mul_91], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf202, buf203, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg157_1, (1536, 8960), (8960, 1), 'input')
            buf204 = reinterpret_tensor(buf201, (s16, 1536), (1536, 1), 0); del buf201  # reuse
            # Topologically Sorted Source Nodes: [linear_58, split_9, silu_9, mul_91, hidden_states_88], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf203, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg157_1, (8960, 1536), (1, 8960), 0), out=buf204)
            del arg157_1
            assert_size_stride_grouped((arg159_1, arg158_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf206 = reinterpret_tensor(buf198, (s16, 1, 1536), (1536, 1536, 1), 0); del buf198  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_88, hidden_states_89, pow_21, variance_20, rsqrt_20, hidden_states_91, hidden_states_92], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf199, buf204, arg159_1, arg158_1.item(), buf206, s16, 1536, stream=raw_stream0)
            del arg158_1
            del arg159_1
            assert_size_stride_grouped((arg161_1, arg160_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf207 = buf183; del buf183  # reuse
            # Topologically Sorted Source Nodes: [linear_60], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg161_1, reinterpret_tensor(buf206, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg160_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf207)
            del arg160_1
            del arg161_1
            assert_size_stride_grouped((arg163_1, arg162_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf208 = buf189; del buf189  # reuse
            # Topologically Sorted Source Nodes: [linear_61], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg163_1, reinterpret_tensor(buf206, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg162_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf208)
            del arg162_1
            del arg163_1
            assert_size_stride(arg166_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg166_1 = copy_if_misaligned(arg166_1)
            buf209 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_13, sin_13, linear_61, view_31, key_states_10, mul_96, x2_21, neg_21, x1_21, cat_42, mul_97, k_embed_10, key_tensors_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg166_1, buf208, arg4_1, arg3_1, arg5_1.item(), buf209, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg166_1
            assert_size_stride_grouped((arg165_1, arg164_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf210 = buf208; del buf208  # reuse
            # Topologically Sorted Source Nodes: [linear_62], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg165_1, reinterpret_tensor(buf206, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg164_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf210)
            del arg164_1
            del arg165_1
            assert_size_stride(arg167_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg167_1 = copy_if_misaligned(arg167_1)
            buf211 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_62, view_32, value_states_10, value_tensors_10], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg167_1, buf210, buf211, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg167_1
            buf212 = reinterpret_tensor(buf206, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf206  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_60, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_41, sin_13, mul_95, q_embed_10, packed_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf207, arg4_1, arg3_1, arg5_1.item(), buf212, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_60, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_41, sin_13, mul_95, q_embed_10, packed_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf213 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf212, buf209, buf211, None, False, scale=0.08838834764831845)
            buf214 = buf213[0]
            assert_tensor_metadata(buf214, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf214, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf213
            buf218 = buf212; del buf212  # reuse
            # Topologically Sorted Source Nodes: [attn_output_40], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf214, buf218, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg168_1, (1536, 1536), (1536, 1), 'input')
            buf219 = reinterpret_tensor(buf214, (s16, 1536), (1536, 1), 0); del buf214  # reuse
            # Topologically Sorted Source Nodes: [attn_output_40, transpose_44, reshape_32, attn_output_43], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf218, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg168_1, (1536, 1536), (1, 1536), 0), out=buf219)
            del arg168_1
            assert_size_stride_grouped((arg170_1, arg169_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf221 = reinterpret_tensor(buf218, (s16, 1, 1536), (1536, 1536, 1), 0); del buf218  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_88, hidden_states_89, attn_output_43, hidden_states_93, pow_22, variance_21, rsqrt_21, hidden_states_95, hidden_states_96], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf199, buf204, buf219, arg170_1, arg169_1.item(), buf221, s16, 1536, stream=raw_stream0)
            del arg169_1
            del arg170_1
            assert_size_stride(arg171_1, (17920, 1536), (1536, 1), 'input')
            buf222 = buf202; del buf202  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_88, hidden_states_89, attn_output_43, hidden_states_93, pow_22, variance_21, rsqrt_21, hidden_states_95, hidden_states_96, linear_64], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf221, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg171_1, (1536, 17920), (1, 1536), 0), out=buf222)
            del arg171_1
            buf223 = buf203; del buf203  # reuse
            # Topologically Sorted Source Nodes: [linear_64, split_10, silu_10, mul_100], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf222, buf223, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg172_1, (1536, 8960), (8960, 1), 'input')
            buf224 = reinterpret_tensor(buf221, (s16, 1536), (1536, 1), 0); del buf221  # reuse
            # Topologically Sorted Source Nodes: [linear_64, split_10, silu_10, mul_100, hidden_states_97], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf223, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg172_1, (8960, 1536), (1, 8960), 0), out=buf224)
            del arg172_1
            assert_size_stride_grouped((arg174_1, arg173_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf226 = reinterpret_tensor(buf207, (s16, 1, 1536), (1536, 1536, 1), 0); del buf207  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_88, hidden_states_89, attn_output_43, hidden_states_93, hidden_states_97, hidden_states_98, pow_23, variance_22, rsqrt_22, hidden_states_100, hidden_states_101], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf199, buf204, buf219, buf224, arg174_1, arg173_1.item(), buf226, s16, 1536, stream=raw_stream0)
            del arg173_1
            del arg174_1
            assert_size_stride_grouped((arg176_1, arg175_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf227 = buf178; del buf178  # reuse
            # Topologically Sorted Source Nodes: [linear_66], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg176_1, reinterpret_tensor(buf226, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg175_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf227)
            del arg175_1
            del arg176_1
            assert_size_stride_grouped((arg178_1, arg177_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf228 = buf210; del buf210  # reuse
            # Topologically Sorted Source Nodes: [linear_67], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg178_1, reinterpret_tensor(buf226, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg177_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf228)
            del arg177_1
            del arg178_1
            assert_size_stride(arg181_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg181_1 = copy_if_misaligned(arg181_1)
            buf229 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_14, sin_14, linear_67, view_34, key_states_11, mul_105, x2_23, neg_23, x1_23, cat_46, mul_106, k_embed_11, key_tensors_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg181_1, buf228, arg4_1, arg3_1, arg5_1.item(), buf229, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg181_1
            assert_size_stride_grouped((arg180_1, arg179_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf230 = buf228; del buf228  # reuse
            # Topologically Sorted Source Nodes: [linear_68], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg180_1, reinterpret_tensor(buf226, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg179_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf230)
            del arg179_1
            del arg180_1
            assert_size_stride(arg182_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg182_1 = copy_if_misaligned(arg182_1)
            buf231 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_68, view_35, value_states_11, value_tensors_11], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg182_1, buf230, buf231, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg182_1
            buf232 = reinterpret_tensor(buf226, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf226  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_66, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_45, sin_14, mul_104, q_embed_11, packed_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf227, arg4_1, arg3_1, arg5_1.item(), buf232, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf227
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_66, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_45, sin_14, mul_104, q_embed_11, packed_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf233 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf232, buf229, buf231, None, False, scale=0.08838834764831845)
            buf234 = buf233[0]
            assert_tensor_metadata(buf234, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf234, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf233
            buf238 = buf232; del buf232  # reuse
            # Topologically Sorted Source Nodes: [attn_output_44], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf234, buf238, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg183_1, (1536, 1536), (1536, 1), 'input')
            buf239 = reinterpret_tensor(buf234, (s16, 1536), (1536, 1), 0); del buf234  # reuse
            # Topologically Sorted Source Nodes: [attn_output_44, transpose_48, reshape_35, attn_output_47], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf238, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg183_1, (1536, 1536), (1, 1536), 0), out=buf239)
            del arg183_1
            assert_size_stride_grouped((arg185_1, arg184_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf240 = buf199; del buf199  # reuse
            buf242 = reinterpret_tensor(buf238, (s16, 1, 1536), (1536, 1536, 1), 0); del buf238  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_88, hidden_states_89, attn_output_43, hidden_states_93, hidden_states_97, hidden_states_98, attn_output_47, hidden_states_102, pow_24, variance_23, rsqrt_23, hidden_states_104, hidden_states_105], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf240, buf204, buf219, buf224, buf239, arg185_1, arg184_1.item(), buf242, s16, 1536, stream=raw_stream0)
            del arg184_1
            del arg185_1
            del buf204
            assert_size_stride(arg186_1, (17920, 1536), (1536, 1), 'input')
            buf243 = buf222; del buf222  # reuse
            # Topologically Sorted Source Nodes: [pow_24, variance_23, rsqrt_23, hidden_states_104, hidden_states_105, linear_70], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf242, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg186_1, (1536, 17920), (1, 1536), 0), out=buf243)
            del arg186_1
            buf244 = buf223; del buf223  # reuse
            # Topologically Sorted Source Nodes: [linear_70, split_11, silu_11, mul_109], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf243, buf244, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg187_1, (1536, 8960), (8960, 1), 'input')
            buf245 = reinterpret_tensor(buf242, (s16, 1536), (1536, 1), 0); del buf242  # reuse
            # Topologically Sorted Source Nodes: [linear_70, split_11, silu_11, mul_109, hidden_states_106], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf244, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg187_1, (8960, 1536), (1, 8960), 0), out=buf245)
            del arg187_1
            assert_size_stride_grouped((arg189_1, arg188_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf247 = reinterpret_tensor(buf239, (s16, 1, 1536), (1536, 1536, 1), 0); del buf239  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_106, hidden_states_107, pow_25, variance_24, rsqrt_24, hidden_states_109, hidden_states_110], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf240, buf245, arg189_1, arg188_1.item(), buf247, s16, 1536, stream=raw_stream0)
            del arg188_1
            del arg189_1
            assert_size_stride_grouped((arg191_1, arg190_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf248 = buf224; del buf224  # reuse
            # Topologically Sorted Source Nodes: [linear_72], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg191_1, reinterpret_tensor(buf247, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg190_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf248)
            del arg190_1
            del arg191_1
            assert_size_stride_grouped((arg193_1, arg192_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf249 = buf230; del buf230  # reuse
            # Topologically Sorted Source Nodes: [linear_73], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg193_1, reinterpret_tensor(buf247, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg192_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf249)
            del arg192_1
            del arg193_1
            assert_size_stride(arg196_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg196_1 = copy_if_misaligned(arg196_1)
            buf250 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_15, sin_15, linear_73, view_37, key_states_12, mul_114, x2_25, neg_25, x1_25, cat_50, mul_115, k_embed_12, key_tensors_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg196_1, buf249, arg4_1, arg3_1, arg5_1.item(), buf250, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg196_1
            assert_size_stride_grouped((arg195_1, arg194_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf251 = buf249; del buf249  # reuse
            # Topologically Sorted Source Nodes: [linear_74], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg195_1, reinterpret_tensor(buf247, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg194_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf251)
            del arg194_1
            del arg195_1
            assert_size_stride(arg197_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg197_1 = copy_if_misaligned(arg197_1)
            buf252 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_74, view_38, value_states_12, value_tensors_12], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg197_1, buf251, buf252, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg197_1
            buf253 = reinterpret_tensor(buf247, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf247  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_72, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_49, sin_15, mul_113, q_embed_12, packed_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf248, arg4_1, arg3_1, arg5_1.item(), buf253, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_72, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_49, sin_15, mul_113, q_embed_12, packed_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf254 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf253, buf250, buf252, None, False, scale=0.08838834764831845)
            buf255 = buf254[0]
            assert_tensor_metadata(buf255, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf255, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf254
            buf259 = buf253; del buf253  # reuse
            # Topologically Sorted Source Nodes: [attn_output_48], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf255, buf259, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg198_1, (1536, 1536), (1536, 1), 'input')
            buf260 = reinterpret_tensor(buf255, (s16, 1536), (1536, 1), 0); del buf255  # reuse
            # Topologically Sorted Source Nodes: [attn_output_48, transpose_52, reshape_38, attn_output_51], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf259, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg198_1, (1536, 1536), (1, 1536), 0), out=buf260)
            del arg198_1
            assert_size_stride_grouped((arg200_1, arg199_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf262 = reinterpret_tensor(buf259, (s16, 1, 1536), (1536, 1536, 1), 0); del buf259  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_106, hidden_states_107, attn_output_51, hidden_states_111, pow_26, variance_25, rsqrt_25, hidden_states_113, hidden_states_114], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf240, buf245, buf260, arg200_1, arg199_1.item(), buf262, s16, 1536, stream=raw_stream0)
            del arg199_1
            del arg200_1
            assert_size_stride(arg201_1, (17920, 1536), (1536, 1), 'input')
            buf263 = buf243; del buf243  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_106, hidden_states_107, attn_output_51, hidden_states_111, pow_26, variance_25, rsqrt_25, hidden_states_113, hidden_states_114, linear_76], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf262, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg201_1, (1536, 17920), (1, 1536), 0), out=buf263)
            del arg201_1
            buf264 = buf244; del buf244  # reuse
            # Topologically Sorted Source Nodes: [linear_76, split_12, silu_12, mul_118], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf263, buf264, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg202_1, (1536, 8960), (8960, 1), 'input')
            buf265 = reinterpret_tensor(buf262, (s16, 1536), (1536, 1), 0); del buf262  # reuse
            # Topologically Sorted Source Nodes: [linear_76, split_12, silu_12, mul_118, hidden_states_115], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf264, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg202_1, (8960, 1536), (1, 8960), 0), out=buf265)
            del arg202_1
            assert_size_stride_grouped((arg204_1, arg203_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf267 = reinterpret_tensor(buf248, (s16, 1, 1536), (1536, 1536, 1), 0); del buf248  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_106, hidden_states_107, attn_output_51, hidden_states_111, hidden_states_115, hidden_states_116, pow_27, variance_26, rsqrt_26, hidden_states_118, hidden_states_119], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf240, buf245, buf260, buf265, arg204_1, arg203_1.item(), buf267, s16, 1536, stream=raw_stream0)
            del arg203_1
            del arg204_1
            assert_size_stride_grouped((arg206_1, arg205_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf268 = buf219; del buf219  # reuse
            # Topologically Sorted Source Nodes: [linear_78], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg206_1, reinterpret_tensor(buf267, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg205_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf268)
            del arg205_1
            del arg206_1
            assert_size_stride_grouped((arg208_1, arg207_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf269 = buf251; del buf251  # reuse
            # Topologically Sorted Source Nodes: [linear_79], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg208_1, reinterpret_tensor(buf267, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg207_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf269)
            del arg207_1
            del arg208_1
            assert_size_stride(arg211_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg211_1 = copy_if_misaligned(arg211_1)
            buf270 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_16, sin_16, linear_79, view_40, key_states_13, mul_123, x2_27, neg_27, x1_27, cat_54, mul_124, k_embed_13, key_tensors_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg211_1, buf269, arg4_1, arg3_1, arg5_1.item(), buf270, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg211_1
            assert_size_stride_grouped((arg210_1, arg209_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf271 = buf269; del buf269  # reuse
            # Topologically Sorted Source Nodes: [linear_80], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg210_1, reinterpret_tensor(buf267, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg209_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf271)
            del arg209_1
            del arg210_1
            assert_size_stride(arg212_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg212_1 = copy_if_misaligned(arg212_1)
            buf272 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_80, view_41, value_states_13, value_tensors_13], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg212_1, buf271, buf272, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg212_1
            buf273 = reinterpret_tensor(buf267, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf267  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_78, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_53, sin_16, mul_122, q_embed_13, packed_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf268, arg4_1, arg3_1, arg5_1.item(), buf273, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf268
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_78, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_53, sin_16, mul_122, q_embed_13, packed_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf274 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf273, buf270, buf272, None, False, scale=0.08838834764831845)
            buf275 = buf274[0]
            assert_tensor_metadata(buf275, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf275, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf274
            buf279 = buf273; del buf273  # reuse
            # Topologically Sorted Source Nodes: [attn_output_52], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf275, buf279, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg213_1, (1536, 1536), (1536, 1), 'input')
            buf280 = reinterpret_tensor(buf275, (s16, 1536), (1536, 1), 0); del buf275  # reuse
            # Topologically Sorted Source Nodes: [attn_output_52, transpose_56, reshape_41, attn_output_55], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf279, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg213_1, (1536, 1536), (1, 1536), 0), out=buf280)
            del arg213_1
            assert_size_stride_grouped((arg215_1, arg214_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf281 = buf240; del buf240  # reuse
            buf283 = reinterpret_tensor(buf279, (s16, 1, 1536), (1536, 1536, 1), 0); del buf279  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_106, hidden_states_107, attn_output_51, hidden_states_111, hidden_states_115, hidden_states_116, attn_output_55, hidden_states_120, pow_28, variance_27, rsqrt_27, hidden_states_122, hidden_states_123], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf281, buf245, buf260, buf265, buf280, arg215_1, arg214_1.item(), buf283, s16, 1536, stream=raw_stream0)
            del arg214_1
            del arg215_1
            del buf245
            assert_size_stride(arg216_1, (17920, 1536), (1536, 1), 'input')
            buf284 = buf263; del buf263  # reuse
            # Topologically Sorted Source Nodes: [pow_28, variance_27, rsqrt_27, hidden_states_122, hidden_states_123, linear_82], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf283, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg216_1, (1536, 17920), (1, 1536), 0), out=buf284)
            del arg216_1
            buf285 = buf264; del buf264  # reuse
            # Topologically Sorted Source Nodes: [linear_82, split_13, silu_13, mul_127], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf284, buf285, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg217_1, (1536, 8960), (8960, 1), 'input')
            buf286 = reinterpret_tensor(buf283, (s16, 1536), (1536, 1), 0); del buf283  # reuse
            # Topologically Sorted Source Nodes: [linear_82, split_13, silu_13, mul_127, hidden_states_124], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf285, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg217_1, (8960, 1536), (1, 8960), 0), out=buf286)
            del arg217_1
            assert_size_stride_grouped((arg219_1, arg218_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf288 = reinterpret_tensor(buf280, (s16, 1, 1536), (1536, 1536, 1), 0); del buf280  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, pow_29, variance_28, rsqrt_28, hidden_states_127, hidden_states_128], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf281, buf286, arg219_1, arg218_1.item(), buf288, s16, 1536, stream=raw_stream0)
            del arg218_1
            del arg219_1
            assert_size_stride_grouped((arg221_1, arg220_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf289 = buf265; del buf265  # reuse
            # Topologically Sorted Source Nodes: [linear_84], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg221_1, reinterpret_tensor(buf288, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg220_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf289)
            del arg220_1
            del arg221_1
            assert_size_stride_grouped((arg223_1, arg222_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf290 = buf271; del buf271  # reuse
            # Topologically Sorted Source Nodes: [linear_85], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg223_1, reinterpret_tensor(buf288, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg222_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf290)
            del arg222_1
            del arg223_1
            assert_size_stride(arg226_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg226_1 = copy_if_misaligned(arg226_1)
            buf291 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_17, sin_17, linear_85, view_43, key_states_14, mul_132, x2_29, neg_29, x1_29, cat_58, mul_133, k_embed_14, key_tensors_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg226_1, buf290, arg4_1, arg3_1, arg5_1.item(), buf291, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg226_1
            assert_size_stride_grouped((arg225_1, arg224_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf292 = buf290; del buf290  # reuse
            # Topologically Sorted Source Nodes: [linear_86], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg225_1, reinterpret_tensor(buf288, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg224_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf292)
            del arg224_1
            del arg225_1
            assert_size_stride(arg227_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg227_1 = copy_if_misaligned(arg227_1)
            buf293 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_86, view_44, value_states_14, value_tensors_14], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg227_1, buf292, buf293, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg227_1
            buf294 = reinterpret_tensor(buf288, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf288  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_57, sin_17, mul_131, q_embed_14, packed_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf289, arg4_1, arg3_1, arg5_1.item(), buf294, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_57, sin_17, mul_131, q_embed_14, packed_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf295 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf294, buf291, buf293, None, False, scale=0.08838834764831845)
            buf296 = buf295[0]
            assert_tensor_metadata(buf296, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf296, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf295
            buf300 = buf294; del buf294  # reuse
            # Topologically Sorted Source Nodes: [attn_output_56], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf296, buf300, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg228_1, (1536, 1536), (1536, 1), 'input')
            buf301 = reinterpret_tensor(buf296, (s16, 1536), (1536, 1), 0); del buf296  # reuse
            # Topologically Sorted Source Nodes: [attn_output_56, transpose_60, reshape_44, attn_output_59], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf300, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg228_1, (1536, 1536), (1, 1536), 0), out=buf301)
            del arg228_1
            assert_size_stride_grouped((arg230_1, arg229_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf303 = reinterpret_tensor(buf300, (s16, 1, 1536), (1536, 1536, 1), 0); del buf300  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, attn_output_59, hidden_states_129, pow_30, variance_29, rsqrt_29, hidden_states_131, hidden_states_132], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf281, buf286, buf301, arg230_1, arg229_1.item(), buf303, s16, 1536, stream=raw_stream0)
            del arg229_1
            del arg230_1
            assert_size_stride(arg231_1, (17920, 1536), (1536, 1), 'input')
            buf304 = buf284; del buf284  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, attn_output_59, hidden_states_129, pow_30, variance_29, rsqrt_29, hidden_states_131, hidden_states_132, linear_88], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf303, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg231_1, (1536, 17920), (1, 1536), 0), out=buf304)
            del arg231_1
            buf305 = buf285; del buf285  # reuse
            # Topologically Sorted Source Nodes: [linear_88, split_14, silu_14, mul_136], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf304, buf305, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg232_1, (1536, 8960), (8960, 1), 'input')
            buf306 = reinterpret_tensor(buf303, (s16, 1536), (1536, 1), 0); del buf303  # reuse
            # Topologically Sorted Source Nodes: [linear_88, split_14, silu_14, mul_136, hidden_states_133], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf305, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg232_1, (8960, 1536), (1, 8960), 0), out=buf306)
            del arg232_1
            assert_size_stride(arg233_1, (1536, ), (1, ), 'input')
            buf308 = reinterpret_tensor(buf289, (s16, 1, 1536), (1536, 1536, 1), 0); del buf289  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, attn_output_59, hidden_states_129, hidden_states_133, hidden_states_134, pow_31, variance_30, add_90, rsqrt_30, hidden_states_136, hidden_states_137], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf281, buf286, buf301, buf306, arg233_1, buf308, s16, 1536, stream=raw_stream0)
            del arg233_1
            assert_size_stride_grouped((arg235_1, arg234_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf309 = buf260; del buf260  # reuse
            # Topologically Sorted Source Nodes: [linear_90], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg235_1, reinterpret_tensor(buf308, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg234_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf309)
            del arg234_1
            del arg235_1
            assert_size_stride_grouped((arg237_1, arg236_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf310 = buf292; del buf292  # reuse
            # Topologically Sorted Source Nodes: [linear_91], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg237_1, reinterpret_tensor(buf308, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg236_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf310)
            del arg236_1
            del arg237_1
            assert_size_stride(arg240_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg240_1 = copy_if_misaligned(arg240_1)
            buf311 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_18, sin_18, linear_91, view_46, key_states_15, mul_141, x2_31, neg_31, x1_31, cat_62, mul_142, k_embed_15, key_tensors_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg240_1, buf310, arg4_1, arg3_1, arg5_1.item(), buf311, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg240_1
            assert_size_stride_grouped((arg239_1, arg238_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf312 = buf310; del buf310  # reuse
            # Topologically Sorted Source Nodes: [linear_92], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg239_1, reinterpret_tensor(buf308, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg238_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf312)
            del arg238_1
            del arg239_1
            assert_size_stride(arg241_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg241_1 = copy_if_misaligned(arg241_1)
            buf313 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_92, view_47, value_states_15, value_tensors_15], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg241_1, buf312, buf313, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg241_1
            buf314 = reinterpret_tensor(buf308, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf308  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_90, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_61, sin_18, mul_140, q_embed_15, packed_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf309, arg4_1, arg3_1, arg5_1.item(), buf314, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf309
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_90, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_61, sin_18, mul_140, q_embed_15, packed_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf315 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf314, buf311, buf313, None, False, scale=0.08838834764831845)
            buf316 = buf315[0]
            assert_tensor_metadata(buf316, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf316, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf315
            buf320 = buf314; del buf314  # reuse
            # Topologically Sorted Source Nodes: [attn_output_60], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf316, buf320, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg242_1, (1536, 1536), (1536, 1), 'input')
            buf321 = reinterpret_tensor(buf316, (s16, 1536), (1536, 1), 0); del buf316  # reuse
            # Topologically Sorted Source Nodes: [attn_output_60, transpose_64, reshape_47, attn_output_63], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf320, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg242_1, (1536, 1536), (1, 1536), 0), out=buf321)
            del arg242_1
            assert_size_stride_grouped((arg244_1, arg243_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf322 = buf281; del buf281  # reuse
            buf324 = reinterpret_tensor(buf320, (s16, 1, 1536), (1536, 1536, 1), 0); del buf320  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_124, hidden_states_125, attn_output_59, hidden_states_129, hidden_states_133, hidden_states_134, attn_output_63, hidden_states_138, pow_32, variance_31, rsqrt_31, hidden_states_140, hidden_states_141], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf322, buf286, buf301, buf306, buf321, arg244_1, arg243_1.item(), buf324, s16, 1536, stream=raw_stream0)
            del arg243_1
            del arg244_1
            del buf286
            assert_size_stride(arg245_1, (17920, 1536), (1536, 1), 'input')
            buf325 = buf304; del buf304  # reuse
            # Topologically Sorted Source Nodes: [pow_32, variance_31, rsqrt_31, hidden_states_140, hidden_states_141, linear_94], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf324, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg245_1, (1536, 17920), (1, 1536), 0), out=buf325)
            del arg245_1
            buf326 = buf305; del buf305  # reuse
            # Topologically Sorted Source Nodes: [linear_94, split_15, silu_15, mul_145], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf325, buf326, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg246_1, (1536, 8960), (8960, 1), 'input')
            buf327 = reinterpret_tensor(buf324, (s16, 1536), (1536, 1), 0); del buf324  # reuse
            # Topologically Sorted Source Nodes: [linear_94, split_15, silu_15, mul_145, hidden_states_142], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf326, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg246_1, (8960, 1536), (1, 8960), 0), out=buf327)
            del arg246_1
            assert_size_stride_grouped((arg248_1, arg247_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf329 = reinterpret_tensor(buf321, (s16, 1, 1536), (1536, 1536, 1), 0); del buf321  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_142, hidden_states_143, pow_33, variance_32, rsqrt_32, hidden_states_145, hidden_states_146], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf322, buf327, arg248_1, arg247_1.item(), buf329, s16, 1536, stream=raw_stream0)
            del arg247_1
            del arg248_1
            assert_size_stride_grouped((arg250_1, arg249_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf330 = buf306; del buf306  # reuse
            # Topologically Sorted Source Nodes: [linear_96], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg250_1, reinterpret_tensor(buf329, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg249_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf330)
            del arg249_1
            del arg250_1
            assert_size_stride_grouped((arg252_1, arg251_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf331 = buf312; del buf312  # reuse
            # Topologically Sorted Source Nodes: [linear_97], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg252_1, reinterpret_tensor(buf329, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg251_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf331)
            del arg251_1
            del arg252_1
            assert_size_stride(arg255_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg255_1 = copy_if_misaligned(arg255_1)
            buf332 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_19, sin_19, linear_97, view_49, key_states_16, mul_150, x2_33, neg_33, x1_33, cat_66, mul_151, k_embed_16, key_tensors_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg255_1, buf331, arg4_1, arg3_1, arg5_1.item(), buf332, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg255_1
            assert_size_stride_grouped((arg254_1, arg253_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf333 = buf331; del buf331  # reuse
            # Topologically Sorted Source Nodes: [linear_98], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg254_1, reinterpret_tensor(buf329, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg253_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf333)
            del arg253_1
            del arg254_1
            assert_size_stride(arg256_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg256_1 = copy_if_misaligned(arg256_1)
            buf334 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_98, view_50, value_states_16, value_tensors_16], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg256_1, buf333, buf334, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg256_1
            buf335 = reinterpret_tensor(buf329, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf329  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_96, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_65, sin_19, mul_149, q_embed_16, packed_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf330, arg4_1, arg3_1, arg5_1.item(), buf335, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_96, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_65, sin_19, mul_149, q_embed_16, packed_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf336 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf335, buf332, buf334, None, False, scale=0.08838834764831845)
            buf337 = buf336[0]
            assert_tensor_metadata(buf337, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf337, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf336
            buf341 = buf335; del buf335  # reuse
            # Topologically Sorted Source Nodes: [attn_output_64], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf337, buf341, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg257_1, (1536, 1536), (1536, 1), 'input')
            buf342 = reinterpret_tensor(buf337, (s16, 1536), (1536, 1), 0); del buf337  # reuse
            # Topologically Sorted Source Nodes: [attn_output_64, transpose_68, reshape_50, attn_output_67], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf341, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg257_1, (1536, 1536), (1, 1536), 0), out=buf342)
            del arg257_1
            assert_size_stride_grouped((arg259_1, arg258_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf344 = reinterpret_tensor(buf341, (s16, 1, 1536), (1536, 1536, 1), 0); del buf341  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_142, hidden_states_143, attn_output_67, hidden_states_147, pow_34, variance_33, rsqrt_33, hidden_states_149, hidden_states_150], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf322, buf327, buf342, arg259_1, arg258_1.item(), buf344, s16, 1536, stream=raw_stream0)
            del arg258_1
            del arg259_1
            assert_size_stride(arg260_1, (17920, 1536), (1536, 1), 'input')
            buf345 = buf325; del buf325  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_142, hidden_states_143, attn_output_67, hidden_states_147, pow_34, variance_33, rsqrt_33, hidden_states_149, hidden_states_150, linear_100], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf344, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg260_1, (1536, 17920), (1, 1536), 0), out=buf345)
            del arg260_1
            buf346 = buf326; del buf326  # reuse
            # Topologically Sorted Source Nodes: [linear_100, split_16, silu_16, mul_154], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf345, buf346, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg261_1, (1536, 8960), (8960, 1), 'input')
            buf347 = reinterpret_tensor(buf344, (s16, 1536), (1536, 1), 0); del buf344  # reuse
            # Topologically Sorted Source Nodes: [linear_100, split_16, silu_16, mul_154, hidden_states_151], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf346, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg261_1, (8960, 1536), (1, 8960), 0), out=buf347)
            del arg261_1
            assert_size_stride_grouped((arg263_1, arg262_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf349 = reinterpret_tensor(buf330, (s16, 1, 1536), (1536, 1536, 1), 0); del buf330  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_142, hidden_states_143, attn_output_67, hidden_states_147, hidden_states_151, hidden_states_152, pow_35, variance_34, rsqrt_34, hidden_states_154, hidden_states_155], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf322, buf327, buf342, buf347, arg263_1, arg262_1.item(), buf349, s16, 1536, stream=raw_stream0)
            del arg262_1
            del arg263_1
            assert_size_stride_grouped((arg265_1, arg264_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf350 = buf301; del buf301  # reuse
            # Topologically Sorted Source Nodes: [linear_102], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg265_1, reinterpret_tensor(buf349, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg264_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf350)
            del arg264_1
            del arg265_1
            assert_size_stride_grouped((arg267_1, arg266_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf351 = buf333; del buf333  # reuse
            # Topologically Sorted Source Nodes: [linear_103], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg267_1, reinterpret_tensor(buf349, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg266_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf351)
            del arg266_1
            del arg267_1
            assert_size_stride(arg270_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg270_1 = copy_if_misaligned(arg270_1)
            buf352 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_20, sin_20, linear_103, view_52, key_states_17, mul_159, x2_35, neg_35, x1_35, cat_70, mul_160, k_embed_17, key_tensors_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg270_1, buf351, arg4_1, arg3_1, arg5_1.item(), buf352, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg270_1
            assert_size_stride_grouped((arg269_1, arg268_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf353 = buf351; del buf351  # reuse
            # Topologically Sorted Source Nodes: [linear_104], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg269_1, reinterpret_tensor(buf349, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg268_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf353)
            del arg268_1
            del arg269_1
            assert_size_stride(arg271_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg271_1 = copy_if_misaligned(arg271_1)
            buf354 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_104, view_53, value_states_17, value_tensors_17], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg271_1, buf353, buf354, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg271_1
            buf355 = reinterpret_tensor(buf349, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf349  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_102, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_69, sin_20, mul_158, q_embed_17, packed_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf350, arg4_1, arg3_1, arg5_1.item(), buf355, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf350
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_102, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_69, sin_20, mul_158, q_embed_17, packed_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf356 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf355, buf352, buf354, None, False, scale=0.08838834764831845)
            buf357 = buf356[0]
            assert_tensor_metadata(buf357, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf357, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf356
            buf361 = buf355; del buf355  # reuse
            # Topologically Sorted Source Nodes: [attn_output_68], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf357, buf361, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg272_1, (1536, 1536), (1536, 1), 'input')
            buf362 = reinterpret_tensor(buf357, (s16, 1536), (1536, 1), 0); del buf357  # reuse
            # Topologically Sorted Source Nodes: [attn_output_68, transpose_72, reshape_53, attn_output_71], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf361, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg272_1, (1536, 1536), (1, 1536), 0), out=buf362)
            del arg272_1
            assert_size_stride_grouped((arg274_1, arg273_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf363 = buf322; del buf322  # reuse
            buf365 = reinterpret_tensor(buf361, (s16, 1, 1536), (1536, 1536, 1), 0); del buf361  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_142, hidden_states_143, attn_output_67, hidden_states_147, hidden_states_151, hidden_states_152, attn_output_71, hidden_states_156, pow_36, variance_35, rsqrt_35, hidden_states_158, hidden_states_159], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf363, buf327, buf342, buf347, buf362, arg274_1, arg273_1.item(), buf365, s16, 1536, stream=raw_stream0)
            del arg273_1
            del arg274_1
            del buf327
            assert_size_stride(arg275_1, (17920, 1536), (1536, 1), 'input')
            buf366 = buf345; del buf345  # reuse
            # Topologically Sorted Source Nodes: [pow_36, variance_35, rsqrt_35, hidden_states_158, hidden_states_159, linear_106], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf365, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg275_1, (1536, 17920), (1, 1536), 0), out=buf366)
            del arg275_1
            buf367 = buf346; del buf346  # reuse
            # Topologically Sorted Source Nodes: [linear_106, split_17, silu_17, mul_163], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf366, buf367, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg276_1, (1536, 8960), (8960, 1), 'input')
            buf368 = reinterpret_tensor(buf365, (s16, 1536), (1536, 1), 0); del buf365  # reuse
            # Topologically Sorted Source Nodes: [linear_106, split_17, silu_17, mul_163, hidden_states_160], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf367, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg276_1, (8960, 1536), (1, 8960), 0), out=buf368)
            del arg276_1
            assert_size_stride_grouped((arg278_1, arg277_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf370 = reinterpret_tensor(buf362, (s16, 1, 1536), (1536, 1536, 1), 0); del buf362  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_160, hidden_states_161, pow_37, variance_36, rsqrt_36, hidden_states_163, hidden_states_164], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf363, buf368, arg278_1, arg277_1.item(), buf370, s16, 1536, stream=raw_stream0)
            del arg277_1
            del arg278_1
            assert_size_stride_grouped((arg280_1, arg279_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf371 = buf347; del buf347  # reuse
            # Topologically Sorted Source Nodes: [linear_108], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg280_1, reinterpret_tensor(buf370, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg279_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf371)
            del arg279_1
            del arg280_1
            assert_size_stride_grouped((arg282_1, arg281_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf372 = buf353; del buf353  # reuse
            # Topologically Sorted Source Nodes: [linear_109], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg282_1, reinterpret_tensor(buf370, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg281_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf372)
            del arg281_1
            del arg282_1
            assert_size_stride(arg285_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg285_1 = copy_if_misaligned(arg285_1)
            buf373 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_21, sin_21, linear_109, view_55, key_states_18, mul_168, x2_37, neg_37, x1_37, cat_74, mul_169, k_embed_18, key_tensors_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg285_1, buf372, arg4_1, arg3_1, arg5_1.item(), buf373, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg285_1
            assert_size_stride_grouped((arg284_1, arg283_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf374 = buf372; del buf372  # reuse
            # Topologically Sorted Source Nodes: [linear_110], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg284_1, reinterpret_tensor(buf370, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg283_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf374)
            del arg283_1
            del arg284_1
            assert_size_stride(arg286_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg286_1 = copy_if_misaligned(arg286_1)
            buf375 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_110, view_56, value_states_18, value_tensors_18], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg286_1, buf374, buf375, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg286_1
            buf376 = reinterpret_tensor(buf370, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf370  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_108, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_73, sin_21, mul_167, q_embed_18, packed_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf371, arg4_1, arg3_1, arg5_1.item(), buf376, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_108, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_73, sin_21, mul_167, q_embed_18, packed_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf377 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf376, buf373, buf375, None, False, scale=0.08838834764831845)
            buf378 = buf377[0]
            assert_tensor_metadata(buf378, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf378, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf377
            buf382 = buf376; del buf376  # reuse
            # Topologically Sorted Source Nodes: [attn_output_72], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf378, buf382, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg287_1, (1536, 1536), (1536, 1), 'input')
            buf383 = reinterpret_tensor(buf378, (s16, 1536), (1536, 1), 0); del buf378  # reuse
            # Topologically Sorted Source Nodes: [attn_output_72, transpose_76, reshape_56, attn_output_75], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf382, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg287_1, (1536, 1536), (1, 1536), 0), out=buf383)
            del arg287_1
            assert_size_stride_grouped((arg289_1, arg288_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf385 = reinterpret_tensor(buf382, (s16, 1, 1536), (1536, 1536, 1), 0); del buf382  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_160, hidden_states_161, attn_output_75, hidden_states_165, pow_38, variance_37, rsqrt_37, hidden_states_167, hidden_states_168], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf363, buf368, buf383, arg289_1, arg288_1.item(), buf385, s16, 1536, stream=raw_stream0)
            del arg288_1
            del arg289_1
            assert_size_stride(arg290_1, (17920, 1536), (1536, 1), 'input')
            buf386 = buf366; del buf366  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_160, hidden_states_161, attn_output_75, hidden_states_165, pow_38, variance_37, rsqrt_37, hidden_states_167, hidden_states_168, linear_112], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf385, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg290_1, (1536, 17920), (1, 1536), 0), out=buf386)
            del arg290_1
            buf387 = buf367; del buf367  # reuse
            # Topologically Sorted Source Nodes: [linear_112, split_18, silu_18, mul_172], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf386, buf387, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg291_1, (1536, 8960), (8960, 1), 'input')
            buf388 = reinterpret_tensor(buf385, (s16, 1536), (1536, 1), 0); del buf385  # reuse
            # Topologically Sorted Source Nodes: [linear_112, split_18, silu_18, mul_172, hidden_states_169], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf387, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg291_1, (8960, 1536), (1, 8960), 0), out=buf388)
            del arg291_1
            assert_size_stride_grouped((arg293_1, arg292_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf390 = reinterpret_tensor(buf371, (s16, 1, 1536), (1536, 1536, 1), 0); del buf371  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_160, hidden_states_161, attn_output_75, hidden_states_165, hidden_states_169, hidden_states_170, pow_39, variance_38, rsqrt_38, hidden_states_172, hidden_states_173], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf363, buf368, buf383, buf388, arg293_1, arg292_1.item(), buf390, s16, 1536, stream=raw_stream0)
            del arg292_1
            del arg293_1
            assert_size_stride_grouped((arg295_1, arg294_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf391 = buf342; del buf342  # reuse
            # Topologically Sorted Source Nodes: [linear_114], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg295_1, reinterpret_tensor(buf390, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg294_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf391)
            del arg294_1
            del arg295_1
            assert_size_stride_grouped((arg297_1, arg296_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf392 = buf374; del buf374  # reuse
            # Topologically Sorted Source Nodes: [linear_115], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg297_1, reinterpret_tensor(buf390, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg296_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf392)
            del arg296_1
            del arg297_1
            assert_size_stride(arg300_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg300_1 = copy_if_misaligned(arg300_1)
            buf393 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_22, sin_22, linear_115, view_58, key_states_19, mul_177, x2_39, neg_39, x1_39, cat_78, mul_178, k_embed_19, key_tensors_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg300_1, buf392, arg4_1, arg3_1, arg5_1.item(), buf393, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg300_1
            assert_size_stride_grouped((arg299_1, arg298_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf394 = buf392; del buf392  # reuse
            # Topologically Sorted Source Nodes: [linear_116], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg299_1, reinterpret_tensor(buf390, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg298_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf394)
            del arg298_1
            del arg299_1
            assert_size_stride(arg301_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg301_1 = copy_if_misaligned(arg301_1)
            buf395 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_116, view_59, value_states_19, value_tensors_19], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg301_1, buf394, buf395, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg301_1
            buf396 = reinterpret_tensor(buf390, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf390  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_114, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_77, sin_22, mul_176, q_embed_19, packed_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf391, arg4_1, arg3_1, arg5_1.item(), buf396, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf391
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_114, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_77, sin_22, mul_176, q_embed_19, packed_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf397 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf396, buf393, buf395, None, False, scale=0.08838834764831845)
            buf398 = buf397[0]
            assert_tensor_metadata(buf398, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf398, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf397
            buf402 = buf396; del buf396  # reuse
            # Topologically Sorted Source Nodes: [attn_output_76], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf398, buf402, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg302_1, (1536, 1536), (1536, 1), 'input')
            buf403 = reinterpret_tensor(buf398, (s16, 1536), (1536, 1), 0); del buf398  # reuse
            # Topologically Sorted Source Nodes: [attn_output_76, transpose_80, reshape_59, attn_output_79], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf402, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg302_1, (1536, 1536), (1, 1536), 0), out=buf403)
            del arg302_1
            assert_size_stride_grouped((arg304_1, arg303_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf404 = buf363; del buf363  # reuse
            buf406 = reinterpret_tensor(buf402, (s16, 1, 1536), (1536, 1536, 1), 0); del buf402  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_160, hidden_states_161, attn_output_75, hidden_states_165, hidden_states_169, hidden_states_170, attn_output_79, hidden_states_174, pow_40, variance_39, rsqrt_39, hidden_states_176, hidden_states_177], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf404, buf368, buf383, buf388, buf403, arg304_1, arg303_1.item(), buf406, s16, 1536, stream=raw_stream0)
            del arg303_1
            del arg304_1
            del buf368
            assert_size_stride(arg305_1, (17920, 1536), (1536, 1), 'input')
            buf407 = buf386; del buf386  # reuse
            # Topologically Sorted Source Nodes: [pow_40, variance_39, rsqrt_39, hidden_states_176, hidden_states_177, linear_118], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf406, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg305_1, (1536, 17920), (1, 1536), 0), out=buf407)
            del arg305_1
            buf408 = buf387; del buf387  # reuse
            # Topologically Sorted Source Nodes: [linear_118, split_19, silu_19, mul_181], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf407, buf408, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg306_1, (1536, 8960), (8960, 1), 'input')
            buf409 = reinterpret_tensor(buf406, (s16, 1536), (1536, 1), 0); del buf406  # reuse
            # Topologically Sorted Source Nodes: [linear_118, split_19, silu_19, mul_181, hidden_states_178], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf408, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg306_1, (8960, 1536), (1, 8960), 0), out=buf409)
            del arg306_1
            assert_size_stride_grouped((arg308_1, arg307_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf411 = reinterpret_tensor(buf403, (s16, 1, 1536), (1536, 1536, 1), 0); del buf403  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_178, hidden_states_179, pow_41, variance_40, rsqrt_40, hidden_states_181, hidden_states_182], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf404, buf409, arg308_1, arg307_1.item(), buf411, s16, 1536, stream=raw_stream0)
            del arg307_1
            del arg308_1
            assert_size_stride_grouped((arg310_1, arg309_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf412 = buf388; del buf388  # reuse
            # Topologically Sorted Source Nodes: [linear_120], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg310_1, reinterpret_tensor(buf411, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg309_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf412)
            del arg309_1
            del arg310_1
            assert_size_stride_grouped((arg312_1, arg311_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf413 = buf394; del buf394  # reuse
            # Topologically Sorted Source Nodes: [linear_121], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg312_1, reinterpret_tensor(buf411, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg311_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf413)
            del arg311_1
            del arg312_1
            assert_size_stride(arg315_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg315_1 = copy_if_misaligned(arg315_1)
            buf414 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_23, sin_23, linear_121, view_61, key_states_20, mul_186, x2_41, neg_41, x1_41, cat_82, mul_187, k_embed_20, key_tensors_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg315_1, buf413, arg4_1, arg3_1, arg5_1.item(), buf414, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg315_1
            assert_size_stride_grouped((arg314_1, arg313_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf415 = buf413; del buf413  # reuse
            # Topologically Sorted Source Nodes: [linear_122], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg314_1, reinterpret_tensor(buf411, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg313_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf415)
            del arg313_1
            del arg314_1
            assert_size_stride(arg316_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg316_1 = copy_if_misaligned(arg316_1)
            buf416 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_122, view_62, value_states_20, value_tensors_20], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg316_1, buf415, buf416, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg316_1
            buf417 = reinterpret_tensor(buf411, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf411  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_120, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_81, sin_23, mul_185, q_embed_20, packed_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf412, arg4_1, arg3_1, arg5_1.item(), buf417, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_120, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_81, sin_23, mul_185, q_embed_20, packed_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf418 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf417, buf414, buf416, None, False, scale=0.08838834764831845)
            buf419 = buf418[0]
            assert_tensor_metadata(buf419, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf419, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf418
            buf423 = buf417; del buf417  # reuse
            # Topologically Sorted Source Nodes: [attn_output_80], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf419, buf423, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg317_1, (1536, 1536), (1536, 1), 'input')
            buf424 = reinterpret_tensor(buf419, (s16, 1536), (1536, 1), 0); del buf419  # reuse
            # Topologically Sorted Source Nodes: [attn_output_80, transpose_84, reshape_62, attn_output_83], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf423, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg317_1, (1536, 1536), (1, 1536), 0), out=buf424)
            del arg317_1
            assert_size_stride_grouped((arg319_1, arg318_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf426 = reinterpret_tensor(buf423, (s16, 1, 1536), (1536, 1536, 1), 0); del buf423  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_178, hidden_states_179, attn_output_83, hidden_states_183, pow_42, variance_41, rsqrt_41, hidden_states_185, hidden_states_186], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf404, buf409, buf424, arg319_1, arg318_1.item(), buf426, s16, 1536, stream=raw_stream0)
            del arg318_1
            del arg319_1
            assert_size_stride(arg320_1, (17920, 1536), (1536, 1), 'input')
            buf427 = buf407; del buf407  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_178, hidden_states_179, attn_output_83, hidden_states_183, pow_42, variance_41, rsqrt_41, hidden_states_185, hidden_states_186, linear_124], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf426, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg320_1, (1536, 17920), (1, 1536), 0), out=buf427)
            del arg320_1
            buf428 = buf408; del buf408  # reuse
            # Topologically Sorted Source Nodes: [linear_124, split_20, silu_20, mul_190], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf427, buf428, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg321_1, (1536, 8960), (8960, 1), 'input')
            buf429 = reinterpret_tensor(buf426, (s16, 1536), (1536, 1), 0); del buf426  # reuse
            # Topologically Sorted Source Nodes: [linear_124, split_20, silu_20, mul_190, hidden_states_187], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf428, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg321_1, (8960, 1536), (1, 8960), 0), out=buf429)
            del arg321_1
            assert_size_stride_grouped((arg323_1, arg322_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf431 = reinterpret_tensor(buf412, (s16, 1, 1536), (1536, 1536, 1), 0); del buf412  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_178, hidden_states_179, attn_output_83, hidden_states_183, hidden_states_187, hidden_states_188, pow_43, variance_42, rsqrt_42, hidden_states_190, hidden_states_191], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf404, buf409, buf424, buf429, arg323_1, arg322_1.item(), buf431, s16, 1536, stream=raw_stream0)
            del arg322_1
            del arg323_1
            assert_size_stride_grouped((arg325_1, arg324_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf432 = buf383; del buf383  # reuse
            # Topologically Sorted Source Nodes: [linear_126], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg325_1, reinterpret_tensor(buf431, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg324_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf432)
            del arg324_1
            del arg325_1
            assert_size_stride_grouped((arg327_1, arg326_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf433 = buf415; del buf415  # reuse
            # Topologically Sorted Source Nodes: [linear_127], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg327_1, reinterpret_tensor(buf431, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg326_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf433)
            del arg326_1
            del arg327_1
            assert_size_stride(arg330_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg330_1 = copy_if_misaligned(arg330_1)
            buf434 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_24, sin_24, linear_127, view_64, key_states_21, mul_195, x2_43, neg_43, x1_43, cat_86, mul_196, k_embed_21, key_tensors_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg330_1, buf433, arg4_1, arg3_1, arg5_1.item(), buf434, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg330_1
            assert_size_stride_grouped((arg329_1, arg328_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf435 = buf433; del buf433  # reuse
            # Topologically Sorted Source Nodes: [linear_128], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg329_1, reinterpret_tensor(buf431, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg328_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf435)
            del arg328_1
            del arg329_1
            assert_size_stride(arg331_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg331_1 = copy_if_misaligned(arg331_1)
            buf436 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_128, view_65, value_states_21, value_tensors_21], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg331_1, buf435, buf436, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg331_1
            buf437 = reinterpret_tensor(buf431, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf431  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_85, sin_24, mul_194, q_embed_21, packed_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf432, arg4_1, arg3_1, arg5_1.item(), buf437, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf432
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_85, sin_24, mul_194, q_embed_21, packed_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf438 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf437, buf434, buf436, None, False, scale=0.08838834764831845)
            buf439 = buf438[0]
            assert_tensor_metadata(buf439, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf439, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf438
            buf443 = buf437; del buf437  # reuse
            # Topologically Sorted Source Nodes: [attn_output_84], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf439, buf443, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg332_1, (1536, 1536), (1536, 1), 'input')
            buf444 = reinterpret_tensor(buf439, (s16, 1536), (1536, 1), 0); del buf439  # reuse
            # Topologically Sorted Source Nodes: [attn_output_84, transpose_88, reshape_65, attn_output_87], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf443, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg332_1, (1536, 1536), (1, 1536), 0), out=buf444)
            del arg332_1
            assert_size_stride_grouped((arg334_1, arg333_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf445 = buf404; del buf404  # reuse
            buf447 = reinterpret_tensor(buf443, (s16, 1, 1536), (1536, 1536, 1), 0); del buf443  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_178, hidden_states_179, attn_output_83, hidden_states_183, hidden_states_187, hidden_states_188, attn_output_87, hidden_states_192, pow_44, variance_43, rsqrt_43, hidden_states_194, hidden_states_195], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf445, buf409, buf424, buf429, buf444, arg334_1, arg333_1.item(), buf447, s16, 1536, stream=raw_stream0)
            del arg333_1
            del arg334_1
            del buf409
            assert_size_stride(arg335_1, (17920, 1536), (1536, 1), 'input')
            buf448 = buf427; del buf427  # reuse
            # Topologically Sorted Source Nodes: [pow_44, variance_43, rsqrt_43, hidden_states_194, hidden_states_195, linear_130], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf447, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg335_1, (1536, 17920), (1, 1536), 0), out=buf448)
            del arg335_1
            buf449 = buf428; del buf428  # reuse
            # Topologically Sorted Source Nodes: [linear_130, split_21, silu_21, mul_199], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf448, buf449, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg336_1, (1536, 8960), (8960, 1), 'input')
            buf450 = reinterpret_tensor(buf447, (s16, 1536), (1536, 1), 0); del buf447  # reuse
            # Topologically Sorted Source Nodes: [linear_130, split_21, silu_21, mul_199, hidden_states_196], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf449, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg336_1, (8960, 1536), (1, 8960), 0), out=buf450)
            del arg336_1
            assert_size_stride_grouped((arg338_1, arg337_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf452 = reinterpret_tensor(buf444, (s16, 1, 1536), (1536, 1536, 1), 0); del buf444  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, pow_45, variance_44, rsqrt_44, hidden_states_199, hidden_states_200], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf445, buf450, arg338_1, arg337_1.item(), buf452, s16, 1536, stream=raw_stream0)
            del arg337_1
            del arg338_1
            assert_size_stride_grouped((arg340_1, arg339_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf453 = buf429; del buf429  # reuse
            # Topologically Sorted Source Nodes: [linear_132], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg340_1, reinterpret_tensor(buf452, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg339_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf453)
            del arg339_1
            del arg340_1
            assert_size_stride_grouped((arg342_1, arg341_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf454 = buf435; del buf435  # reuse
            # Topologically Sorted Source Nodes: [linear_133], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg342_1, reinterpret_tensor(buf452, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg341_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf454)
            del arg341_1
            del arg342_1
            assert_size_stride(arg345_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg345_1 = copy_if_misaligned(arg345_1)
            buf455 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_25, sin_25, linear_133, view_67, key_states_22, mul_204, x2_45, neg_45, x1_45, cat_90, mul_205, k_embed_22, key_tensors_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg345_1, buf454, arg4_1, arg3_1, arg5_1.item(), buf455, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg345_1
            assert_size_stride_grouped((arg344_1, arg343_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf456 = buf454; del buf454  # reuse
            # Topologically Sorted Source Nodes: [linear_134], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg344_1, reinterpret_tensor(buf452, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg343_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf456)
            del arg343_1
            del arg344_1
            assert_size_stride(arg346_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg346_1 = copy_if_misaligned(arg346_1)
            buf457 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_134, view_68, value_states_22, value_tensors_22], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg346_1, buf456, buf457, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg346_1
            buf458 = reinterpret_tensor(buf452, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf452  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_132, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_89, sin_25, mul_203, q_embed_22, packed_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf453, arg4_1, arg3_1, arg5_1.item(), buf458, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_132, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_89, sin_25, mul_203, q_embed_22, packed_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf459 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf458, buf455, buf457, None, False, scale=0.08838834764831845)
            buf460 = buf459[0]
            assert_tensor_metadata(buf460, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf460, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf459
            buf464 = buf458; del buf458  # reuse
            # Topologically Sorted Source Nodes: [attn_output_88], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf460, buf464, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg347_1, (1536, 1536), (1536, 1), 'input')
            buf465 = reinterpret_tensor(buf460, (s16, 1536), (1536, 1), 0); del buf460  # reuse
            # Topologically Sorted Source Nodes: [attn_output_88, transpose_92, reshape_68, attn_output_91], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf464, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg347_1, (1536, 1536), (1, 1536), 0), out=buf465)
            del arg347_1
            assert_size_stride_grouped((arg349_1, arg348_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf467 = reinterpret_tensor(buf464, (s16, 1, 1536), (1536, 1536, 1), 0); del buf464  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, attn_output_91, hidden_states_201, pow_46, variance_45, rsqrt_45, hidden_states_203, hidden_states_204], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf445, buf450, buf465, arg349_1, arg348_1.item(), buf467, s16, 1536, stream=raw_stream0)
            del arg348_1
            del arg349_1
            assert_size_stride(arg350_1, (17920, 1536), (1536, 1), 'input')
            buf468 = buf448; del buf448  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, attn_output_91, hidden_states_201, pow_46, variance_45, rsqrt_45, hidden_states_203, hidden_states_204, linear_136], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf467, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg350_1, (1536, 17920), (1, 1536), 0), out=buf468)
            del arg350_1
            buf469 = buf449; del buf449  # reuse
            # Topologically Sorted Source Nodes: [linear_136, split_22, silu_22, mul_208], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf468, buf469, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg351_1, (1536, 8960), (8960, 1), 'input')
            buf470 = reinterpret_tensor(buf467, (s16, 1536), (1536, 1), 0); del buf467  # reuse
            # Topologically Sorted Source Nodes: [linear_136, split_22, silu_22, mul_208, hidden_states_205], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf469, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg351_1, (8960, 1536), (1, 8960), 0), out=buf470)
            del arg351_1
            assert_size_stride_grouped((arg353_1, arg352_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf472 = reinterpret_tensor(buf453, (s16, 1, 1536), (1536, 1536, 1), 0); del buf453  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, attn_output_91, hidden_states_201, hidden_states_205, hidden_states_206, pow_47, variance_46, rsqrt_46, hidden_states_208, hidden_states_209], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf445, buf450, buf465, buf470, arg353_1, arg352_1.item(), buf472, s16, 1536, stream=raw_stream0)
            del arg352_1
            del arg353_1
            assert_size_stride_grouped((arg355_1, arg354_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf473 = buf424; del buf424  # reuse
            # Topologically Sorted Source Nodes: [linear_138], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg355_1, reinterpret_tensor(buf472, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg354_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf473)
            del arg354_1
            del arg355_1
            assert_size_stride_grouped((arg357_1, arg356_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf474 = buf456; del buf456  # reuse
            # Topologically Sorted Source Nodes: [linear_139], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg357_1, reinterpret_tensor(buf472, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg356_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf474)
            del arg356_1
            del arg357_1
            assert_size_stride(arg360_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg360_1 = copy_if_misaligned(arg360_1)
            buf475 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_26, sin_26, linear_139, view_70, key_states_23, mul_213, x2_47, neg_47, x1_47, cat_94, mul_214, k_embed_23, key_tensors_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg360_1, buf474, arg4_1, arg3_1, arg5_1.item(), buf475, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg360_1
            assert_size_stride_grouped((arg359_1, arg358_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf476 = buf474; del buf474  # reuse
            # Topologically Sorted Source Nodes: [linear_140], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg359_1, reinterpret_tensor(buf472, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg358_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf476)
            del arg358_1
            del arg359_1
            assert_size_stride(arg361_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg361_1 = copy_if_misaligned(arg361_1)
            buf477 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_140, view_71, value_states_23, value_tensors_23], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg361_1, buf476, buf477, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg361_1
            buf478 = reinterpret_tensor(buf472, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf472  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_138, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_93, sin_26, mul_212, q_embed_23, packed_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf473, arg4_1, arg3_1, arg5_1.item(), buf478, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf473
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_138, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_93, sin_26, mul_212, q_embed_23, packed_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf479 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf478, buf475, buf477, None, False, scale=0.08838834764831845)
            buf480 = buf479[0]
            assert_tensor_metadata(buf480, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf480, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf479
            buf484 = buf478; del buf478  # reuse
            # Topologically Sorted Source Nodes: [attn_output_92], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf480, buf484, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg362_1, (1536, 1536), (1536, 1), 'input')
            buf485 = reinterpret_tensor(buf480, (s16, 1536), (1536, 1), 0); del buf480  # reuse
            # Topologically Sorted Source Nodes: [attn_output_92, transpose_96, reshape_71, attn_output_95], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf484, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg362_1, (1536, 1536), (1, 1536), 0), out=buf485)
            del arg362_1
            assert_size_stride_grouped((arg364_1, arg363_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf486 = buf445; del buf445  # reuse
            buf488 = reinterpret_tensor(buf484, (s16, 1, 1536), (1536, 1536, 1), 0); del buf484  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_196, hidden_states_197, attn_output_91, hidden_states_201, hidden_states_205, hidden_states_206, attn_output_95, hidden_states_210, pow_48, variance_47, rsqrt_47, hidden_states_212, hidden_states_213], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf486, buf450, buf465, buf470, buf485, arg364_1, arg363_1.item(), buf488, s16, 1536, stream=raw_stream0)
            del arg363_1
            del arg364_1
            del buf450
            assert_size_stride(arg365_1, (17920, 1536), (1536, 1), 'input')
            buf489 = buf468; del buf468  # reuse
            # Topologically Sorted Source Nodes: [pow_48, variance_47, rsqrt_47, hidden_states_212, hidden_states_213, linear_142], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf488, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg365_1, (1536, 17920), (1, 1536), 0), out=buf489)
            del arg365_1
            buf490 = buf469; del buf469  # reuse
            # Topologically Sorted Source Nodes: [linear_142, split_23, silu_23, mul_217], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf489, buf490, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg366_1, (1536, 8960), (8960, 1), 'input')
            buf491 = reinterpret_tensor(buf488, (s16, 1536), (1536, 1), 0); del buf488  # reuse
            # Topologically Sorted Source Nodes: [linear_142, split_23, silu_23, mul_217, hidden_states_214], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf490, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg366_1, (8960, 1536), (1, 8960), 0), out=buf491)
            del arg366_1
            assert_size_stride_grouped((arg368_1, arg367_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf493 = reinterpret_tensor(buf485, (s16, 1, 1536), (1536, 1536, 1), 0); del buf485  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_214, hidden_states_215, pow_49, variance_48, rsqrt_48, hidden_states_217, hidden_states_218], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf486, buf491, arg368_1, arg367_1.item(), buf493, s16, 1536, stream=raw_stream0)
            del arg367_1
            del arg368_1
            assert_size_stride_grouped((arg370_1, arg369_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf494 = buf470; del buf470  # reuse
            # Topologically Sorted Source Nodes: [linear_144], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg370_1, reinterpret_tensor(buf493, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg369_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf494)
            del arg369_1
            del arg370_1
            assert_size_stride_grouped((arg372_1, arg371_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf495 = buf476; del buf476  # reuse
            # Topologically Sorted Source Nodes: [linear_145], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg372_1, reinterpret_tensor(buf493, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg371_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf495)
            del arg371_1
            del arg372_1
            assert_size_stride(arg375_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg375_1 = copy_if_misaligned(arg375_1)
            buf496 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_27, sin_27, linear_145, view_73, key_states_24, mul_222, x2_49, neg_49, x1_49, cat_98, mul_223, k_embed_24, key_tensors_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg375_1, buf495, arg4_1, arg3_1, arg5_1.item(), buf496, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg375_1
            assert_size_stride_grouped((arg374_1, arg373_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf497 = buf495; del buf495  # reuse
            # Topologically Sorted Source Nodes: [linear_146], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg374_1, reinterpret_tensor(buf493, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg373_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf497)
            del arg373_1
            del arg374_1
            assert_size_stride(arg376_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg376_1 = copy_if_misaligned(arg376_1)
            buf498 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_146, view_74, value_states_24, value_tensors_24], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg376_1, buf497, buf498, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg376_1
            buf499 = reinterpret_tensor(buf493, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf493  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_144, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_97, sin_27, mul_221, q_embed_24, packed_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf494, arg4_1, arg3_1, arg5_1.item(), buf499, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_144, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_97, sin_27, mul_221, q_embed_24, packed_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf500 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf499, buf496, buf498, None, False, scale=0.08838834764831845)
            buf501 = buf500[0]
            assert_tensor_metadata(buf501, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf501, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf500
            buf505 = buf499; del buf499  # reuse
            # Topologically Sorted Source Nodes: [attn_output_96], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf501, buf505, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg377_1, (1536, 1536), (1536, 1), 'input')
            buf506 = reinterpret_tensor(buf501, (s16, 1536), (1536, 1), 0); del buf501  # reuse
            # Topologically Sorted Source Nodes: [attn_output_96, transpose_100, reshape_74, attn_output_99], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf505, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg377_1, (1536, 1536), (1, 1536), 0), out=buf506)
            del arg377_1
            assert_size_stride_grouped((arg379_1, arg378_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf508 = reinterpret_tensor(buf505, (s16, 1, 1536), (1536, 1536, 1), 0); del buf505  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_214, hidden_states_215, attn_output_99, hidden_states_219, pow_50, variance_49, rsqrt_49, hidden_states_221, hidden_states_222], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf486, buf491, buf506, arg379_1, arg378_1.item(), buf508, s16, 1536, stream=raw_stream0)
            del arg378_1
            del arg379_1
            assert_size_stride(arg380_1, (17920, 1536), (1536, 1), 'input')
            buf509 = buf489; del buf489  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_214, hidden_states_215, attn_output_99, hidden_states_219, pow_50, variance_49, rsqrt_49, hidden_states_221, hidden_states_222, linear_148], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf508, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg380_1, (1536, 17920), (1, 1536), 0), out=buf509)
            del arg380_1
            buf510 = buf490; del buf490  # reuse
            # Topologically Sorted Source Nodes: [linear_148, split_24, silu_24, mul_226], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf509, buf510, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg381_1, (1536, 8960), (8960, 1), 'input')
            buf511 = reinterpret_tensor(buf508, (s16, 1536), (1536, 1), 0); del buf508  # reuse
            # Topologically Sorted Source Nodes: [linear_148, split_24, silu_24, mul_226, hidden_states_223], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf510, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg381_1, (8960, 1536), (1, 8960), 0), out=buf511)
            del arg381_1
            assert_size_stride_grouped((arg383_1, arg382_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf513 = reinterpret_tensor(buf494, (s16, 1, 1536), (1536, 1536, 1), 0); del buf494  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_214, hidden_states_215, attn_output_99, hidden_states_219, hidden_states_223, hidden_states_224, pow_51, variance_50, rsqrt_50, hidden_states_226, hidden_states_227], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf486, buf491, buf506, buf511, arg383_1, arg382_1.item(), buf513, s16, 1536, stream=raw_stream0)
            del arg382_1
            del arg383_1
            assert_size_stride_grouped((arg385_1, arg384_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf514 = buf465; del buf465  # reuse
            # Topologically Sorted Source Nodes: [linear_150], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg385_1, reinterpret_tensor(buf513, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg384_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf514)
            del arg384_1
            del arg385_1
            assert_size_stride_grouped((arg387_1, arg386_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf515 = buf497; del buf497  # reuse
            # Topologically Sorted Source Nodes: [linear_151], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg387_1, reinterpret_tensor(buf513, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg386_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf515)
            del arg386_1
            del arg387_1
            assert_size_stride(arg390_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg390_1 = copy_if_misaligned(arg390_1)
            buf516 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_28, sin_28, linear_151, view_76, key_states_25, mul_231, x2_51, neg_51, x1_51, cat_102, mul_232, k_embed_25, key_tensors_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg390_1, buf515, arg4_1, arg3_1, arg5_1.item(), buf516, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg390_1
            assert_size_stride_grouped((arg389_1, arg388_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf517 = buf515; del buf515  # reuse
            # Topologically Sorted Source Nodes: [linear_152], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg389_1, reinterpret_tensor(buf513, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg388_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf517)
            del arg388_1
            del arg389_1
            assert_size_stride(arg391_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg391_1 = copy_if_misaligned(arg391_1)
            buf518 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_152, view_77, value_states_25, value_tensors_25], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg391_1, buf517, buf518, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg391_1
            buf519 = reinterpret_tensor(buf513, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf513  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_150, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_101, sin_28, mul_230, q_embed_25, packed_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf514, arg4_1, arg3_1, arg5_1.item(), buf519, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf514
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_150, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_101, sin_28, mul_230, q_embed_25, packed_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf520 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf519, buf516, buf518, None, False, scale=0.08838834764831845)
            buf521 = buf520[0]
            assert_tensor_metadata(buf521, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf521, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf520
            buf525 = buf519; del buf519  # reuse
            # Topologically Sorted Source Nodes: [attn_output_100], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf521, buf525, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg392_1, (1536, 1536), (1536, 1), 'input')
            buf526 = reinterpret_tensor(buf521, (s16, 1536), (1536, 1), 0); del buf521  # reuse
            # Topologically Sorted Source Nodes: [attn_output_100, transpose_104, reshape_77, attn_output_103], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf525, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg392_1, (1536, 1536), (1, 1536), 0), out=buf526)
            del arg392_1
            assert_size_stride_grouped((arg394_1, arg393_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf527 = buf486; del buf486  # reuse
            buf529 = reinterpret_tensor(buf525, (s16, 1, 1536), (1536, 1536, 1), 0); del buf525  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_214, hidden_states_215, attn_output_99, hidden_states_219, hidden_states_223, hidden_states_224, attn_output_103, hidden_states_228, pow_52, variance_51, rsqrt_51, hidden_states_230, hidden_states_231], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf527, buf491, buf506, buf511, buf526, arg394_1, arg393_1.item(), buf529, s16, 1536, stream=raw_stream0)
            del arg393_1
            del arg394_1
            del buf491
            assert_size_stride(arg395_1, (17920, 1536), (1536, 1), 'input')
            buf530 = buf509; del buf509  # reuse
            # Topologically Sorted Source Nodes: [pow_52, variance_51, rsqrt_51, hidden_states_230, hidden_states_231, linear_154], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf529, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg395_1, (1536, 17920), (1, 1536), 0), out=buf530)
            del arg395_1
            buf531 = buf510; del buf510  # reuse
            # Topologically Sorted Source Nodes: [linear_154, split_25, silu_25, mul_235], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf530, buf531, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg396_1, (1536, 8960), (8960, 1), 'input')
            buf532 = reinterpret_tensor(buf529, (s16, 1536), (1536, 1), 0); del buf529  # reuse
            # Topologically Sorted Source Nodes: [linear_154, split_25, silu_25, mul_235, hidden_states_232], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf531, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg396_1, (8960, 1536), (1, 8960), 0), out=buf532)
            del arg396_1
            assert_size_stride_grouped((arg398_1, arg397_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf534 = reinterpret_tensor(buf526, (s16, 1, 1536), (1536, 1536, 1), 0); del buf526  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_232, hidden_states_233, pow_53, variance_52, rsqrt_52, hidden_states_235, hidden_states_236], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf527, buf532, arg398_1, arg397_1.item(), buf534, s16, 1536, stream=raw_stream0)
            del arg397_1
            del arg398_1
            assert_size_stride_grouped((arg400_1, arg399_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf535 = buf511; del buf511  # reuse
            # Topologically Sorted Source Nodes: [linear_156], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg400_1, reinterpret_tensor(buf534, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg399_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf535)
            del arg399_1
            del arg400_1
            assert_size_stride_grouped((arg402_1, arg401_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf536 = buf517; del buf517  # reuse
            # Topologically Sorted Source Nodes: [linear_157], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg402_1, reinterpret_tensor(buf534, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg401_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf536)
            del arg401_1
            del arg402_1
            assert_size_stride(arg405_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg405_1 = copy_if_misaligned(arg405_1)
            buf537 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_29, sin_29, linear_157, view_79, key_states_26, mul_240, x2_53, neg_53, x1_53, cat_106, mul_241, k_embed_26, key_tensors_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg405_1, buf536, arg4_1, arg3_1, arg5_1.item(), buf537, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg405_1
            assert_size_stride_grouped((arg404_1, arg403_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf538 = buf536; del buf536  # reuse
            # Topologically Sorted Source Nodes: [linear_158], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg404_1, reinterpret_tensor(buf534, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg403_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf538)
            del arg403_1
            del arg404_1
            assert_size_stride(arg406_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg406_1 = copy_if_misaligned(arg406_1)
            buf539 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_158, view_80, value_states_26, value_tensors_26], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg406_1, buf538, buf539, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg406_1
            buf540 = reinterpret_tensor(buf534, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf534  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_156, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_105, sin_29, mul_239, q_embed_26, packed_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf535, arg4_1, arg3_1, arg5_1.item(), buf540, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_156, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_105, sin_29, mul_239, q_embed_26, packed_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf541 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf540, buf537, buf539, None, False, scale=0.08838834764831845)
            buf542 = buf541[0]
            assert_tensor_metadata(buf542, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf542, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf541
            buf546 = buf540; del buf540  # reuse
            # Topologically Sorted Source Nodes: [attn_output_104], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf542, buf546, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg407_1, (1536, 1536), (1536, 1), 'input')
            buf547 = reinterpret_tensor(buf542, (s16, 1536), (1536, 1), 0); del buf542  # reuse
            # Topologically Sorted Source Nodes: [attn_output_104, transpose_108, reshape_80, attn_output_107], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf546, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg407_1, (1536, 1536), (1, 1536), 0), out=buf547)
            del arg407_1
            assert_size_stride_grouped((arg409_1, arg408_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf549 = reinterpret_tensor(buf546, (s16, 1, 1536), (1536, 1536, 1), 0); del buf546  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_232, hidden_states_233, attn_output_107, hidden_states_237, pow_54, variance_53, rsqrt_53, hidden_states_239, hidden_states_240], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf527, buf532, buf547, arg409_1, arg408_1.item(), buf549, s16, 1536, stream=raw_stream0)
            del arg408_1
            del arg409_1
            assert_size_stride(arg410_1, (17920, 1536), (1536, 1), 'input')
            buf550 = buf530; del buf530  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_232, hidden_states_233, attn_output_107, hidden_states_237, pow_54, variance_53, rsqrt_53, hidden_states_239, hidden_states_240, linear_160], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf549, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg410_1, (1536, 17920), (1, 1536), 0), out=buf550)
            del arg410_1
            buf551 = buf531; del buf531  # reuse
            # Topologically Sorted Source Nodes: [linear_160, split_26, silu_26, mul_244], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf550, buf551, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg411_1, (1536, 8960), (8960, 1), 'input')
            buf552 = reinterpret_tensor(buf549, (s16, 1536), (1536, 1), 0); del buf549  # reuse
            # Topologically Sorted Source Nodes: [linear_160, split_26, silu_26, mul_244, hidden_states_241], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf551, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg411_1, (8960, 1536), (1, 8960), 0), out=buf552)
            del arg411_1
            assert_size_stride_grouped((arg413_1, arg412_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf554 = reinterpret_tensor(buf535, (s16, 1, 1536), (1536, 1536, 1), 0); del buf535  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_232, hidden_states_233, attn_output_107, hidden_states_237, hidden_states_241, hidden_states_242, pow_55, variance_54, rsqrt_54, hidden_states_244, hidden_states_245], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf527, buf532, buf547, buf552, arg413_1, arg412_1.item(), buf554, s16, 1536, stream=raw_stream0)
            del arg412_1
            del arg413_1
            assert_size_stride_grouped((arg415_1, arg414_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf555 = buf506; del buf506  # reuse
            # Topologically Sorted Source Nodes: [linear_162], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg415_1, reinterpret_tensor(buf554, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg414_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf555)
            del arg414_1
            del arg415_1
            assert_size_stride_grouped((arg417_1, arg416_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf556 = buf538; del buf538  # reuse
            # Topologically Sorted Source Nodes: [linear_163], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg417_1, reinterpret_tensor(buf554, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg416_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf556)
            del arg416_1
            del arg417_1
            assert_size_stride(arg420_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg420_1 = copy_if_misaligned(arg420_1)
            buf557 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_30, sin_30, linear_163, view_82, key_states_27, mul_249, x2_55, neg_55, x1_55, cat_110, mul_250, k_embed_27, key_tensors_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg420_1, buf556, arg4_1, arg3_1, arg5_1.item(), buf557, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg420_1
            assert_size_stride_grouped((arg419_1, arg418_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf558 = buf556; del buf556  # reuse
            # Topologically Sorted Source Nodes: [linear_164], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg419_1, reinterpret_tensor(buf554, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg418_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf558)
            del arg418_1
            del arg419_1
            assert_size_stride(arg421_1, (s16, 2, s53, 128), (256*s53, 128*s53, 128, 1), 'input')
            arg421_1 = copy_if_misaligned(arg421_1)
            buf559 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_164, view_83, value_states_27, value_tensors_27], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg421_1, buf558, buf559, ps0, s53, ps1, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg421_1
            del buf558
            buf560 = reinterpret_tensor(buf554, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf554  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_162, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_109, sin_30, mul_248, q_embed_27, packed_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf555, arg4_1, arg3_1, arg5_1.item(), buf560, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg3_1
            del arg4_1
            del arg5_1
            del buf555
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_162, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_109, sin_30, mul_248, q_embed_27, packed_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf561 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf560, buf557, buf559, None, False, scale=0.08838834764831845)
            buf562 = buf561[0]
            assert_tensor_metadata(buf562, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf562, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf561
            buf566 = buf560; del buf560  # reuse
            # Topologically Sorted Source Nodes: [attn_output_108], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf562, buf566, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg422_1, (1536, 1536), (1536, 1), 'input')
            buf567 = reinterpret_tensor(buf562, (s16, 1536), (1536, 1), 0); del buf562  # reuse
            # Topologically Sorted Source Nodes: [attn_output_108, transpose_112, reshape_83, attn_output_111], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf566, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg422_1, (1536, 1536), (1, 1536), 0), out=buf567)
            del arg422_1
            assert_size_stride_grouped((arg424_1, arg423_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf568 = buf527; del buf527  # reuse
            buf570 = reinterpret_tensor(buf566, (s16, 1, 1536), (1536, 1536, 1), 0); del buf566  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_232, hidden_states_233, attn_output_107, hidden_states_237, hidden_states_241, hidden_states_242, attn_output_111, hidden_states_246, pow_56, variance_55, rsqrt_55, hidden_states_248, hidden_states_249], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf568, buf532, buf547, buf552, buf567, arg424_1, arg423_1.item(), buf570, s16, 1536, stream=raw_stream0)
            del arg423_1
            del arg424_1
            del buf532
            del buf547
            del buf552
            del buf567
            assert_size_stride(arg425_1, (17920, 1536), (1536, 1), 'input')
            buf571 = buf550; del buf550  # reuse
            # Topologically Sorted Source Nodes: [pow_56, variance_55, rsqrt_55, hidden_states_248, hidden_states_249, linear_166], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf570, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg425_1, (1536, 17920), (1, 1536), 0), out=buf571)
            del arg425_1
            buf572 = buf551; del buf551  # reuse
            # Topologically Sorted Source Nodes: [linear_166, split_27, silu_27, mul_253], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_split_6.run(buf571, buf572, triton_poi_fused__unsafe_view_mul_silu_split_6_xnumel, stream=raw_stream0)
            del buf571
            assert_size_stride(arg426_1, (1536, 8960), (8960, 1), 'input')
            buf573 = reinterpret_tensor(buf570, (s16, 1536), (1536, 1), 0); del buf570  # reuse
            # Topologically Sorted Source Nodes: [linear_166, split_27, silu_27, mul_253, hidden_states_250], Original ATen: [aten._unsafe_view, aten.split, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf572, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg426_1, (8960, 1536), (1, 8960), 0), out=buf573)
            del arg426_1
            del buf572
            assert_size_stride_grouped((arg428_1, arg427_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf575 = reinterpret_tensor(buf568, (s16, 1, 1536), (1536, 1536, 1), 0); del buf568  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_250, hidden_states_251, pow_57, variance_56, rsqrt_56, hidden_states_253, hidden_states_254], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14.run(buf575, buf573, arg428_1, arg427_1.item(), s16, 1536, stream=raw_stream0)
            del arg427_1
            del arg428_1
            del buf573
            buf576 = empty_strided_cuda((s16, 152265), (152265, 1), torch.float32)
            # Topologically Sorted Source Nodes: [hidden_states_250, hidden_states_251, pow_57, variance_56, rsqrt_56, hidden_states_253, hidden_states_254, getitem_1908, logits], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.slice, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf575, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg2_1, (1536, 152265), (1, 1536), 0), out=buf576)
            del arg2_1
            del buf575
        return (buf6, buf4, buf26, buf24, buf47, buf45, buf67, buf65, buf88, buf86, buf108, buf106, buf129, buf127, buf149, buf147, buf170, buf168, buf190, buf188, buf211, buf209, buf231, buf229, buf252, buf250, buf272, buf270, buf293, buf291, buf313, buf311, buf334, buf332, buf354, buf352, buf375, buf373, buf395, buf393, buf416, buf414, buf436, buf434, buf457, buf455, buf477, buf475, buf498, buf496, buf518, buf516, buf539, buf537, buf559, buf557, reinterpret_tensor(buf576, (s16, 1, 152265), (152265, 152265, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = 50
    arg1_1 = rand_strided((50, 1), (1, 1), device='cuda:0', dtype=torch.int64)
    arg2_1 = rand_strided((152265, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg3_1 = rand_strided((50, 1), (1, 1), device='cuda:0', dtype=torch.int64)
    arg4_1 = rand_strided((64, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg5_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg6_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg7_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg8_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg9_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg10_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg11_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg12_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg13_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg14_1 = 50
    arg15_1 = 76
    arg16_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg17_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg18_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg19_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg20_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg21_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg22_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg23_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg24_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg25_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg26_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg27_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg28_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg29_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg30_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg31_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg32_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg33_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg34_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg35_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg36_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg37_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg38_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg39_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg40_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg41_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg42_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg43_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg44_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg45_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg46_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg47_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg48_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg49_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg50_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg51_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg52_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg53_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg54_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg55_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg56_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg57_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg58_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg59_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg60_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg61_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg62_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg63_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg64_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg65_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg66_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg67_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg68_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg69_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg70_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg71_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg72_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg73_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg74_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg75_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg76_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg77_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg78_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg79_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg80_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg81_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg82_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg83_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg84_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg85_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg86_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg87_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg88_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg89_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg90_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg91_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg92_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg93_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg94_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg95_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg96_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg97_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg98_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg99_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg100_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg101_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg102_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg103_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg104_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg105_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg106_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg107_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg108_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg109_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg110_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg111_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg112_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg113_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg114_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg115_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg116_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg117_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg118_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg119_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg120_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg121_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg122_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg123_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg124_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg125_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg126_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg127_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg128_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg129_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg130_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg131_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg132_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg133_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg134_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg135_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg136_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg137_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg138_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg139_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg140_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg141_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg142_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg143_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg144_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg145_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg146_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg147_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg148_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg149_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg150_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg151_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg152_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg153_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg154_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg155_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg156_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg157_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg158_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg159_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg160_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg161_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg162_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg163_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg164_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg165_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg166_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg167_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg168_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg169_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg170_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg171_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg172_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg173_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg174_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg175_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg176_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg177_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg178_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg179_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg180_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg181_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg182_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg183_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg184_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg185_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg186_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg187_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg188_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg189_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg190_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg191_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg192_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg193_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg194_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg195_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg196_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg197_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg198_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg199_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg200_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg201_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg202_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg203_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg204_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg205_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg206_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg207_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg208_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg209_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg210_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg211_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg212_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg213_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg214_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg215_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg216_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg217_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg218_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg219_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg220_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg221_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg222_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg223_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg224_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg225_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg226_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg227_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg228_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg229_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg230_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg231_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg232_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg233_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg234_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg235_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg236_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg237_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg238_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg239_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg240_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg241_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg242_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg243_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg244_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg245_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg246_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg247_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg248_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg249_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg250_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg251_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg252_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg253_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg254_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg255_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg256_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg257_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg258_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg259_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg260_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg261_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg262_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg263_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg264_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg265_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg266_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg267_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg268_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg269_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg270_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg271_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg272_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg273_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg274_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg275_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg276_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg277_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg278_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg279_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg280_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg281_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg282_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg283_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg284_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg285_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg286_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg287_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg288_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg289_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg290_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg291_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg292_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg293_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg294_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg295_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg296_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg297_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg298_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg299_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg300_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg301_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg302_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg303_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg304_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg305_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg306_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg307_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg308_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg309_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg310_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg311_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg312_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg313_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg314_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg315_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg316_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg317_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg318_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg319_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg320_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg321_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg322_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg323_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg324_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg325_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg326_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg327_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg328_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg329_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg330_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg331_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg332_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg333_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg334_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg335_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg336_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg337_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg338_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg339_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg340_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg341_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg342_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg343_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg344_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg345_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg346_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg347_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg348_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg349_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg350_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg351_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg352_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg353_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg354_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg355_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg356_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg357_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg358_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg359_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg360_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg361_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg362_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg363_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg364_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg365_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg366_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg367_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg368_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg369_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg370_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg371_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg372_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg373_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg374_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg375_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg376_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg377_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg378_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg379_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg380_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg381_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg382_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg383_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg384_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg385_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg386_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg387_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg388_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg389_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg390_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg391_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg392_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg393_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg394_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg395_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg396_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg397_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg398_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg399_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg400_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg401_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg402_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg403_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg404_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg405_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg406_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg407_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg408_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg409_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg410_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg411_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg412_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg413_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg414_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg415_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg416_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg417_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg418_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg419_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg420_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg421_1 = rand_strided((50, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg422_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg423_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg424_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg425_1 = rand_strided((17920, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg426_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg427_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg428_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg429_1 = 1
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
