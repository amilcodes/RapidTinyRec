# AOT ID: ['5_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
from torch._inductor.runtime.runtime_utils import assert_tensor_metadata

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/ck/cckvoeogtkik3fvabh6wpahgnd7vvfo7wgbirhk4tknbhnscvv2v.py
# Topologically Sorted Source Nodes: [inputs_embeds, pow_1, variance, rsqrt, hidden_states_1, hidden_states_2], Original ATen: [aten.embedding, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   hidden_states_1 => mul_44
#   hidden_states_2 => mul_47
#   inputs_embeds => embedding
#   pow_1 => pow_1
#   rsqrt => rsqrt
#   variance => mean
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %arg7_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg7_1]
#   %buf0 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf0]
#   %arg6_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg6_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %pow_1 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%embedding, 2), kwargs = {})
#   %mean : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %convert_element_type_default_4 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg6_1, torch.float32), kwargs = {})
#   %add_tensor : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, %convert_element_type_default_4), kwargs = {})
#   %rsqrt : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor,), kwargs = {})
#   %mul_44 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%embedding, %rsqrt), kwargs = {})
#   %mul_47 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg7_1, %mul_44), kwargs = {})
#   return %buf0,%mul_47
triton_red_fused_embedding_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_red_fused_embedding_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_embedding_mean_mul_pow_rsqrt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 620544}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_embedding_mean_mul_pow_rsqrt_0(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    tmp12 = in_ptr3
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp9 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tl.full([1, 1], 1536.0, tl.float32)
        tmp11 = (tmp5 / tmp10)
        tmp13 = tmp12.to(tl.float32)
        tmp14 = tmp11 + tmp13
        tmp15 = libdevice.rsqrt(tmp14)
        tmp16 = tmp9 * tmp15
        tmp17 = tmp7 * tmp16
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp17, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/ga/cgateun2feykz2hvaxvlj33lb6mkifswl7gzxo7c2kmm6n4nasud.py
# Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, sin, sin_3, linear_1, view_1, key_states, mul_6, x2_1, neg_1, x1_1, cat_2, mul_7, k_embed], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
# Source node to ATen node mapping:
#   cat_2 => cat_1
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   k_embed => add_216
#   key_states => permute_4
#   linear_1 => view_8
#   matmul => mul_14
#   mul_6 => mul_103
#   mul_7 => mul_114
#   neg_1 => neg_1
#   position_ids_expanded => convert_element_type
#   sin => sin
#   sin_3 => unsqueeze_5
#   view_1 => view_9
#   x1_1 => slice_4
#   x2_1 => slice_5
# Graph fragment:
#   %addmm_1 : Tensor "f32[s16, 256][256, 1]cuda:0" = PlaceHolder[target=addmm_1]
#   %arg4_1 : Tensor "f32[64][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %arg3_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg3_1]
#   %arg5_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg5_1]
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %view_8 : Tensor "f32[s16, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_1, [%arg14_1, 1, 256]), kwargs = {})
#   %view_9 : Tensor "f32[s16, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_8, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_4 : Tensor "f32[s16, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_9, [0, 2, 1, 3]), kwargs = {})
#   %mul_103 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_4, %unsqueeze_4), kwargs = {})
#   %slice_5 : Tensor "f32[s16, 2, 1, 64][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_4, 3, 64, 9223372036854775807), kwargs = {})
#   %neg_1 : Tensor "f32[s16, 2, 1, 64][128, 64, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_5,), kwargs = {})
#   %slice_4 : Tensor "f32[s16, 2, 1, 64][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_4, 3, 0, 64), kwargs = {})
#   %cat_1 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %slice_4], -1), kwargs = {})
#   %mul_114 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %unsqueeze_5), kwargs = {})
#   %add_216 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_103, %mul_114), kwargs = {})
#   return %add_216
triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1 = async_compile.triton('triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16384}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*i64', 'in_ptr3': 'fp64', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 256656}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x3 = xindex
    x2 = xindex // 256
    x0 = (xindex % 128)
    x4 = xindex // 128
    tmp0 = tl.load(in_ptr0 + (x3), xmask)
    tmp1 = tl.load(in_ptr1 + ((x3 % 64)), xmask, eviction_policy='evict_last')
    tmp2 = tl.load(in_ptr2 + (x2), xmask, eviction_policy='evict_last')
    tmp6 = in_ptr3
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp1 * tmp3
    tmp5 = tl_math.cos(tmp4)
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tmp5 * tmp7
    tmp9 = tmp0 * tmp8
    tmp10 = (x0).to(tl.int32)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 >= tmp11
    tmp13 = (x0).to(tl.int64)
    tmp14 = (tmp13).to(tl.int64)
    tmp15 = tl.full([1], 64, tl.int64)
    tmp16 = tmp14 < tmp15
    tmp17 = tl.load(in_ptr0 + (64 + 128*x4 + (x0)), tmp16 & xmask, eviction_policy='evict_last', other=0.0)
    tmp18 = -tmp17
    tmp19 = tl.full(tmp18.shape, 0.0, tmp18.dtype)
    tmp20 = tl.where(tmp16, tmp18, tmp19)
    tmp21 = tmp10 >= tmp15
    tmp22 = tl.full([1], 128, tl.int64)
    tmp23 = tmp10 < tmp22
    tmp24 = tl.load(in_ptr0 + (128*x4 + ((-64) + x0)), tmp21 & xmask, eviction_policy='evict_last', other=0.0)
    tmp25 = tl.where(tmp16, tmp20, tmp24)
    tmp26 = tl_math.sin(tmp4)
    tmp27 = tmp26 * tmp7
    tmp28 = tmp25 * tmp27
    tmp29 = tmp9 + tmp28
    tl.store(out_ptr0 + (x3), tmp29, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/ni/cnipjlnjtfvknyfvj2gktqha2gyxmk4ovk7jftxrycez5ytajbce.py
# Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, linear_2, view_2, value_states, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
# Source node to ATen node mapping:
#   cat_1 => cat
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   expand_1 => expand_4
#   expand_2 => expand_5
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   key_tensors => cat_2
#   linear => view_5
#   linear_2 => view_11
#   matmul => mul_14
#   mul_4 => mul_87
#   mul_5 => mul_98
#   neg => neg
#   output => _scaled_dot_product_efficient_attention
#   packed => view_13
#   position_ids_expanded => convert_element_type
#   q_embed => add_180
#   query_states => permute_2
#   sin => sin
#   sin_3 => unsqueeze_5
#   value_states => permute_6
#   value_tensors => cat_3
#   view => view_6
#   view_2 => view_12
#   x1 => slice_2
#   x2 => slice_3
# Graph fragment:
#   %addmm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=addmm]
#   %arg4_1 : Tensor "f32[64][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %arg3_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg3_1]
#   %arg5_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg5_1]
#   %view_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [%arg14_1, 1, 1536]), kwargs = {})
#   %view_6 : Tensor "f32[s16, 1, 12, 128][1536, 1536, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_5, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_2 : Tensor "f32[s16, 12, 1, 128][1536, 128, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_6, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %mul_87 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_2, %unsqueeze_4), kwargs = {})
#   %slice_3 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "f32[s16, 12, 1, 64][768, 64, 768, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_3,), kwargs = {})
#   %slice_2 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 0, 64), kwargs = {})
#   %cat : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_2], -1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %mul_98 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_5), kwargs = {})
#   %add_180 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_87, %mul_98), kwargs = {})
#   %view_13 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add_180, [%arg14_1, 2, 6, 128]), kwargs = {})
#   %expand_4 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg18_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %cat_2 : Tensor "f32[s16, 2, s91 + 1, 128][256*s91 + 256, 128*s91 + 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_4, %add_216], -2), kwargs = {})
#   %expand_5 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg19_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %view_11 : Tensor "f32[s16, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_2, [%arg14_1, 1, 256]), kwargs = {})
#   %view_12 : Tensor "f32[s16, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_11, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_6 : Tensor "f32[s16, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_12, [0, 2, 1, 3]), kwargs = {})
#   %cat_3 : Tensor "f32[s16, 2, s91 + 1, 128][256*s91 + 256, 128*s91 + 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_5, %permute_6], -2), kwargs = {})
#   %_scaled_dot_product_efficient_attention : [num_users=1] = call_function[target=torch.ops.aten._scaled_dot_product_efficient_attention.default](args = (%view_13, %cat_2, %cat_3, None, False), kwargs = {scale: 0.08838834764831845})
#   return %buf6
triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2 = async_compile.triton('triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*i64', 'in_ptr3': 'fp64', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1536656}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x3 = xindex
    x2 = xindex // 1536
    x0 = (xindex % 128)
    x4 = xindex // 128
    tmp0 = tl.load(in_ptr0 + (x3), xmask)
    tmp1 = tl.load(in_ptr1 + ((x3 % 64)), xmask, eviction_policy='evict_last')
    tmp2 = tl.load(in_ptr2 + (x2), xmask, eviction_policy='evict_last')
    tmp6 = in_ptr3
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp1 * tmp3
    tmp5 = tl_math.cos(tmp4)
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tmp5 * tmp7
    tmp9 = tmp0 * tmp8
    tmp10 = (x0).to(tl.int32)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 >= tmp11
    tmp13 = (x0).to(tl.int64)
    tmp14 = (tmp13).to(tl.int64)
    tmp15 = tl.full([1], 64, tl.int64)
    tmp16 = tmp14 < tmp15
    tmp17 = tl.load(in_ptr0 + (64 + 128*x4 + (x0)), tmp16 & xmask, eviction_policy='evict_last', other=0.0)
    tmp18 = -tmp17
    tmp19 = tl.full(tmp18.shape, 0.0, tmp18.dtype)
    tmp20 = tl.where(tmp16, tmp18, tmp19)
    tmp21 = tmp10 >= tmp15
    tmp22 = tl.full([1], 128, tl.int64)
    tmp23 = tmp10 < tmp22
    tmp24 = tl.load(in_ptr0 + (128*x4 + ((-64) + x0)), tmp21 & xmask, eviction_policy='evict_last', other=0.0)
    tmp25 = tl.where(tmp16, tmp20, tmp24)
    tmp26 = tl_math.sin(tmp4)
    tmp27 = tmp26 * tmp7
    tmp28 = tmp25 * tmp27
    tmp29 = tmp9 + tmp28
    tl.store(out_ptr0 + (x3), tmp29, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/ft/cftrprs67pmjpkgoa7igfogfk6blesiyk6g2wc6cv34qaedcqeeo.py
# Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, linear_2, view_2, value_states, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
# Source node to ATen node mapping:
#   cat_1 => cat
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   expand_1 => expand_4
#   expand_2 => expand_5
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   key_tensors => cat_2
#   linear => view_5
#   linear_2 => view_11
#   matmul => mul_14
#   mul_4 => mul_87
#   mul_5 => mul_98
#   neg => neg
#   output => _scaled_dot_product_efficient_attention
#   packed => view_13
#   position_ids_expanded => convert_element_type
#   q_embed => add_180
#   query_states => permute_2
#   sin => sin
#   sin_3 => unsqueeze_5
#   value_states => permute_6
#   value_tensors => cat_3
#   view => view_6
#   view_2 => view_12
#   x1 => slice_2
#   x2 => slice_3
# Graph fragment:
#   %arg18_1 : Tensor "f32[1, 2, s91, 128][256*s91, 128*s91, 128, 1]cuda:0" = PlaceHolder[target=arg18_1]
#   %add_216 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0" = PlaceHolder[target=add_216]
#   %view_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [%arg14_1, 1, 1536]), kwargs = {})
#   %view_6 : Tensor "f32[s16, 1, 12, 128][1536, 1536, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_5, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_2 : Tensor "f32[s16, 12, 1, 128][1536, 128, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_6, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %mul_87 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_2, %unsqueeze_4), kwargs = {})
#   %slice_3 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "f32[s16, 12, 1, 64][768, 64, 768, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_3,), kwargs = {})
#   %slice_2 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 0, 64), kwargs = {})
#   %cat : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_2], -1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %mul_98 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_5), kwargs = {})
#   %add_180 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_87, %mul_98), kwargs = {})
#   %view_13 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add_180, [%arg14_1, 2, 6, 128]), kwargs = {})
#   %expand_4 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg18_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %cat_2 : Tensor "f32[s16, 2, s91 + 1, 128][256*s91 + 256, 128*s91 + 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_4, %add_216], -2), kwargs = {})
#   %expand_5 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg19_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %view_11 : Tensor "f32[s16, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_2, [%arg14_1, 1, 256]), kwargs = {})
#   %view_12 : Tensor "f32[s16, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_11, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_6 : Tensor "f32[s16, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_12, [0, 2, 1, 3]), kwargs = {})
#   %cat_3 : Tensor "f32[s16, 2, s91 + 1, 128][256*s91 + 256, 128*s91 + 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_5, %permute_6], -2), kwargs = {})
#   %_scaled_dot_product_efficient_attention : [num_users=1] = call_function[target=torch.ops.aten._scaled_dot_product_efficient_attention.default](args = (%view_13, %cat_2, %cat_3, None, False), kwargs = {scale: 0.08838834764831845})
#   return %buf7
triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3 = async_compile.triton('triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'ks0': 'i64', 'ks1': 'i64', 'ks2': 'i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 8013824}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3(in_ptr0, in_ptr1, out_ptr0, ks0, ks1, ks2, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = ((xindex // 128) % ks0)
    x0 = (xindex % 128)
    x2 = ((xindex // ks2) % 2)
    x5 = xindex // ks2
    x4 = xindex
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x1).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = (ks1).to(tl.int64)
    tmp6 = (tmp5).to(tl.int64)
    tmp7 = tmp4 < tmp6
    tmp8 = tl.load(in_ptr0 + (x0 + 128*(x1) + 128*ks1*x2), tmp7 & xmask, eviction_policy='evict_last', other=0.0)
    tmp9 = (ks1).to(tl.int32)
    tmp10 = tmp0 >= tmp9
    tmp11 = (ks0).to(tl.int32)
    tmp12 = tmp0 < tmp11
    tmp13 = tl.load(in_ptr1 + (x0 + 128*x5), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp14 = tl.where(tmp7, tmp8, tmp13)
    tl.store(out_ptr0 + (x4), tmp14, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/hr/chrjjprrivuviusbims7kprdvank2wjgmz7x52lmec3v6cd4yg56.py
# Topologically Sorted Source Nodes: [attn_output], Original ATen: [aten.clone]
# Source node to ATen node mapping:
#   attn_output => clone_4
# Graph fragment:
#   %getitem : Tensor "f32[s16, 2, 6, 128][1536, 128, 256, 1]cuda:0" = PlaceHolder[target=getitem]
#   %clone_4 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%getitem,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone_4
triton_poi_fused_clone_4 = async_compile.triton('triton_poi_fused_clone_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_clone_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 921600}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_clone_4(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 6)
    x2 = ((xindex // 768) % 2)
    x3 = xindex // 1536
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 128*x2 + 256*x1 + 1536*x3), xmask)
    tl.store(out_ptr0 + (x4), tmp0, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/yu/cyuadoqeapbd2t34bycowlx4e4odu3litthbwlkmmyknikc5p5zf.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, pow_2, variance_1, rsqrt_1, hidden_states_5, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   hidden_states_3 => add_291
#   hidden_states_5 => mul_217
#   hidden_states_6 => mul_220
#   inputs_embeds => embedding
#   pow_2 => pow_2
#   rsqrt_1 => rsqrt_1
#   variance_1 => mean_1
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %arg22_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg22_1]
#   %buf16 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf16]
#   %arg21_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg21_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_291 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %pow_2 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_291, 2), kwargs = {})
#   %mean_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %convert_element_type_default_6 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg21_1, torch.float32), kwargs = {})
#   %add_tensor_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, %convert_element_type_default_6), kwargs = {})
#   %rsqrt_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_1,), kwargs = {})
#   %mul_217 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_291, %rsqrt_1), kwargs = {})
#   %mul_220 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg22_1, %mul_217), kwargs = {})
#   return %buf16,%mul_220
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 927744}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    tmp16 = in_ptr4
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tmp11 + tmp12
        tmp14 = tl.full([1, 1], 1536.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tmp15 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp13 * tmp19
        tmp21 = tmp9 * tmp20
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp21, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/ge/cgeubuhpoiyy2agm5o3xjspcpt3zzcgpqynavmr72iv5pyddffmt.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_10], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
# Source node to ATen node mapping:
#   linear_4 => view_19
#   linear_5 => view_21
#   mul_10 => mul_250
#   silu => add_331, div, exp, neg_2
# Graph fragment:
#   %mm_1 : Tensor "f32[s16, 8960][8960, 1]cuda:0" = PlaceHolder[target=mm_1]
#   %mm_2 : Tensor "f32[s16, 8960][8960, 1]cuda:0" = PlaceHolder[target=mm_2]
#   %view_19 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [%arg14_1, 1, 8960]), kwargs = {})
#   %neg_2 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%view_19,), kwargs = {})
#   %exp : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_331 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%view_19, %add_331), kwargs = {})
#   %view_21 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [%arg14_1, 1, 8960]), kwargs = {})
#   %mul_250 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%div, %view_21), kwargs = {})
#   return %mul_250
triton_poi_fused__unsafe_view_mul_silu_6 = async_compile.triton('triton_poi_fused__unsafe_view_mul_silu_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_mul_silu_6', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 7168000}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_mul_silu_6(in_out_ptr0, in_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_out_ptr0 + (x0), xmask)
    tmp6 = tl.load(in_ptr0 + (x0), xmask)
    tmp1 = -tmp0
    tmp2 = libdevice.exp(tmp1)
    tmp3 = tl.full([1], 1.0, tl.float32)
    tmp4 = tmp2 + tmp3
    tmp5 = (tmp0 / tmp4)
    tmp7 = tmp5 * tmp6
    tl.store(in_out_ptr0 + (x0), tmp7, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/3n/c3n4p53u2b5ksqygihm5ukzkzve35a42ian3rmgaalbiujudwqah.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, down_proj, hidden_states_7, pow_3, variance_2, rsqrt_2, hidden_states_9, hidden_states_10], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   down_proj => view_23
#   hidden_states_10 => mul_277
#   hidden_states_3 => add_291
#   hidden_states_7 => add_360
#   hidden_states_9 => mul_274
#   inputs_embeds => embedding
#   pow_3 => pow_3
#   rsqrt_2 => rsqrt_2
#   variance_2 => mean_2
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %mm_3 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_3]
#   %arg27_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg27_1]
#   %buf22 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf22]
#   %arg26_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg26_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_291 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %view_23 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_360 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_291, %view_23), kwargs = {})
#   %pow_3 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_360, 2), kwargs = {})
#   %mean_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %convert_element_type_default_8 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg26_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, %convert_element_type_default_8), kwargs = {})
#   %rsqrt_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_2,), kwargs = {})
#   %mul_274 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_360, %rsqrt_2), kwargs = {})
#   %mul_277 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg27_1, %mul_274), kwargs = {})
#   return %buf22,%mul_277
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    tmp20 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp14 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp16 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tmp13 + tmp14
        tmp17 = tmp15 + tmp16
        tmp18 = tl.full([1, 1], 1536.0, tl.float32)
        tmp19 = (tmp9 / tmp18)
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp19 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp17 * tmp23
        tmp25 = tmp11 * tmp24
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp25, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/sn/csn6ccor6ary7eqpdezyaaq4ntwang2mm355374s2sv46v6rp7fh.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, down_proj, hidden_states_7, attn_output_7, hidden_states_11, pow_4, variance_3, rsqrt_3, hidden_states_13, hidden_states_14], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   attn_output_7 => view_37
#   down_proj => view_23
#   hidden_states_11 => add_601
#   hidden_states_13 => mul_447
#   hidden_states_14 => mul_450
#   hidden_states_3 => add_291
#   hidden_states_7 => add_360
#   inputs_embeds => embedding
#   pow_4 => pow_4
#   rsqrt_3 => rsqrt_3
#   variance_3 => mean_3
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %mm_3 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_3]
#   %mm_4 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_4]
#   %add_601 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_601]
#   %arg40_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg40_1]
#   %buf39 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf39]
#   %arg39_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg39_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_291 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %view_23 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_360 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_291, %view_23), kwargs = {})
#   %view_37 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_601 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_360, %view_37), kwargs = {})
#   %pow_4 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_601, 2), kwargs = {})
#   %mean_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %convert_element_type_default_10 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg39_1, torch.float32), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, %convert_element_type_default_10), kwargs = {})
#   %rsqrt_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_447 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_601, %rsqrt_3), kwargs = {})
#   %mul_450 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg40_1, %mul_447), kwargs = {})
#   return %add_601,%buf39,%mul_450
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 2156544}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp11 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp5 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp7 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask & xmask, tmp12, _tmp11)
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp8, r0_mask & xmask)
    tmp11 = tl.sum(_tmp11, 1)[:, None]
    tmp17 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.debug_barrier()
        tmp14 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp11 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp13 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/5l/c5llxk643ulqbekz24lcsa2sz6kwkig7mnhzxrdnnuldedvttsju.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, pow_5, variance_4, rsqrt_4, hidden_states_17, hidden_states_18], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   down_proj_1 => view_43
#   hidden_states_15 => add_670
#   hidden_states_17 => mul_504
#   hidden_states_18 => mul_507
#   pow_5 => pow_5
#   rsqrt_4 => rsqrt_4
#   variance_4 => mean_4
# Graph fragment:
#   %add_601 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_601]
#   %mm_7 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %arg45_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg45_1]
#   %buf45 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf45]
#   %arg44_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg44_1]
#   %view_43 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_670 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_601, %view_43), kwargs = {})
#   %pow_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_670, 2), kwargs = {})
#   %mean_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [-1], True), kwargs = {})
#   %convert_element_type_default_12 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg44_1, torch.float32), kwargs = {})
#   %add_tensor_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_4, %convert_element_type_default_12), kwargs = {})
#   %rsqrt_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_4,), kwargs = {})
#   %mul_504 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_670, %rsqrt_4), kwargs = {})
#   %mul_507 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg45_1, %mul_504), kwargs = {})
#   return %buf45,%mul_507
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    tmp13 = in_ptr3
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp8 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp9 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tmp8 + tmp9
        tmp11 = tl.full([1, 1], 1536.0, tl.float32)
        tmp12 = (tmp5 / tmp11)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tmp12 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp10 * tmp16
        tmp18 = tmp7 * tmp17
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp18, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/7a/c7aklu4fbiemns3ltg3c54mrcudd2a7nyscig7bkcvaywbl72f5d.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, pow_6, variance_5, rsqrt_5, hidden_states_21, hidden_states_22], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_57
#   down_proj_1 => view_43
#   hidden_states_15 => add_670
#   hidden_states_19 => add_911
#   hidden_states_21 => mul_677
#   hidden_states_22 => mul_680
#   pow_6 => pow_6
#   rsqrt_5 => rsqrt_5
#   variance_5 => mean_5
# Graph fragment:
#   %add_601 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_601]
#   %mm_7 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %mm_8 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %arg58_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg58_1]
#   %buf61 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf61]
#   %arg57_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg57_1]
#   %view_43 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_670 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_601, %view_43), kwargs = {})
#   %view_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_911 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_670, %view_57), kwargs = {})
#   %pow_6 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_911, 2), kwargs = {})
#   %mean_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %convert_element_type_default_14 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg57_1, torch.float32), kwargs = {})
#   %add_tensor_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, %convert_element_type_default_14), kwargs = {})
#   %rsqrt_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_5,), kwargs = {})
#   %mul_677 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_911, %rsqrt_5), kwargs = {})
#   %mul_680 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg58_1, %mul_677), kwargs = {})
#   return %buf61,%mul_680
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1542144}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    tmp17 = in_ptr4
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp10 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp7 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp9 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/sk/cskx4kb6fpqafmn3f6xhgtoz5ohz2rfyt3rnqnmrmmwximkffpn5.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, down_proj_2, hidden_states_23, pow_7, variance_6, rsqrt_6, hidden_states_25, hidden_states_26], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_57
#   down_proj_1 => view_43
#   down_proj_2 => view_63
#   hidden_states_15 => add_670
#   hidden_states_19 => add_911
#   hidden_states_23 => add_980
#   hidden_states_25 => mul_734
#   hidden_states_26 => mul_737
#   pow_7 => pow_7
#   rsqrt_6 => rsqrt_6
#   variance_6 => mean_6
# Graph fragment:
#   %add_601 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_601]
#   %mm_7 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %mm_8 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %mm_11 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_11]
#   %arg63_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg63_1]
#   %buf67 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf67]
#   %arg62_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg62_1]
#   %view_43 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_670 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_601, %view_43), kwargs = {})
#   %view_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_911 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_670, %view_57), kwargs = {})
#   %view_63 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_11, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_980 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_911, %view_63), kwargs = {})
#   %pow_7 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_980, 2), kwargs = {})
#   %mean_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [-1], True), kwargs = {})
#   %convert_element_type_default_16 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg62_1, torch.float32), kwargs = {})
#   %add_tensor_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_6, %convert_element_type_default_16), kwargs = {})
#   %rsqrt_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_6,), kwargs = {})
#   %mul_734 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_980, %rsqrt_6), kwargs = {})
#   %mul_737 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg63_1, %mul_734), kwargs = {})
#   return %buf67,%mul_737
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 10, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1849344}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    tmp21 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp17 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tl.full([1, 1], 1536.0, tl.float32)
        tmp20 = (tmp9 / tmp19)
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tmp20 + tmp22
        tmp24 = libdevice.rsqrt(tmp23)
        tmp25 = tmp18 * tmp24
        tmp26 = tmp11 * tmp25
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp26, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/ca/ccakktfdoy2u7gzyqufh3ofs6ubj4cxdwh34rylvw24c4wkukic5.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, down_proj_2, hidden_states_23, attn_output_15, hidden_states_27, pow_8, variance_7, rsqrt_7, hidden_states_29, hidden_states_30], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_57
#   attn_output_15 => view_77
#   down_proj_1 => view_43
#   down_proj_2 => view_63
#   hidden_states_15 => add_670
#   hidden_states_19 => add_911
#   hidden_states_23 => add_980
#   hidden_states_27 => add_1221
#   hidden_states_29 => mul_907
#   hidden_states_30 => mul_910
#   pow_8 => pow_8
#   rsqrt_7 => rsqrt_7
#   variance_7 => mean_7
# Graph fragment:
#   %add_601 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_601]
#   %mm_7 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %mm_8 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %mm_11 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_11]
#   %mm_12 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_12]
#   %add_1221 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_1221]
#   %arg76_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg76_1]
#   %buf84 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf84]
#   %arg75_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg75_1]
#   %view_43 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_670 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_601, %view_43), kwargs = {})
#   %view_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_911 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_670, %view_57), kwargs = {})
#   %view_63 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_11, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_980 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_911, %view_63), kwargs = {})
#   %view_77 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_12, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_1221 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_980, %view_77), kwargs = {})
#   %pow_8 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_1221, 2), kwargs = {})
#   %mean_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_8, [-1], True), kwargs = {})
#   %convert_element_type_default_18 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg75_1, torch.float32), kwargs = {})
#   %add_tensor_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_7, %convert_element_type_default_18), kwargs = {})
#   %rsqrt_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_7,), kwargs = {})
#   %mul_907 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_1221, %rsqrt_7), kwargs = {})
#   %mul_910 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg76_1, %mul_907), kwargs = {})
#   return %add_1221,%buf84,%mul_910
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 2770944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp11 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp3 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp5 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp7 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask & xmask, tmp12, _tmp11)
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp8, r0_mask & xmask)
    tmp11 = tl.sum(_tmp11, 1)[:, None]
    tmp17 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.debug_barrier()
        tmp14 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp11 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp13 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/cb/ccbefgmbd7oj7qu6z62xiurvt56fgv7um3maaspmw4ykilbgq55g.py
# Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, attn_output_59, hidden_states_115, down_proj_14, hidden_states_119, pow_31, variance_30, add_90, rsqrt_30, hidden_states_121, hidden_states_122], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_90 => add_4713
#   attn_output_59 => view_297
#   down_proj_13 => view_283
#   down_proj_14 => view_303
#   hidden_states_111 => add_4390
#   hidden_states_115 => add_4631
#   hidden_states_119 => add_4700
#   hidden_states_121 => mul_3494
#   hidden_states_122 => mul_3497
#   pow_31 => pow_31
#   rsqrt_30 => rsqrt_30
#   variance_30 => mean_30
# Graph fragment:
#   %add_4321 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_4321]
#   %mm_55 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_55]
#   %mm_56 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_56]
#   %mm_59 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_59]
#   %arg278_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg278_1]
#   %buf337 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf337]
#   %view_283 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_55, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4390 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4321, %view_283), kwargs = {})
#   %view_297 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_56, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4631 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4390, %view_297), kwargs = {})
#   %view_303 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_59, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4700 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4631, %view_303), kwargs = {})
#   %pow_31 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_4700, 2), kwargs = {})
#   %mean_30 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_31, [-1], True), kwargs = {})
#   %add_4713 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_30, 1e-06), kwargs = {})
#   %rsqrt_30 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4713,), kwargs = {})
#   %mul_3494 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_4700, %rsqrt_30), kwargs = {})
#   %mul_3497 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg278_1, %mul_3494), kwargs = {})
#   return %buf337,%mul_3497
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1849344}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp17 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tl.full([1, 1], 1536.0, tl.float32)
        tmp20 = (tmp9 / tmp19)
        tmp21 = tl.full([1, 1], 1e-06, tl.float32)
        tmp22 = tmp20 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp18 * tmp23
        tmp25 = tmp11 * tmp24
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp25, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/ok/cokj6pzt5wpj7spgw3uq4s6dpva4cuf2g3ueahcpnduhkr5ene6y.py
# Topologically Sorted Source Nodes: [down_proj_21, hidden_states_175, attn_output_91, hidden_states_179, pow_46, variance_45, add_136, rsqrt_45, hidden_states_181, hidden_states_182], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_136 => add_7124
#   attn_output_91 => view_457
#   down_proj_21 => view_443
#   hidden_states_175 => add_6870
#   hidden_states_179 => add_7111
#   hidden_states_181 => mul_5277
#   hidden_states_182 => mul_5280
#   pow_46 => pow_46
#   rsqrt_45 => rsqrt_45
#   variance_45 => mean_45
# Graph fragment:
#   %add_6801 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_6801]
#   %mm_87 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_87]
#   %mm_88 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_88]
#   %arg416_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg416_1]
#   %buf511 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf511]
#   %view_443 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_87, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_6870 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_6801, %view_443), kwargs = {})
#   %view_457 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_88, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_7111 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_6870, %view_457), kwargs = {})
#   %pow_46 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_7111, 2), kwargs = {})
#   %mean_45 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_46, [-1], True), kwargs = {})
#   %add_7124 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_45, 1e-06), kwargs = {})
#   %rsqrt_45 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7124,), kwargs = {})
#   %mul_5277 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_7111, %rsqrt_45), kwargs = {})
#   %mul_5280 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg416_1, %mul_5277), kwargs = {})
#   return %buf511,%mul_5280
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1542144}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp10 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp7 / tmp15)
        tmp17 = tl.full([1, 1], 1e-06, tl.float32)
        tmp18 = tmp16 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp14 * tmp19
        tmp21 = tmp9 * tmp20
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp21, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-decode-replay/packed-mlp-pilot-20261024T215118Z-533138a5b479/compile-cache/folded/inductor/hp/chpam4npgnp34nonval3gujwdkgw5yahnn36jidjbterbbrps6ye.py
# Topologically Sorted Source Nodes: [down_proj_27, hidden_states_223, pow_57, variance_56, add_168, rsqrt_56, hidden_states_225, hidden_states_226], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_168 => add_8743
#   down_proj_27 => view_563
#   hidden_states_223 => add_8730
#   hidden_states_225 => mul_6484
#   hidden_states_226 => mul_6487
#   pow_57 => pow_57
#   rsqrt_56 => rsqrt_56
#   variance_56 => mean_56
# Graph fragment:
#   %add_8661 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_8661]
#   %mm_111 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_111]
#   %arg510_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg510_1]
#   %buf630 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf630]
#   %view_563 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_111, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_8730 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_8661, %view_563), kwargs = {})
#   %pow_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_8730, 2), kwargs = {})
#   %mean_56 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_57, [-1], True), kwargs = {})
#   %add_8743 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_56, 1e-06), kwargs = {})
#   %rsqrt_56 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_8743,), kwargs = {})
#   %mul_6484 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_8730, %rsqrt_56), kwargs = {})
#   %mul_6487 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg510_1, %mul_6484), kwargs = {})
#   return %buf630,%mul_6487
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr1 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp8 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp9 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tmp8 + tmp9
        tmp11 = tl.full([1, 1], 1536.0, tl.float32)
        tmp12 = (tmp5 / tmp11)
        tmp13 = tl.full([1, 1], 1e-06, tl.float32)
        tmp14 = tmp12 + tmp13
        tmp15 = libdevice.rsqrt(tmp14)
        tmp16 = tmp10 * tmp15
        tmp17 = tmp7 * tmp16
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp17, r0_mask & xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1, arg458_1, arg459_1, arg460_1, arg461_1, arg462_1, arg463_1, arg464_1, arg465_1, arg466_1, arg467_1, arg468_1, arg469_1, arg470_1, arg471_1, arg472_1, arg473_1, arg474_1, arg475_1, arg476_1, arg477_1, arg478_1, arg479_1, arg480_1, arg481_1, arg482_1, arg483_1, arg484_1, arg485_1, arg486_1, arg487_1, arg488_1, arg489_1, arg490_1, arg491_1, arg492_1, arg493_1, arg494_1, arg495_1, arg496_1, arg497_1, arg498_1, arg499_1, arg500_1, arg501_1, arg502_1, arg503_1, arg504_1, arg505_1, arg506_1, arg507_1, arg508_1, arg509_1, arg510_1, arg511_1 = args
        args.clear()
        s16 = arg0_1
        s74 = s16
        s52 = s16
        s91 = arg17_1
        s35 = arg511_1
        assert_size_stride_grouped((arg1_1, arg2_1, arg7_1, arg6_1), ((s16, 1), (152265, 1536), (1536, ), ()), ((1, 1), (1536, 1), (1, ), ()), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg1_1 = copy_if_misaligned(arg1_1)
            buf1 = empty_strided_cuda((s16, 1, 1536), (1536, 1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [inputs_embeds, pow_1, variance, rsqrt, hidden_states_1, hidden_states_2], Original ATen: [aten.embedding, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_embedding_mean_mul_pow_rsqrt_0.run(arg1_1, arg2_1, arg7_1, arg6_1.item(), buf1, s16, 1536, stream=raw_stream0)
            del arg6_1
            del arg7_1
            assert_size_stride_grouped((arg9_1, arg8_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf2 = empty_strided_cuda((s16, 1536), (1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg9_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg8_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf2)
            del arg8_1
            del arg9_1
            assert_size_stride_grouped((arg11_1, arg10_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf3 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg11_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg10_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf3)
            del arg10_1
            del arg11_1
            assert_size_stride_grouped((arg4_1, arg3_1, arg5_1), ((64, ), (s16, 1), ()), ((1, ), (1, 1), ()), 'input')
            arg3_1 = copy_if_misaligned(arg3_1)
            buf4 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, sin, sin_3, linear_1, view_1, key_states, mul_6, x2_1, neg_1, x1_1, cat_2, mul_7, k_embed], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf3, arg4_1, arg3_1, arg5_1.item(), buf4, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg13_1, arg12_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf5 = buf3; del buf3  # reuse
            # Topologically Sorted Source Nodes: [linear_2], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg13_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg12_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf5)
            del arg12_1
            del arg13_1
            buf6 = reinterpret_tensor(buf1, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf1  # reuse
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, linear_2, view_2, value_states, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf2, arg4_1, arg3_1, arg5_1.item(), buf6, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg18_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg18_1 = copy_if_misaligned(arg18_1)
            ps0 = 1 + s91
            ps1 = 128 + 128*s91
            buf7 = empty_strided_cuda((s16, 2, 1 + s91, 128), (256 + 256*s91, 128 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, linear_2, view_2, value_states, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg18_1, buf4, buf7, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg18_1
            assert_size_stride(arg19_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg19_1 = copy_if_misaligned(arg19_1)
            buf8 = empty_strided_cuda((s16, 2, 1 + s91, 128), (256 + 256*s91, 128 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, linear_2, view_2, value_states, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg19_1, buf5, buf8, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg19_1
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, linear_2, view_2, value_states, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            buf9 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf6, buf7, buf8, None, False, scale=0.08838834764831845)
            buf10 = buf9[0]
            assert_tensor_metadata(buf10, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf10, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf9
            buf14 = buf6; del buf6  # reuse
            # Topologically Sorted Source Nodes: [attn_output], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf10, buf14, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg20_1, (1536, 1536), (1536, 1), 'input')
            buf15 = reinterpret_tensor(buf10, (s16, 1536), (1536, 1), 0); del buf10  # reuse
            # Topologically Sorted Source Nodes: [attn_output, transpose_4, reshape_2, attn_output_3], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf14, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg20_1, (1536, 1536), (1, 1536), 0), out=buf15)
            del arg20_1
            assert_size_stride_grouped((arg22_1, arg21_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf17 = reinterpret_tensor(buf14, (s16, 1, 1536), (1536, 1536, 1), 0); del buf14  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, pow_2, variance_1, rsqrt_1, hidden_states_5, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5.run(arg1_1, arg2_1, buf15, arg22_1, arg21_1.item(), buf17, s16, 1536, stream=raw_stream0)
            del arg21_1
            del arg22_1
            assert_size_stride(arg23_1, (8960, 1536), (1536, 1), 'input')
            buf18 = empty_strided_cuda((s16, 8960), (8960, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf17, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg23_1, (1536, 8960), (1, 1536), 0), out=buf18)
            del arg23_1
            assert_size_stride(arg24_1, (8960, 1536), (1536, 1), 'input')
            buf19 = empty_strided_cuda((s16, 8960), (8960, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_5], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf17, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg24_1, (1536, 8960), (1, 1536), 0), out=buf19)
            del arg24_1
            buf20 = reinterpret_tensor(buf18, (s16, 1, 8960), (8960, 8960, 1), 0); del buf18  # reuse
            # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_10], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf20, buf19, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg25_1, (1536, 8960), (8960, 1), 'input')
            buf21 = reinterpret_tensor(buf17, (s16, 1536), (1536, 1), 0); del buf17  # reuse
            # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_10, down_proj], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf20, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg25_1, (8960, 1536), (1, 8960), 0), out=buf21)
            del arg25_1
            assert_size_stride_grouped((arg27_1, arg26_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf23 = reinterpret_tensor(buf2, (s16, 1, 1536), (1536, 1536, 1), 0); del buf2  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, down_proj, hidden_states_7, pow_3, variance_2, rsqrt_2, hidden_states_9, hidden_states_10], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7.run(arg1_1, arg2_1, buf15, buf21, arg27_1, arg26_1.item(), buf23, s16, 1536, stream=raw_stream0)
            del arg26_1
            del arg27_1
            assert_size_stride_grouped((arg29_1, arg28_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf24 = empty_strided_cuda((s16, 1536), (1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg29_1, reinterpret_tensor(buf23, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg28_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf24)
            del arg28_1
            del arg29_1
            assert_size_stride_grouped((arg31_1, arg30_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf25 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_8], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg31_1, reinterpret_tensor(buf23, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg30_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf25)
            del arg30_1
            del arg31_1
            buf26 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_4, sin_4, linear_8, view_4, key_states_1, mul_15, x2_3, neg_3, x1_3, cat_8, mul_16, k_embed_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf25, arg4_1, arg3_1, arg5_1.item(), buf26, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg33_1, arg32_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf27 = buf25; del buf25  # reuse
            # Topologically Sorted Source Nodes: [linear_9], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg33_1, reinterpret_tensor(buf23, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg32_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf27)
            del arg32_1
            del arg33_1
            buf28 = reinterpret_tensor(buf23, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf23  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_7, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, linear_9, view_5, value_states_1, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf24, arg4_1, arg3_1, arg5_1.item(), buf28, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg36_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg36_1 = copy_if_misaligned(arg36_1)
            buf29 = buf8; del buf8  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_7, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, linear_9, view_5, value_states_1, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg36_1, buf26, buf29, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg36_1
            assert_size_stride(arg37_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg37_1 = copy_if_misaligned(arg37_1)
            buf30 = buf7; del buf7  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_7, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, linear_9, view_5, value_states_1, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg37_1, buf27, buf30, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg37_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_7, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, linear_9, view_5, value_states_1, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf31 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf28, buf29, buf30, None, False, scale=0.08838834764831845)
            buf32 = buf31[0]
            assert_tensor_metadata(buf32, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf32, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf31
            buf36 = buf28; del buf28  # reuse
            # Topologically Sorted Source Nodes: [attn_output_4], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf32, buf36, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg38_1, (1536, 1536), (1536, 1), 'input')
            buf37 = reinterpret_tensor(buf32, (s16, 1536), (1536, 1), 0); del buf32  # reuse
            # Topologically Sorted Source Nodes: [attn_output_4, transpose_8, reshape_5, attn_output_7], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf36, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg38_1, (1536, 1536), (1, 1536), 0), out=buf37)
            del arg38_1
            assert_size_stride_grouped((arg40_1, arg39_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf38 = reinterpret_tensor(buf15, (s16, 1, 1536), (1536, 1536*s16, 1), 0); del buf15  # reuse
            buf40 = reinterpret_tensor(buf36, (s16, 1, 1536), (1536, 1536, 1), 0); del buf36  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, down_proj, hidden_states_7, attn_output_7, hidden_states_11, pow_4, variance_3, rsqrt_3, hidden_states_13, hidden_states_14], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8.run(buf38, arg1_1, arg2_1, buf21, buf37, arg40_1, arg39_1.item(), buf40, s16, 1536, stream=raw_stream0)
            del arg1_1
            del arg39_1
            del arg40_1
            assert_size_stride(arg41_1, (8960, 1536), (1536, 1), 'input')
            buf41 = reinterpret_tensor(buf20, (s16, 8960), (8960, 1), 0); del buf20  # reuse
            # Topologically Sorted Source Nodes: [pow_4, variance_3, rsqrt_3, hidden_states_13, hidden_states_14, linear_11], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf40, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg41_1, (1536, 8960), (1, 1536), 0), out=buf41)
            del arg41_1
            assert_size_stride(arg42_1, (8960, 1536), (1536, 1), 'input')
            buf42 = buf19; del buf19  # reuse
            # Topologically Sorted Source Nodes: [linear_12], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf40, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg42_1, (1536, 8960), (1, 1536), 0), out=buf42)
            del arg42_1
            buf43 = reinterpret_tensor(buf41, (s16, 1, 8960), (8960, 8960, 1), 0); del buf41  # reuse
            # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_19], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf43, buf42, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg43_1, (1536, 8960), (8960, 1), 'input')
            buf44 = reinterpret_tensor(buf40, (s16, 1536), (1536, 1), 0); del buf40  # reuse
            # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_19, down_proj_1], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf43, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg43_1, (8960, 1536), (1, 8960), 0), out=buf44)
            del arg43_1
            assert_size_stride_grouped((arg45_1, arg44_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf46 = reinterpret_tensor(buf37, (s16, 1, 1536), (1536, 1536, 1), 0); del buf37  # reuse
            # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, pow_5, variance_4, rsqrt_4, hidden_states_17, hidden_states_18], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf38, buf44, arg45_1, arg44_1.item(), buf46, s16, 1536, stream=raw_stream0)
            del arg44_1
            del arg45_1
            assert_size_stride_grouped((arg47_1, arg46_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf47 = buf21; del buf21  # reuse
            # Topologically Sorted Source Nodes: [linear_14], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg47_1, reinterpret_tensor(buf46, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg46_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf47)
            del arg46_1
            del arg47_1
            assert_size_stride_grouped((arg49_1, arg48_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf48 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_15], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg49_1, reinterpret_tensor(buf46, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg48_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf48)
            del arg48_1
            del arg49_1
            buf49 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_5, sin_5, linear_15, view_7, key_states_2, mul_24, x2_5, neg_5, x1_5, cat_14, mul_25, k_embed_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf48, arg4_1, arg3_1, arg5_1.item(), buf49, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg51_1, arg50_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf50 = buf48; del buf48  # reuse
            # Topologically Sorted Source Nodes: [linear_16], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg51_1, reinterpret_tensor(buf46, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg50_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf50)
            del arg50_1
            del arg51_1
            buf51 = reinterpret_tensor(buf46, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf46  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_14, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, linear_16, view_8, value_states_2, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf47, arg4_1, arg3_1, arg5_1.item(), buf51, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg54_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg54_1 = copy_if_misaligned(arg54_1)
            buf52 = buf30; del buf30  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_14, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, linear_16, view_8, value_states_2, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg54_1, buf49, buf52, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg54_1
            assert_size_stride(arg55_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg55_1 = copy_if_misaligned(arg55_1)
            buf53 = buf29; del buf29  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_14, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, linear_16, view_8, value_states_2, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg55_1, buf50, buf53, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg55_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_14, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, linear_16, view_8, value_states_2, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf54 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf51, buf52, buf53, None, False, scale=0.08838834764831845)
            buf55 = buf54[0]
            assert_tensor_metadata(buf55, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf55, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf54
            buf59 = buf51; del buf51  # reuse
            # Topologically Sorted Source Nodes: [attn_output_8], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf55, buf59, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg56_1, (1536, 1536), (1536, 1), 'input')
            buf60 = reinterpret_tensor(buf55, (s16, 1536), (1536, 1), 0); del buf55  # reuse
            # Topologically Sorted Source Nodes: [attn_output_8, transpose_12, reshape_8, attn_output_11], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf59, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg56_1, (1536, 1536), (1, 1536), 0), out=buf60)
            del arg56_1
            assert_size_stride_grouped((arg58_1, arg57_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf62 = reinterpret_tensor(buf59, (s16, 1, 1536), (1536, 1536, 1), 0); del buf59  # reuse
            # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, pow_6, variance_5, rsqrt_5, hidden_states_21, hidden_states_22], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf38, buf44, buf60, arg58_1, arg57_1.item(), buf62, s16, 1536, stream=raw_stream0)
            del arg57_1
            del arg58_1
            assert_size_stride(arg59_1, (8960, 1536), (1536, 1), 'input')
            buf63 = reinterpret_tensor(buf43, (s16, 8960), (8960, 1), 0); del buf43  # reuse
            # Topologically Sorted Source Nodes: [linear_18], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf62, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg59_1, (1536, 8960), (1, 1536), 0), out=buf63)
            del arg59_1
            assert_size_stride(arg60_1, (8960, 1536), (1536, 1), 'input')
            buf64 = buf42; del buf42  # reuse
            # Topologically Sorted Source Nodes: [linear_19], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf62, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg60_1, (1536, 8960), (1, 1536), 0), out=buf64)
            del arg60_1
            buf65 = reinterpret_tensor(buf63, (s16, 1, 8960), (8960, 8960, 1), 0); del buf63  # reuse
            # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_28], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf65, buf64, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg61_1, (1536, 8960), (8960, 1), 'input')
            buf66 = reinterpret_tensor(buf62, (s16, 1536), (1536, 1), 0); del buf62  # reuse
            # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_28, down_proj_2], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf65, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg61_1, (8960, 1536), (1, 8960), 0), out=buf66)
            del arg61_1
            assert_size_stride_grouped((arg63_1, arg62_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf68 = reinterpret_tensor(buf47, (s16, 1, 1536), (1536, 1536, 1), 0); del buf47  # reuse
            # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, down_proj_2, hidden_states_23, pow_7, variance_6, rsqrt_6, hidden_states_25, hidden_states_26], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf38, buf44, buf60, buf66, arg63_1, arg62_1.item(), buf68, s16, 1536, stream=raw_stream0)
            del arg62_1
            del arg63_1
            assert_size_stride_grouped((arg65_1, arg64_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf69 = buf24; del buf24  # reuse
            # Topologically Sorted Source Nodes: [linear_21], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg65_1, reinterpret_tensor(buf68, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg64_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf69)
            del arg64_1
            del arg65_1
            assert_size_stride_grouped((arg67_1, arg66_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf70 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_22], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg67_1, reinterpret_tensor(buf68, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg66_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf70)
            del arg66_1
            del arg67_1
            buf71 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_6, sin_6, linear_22, view_10, key_states_3, mul_33, x2_7, neg_7, x1_7, cat_20, mul_34, k_embed_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf70, arg4_1, arg3_1, arg5_1.item(), buf71, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg69_1, arg68_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf72 = buf70; del buf70  # reuse
            # Topologically Sorted Source Nodes: [linear_23], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg69_1, reinterpret_tensor(buf68, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg68_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf72)
            del arg68_1
            del arg69_1
            buf73 = reinterpret_tensor(buf68, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf68  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_21, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, linear_23, view_11, value_states_3, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf69, arg4_1, arg3_1, arg5_1.item(), buf73, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf69
            assert_size_stride(arg72_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg72_1 = copy_if_misaligned(arg72_1)
            buf74 = buf53; del buf53  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_21, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, linear_23, view_11, value_states_3, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg72_1, buf71, buf74, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg72_1
            assert_size_stride(arg73_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg73_1 = copy_if_misaligned(arg73_1)
            buf75 = buf52; del buf52  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_21, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, linear_23, view_11, value_states_3, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg73_1, buf72, buf75, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg73_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_21, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, linear_23, view_11, value_states_3, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf76 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf73, buf74, buf75, None, False, scale=0.08838834764831845)
            buf77 = buf76[0]
            assert_tensor_metadata(buf77, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf77, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf76
            buf81 = buf73; del buf73  # reuse
            # Topologically Sorted Source Nodes: [attn_output_12], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf77, buf81, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg74_1, (1536, 1536), (1536, 1), 'input')
            buf82 = reinterpret_tensor(buf77, (s16, 1536), (1536, 1), 0); del buf77  # reuse
            # Topologically Sorted Source Nodes: [attn_output_12, transpose_16, reshape_11, attn_output_15], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf81, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg74_1, (1536, 1536), (1, 1536), 0), out=buf82)
            del arg74_1
            assert_size_stride_grouped((arg76_1, arg75_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf83 = buf38; del buf38  # reuse
            buf85 = reinterpret_tensor(buf81, (s16, 1, 1536), (1536, 1536, 1), 0); del buf81  # reuse
            # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, down_proj_2, hidden_states_23, attn_output_15, hidden_states_27, pow_8, variance_7, rsqrt_7, hidden_states_29, hidden_states_30], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf83, buf44, buf60, buf66, buf82, arg76_1, arg75_1.item(), buf85, s16, 1536, stream=raw_stream0)
            del arg75_1
            del arg76_1
            del buf44
            assert_size_stride(arg77_1, (8960, 1536), (1536, 1), 'input')
            buf86 = reinterpret_tensor(buf65, (s16, 8960), (8960, 1), 0); del buf65  # reuse
            # Topologically Sorted Source Nodes: [pow_8, variance_7, rsqrt_7, hidden_states_29, hidden_states_30, linear_25], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf85, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg77_1, (1536, 8960), (1, 1536), 0), out=buf86)
            del arg77_1
            assert_size_stride(arg78_1, (8960, 1536), (1536, 1), 'input')
            buf87 = buf64; del buf64  # reuse
            # Topologically Sorted Source Nodes: [linear_26], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf85, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg78_1, (1536, 8960), (1, 1536), 0), out=buf87)
            del arg78_1
            buf88 = reinterpret_tensor(buf86, (s16, 1, 8960), (8960, 8960, 1), 0); del buf86  # reuse
            # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_37], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf88, buf87, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg79_1, (1536, 8960), (8960, 1), 'input')
            buf89 = reinterpret_tensor(buf85, (s16, 1536), (1536, 1), 0); del buf85  # reuse
            # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_37, down_proj_3], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf88, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg79_1, (8960, 1536), (1, 8960), 0), out=buf89)
            del arg79_1
            assert_size_stride_grouped((arg81_1, arg80_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf91 = reinterpret_tensor(buf82, (s16, 1, 1536), (1536, 1536, 1), 0); del buf82  # reuse
            # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_31, pow_9, variance_8, rsqrt_8, hidden_states_33, hidden_states_34], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf83, buf89, arg81_1, arg80_1.item(), buf91, s16, 1536, stream=raw_stream0)
            del arg80_1
            del arg81_1
            assert_size_stride_grouped((arg83_1, arg82_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf92 = buf66; del buf66  # reuse
            # Topologically Sorted Source Nodes: [linear_28], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg83_1, reinterpret_tensor(buf91, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg82_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf92)
            del arg82_1
            del arg83_1
            assert_size_stride_grouped((arg85_1, arg84_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf93 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_29], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg85_1, reinterpret_tensor(buf91, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg84_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf93)
            del arg84_1
            del arg85_1
            buf94 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_7, sin_7, linear_29, view_13, key_states_4, mul_42, x2_9, neg_9, x1_9, cat_26, mul_43, k_embed_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf93, arg4_1, arg3_1, arg5_1.item(), buf94, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg87_1, arg86_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf95 = buf93; del buf93  # reuse
            # Topologically Sorted Source Nodes: [linear_30], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg87_1, reinterpret_tensor(buf91, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg86_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf95)
            del arg86_1
            del arg87_1
            buf96 = reinterpret_tensor(buf91, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf91  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_28, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, linear_30, view_14, value_states_4, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf92, arg4_1, arg3_1, arg5_1.item(), buf96, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg90_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg90_1 = copy_if_misaligned(arg90_1)
            buf97 = buf75; del buf75  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_28, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, linear_30, view_14, value_states_4, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg90_1, buf94, buf97, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg90_1
            assert_size_stride(arg91_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg91_1 = copy_if_misaligned(arg91_1)
            buf98 = buf74; del buf74  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_28, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, linear_30, view_14, value_states_4, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg91_1, buf95, buf98, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg91_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_28, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, linear_30, view_14, value_states_4, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf99 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf96, buf97, buf98, None, False, scale=0.08838834764831845)
            buf100 = buf99[0]
            assert_tensor_metadata(buf100, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf100, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf99
            buf104 = buf96; del buf96  # reuse
            # Topologically Sorted Source Nodes: [attn_output_16], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf100, buf104, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg92_1, (1536, 1536), (1536, 1), 'input')
            buf105 = reinterpret_tensor(buf100, (s16, 1536), (1536, 1), 0); del buf100  # reuse
            # Topologically Sorted Source Nodes: [attn_output_16, transpose_20, reshape_14, attn_output_19], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf104, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg92_1, (1536, 1536), (1, 1536), 0), out=buf105)
            del arg92_1
            assert_size_stride_grouped((arg94_1, arg93_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf107 = reinterpret_tensor(buf104, (s16, 1, 1536), (1536, 1536, 1), 0); del buf104  # reuse
            # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_31, attn_output_19, hidden_states_35, pow_10, variance_9, rsqrt_9, hidden_states_37, hidden_states_38], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf83, buf89, buf105, arg94_1, arg93_1.item(), buf107, s16, 1536, stream=raw_stream0)
            del arg93_1
            del arg94_1
            assert_size_stride(arg95_1, (8960, 1536), (1536, 1), 'input')
            buf108 = reinterpret_tensor(buf88, (s16, 8960), (8960, 1), 0); del buf88  # reuse
            # Topologically Sorted Source Nodes: [linear_32], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf107, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg95_1, (1536, 8960), (1, 1536), 0), out=buf108)
            del arg95_1
            assert_size_stride(arg96_1, (8960, 1536), (1536, 1), 'input')
            buf109 = buf87; del buf87  # reuse
            # Topologically Sorted Source Nodes: [linear_33], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf107, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg96_1, (1536, 8960), (1, 1536), 0), out=buf109)
            del arg96_1
            buf110 = reinterpret_tensor(buf108, (s16, 1, 8960), (8960, 8960, 1), 0); del buf108  # reuse
            # Topologically Sorted Source Nodes: [linear_32, silu_4, linear_33, mul_46], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf110, buf109, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg97_1, (1536, 8960), (8960, 1), 'input')
            buf111 = reinterpret_tensor(buf107, (s16, 1536), (1536, 1), 0); del buf107  # reuse
            # Topologically Sorted Source Nodes: [linear_32, silu_4, linear_33, mul_46, down_proj_4], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf110, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg97_1, (8960, 1536), (1, 8960), 0), out=buf111)
            del arg97_1
            assert_size_stride_grouped((arg99_1, arg98_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf113 = reinterpret_tensor(buf92, (s16, 1, 1536), (1536, 1536, 1), 0); del buf92  # reuse
            # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_31, attn_output_19, hidden_states_35, down_proj_4, hidden_states_39, pow_11, variance_10, rsqrt_10, hidden_states_41, hidden_states_42], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf83, buf89, buf105, buf111, arg99_1, arg98_1.item(), buf113, s16, 1536, stream=raw_stream0)
            del arg98_1
            del arg99_1
            assert_size_stride_grouped((arg101_1, arg100_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf114 = buf60; del buf60  # reuse
            # Topologically Sorted Source Nodes: [linear_35], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg101_1, reinterpret_tensor(buf113, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg100_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf114)
            del arg100_1
            del arg101_1
            assert_size_stride_grouped((arg103_1, arg102_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf115 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_36], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg103_1, reinterpret_tensor(buf113, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg102_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf115)
            del arg102_1
            del arg103_1
            buf116 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_8, sin_8, linear_36, view_16, key_states_5, mul_51, x2_11, neg_11, x1_11, cat_32, mul_52, k_embed_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf115, arg4_1, arg3_1, arg5_1.item(), buf116, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg105_1, arg104_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf117 = buf115; del buf115  # reuse
            # Topologically Sorted Source Nodes: [linear_37], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg105_1, reinterpret_tensor(buf113, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg104_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf117)
            del arg104_1
            del arg105_1
            buf118 = reinterpret_tensor(buf113, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf113  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_35, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, linear_37, view_17, value_states_5, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf114, arg4_1, arg3_1, arg5_1.item(), buf118, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf114
            assert_size_stride(arg108_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg108_1 = copy_if_misaligned(arg108_1)
            buf119 = buf98; del buf98  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_35, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, linear_37, view_17, value_states_5, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg108_1, buf116, buf119, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg108_1
            assert_size_stride(arg109_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg109_1 = copy_if_misaligned(arg109_1)
            buf120 = buf97; del buf97  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_35, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, linear_37, view_17, value_states_5, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg109_1, buf117, buf120, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg109_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_35, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, linear_37, view_17, value_states_5, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf121 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf118, buf119, buf120, None, False, scale=0.08838834764831845)
            buf122 = buf121[0]
            assert_tensor_metadata(buf122, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf122, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf121
            buf126 = buf118; del buf118  # reuse
            # Topologically Sorted Source Nodes: [attn_output_20], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf122, buf126, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg110_1, (1536, 1536), (1536, 1), 'input')
            buf127 = reinterpret_tensor(buf122, (s16, 1536), (1536, 1), 0); del buf122  # reuse
            # Topologically Sorted Source Nodes: [attn_output_20, transpose_24, reshape_17, attn_output_23], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf126, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg110_1, (1536, 1536), (1, 1536), 0), out=buf127)
            del arg110_1
            assert_size_stride_grouped((arg112_1, arg111_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf128 = buf83; del buf83  # reuse
            buf130 = reinterpret_tensor(buf126, (s16, 1, 1536), (1536, 1536, 1), 0); del buf126  # reuse
            # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_31, attn_output_19, hidden_states_35, down_proj_4, hidden_states_39, attn_output_23, hidden_states_43, pow_12, variance_11, rsqrt_11, hidden_states_45, hidden_states_46], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf128, buf89, buf105, buf111, buf127, arg112_1, arg111_1.item(), buf130, s16, 1536, stream=raw_stream0)
            del arg111_1
            del arg112_1
            del buf105
            assert_size_stride(arg113_1, (8960, 1536), (1536, 1), 'input')
            buf131 = reinterpret_tensor(buf110, (s16, 8960), (8960, 1), 0); del buf110  # reuse
            # Topologically Sorted Source Nodes: [pow_12, variance_11, rsqrt_11, hidden_states_45, hidden_states_46, linear_39], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf130, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg113_1, (1536, 8960), (1, 1536), 0), out=buf131)
            del arg113_1
            assert_size_stride(arg114_1, (8960, 1536), (1536, 1), 'input')
            buf132 = buf109; del buf109  # reuse
            # Topologically Sorted Source Nodes: [linear_40], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf130, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg114_1, (1536, 8960), (1, 1536), 0), out=buf132)
            del arg114_1
            buf133 = reinterpret_tensor(buf131, (s16, 1, 8960), (8960, 8960, 1), 0); del buf131  # reuse
            # Topologically Sorted Source Nodes: [linear_39, silu_5, linear_40, mul_55], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf133, buf132, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg115_1, (1536, 8960), (8960, 1), 'input')
            buf134 = reinterpret_tensor(buf130, (s16, 1536), (1536, 1), 0); del buf130  # reuse
            # Topologically Sorted Source Nodes: [linear_39, silu_5, linear_40, mul_55, down_proj_5], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf133, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg115_1, (8960, 1536), (1, 8960), 0), out=buf134)
            del arg115_1
            assert_size_stride_grouped((arg117_1, arg116_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf136 = reinterpret_tensor(buf89, (s16, 1, 1536), (1536, 1536, 1), 0); del buf89  # reuse
            # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_47, pow_13, variance_12, rsqrt_12, hidden_states_49, hidden_states_50], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf128, buf134, arg117_1, arg116_1.item(), buf136, s16, 1536, stream=raw_stream0)
            del arg116_1
            del arg117_1
            assert_size_stride_grouped((arg119_1, arg118_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf137 = buf127; del buf127  # reuse
            # Topologically Sorted Source Nodes: [linear_42], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg119_1, reinterpret_tensor(buf136, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg118_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf137)
            del arg118_1
            del arg119_1
            assert_size_stride_grouped((arg121_1, arg120_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf138 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_43], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg121_1, reinterpret_tensor(buf136, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg120_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf138)
            del arg120_1
            del arg121_1
            buf139 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_9, sin_9, linear_43, view_19, key_states_6, mul_60, x2_13, neg_13, x1_13, cat_38, mul_61, k_embed_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf138, arg4_1, arg3_1, arg5_1.item(), buf139, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg123_1, arg122_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf140 = buf138; del buf138  # reuse
            # Topologically Sorted Source Nodes: [linear_44], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg123_1, reinterpret_tensor(buf136, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg122_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf140)
            del arg122_1
            del arg123_1
            buf141 = reinterpret_tensor(buf136, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf136  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, linear_44, view_20, value_states_6, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf137, arg4_1, arg3_1, arg5_1.item(), buf141, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg126_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg126_1 = copy_if_misaligned(arg126_1)
            buf142 = buf120; del buf120  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, linear_44, view_20, value_states_6, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg126_1, buf139, buf142, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg126_1
            assert_size_stride(arg127_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg127_1 = copy_if_misaligned(arg127_1)
            buf143 = buf119; del buf119  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, linear_44, view_20, value_states_6, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg127_1, buf140, buf143, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg127_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, linear_44, view_20, value_states_6, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf144 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf141, buf142, buf143, None, False, scale=0.08838834764831845)
            buf145 = buf144[0]
            assert_tensor_metadata(buf145, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf145, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf144
            buf149 = buf141; del buf141  # reuse
            # Topologically Sorted Source Nodes: [attn_output_24], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf145, buf149, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg128_1, (1536, 1536), (1536, 1), 'input')
            buf150 = reinterpret_tensor(buf145, (s16, 1536), (1536, 1), 0); del buf145  # reuse
            # Topologically Sorted Source Nodes: [attn_output_24, transpose_28, reshape_20, attn_output_27], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf149, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg128_1, (1536, 1536), (1, 1536), 0), out=buf150)
            del arg128_1
            assert_size_stride_grouped((arg130_1, arg129_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf152 = reinterpret_tensor(buf149, (s16, 1, 1536), (1536, 1536, 1), 0); del buf149  # reuse
            # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_47, attn_output_27, hidden_states_51, pow_14, variance_13, rsqrt_13, hidden_states_53, hidden_states_54], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf128, buf134, buf150, arg130_1, arg129_1.item(), buf152, s16, 1536, stream=raw_stream0)
            del arg129_1
            del arg130_1
            assert_size_stride(arg131_1, (8960, 1536), (1536, 1), 'input')
            buf153 = reinterpret_tensor(buf133, (s16, 8960), (8960, 1), 0); del buf133  # reuse
            # Topologically Sorted Source Nodes: [linear_46], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf152, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg131_1, (1536, 8960), (1, 1536), 0), out=buf153)
            del arg131_1
            assert_size_stride(arg132_1, (8960, 1536), (1536, 1), 'input')
            buf154 = buf132; del buf132  # reuse
            # Topologically Sorted Source Nodes: [linear_47], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf152, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg132_1, (1536, 8960), (1, 1536), 0), out=buf154)
            del arg132_1
            buf155 = reinterpret_tensor(buf153, (s16, 1, 8960), (8960, 8960, 1), 0); del buf153  # reuse
            # Topologically Sorted Source Nodes: [linear_46, silu_6, linear_47, mul_64], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf155, buf154, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg133_1, (1536, 8960), (8960, 1), 'input')
            buf156 = reinterpret_tensor(buf152, (s16, 1536), (1536, 1), 0); del buf152  # reuse
            # Topologically Sorted Source Nodes: [linear_46, silu_6, linear_47, mul_64, down_proj_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf155, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg133_1, (8960, 1536), (1, 8960), 0), out=buf156)
            del arg133_1
            assert_size_stride_grouped((arg135_1, arg134_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf158 = reinterpret_tensor(buf137, (s16, 1, 1536), (1536, 1536, 1), 0); del buf137  # reuse
            # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_47, attn_output_27, hidden_states_51, down_proj_6, hidden_states_55, pow_15, variance_14, rsqrt_14, hidden_states_57, hidden_states_58], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf128, buf134, buf150, buf156, arg135_1, arg134_1.item(), buf158, s16, 1536, stream=raw_stream0)
            del arg134_1
            del arg135_1
            assert_size_stride_grouped((arg137_1, arg136_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf159 = buf111; del buf111  # reuse
            # Topologically Sorted Source Nodes: [linear_49], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg137_1, reinterpret_tensor(buf158, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg136_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf159)
            del arg136_1
            del arg137_1
            assert_size_stride_grouped((arg139_1, arg138_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf160 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_50], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg139_1, reinterpret_tensor(buf158, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg138_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf160)
            del arg138_1
            del arg139_1
            buf161 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_10, sin_10, linear_50, view_22, key_states_7, mul_69, x2_15, neg_15, x1_15, cat_44, mul_70, k_embed_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf160, arg4_1, arg3_1, arg5_1.item(), buf161, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg141_1, arg140_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf162 = buf160; del buf160  # reuse
            # Topologically Sorted Source Nodes: [linear_51], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg141_1, reinterpret_tensor(buf158, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg140_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf162)
            del arg140_1
            del arg141_1
            buf163 = reinterpret_tensor(buf158, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf158  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_49, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, linear_51, view_23, value_states_7, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf159, arg4_1, arg3_1, arg5_1.item(), buf163, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf159
            assert_size_stride(arg144_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg144_1 = copy_if_misaligned(arg144_1)
            buf164 = buf143; del buf143  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_49, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, linear_51, view_23, value_states_7, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg144_1, buf161, buf164, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg144_1
            assert_size_stride(arg145_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg145_1 = copy_if_misaligned(arg145_1)
            buf165 = buf142; del buf142  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_49, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, linear_51, view_23, value_states_7, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg145_1, buf162, buf165, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg145_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_49, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, linear_51, view_23, value_states_7, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf166 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf163, buf164, buf165, None, False, scale=0.08838834764831845)
            buf167 = buf166[0]
            assert_tensor_metadata(buf167, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf167, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf166
            buf171 = buf163; del buf163  # reuse
            # Topologically Sorted Source Nodes: [attn_output_28], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf167, buf171, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg146_1, (1536, 1536), (1536, 1), 'input')
            buf172 = reinterpret_tensor(buf167, (s16, 1536), (1536, 1), 0); del buf167  # reuse
            # Topologically Sorted Source Nodes: [attn_output_28, transpose_32, reshape_23, attn_output_31], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf171, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg146_1, (1536, 1536), (1, 1536), 0), out=buf172)
            del arg146_1
            assert_size_stride_grouped((arg148_1, arg147_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf173 = buf128; del buf128  # reuse
            buf175 = reinterpret_tensor(buf171, (s16, 1, 1536), (1536, 1536, 1), 0); del buf171  # reuse
            # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_47, attn_output_27, hidden_states_51, down_proj_6, hidden_states_55, attn_output_31, hidden_states_59, pow_16, variance_15, rsqrt_15, hidden_states_61, hidden_states_62], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf173, buf134, buf150, buf156, buf172, arg148_1, arg147_1.item(), buf175, s16, 1536, stream=raw_stream0)
            del arg147_1
            del arg148_1
            del buf134
            assert_size_stride(arg149_1, (8960, 1536), (1536, 1), 'input')
            buf176 = reinterpret_tensor(buf155, (s16, 8960), (8960, 1), 0); del buf155  # reuse
            # Topologically Sorted Source Nodes: [pow_16, variance_15, rsqrt_15, hidden_states_61, hidden_states_62, linear_53], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf175, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg149_1, (1536, 8960), (1, 1536), 0), out=buf176)
            del arg149_1
            assert_size_stride(arg150_1, (8960, 1536), (1536, 1), 'input')
            buf177 = buf154; del buf154  # reuse
            # Topologically Sorted Source Nodes: [linear_54], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf175, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg150_1, (1536, 8960), (1, 1536), 0), out=buf177)
            del arg150_1
            buf178 = reinterpret_tensor(buf176, (s16, 1, 8960), (8960, 8960, 1), 0); del buf176  # reuse
            # Topologically Sorted Source Nodes: [linear_53, silu_7, linear_54, mul_73], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf178, buf177, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg151_1, (1536, 8960), (8960, 1), 'input')
            buf179 = reinterpret_tensor(buf175, (s16, 1536), (1536, 1), 0); del buf175  # reuse
            # Topologically Sorted Source Nodes: [linear_53, silu_7, linear_54, mul_73, down_proj_7], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf178, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg151_1, (8960, 1536), (1, 8960), 0), out=buf179)
            del arg151_1
            assert_size_stride_grouped((arg153_1, arg152_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf181 = reinterpret_tensor(buf172, (s16, 1, 1536), (1536, 1536, 1), 0); del buf172  # reuse
            # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_63, pow_17, variance_16, rsqrt_16, hidden_states_65, hidden_states_66], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf173, buf179, arg153_1, arg152_1.item(), buf181, s16, 1536, stream=raw_stream0)
            del arg152_1
            del arg153_1
            assert_size_stride_grouped((arg155_1, arg154_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf182 = buf156; del buf156  # reuse
            # Topologically Sorted Source Nodes: [linear_56], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg155_1, reinterpret_tensor(buf181, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg154_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf182)
            del arg154_1
            del arg155_1
            assert_size_stride_grouped((arg157_1, arg156_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf183 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_57], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg157_1, reinterpret_tensor(buf181, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg156_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf183)
            del arg156_1
            del arg157_1
            buf184 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_11, sin_11, linear_57, view_25, key_states_8, mul_78, x2_17, neg_17, x1_17, cat_50, mul_79, k_embed_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf183, arg4_1, arg3_1, arg5_1.item(), buf184, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg159_1, arg158_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf185 = buf183; del buf183  # reuse
            # Topologically Sorted Source Nodes: [linear_58], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg159_1, reinterpret_tensor(buf181, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg158_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf185)
            del arg158_1
            del arg159_1
            buf186 = reinterpret_tensor(buf181, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf181  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_56, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, linear_58, view_26, value_states_8, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf182, arg4_1, arg3_1, arg5_1.item(), buf186, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg162_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg162_1 = copy_if_misaligned(arg162_1)
            buf187 = buf165; del buf165  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_56, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, linear_58, view_26, value_states_8, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg162_1, buf184, buf187, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg162_1
            assert_size_stride(arg163_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg163_1 = copy_if_misaligned(arg163_1)
            buf188 = buf164; del buf164  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_56, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, linear_58, view_26, value_states_8, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg163_1, buf185, buf188, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg163_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_56, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, linear_58, view_26, value_states_8, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf189 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf186, buf187, buf188, None, False, scale=0.08838834764831845)
            buf190 = buf189[0]
            assert_tensor_metadata(buf190, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf190, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf189
            buf194 = buf186; del buf186  # reuse
            # Topologically Sorted Source Nodes: [attn_output_32], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf190, buf194, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg164_1, (1536, 1536), (1536, 1), 'input')
            buf195 = reinterpret_tensor(buf190, (s16, 1536), (1536, 1), 0); del buf190  # reuse
            # Topologically Sorted Source Nodes: [attn_output_32, transpose_36, reshape_26, attn_output_35], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf194, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg164_1, (1536, 1536), (1, 1536), 0), out=buf195)
            del arg164_1
            assert_size_stride_grouped((arg166_1, arg165_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf197 = reinterpret_tensor(buf194, (s16, 1, 1536), (1536, 1536, 1), 0); del buf194  # reuse
            # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_63, attn_output_35, hidden_states_67, pow_18, variance_17, rsqrt_17, hidden_states_69, hidden_states_70], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf173, buf179, buf195, arg166_1, arg165_1.item(), buf197, s16, 1536, stream=raw_stream0)
            del arg165_1
            del arg166_1
            assert_size_stride(arg167_1, (8960, 1536), (1536, 1), 'input')
            buf198 = reinterpret_tensor(buf178, (s16, 8960), (8960, 1), 0); del buf178  # reuse
            # Topologically Sorted Source Nodes: [linear_60], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf197, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg167_1, (1536, 8960), (1, 1536), 0), out=buf198)
            del arg167_1
            assert_size_stride(arg168_1, (8960, 1536), (1536, 1), 'input')
            buf199 = buf177; del buf177  # reuse
            # Topologically Sorted Source Nodes: [linear_61], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf197, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg168_1, (1536, 8960), (1, 1536), 0), out=buf199)
            del arg168_1
            buf200 = reinterpret_tensor(buf198, (s16, 1, 8960), (8960, 8960, 1), 0); del buf198  # reuse
            # Topologically Sorted Source Nodes: [linear_60, silu_8, linear_61, mul_82], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf200, buf199, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg169_1, (1536, 8960), (8960, 1), 'input')
            buf201 = reinterpret_tensor(buf197, (s16, 1536), (1536, 1), 0); del buf197  # reuse
            # Topologically Sorted Source Nodes: [linear_60, silu_8, linear_61, mul_82, down_proj_8], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf200, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg169_1, (8960, 1536), (1, 8960), 0), out=buf201)
            del arg169_1
            assert_size_stride_grouped((arg171_1, arg170_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf203 = reinterpret_tensor(buf182, (s16, 1, 1536), (1536, 1536, 1), 0); del buf182  # reuse
            # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_63, attn_output_35, hidden_states_67, down_proj_8, hidden_states_71, pow_19, variance_18, rsqrt_18, hidden_states_73, hidden_states_74], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf173, buf179, buf195, buf201, arg171_1, arg170_1.item(), buf203, s16, 1536, stream=raw_stream0)
            del arg170_1
            del arg171_1
            assert_size_stride_grouped((arg173_1, arg172_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf204 = buf150; del buf150  # reuse
            # Topologically Sorted Source Nodes: [linear_63], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg173_1, reinterpret_tensor(buf203, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg172_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf204)
            del arg172_1
            del arg173_1
            assert_size_stride_grouped((arg175_1, arg174_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf205 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_64], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg175_1, reinterpret_tensor(buf203, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg174_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf205)
            del arg174_1
            del arg175_1
            buf206 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_12, sin_12, linear_64, view_28, key_states_9, mul_87, x2_19, neg_19, x1_19, cat_56, mul_88, k_embed_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf205, arg4_1, arg3_1, arg5_1.item(), buf206, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg177_1, arg176_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf207 = buf205; del buf205  # reuse
            # Topologically Sorted Source Nodes: [linear_65], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg177_1, reinterpret_tensor(buf203, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg176_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf207)
            del arg176_1
            del arg177_1
            buf208 = reinterpret_tensor(buf203, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf203  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_63, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, linear_65, view_29, value_states_9, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf204, arg4_1, arg3_1, arg5_1.item(), buf208, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf204
            assert_size_stride(arg180_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg180_1 = copy_if_misaligned(arg180_1)
            buf209 = buf188; del buf188  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_63, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, linear_65, view_29, value_states_9, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg180_1, buf206, buf209, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg180_1
            assert_size_stride(arg181_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg181_1 = copy_if_misaligned(arg181_1)
            buf210 = buf187; del buf187  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_63, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, linear_65, view_29, value_states_9, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg181_1, buf207, buf210, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg181_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_63, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, linear_65, view_29, value_states_9, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf211 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf208, buf209, buf210, None, False, scale=0.08838834764831845)
            buf212 = buf211[0]
            assert_tensor_metadata(buf212, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf212, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf211
            buf216 = buf208; del buf208  # reuse
            # Topologically Sorted Source Nodes: [attn_output_36], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf212, buf216, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg182_1, (1536, 1536), (1536, 1), 'input')
            buf217 = reinterpret_tensor(buf212, (s16, 1536), (1536, 1), 0); del buf212  # reuse
            # Topologically Sorted Source Nodes: [attn_output_36, transpose_40, reshape_29, attn_output_39], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf216, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg182_1, (1536, 1536), (1, 1536), 0), out=buf217)
            del arg182_1
            assert_size_stride_grouped((arg184_1, arg183_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf218 = buf173; del buf173  # reuse
            buf220 = reinterpret_tensor(buf216, (s16, 1, 1536), (1536, 1536, 1), 0); del buf216  # reuse
            # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_63, attn_output_35, hidden_states_67, down_proj_8, hidden_states_71, attn_output_39, hidden_states_75, pow_20, variance_19, rsqrt_19, hidden_states_77, hidden_states_78], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf218, buf179, buf195, buf201, buf217, arg184_1, arg183_1.item(), buf220, s16, 1536, stream=raw_stream0)
            del arg183_1
            del arg184_1
            del buf179
            assert_size_stride(arg185_1, (8960, 1536), (1536, 1), 'input')
            buf221 = reinterpret_tensor(buf200, (s16, 8960), (8960, 1), 0); del buf200  # reuse
            # Topologically Sorted Source Nodes: [pow_20, variance_19, rsqrt_19, hidden_states_77, hidden_states_78, linear_67], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf220, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg185_1, (1536, 8960), (1, 1536), 0), out=buf221)
            del arg185_1
            assert_size_stride(arg186_1, (8960, 1536), (1536, 1), 'input')
            buf222 = buf199; del buf199  # reuse
            # Topologically Sorted Source Nodes: [linear_68], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf220, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg186_1, (1536, 8960), (1, 1536), 0), out=buf222)
            del arg186_1
            buf223 = reinterpret_tensor(buf221, (s16, 1, 8960), (8960, 8960, 1), 0); del buf221  # reuse
            # Topologically Sorted Source Nodes: [linear_67, silu_9, linear_68, mul_91], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf223, buf222, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg187_1, (1536, 8960), (8960, 1), 'input')
            buf224 = reinterpret_tensor(buf220, (s16, 1536), (1536, 1), 0); del buf220  # reuse
            # Topologically Sorted Source Nodes: [linear_67, silu_9, linear_68, mul_91, down_proj_9], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf223, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg187_1, (8960, 1536), (1, 8960), 0), out=buf224)
            del arg187_1
            assert_size_stride_grouped((arg189_1, arg188_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf226 = reinterpret_tensor(buf217, (s16, 1, 1536), (1536, 1536, 1), 0); del buf217  # reuse
            # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_79, pow_21, variance_20, rsqrt_20, hidden_states_81, hidden_states_82], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf218, buf224, arg189_1, arg188_1.item(), buf226, s16, 1536, stream=raw_stream0)
            del arg188_1
            del arg189_1
            assert_size_stride_grouped((arg191_1, arg190_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf227 = buf201; del buf201  # reuse
            # Topologically Sorted Source Nodes: [linear_70], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg191_1, reinterpret_tensor(buf226, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg190_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf227)
            del arg190_1
            del arg191_1
            assert_size_stride_grouped((arg193_1, arg192_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf228 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_71], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg193_1, reinterpret_tensor(buf226, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg192_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf228)
            del arg192_1
            del arg193_1
            buf229 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_13, sin_13, linear_71, view_31, key_states_10, mul_96, x2_21, neg_21, x1_21, cat_62, mul_97, k_embed_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf228, arg4_1, arg3_1, arg5_1.item(), buf229, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg195_1, arg194_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf230 = buf228; del buf228  # reuse
            # Topologically Sorted Source Nodes: [linear_72], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg195_1, reinterpret_tensor(buf226, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg194_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf230)
            del arg194_1
            del arg195_1
            buf231 = reinterpret_tensor(buf226, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf226  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_70, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, linear_72, view_32, value_states_10, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf227, arg4_1, arg3_1, arg5_1.item(), buf231, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg198_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg198_1 = copy_if_misaligned(arg198_1)
            buf232 = buf210; del buf210  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_70, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, linear_72, view_32, value_states_10, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg198_1, buf229, buf232, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg198_1
            assert_size_stride(arg199_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg199_1 = copy_if_misaligned(arg199_1)
            buf233 = buf209; del buf209  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_70, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, linear_72, view_32, value_states_10, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg199_1, buf230, buf233, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg199_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_70, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, linear_72, view_32, value_states_10, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf234 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf231, buf232, buf233, None, False, scale=0.08838834764831845)
            buf235 = buf234[0]
            assert_tensor_metadata(buf235, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf235, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf234
            buf239 = buf231; del buf231  # reuse
            # Topologically Sorted Source Nodes: [attn_output_40], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf235, buf239, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg200_1, (1536, 1536), (1536, 1), 'input')
            buf240 = reinterpret_tensor(buf235, (s16, 1536), (1536, 1), 0); del buf235  # reuse
            # Topologically Sorted Source Nodes: [attn_output_40, transpose_44, reshape_32, attn_output_43], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf239, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg200_1, (1536, 1536), (1, 1536), 0), out=buf240)
            del arg200_1
            assert_size_stride_grouped((arg202_1, arg201_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf242 = reinterpret_tensor(buf239, (s16, 1, 1536), (1536, 1536, 1), 0); del buf239  # reuse
            # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_79, attn_output_43, hidden_states_83, pow_22, variance_21, rsqrt_21, hidden_states_85, hidden_states_86], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf218, buf224, buf240, arg202_1, arg201_1.item(), buf242, s16, 1536, stream=raw_stream0)
            del arg201_1
            del arg202_1
            assert_size_stride(arg203_1, (8960, 1536), (1536, 1), 'input')
            buf243 = reinterpret_tensor(buf223, (s16, 8960), (8960, 1), 0); del buf223  # reuse
            # Topologically Sorted Source Nodes: [linear_74], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf242, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg203_1, (1536, 8960), (1, 1536), 0), out=buf243)
            del arg203_1
            assert_size_stride(arg204_1, (8960, 1536), (1536, 1), 'input')
            buf244 = buf222; del buf222  # reuse
            # Topologically Sorted Source Nodes: [linear_75], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf242, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg204_1, (1536, 8960), (1, 1536), 0), out=buf244)
            del arg204_1
            buf245 = reinterpret_tensor(buf243, (s16, 1, 8960), (8960, 8960, 1), 0); del buf243  # reuse
            # Topologically Sorted Source Nodes: [linear_74, silu_10, linear_75, mul_100], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf245, buf244, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg205_1, (1536, 8960), (8960, 1), 'input')
            buf246 = reinterpret_tensor(buf242, (s16, 1536), (1536, 1), 0); del buf242  # reuse
            # Topologically Sorted Source Nodes: [linear_74, silu_10, linear_75, mul_100, down_proj_10], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf245, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg205_1, (8960, 1536), (1, 8960), 0), out=buf246)
            del arg205_1
            assert_size_stride_grouped((arg207_1, arg206_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf248 = reinterpret_tensor(buf227, (s16, 1, 1536), (1536, 1536, 1), 0); del buf227  # reuse
            # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_79, attn_output_43, hidden_states_83, down_proj_10, hidden_states_87, pow_23, variance_22, rsqrt_22, hidden_states_89, hidden_states_90], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf218, buf224, buf240, buf246, arg207_1, arg206_1.item(), buf248, s16, 1536, stream=raw_stream0)
            del arg206_1
            del arg207_1
            assert_size_stride_grouped((arg209_1, arg208_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf249 = buf195; del buf195  # reuse
            # Topologically Sorted Source Nodes: [linear_77], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg209_1, reinterpret_tensor(buf248, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg208_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf249)
            del arg208_1
            del arg209_1
            assert_size_stride_grouped((arg211_1, arg210_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf250 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_78], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg211_1, reinterpret_tensor(buf248, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg210_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf250)
            del arg210_1
            del arg211_1
            buf251 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_14, sin_14, linear_78, view_34, key_states_11, mul_105, x2_23, neg_23, x1_23, cat_68, mul_106, k_embed_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf250, arg4_1, arg3_1, arg5_1.item(), buf251, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg213_1, arg212_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf252 = buf250; del buf250  # reuse
            # Topologically Sorted Source Nodes: [linear_79], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg213_1, reinterpret_tensor(buf248, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg212_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf252)
            del arg212_1
            del arg213_1
            buf253 = reinterpret_tensor(buf248, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf248  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_77, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, linear_79, view_35, value_states_11, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf249, arg4_1, arg3_1, arg5_1.item(), buf253, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf249
            assert_size_stride(arg216_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg216_1 = copy_if_misaligned(arg216_1)
            buf254 = buf233; del buf233  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_77, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, linear_79, view_35, value_states_11, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg216_1, buf251, buf254, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg216_1
            assert_size_stride(arg217_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg217_1 = copy_if_misaligned(arg217_1)
            buf255 = buf232; del buf232  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_77, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, linear_79, view_35, value_states_11, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg217_1, buf252, buf255, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg217_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_77, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, linear_79, view_35, value_states_11, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf256 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf253, buf254, buf255, None, False, scale=0.08838834764831845)
            buf257 = buf256[0]
            assert_tensor_metadata(buf257, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf257, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf256
            buf261 = buf253; del buf253  # reuse
            # Topologically Sorted Source Nodes: [attn_output_44], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf257, buf261, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg218_1, (1536, 1536), (1536, 1), 'input')
            buf262 = reinterpret_tensor(buf257, (s16, 1536), (1536, 1), 0); del buf257  # reuse
            # Topologically Sorted Source Nodes: [attn_output_44, transpose_48, reshape_35, attn_output_47], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf261, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg218_1, (1536, 1536), (1, 1536), 0), out=buf262)
            del arg218_1
            assert_size_stride_grouped((arg220_1, arg219_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf263 = buf218; del buf218  # reuse
            buf265 = reinterpret_tensor(buf261, (s16, 1, 1536), (1536, 1536, 1), 0); del buf261  # reuse
            # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_79, attn_output_43, hidden_states_83, down_proj_10, hidden_states_87, attn_output_47, hidden_states_91, pow_24, variance_23, rsqrt_23, hidden_states_93, hidden_states_94], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf263, buf224, buf240, buf246, buf262, arg220_1, arg219_1.item(), buf265, s16, 1536, stream=raw_stream0)
            del arg219_1
            del arg220_1
            del buf224
            assert_size_stride(arg221_1, (8960, 1536), (1536, 1), 'input')
            buf266 = reinterpret_tensor(buf245, (s16, 8960), (8960, 1), 0); del buf245  # reuse
            # Topologically Sorted Source Nodes: [pow_24, variance_23, rsqrt_23, hidden_states_93, hidden_states_94, linear_81], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf265, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg221_1, (1536, 8960), (1, 1536), 0), out=buf266)
            del arg221_1
            assert_size_stride(arg222_1, (8960, 1536), (1536, 1), 'input')
            buf267 = buf244; del buf244  # reuse
            # Topologically Sorted Source Nodes: [linear_82], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf265, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg222_1, (1536, 8960), (1, 1536), 0), out=buf267)
            del arg222_1
            buf268 = reinterpret_tensor(buf266, (s16, 1, 8960), (8960, 8960, 1), 0); del buf266  # reuse
            # Topologically Sorted Source Nodes: [linear_81, silu_11, linear_82, mul_109], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf268, buf267, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg223_1, (1536, 8960), (8960, 1), 'input')
            buf269 = reinterpret_tensor(buf265, (s16, 1536), (1536, 1), 0); del buf265  # reuse
            # Topologically Sorted Source Nodes: [linear_81, silu_11, linear_82, mul_109, down_proj_11], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf268, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg223_1, (8960, 1536), (1, 8960), 0), out=buf269)
            del arg223_1
            assert_size_stride_grouped((arg225_1, arg224_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf271 = reinterpret_tensor(buf262, (s16, 1, 1536), (1536, 1536, 1), 0); del buf262  # reuse
            # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_95, pow_25, variance_24, rsqrt_24, hidden_states_97, hidden_states_98], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf263, buf269, arg225_1, arg224_1.item(), buf271, s16, 1536, stream=raw_stream0)
            del arg224_1
            del arg225_1
            assert_size_stride_grouped((arg227_1, arg226_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf272 = buf246; del buf246  # reuse
            # Topologically Sorted Source Nodes: [linear_84], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg227_1, reinterpret_tensor(buf271, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg226_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf272)
            del arg226_1
            del arg227_1
            assert_size_stride_grouped((arg229_1, arg228_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf273 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_85], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg229_1, reinterpret_tensor(buf271, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg228_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf273)
            del arg228_1
            del arg229_1
            buf274 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_15, sin_15, linear_85, view_37, key_states_12, mul_114, x2_25, neg_25, x1_25, cat_74, mul_115, k_embed_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf273, arg4_1, arg3_1, arg5_1.item(), buf274, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg231_1, arg230_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf275 = buf273; del buf273  # reuse
            # Topologically Sorted Source Nodes: [linear_86], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg231_1, reinterpret_tensor(buf271, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg230_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf275)
            del arg230_1
            del arg231_1
            buf276 = reinterpret_tensor(buf271, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf271  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, linear_86, view_38, value_states_12, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf272, arg4_1, arg3_1, arg5_1.item(), buf276, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg234_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg234_1 = copy_if_misaligned(arg234_1)
            buf277 = buf255; del buf255  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, linear_86, view_38, value_states_12, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg234_1, buf274, buf277, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg234_1
            assert_size_stride(arg235_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg235_1 = copy_if_misaligned(arg235_1)
            buf278 = buf254; del buf254  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, linear_86, view_38, value_states_12, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg235_1, buf275, buf278, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg235_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, linear_86, view_38, value_states_12, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf279 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf276, buf277, buf278, None, False, scale=0.08838834764831845)
            buf280 = buf279[0]
            assert_tensor_metadata(buf280, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf280, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf279
            buf284 = buf276; del buf276  # reuse
            # Topologically Sorted Source Nodes: [attn_output_48], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf280, buf284, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg236_1, (1536, 1536), (1536, 1), 'input')
            buf285 = reinterpret_tensor(buf280, (s16, 1536), (1536, 1), 0); del buf280  # reuse
            # Topologically Sorted Source Nodes: [attn_output_48, transpose_52, reshape_38, attn_output_51], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf284, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg236_1, (1536, 1536), (1, 1536), 0), out=buf285)
            del arg236_1
            assert_size_stride_grouped((arg238_1, arg237_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf287 = reinterpret_tensor(buf284, (s16, 1, 1536), (1536, 1536, 1), 0); del buf284  # reuse
            # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_95, attn_output_51, hidden_states_99, pow_26, variance_25, rsqrt_25, hidden_states_101, hidden_states_102], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf263, buf269, buf285, arg238_1, arg237_1.item(), buf287, s16, 1536, stream=raw_stream0)
            del arg237_1
            del arg238_1
            assert_size_stride(arg239_1, (8960, 1536), (1536, 1), 'input')
            buf288 = reinterpret_tensor(buf268, (s16, 8960), (8960, 1), 0); del buf268  # reuse
            # Topologically Sorted Source Nodes: [linear_88], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf287, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg239_1, (1536, 8960), (1, 1536), 0), out=buf288)
            del arg239_1
            assert_size_stride(arg240_1, (8960, 1536), (1536, 1), 'input')
            buf289 = buf267; del buf267  # reuse
            # Topologically Sorted Source Nodes: [linear_89], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf287, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg240_1, (1536, 8960), (1, 1536), 0), out=buf289)
            del arg240_1
            buf290 = reinterpret_tensor(buf288, (s16, 1, 8960), (8960, 8960, 1), 0); del buf288  # reuse
            # Topologically Sorted Source Nodes: [linear_88, silu_12, linear_89, mul_118], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf290, buf289, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg241_1, (1536, 8960), (8960, 1), 'input')
            buf291 = reinterpret_tensor(buf287, (s16, 1536), (1536, 1), 0); del buf287  # reuse
            # Topologically Sorted Source Nodes: [linear_88, silu_12, linear_89, mul_118, down_proj_12], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf290, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg241_1, (8960, 1536), (1, 8960), 0), out=buf291)
            del arg241_1
            assert_size_stride_grouped((arg243_1, arg242_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf293 = reinterpret_tensor(buf272, (s16, 1, 1536), (1536, 1536, 1), 0); del buf272  # reuse
            # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_95, attn_output_51, hidden_states_99, down_proj_12, hidden_states_103, pow_27, variance_26, rsqrt_26, hidden_states_105, hidden_states_106], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf263, buf269, buf285, buf291, arg243_1, arg242_1.item(), buf293, s16, 1536, stream=raw_stream0)
            del arg242_1
            del arg243_1
            assert_size_stride_grouped((arg245_1, arg244_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf294 = buf240; del buf240  # reuse
            # Topologically Sorted Source Nodes: [linear_91], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg245_1, reinterpret_tensor(buf293, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg244_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf294)
            del arg244_1
            del arg245_1
            assert_size_stride_grouped((arg247_1, arg246_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf295 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_92], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg247_1, reinterpret_tensor(buf293, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg246_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf295)
            del arg246_1
            del arg247_1
            buf296 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_16, sin_16, linear_92, view_40, key_states_13, mul_123, x2_27, neg_27, x1_27, cat_80, mul_124, k_embed_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf295, arg4_1, arg3_1, arg5_1.item(), buf296, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg249_1, arg248_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf297 = buf295; del buf295  # reuse
            # Topologically Sorted Source Nodes: [linear_93], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg249_1, reinterpret_tensor(buf293, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg248_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf297)
            del arg248_1
            del arg249_1
            buf298 = reinterpret_tensor(buf293, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf293  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_91, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, linear_93, view_41, value_states_13, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf294, arg4_1, arg3_1, arg5_1.item(), buf298, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf294
            assert_size_stride(arg252_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg252_1 = copy_if_misaligned(arg252_1)
            buf299 = buf278; del buf278  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_91, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, linear_93, view_41, value_states_13, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg252_1, buf296, buf299, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg252_1
            assert_size_stride(arg253_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg253_1 = copy_if_misaligned(arg253_1)
            buf300 = buf277; del buf277  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_91, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, linear_93, view_41, value_states_13, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg253_1, buf297, buf300, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg253_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_91, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, linear_93, view_41, value_states_13, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf301 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf298, buf299, buf300, None, False, scale=0.08838834764831845)
            buf302 = buf301[0]
            assert_tensor_metadata(buf302, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf302, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf301
            buf306 = buf298; del buf298  # reuse
            # Topologically Sorted Source Nodes: [attn_output_52], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf302, buf306, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg254_1, (1536, 1536), (1536, 1), 'input')
            buf307 = reinterpret_tensor(buf302, (s16, 1536), (1536, 1), 0); del buf302  # reuse
            # Topologically Sorted Source Nodes: [attn_output_52, transpose_56, reshape_41, attn_output_55], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf306, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg254_1, (1536, 1536), (1, 1536), 0), out=buf307)
            del arg254_1
            assert_size_stride_grouped((arg256_1, arg255_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf308 = buf263; del buf263  # reuse
            buf310 = reinterpret_tensor(buf306, (s16, 1, 1536), (1536, 1536, 1), 0); del buf306  # reuse
            # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_95, attn_output_51, hidden_states_99, down_proj_12, hidden_states_103, attn_output_55, hidden_states_107, pow_28, variance_27, rsqrt_27, hidden_states_109, hidden_states_110], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf308, buf269, buf285, buf291, buf307, arg256_1, arg255_1.item(), buf310, s16, 1536, stream=raw_stream0)
            del arg255_1
            del arg256_1
            del buf269
            assert_size_stride(arg257_1, (8960, 1536), (1536, 1), 'input')
            buf311 = reinterpret_tensor(buf290, (s16, 8960), (8960, 1), 0); del buf290  # reuse
            # Topologically Sorted Source Nodes: [pow_28, variance_27, rsqrt_27, hidden_states_109, hidden_states_110, linear_95], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf310, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg257_1, (1536, 8960), (1, 1536), 0), out=buf311)
            del arg257_1
            assert_size_stride(arg258_1, (8960, 1536), (1536, 1), 'input')
            buf312 = buf289; del buf289  # reuse
            # Topologically Sorted Source Nodes: [linear_96], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf310, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg258_1, (1536, 8960), (1, 1536), 0), out=buf312)
            del arg258_1
            buf313 = reinterpret_tensor(buf311, (s16, 1, 8960), (8960, 8960, 1), 0); del buf311  # reuse
            # Topologically Sorted Source Nodes: [linear_95, silu_13, linear_96, mul_127], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf313, buf312, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg259_1, (1536, 8960), (8960, 1), 'input')
            buf314 = reinterpret_tensor(buf310, (s16, 1536), (1536, 1), 0); del buf310  # reuse
            # Topologically Sorted Source Nodes: [linear_95, silu_13, linear_96, mul_127, down_proj_13], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf313, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg259_1, (8960, 1536), (1, 8960), 0), out=buf314)
            del arg259_1
            assert_size_stride_grouped((arg261_1, arg260_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf316 = reinterpret_tensor(buf307, (s16, 1, 1536), (1536, 1536, 1), 0); del buf307  # reuse
            # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, pow_29, variance_28, rsqrt_28, hidden_states_113, hidden_states_114], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf308, buf314, arg261_1, arg260_1.item(), buf316, s16, 1536, stream=raw_stream0)
            del arg260_1
            del arg261_1
            assert_size_stride_grouped((arg263_1, arg262_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf317 = buf291; del buf291  # reuse
            # Topologically Sorted Source Nodes: [linear_98], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg263_1, reinterpret_tensor(buf316, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg262_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf317)
            del arg262_1
            del arg263_1
            assert_size_stride_grouped((arg265_1, arg264_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf318 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_99], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg265_1, reinterpret_tensor(buf316, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg264_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf318)
            del arg264_1
            del arg265_1
            buf319 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_17, sin_17, linear_99, view_43, key_states_14, mul_132, x2_29, neg_29, x1_29, cat_86, mul_133, k_embed_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf318, arg4_1, arg3_1, arg5_1.item(), buf319, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg267_1, arg266_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf320 = buf318; del buf318  # reuse
            # Topologically Sorted Source Nodes: [linear_100], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg267_1, reinterpret_tensor(buf316, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg266_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf320)
            del arg266_1
            del arg267_1
            buf321 = reinterpret_tensor(buf316, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf316  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_98, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, linear_100, view_44, value_states_14, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf317, arg4_1, arg3_1, arg5_1.item(), buf321, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg270_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg270_1 = copy_if_misaligned(arg270_1)
            buf322 = buf300; del buf300  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_98, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, linear_100, view_44, value_states_14, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg270_1, buf319, buf322, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg270_1
            assert_size_stride(arg271_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg271_1 = copy_if_misaligned(arg271_1)
            buf323 = buf299; del buf299  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_98, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, linear_100, view_44, value_states_14, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg271_1, buf320, buf323, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg271_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_98, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, linear_100, view_44, value_states_14, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf324 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf321, buf322, buf323, None, False, scale=0.08838834764831845)
            buf325 = buf324[0]
            assert_tensor_metadata(buf325, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf325, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf324
            buf329 = buf321; del buf321  # reuse
            # Topologically Sorted Source Nodes: [attn_output_56], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf325, buf329, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg272_1, (1536, 1536), (1536, 1), 'input')
            buf330 = reinterpret_tensor(buf325, (s16, 1536), (1536, 1), 0); del buf325  # reuse
            # Topologically Sorted Source Nodes: [attn_output_56, transpose_60, reshape_44, attn_output_59], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf329, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg272_1, (1536, 1536), (1, 1536), 0), out=buf330)
            del arg272_1
            assert_size_stride_grouped((arg274_1, arg273_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf332 = reinterpret_tensor(buf329, (s16, 1, 1536), (1536, 1536, 1), 0); del buf329  # reuse
            # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, attn_output_59, hidden_states_115, pow_30, variance_29, rsqrt_29, hidden_states_117, hidden_states_118], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf308, buf314, buf330, arg274_1, arg273_1.item(), buf332, s16, 1536, stream=raw_stream0)
            del arg273_1
            del arg274_1
            assert_size_stride(arg275_1, (8960, 1536), (1536, 1), 'input')
            buf333 = reinterpret_tensor(buf313, (s16, 8960), (8960, 1), 0); del buf313  # reuse
            # Topologically Sorted Source Nodes: [linear_102], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf332, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg275_1, (1536, 8960), (1, 1536), 0), out=buf333)
            del arg275_1
            assert_size_stride(arg276_1, (8960, 1536), (1536, 1), 'input')
            buf334 = buf312; del buf312  # reuse
            # Topologically Sorted Source Nodes: [linear_103], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf332, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg276_1, (1536, 8960), (1, 1536), 0), out=buf334)
            del arg276_1
            buf335 = reinterpret_tensor(buf333, (s16, 1, 8960), (8960, 8960, 1), 0); del buf333  # reuse
            # Topologically Sorted Source Nodes: [linear_102, silu_14, linear_103, mul_136], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf335, buf334, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg277_1, (1536, 8960), (8960, 1), 'input')
            buf336 = reinterpret_tensor(buf332, (s16, 1536), (1536, 1), 0); del buf332  # reuse
            # Topologically Sorted Source Nodes: [linear_102, silu_14, linear_103, mul_136, down_proj_14], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf335, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg277_1, (8960, 1536), (1, 8960), 0), out=buf336)
            del arg277_1
            assert_size_stride(arg278_1, (1536, ), (1, ), 'input')
            buf338 = reinterpret_tensor(buf317, (s16, 1, 1536), (1536, 1536, 1), 0); del buf317  # reuse
            # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, attn_output_59, hidden_states_115, down_proj_14, hidden_states_119, pow_31, variance_30, add_90, rsqrt_30, hidden_states_121, hidden_states_122], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf308, buf314, buf330, buf336, arg278_1, buf338, s16, 1536, stream=raw_stream0)
            del arg278_1
            assert_size_stride_grouped((arg280_1, arg279_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf339 = buf285; del buf285  # reuse
            # Topologically Sorted Source Nodes: [linear_105], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg280_1, reinterpret_tensor(buf338, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg279_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf339)
            del arg279_1
            del arg280_1
            assert_size_stride_grouped((arg282_1, arg281_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf340 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_106], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg282_1, reinterpret_tensor(buf338, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg281_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf340)
            del arg281_1
            del arg282_1
            buf341 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_18, sin_18, linear_106, view_46, key_states_15, mul_141, x2_31, neg_31, x1_31, cat_92, mul_142, k_embed_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf340, arg4_1, arg3_1, arg5_1.item(), buf341, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg284_1, arg283_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf342 = buf340; del buf340  # reuse
            # Topologically Sorted Source Nodes: [linear_107], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg284_1, reinterpret_tensor(buf338, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg283_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf342)
            del arg283_1
            del arg284_1
            buf343 = reinterpret_tensor(buf338, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf338  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_105, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, linear_107, view_47, value_states_15, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf339, arg4_1, arg3_1, arg5_1.item(), buf343, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf339
            assert_size_stride(arg287_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg287_1 = copy_if_misaligned(arg287_1)
            buf344 = buf323; del buf323  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_105, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, linear_107, view_47, value_states_15, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg287_1, buf341, buf344, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg287_1
            assert_size_stride(arg288_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg288_1 = copy_if_misaligned(arg288_1)
            buf345 = buf322; del buf322  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_105, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, linear_107, view_47, value_states_15, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg288_1, buf342, buf345, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg288_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_105, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, linear_107, view_47, value_states_15, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf346 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf343, buf344, buf345, None, False, scale=0.08838834764831845)
            buf347 = buf346[0]
            assert_tensor_metadata(buf347, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf347, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf346
            buf351 = buf343; del buf343  # reuse
            # Topologically Sorted Source Nodes: [attn_output_60], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf347, buf351, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg289_1, (1536, 1536), (1536, 1), 'input')
            buf352 = reinterpret_tensor(buf347, (s16, 1536), (1536, 1), 0); del buf347  # reuse
            # Topologically Sorted Source Nodes: [attn_output_60, transpose_64, reshape_47, attn_output_63], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf351, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg289_1, (1536, 1536), (1, 1536), 0), out=buf352)
            del arg289_1
            assert_size_stride_grouped((arg291_1, arg290_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf353 = buf308; del buf308  # reuse
            buf355 = reinterpret_tensor(buf351, (s16, 1, 1536), (1536, 1536, 1), 0); del buf351  # reuse
            # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, attn_output_59, hidden_states_115, down_proj_14, hidden_states_119, attn_output_63, hidden_states_123, pow_32, variance_31, rsqrt_31, hidden_states_125, hidden_states_126], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf353, buf314, buf330, buf336, buf352, arg291_1, arg290_1.item(), buf355, s16, 1536, stream=raw_stream0)
            del arg290_1
            del arg291_1
            del buf314
            assert_size_stride(arg292_1, (8960, 1536), (1536, 1), 'input')
            buf356 = reinterpret_tensor(buf335, (s16, 8960), (8960, 1), 0); del buf335  # reuse
            # Topologically Sorted Source Nodes: [pow_32, variance_31, rsqrt_31, hidden_states_125, hidden_states_126, linear_109], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf355, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg292_1, (1536, 8960), (1, 1536), 0), out=buf356)
            del arg292_1
            assert_size_stride(arg293_1, (8960, 1536), (1536, 1), 'input')
            buf357 = buf334; del buf334  # reuse
            # Topologically Sorted Source Nodes: [linear_110], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf355, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg293_1, (1536, 8960), (1, 1536), 0), out=buf357)
            del arg293_1
            buf358 = reinterpret_tensor(buf356, (s16, 1, 8960), (8960, 8960, 1), 0); del buf356  # reuse
            # Topologically Sorted Source Nodes: [linear_109, silu_15, linear_110, mul_145], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf358, buf357, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg294_1, (1536, 8960), (8960, 1), 'input')
            buf359 = reinterpret_tensor(buf355, (s16, 1536), (1536, 1), 0); del buf355  # reuse
            # Topologically Sorted Source Nodes: [linear_109, silu_15, linear_110, mul_145, down_proj_15], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf358, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg294_1, (8960, 1536), (1, 8960), 0), out=buf359)
            del arg294_1
            assert_size_stride_grouped((arg296_1, arg295_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf361 = reinterpret_tensor(buf352, (s16, 1, 1536), (1536, 1536, 1), 0); del buf352  # reuse
            # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_127, pow_33, variance_32, rsqrt_32, hidden_states_129, hidden_states_130], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf353, buf359, arg296_1, arg295_1.item(), buf361, s16, 1536, stream=raw_stream0)
            del arg295_1
            del arg296_1
            assert_size_stride_grouped((arg298_1, arg297_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf362 = buf336; del buf336  # reuse
            # Topologically Sorted Source Nodes: [linear_112], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg298_1, reinterpret_tensor(buf361, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg297_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf362)
            del arg297_1
            del arg298_1
            assert_size_stride_grouped((arg300_1, arg299_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf363 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_113], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg300_1, reinterpret_tensor(buf361, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg299_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf363)
            del arg299_1
            del arg300_1
            buf364 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_19, sin_19, linear_113, view_49, key_states_16, mul_150, x2_33, neg_33, x1_33, cat_98, mul_151, k_embed_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf363, arg4_1, arg3_1, arg5_1.item(), buf364, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg302_1, arg301_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf365 = buf363; del buf363  # reuse
            # Topologically Sorted Source Nodes: [linear_114], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg302_1, reinterpret_tensor(buf361, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg301_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf365)
            del arg301_1
            del arg302_1
            buf366 = reinterpret_tensor(buf361, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf361  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_112, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, linear_114, view_50, value_states_16, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf362, arg4_1, arg3_1, arg5_1.item(), buf366, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg305_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg305_1 = copy_if_misaligned(arg305_1)
            buf367 = buf345; del buf345  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_112, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, linear_114, view_50, value_states_16, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg305_1, buf364, buf367, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg305_1
            assert_size_stride(arg306_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg306_1 = copy_if_misaligned(arg306_1)
            buf368 = buf344; del buf344  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_112, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, linear_114, view_50, value_states_16, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg306_1, buf365, buf368, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg306_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_112, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, linear_114, view_50, value_states_16, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf369 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf366, buf367, buf368, None, False, scale=0.08838834764831845)
            buf370 = buf369[0]
            assert_tensor_metadata(buf370, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf370, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf369
            buf374 = buf366; del buf366  # reuse
            # Topologically Sorted Source Nodes: [attn_output_64], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf370, buf374, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg307_1, (1536, 1536), (1536, 1), 'input')
            buf375 = reinterpret_tensor(buf370, (s16, 1536), (1536, 1), 0); del buf370  # reuse
            # Topologically Sorted Source Nodes: [attn_output_64, transpose_68, reshape_50, attn_output_67], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf374, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg307_1, (1536, 1536), (1, 1536), 0), out=buf375)
            del arg307_1
            assert_size_stride_grouped((arg309_1, arg308_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf377 = reinterpret_tensor(buf374, (s16, 1, 1536), (1536, 1536, 1), 0); del buf374  # reuse
            # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_127, attn_output_67, hidden_states_131, pow_34, variance_33, rsqrt_33, hidden_states_133, hidden_states_134], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf353, buf359, buf375, arg309_1, arg308_1.item(), buf377, s16, 1536, stream=raw_stream0)
            del arg308_1
            del arg309_1
            assert_size_stride(arg310_1, (8960, 1536), (1536, 1), 'input')
            buf378 = reinterpret_tensor(buf358, (s16, 8960), (8960, 1), 0); del buf358  # reuse
            # Topologically Sorted Source Nodes: [linear_116], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf377, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg310_1, (1536, 8960), (1, 1536), 0), out=buf378)
            del arg310_1
            assert_size_stride(arg311_1, (8960, 1536), (1536, 1), 'input')
            buf379 = buf357; del buf357  # reuse
            # Topologically Sorted Source Nodes: [linear_117], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf377, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg311_1, (1536, 8960), (1, 1536), 0), out=buf379)
            del arg311_1
            buf380 = reinterpret_tensor(buf378, (s16, 1, 8960), (8960, 8960, 1), 0); del buf378  # reuse
            # Topologically Sorted Source Nodes: [linear_116, silu_16, linear_117, mul_154], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf380, buf379, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg312_1, (1536, 8960), (8960, 1), 'input')
            buf381 = reinterpret_tensor(buf377, (s16, 1536), (1536, 1), 0); del buf377  # reuse
            # Topologically Sorted Source Nodes: [linear_116, silu_16, linear_117, mul_154, down_proj_16], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf380, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg312_1, (8960, 1536), (1, 8960), 0), out=buf381)
            del arg312_1
            assert_size_stride_grouped((arg314_1, arg313_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf383 = reinterpret_tensor(buf362, (s16, 1, 1536), (1536, 1536, 1), 0); del buf362  # reuse
            # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_127, attn_output_67, hidden_states_131, down_proj_16, hidden_states_135, pow_35, variance_34, rsqrt_34, hidden_states_137, hidden_states_138], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf353, buf359, buf375, buf381, arg314_1, arg313_1.item(), buf383, s16, 1536, stream=raw_stream0)
            del arg313_1
            del arg314_1
            assert_size_stride_grouped((arg316_1, arg315_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf384 = buf330; del buf330  # reuse
            # Topologically Sorted Source Nodes: [linear_119], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg316_1, reinterpret_tensor(buf383, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg315_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf384)
            del arg315_1
            del arg316_1
            assert_size_stride_grouped((arg318_1, arg317_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf385 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_120], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg318_1, reinterpret_tensor(buf383, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg317_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf385)
            del arg317_1
            del arg318_1
            buf386 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_20, sin_20, linear_120, view_52, key_states_17, mul_159, x2_35, neg_35, x1_35, cat_104, mul_160, k_embed_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf385, arg4_1, arg3_1, arg5_1.item(), buf386, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg320_1, arg319_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf387 = buf385; del buf385  # reuse
            # Topologically Sorted Source Nodes: [linear_121], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg320_1, reinterpret_tensor(buf383, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg319_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf387)
            del arg319_1
            del arg320_1
            buf388 = reinterpret_tensor(buf383, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf383  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_119, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, linear_121, view_53, value_states_17, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf384, arg4_1, arg3_1, arg5_1.item(), buf388, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf384
            assert_size_stride(arg323_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg323_1 = copy_if_misaligned(arg323_1)
            buf389 = buf368; del buf368  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_119, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, linear_121, view_53, value_states_17, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg323_1, buf386, buf389, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg323_1
            assert_size_stride(arg324_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg324_1 = copy_if_misaligned(arg324_1)
            buf390 = buf367; del buf367  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_119, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, linear_121, view_53, value_states_17, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg324_1, buf387, buf390, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg324_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_119, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, linear_121, view_53, value_states_17, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf391 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf388, buf389, buf390, None, False, scale=0.08838834764831845)
            buf392 = buf391[0]
            assert_tensor_metadata(buf392, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf392, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf391
            buf396 = buf388; del buf388  # reuse
            # Topologically Sorted Source Nodes: [attn_output_68], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf392, buf396, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg325_1, (1536, 1536), (1536, 1), 'input')
            buf397 = reinterpret_tensor(buf392, (s16, 1536), (1536, 1), 0); del buf392  # reuse
            # Topologically Sorted Source Nodes: [attn_output_68, transpose_72, reshape_53, attn_output_71], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf396, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg325_1, (1536, 1536), (1, 1536), 0), out=buf397)
            del arg325_1
            assert_size_stride_grouped((arg327_1, arg326_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf398 = buf353; del buf353  # reuse
            buf400 = reinterpret_tensor(buf396, (s16, 1, 1536), (1536, 1536, 1), 0); del buf396  # reuse
            # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_127, attn_output_67, hidden_states_131, down_proj_16, hidden_states_135, attn_output_71, hidden_states_139, pow_36, variance_35, rsqrt_35, hidden_states_141, hidden_states_142], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf398, buf359, buf375, buf381, buf397, arg327_1, arg326_1.item(), buf400, s16, 1536, stream=raw_stream0)
            del arg326_1
            del arg327_1
            del buf359
            assert_size_stride(arg328_1, (8960, 1536), (1536, 1), 'input')
            buf401 = reinterpret_tensor(buf380, (s16, 8960), (8960, 1), 0); del buf380  # reuse
            # Topologically Sorted Source Nodes: [pow_36, variance_35, rsqrt_35, hidden_states_141, hidden_states_142, linear_123], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf400, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg328_1, (1536, 8960), (1, 1536), 0), out=buf401)
            del arg328_1
            assert_size_stride(arg329_1, (8960, 1536), (1536, 1), 'input')
            buf402 = buf379; del buf379  # reuse
            # Topologically Sorted Source Nodes: [linear_124], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf400, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg329_1, (1536, 8960), (1, 1536), 0), out=buf402)
            del arg329_1
            buf403 = reinterpret_tensor(buf401, (s16, 1, 8960), (8960, 8960, 1), 0); del buf401  # reuse
            # Topologically Sorted Source Nodes: [linear_123, silu_17, linear_124, mul_163], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf403, buf402, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg330_1, (1536, 8960), (8960, 1), 'input')
            buf404 = reinterpret_tensor(buf400, (s16, 1536), (1536, 1), 0); del buf400  # reuse
            # Topologically Sorted Source Nodes: [linear_123, silu_17, linear_124, mul_163, down_proj_17], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf403, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg330_1, (8960, 1536), (1, 8960), 0), out=buf404)
            del arg330_1
            assert_size_stride_grouped((arg332_1, arg331_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf406 = reinterpret_tensor(buf397, (s16, 1, 1536), (1536, 1536, 1), 0); del buf397  # reuse
            # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_143, pow_37, variance_36, rsqrt_36, hidden_states_145, hidden_states_146], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf398, buf404, arg332_1, arg331_1.item(), buf406, s16, 1536, stream=raw_stream0)
            del arg331_1
            del arg332_1
            assert_size_stride_grouped((arg334_1, arg333_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf407 = buf381; del buf381  # reuse
            # Topologically Sorted Source Nodes: [linear_126], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg334_1, reinterpret_tensor(buf406, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg333_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf407)
            del arg333_1
            del arg334_1
            assert_size_stride_grouped((arg336_1, arg335_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf408 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_127], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg336_1, reinterpret_tensor(buf406, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg335_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf408)
            del arg335_1
            del arg336_1
            buf409 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_21, sin_21, linear_127, view_55, key_states_18, mul_168, x2_37, neg_37, x1_37, cat_110, mul_169, k_embed_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf408, arg4_1, arg3_1, arg5_1.item(), buf409, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg338_1, arg337_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf410 = buf408; del buf408  # reuse
            # Topologically Sorted Source Nodes: [linear_128], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg338_1, reinterpret_tensor(buf406, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg337_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf410)
            del arg337_1
            del arg338_1
            buf411 = reinterpret_tensor(buf406, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf406  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, linear_128, view_56, value_states_18, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf407, arg4_1, arg3_1, arg5_1.item(), buf411, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg341_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg341_1 = copy_if_misaligned(arg341_1)
            buf412 = buf390; del buf390  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, linear_128, view_56, value_states_18, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg341_1, buf409, buf412, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg341_1
            assert_size_stride(arg342_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg342_1 = copy_if_misaligned(arg342_1)
            buf413 = buf389; del buf389  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, linear_128, view_56, value_states_18, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg342_1, buf410, buf413, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg342_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, linear_128, view_56, value_states_18, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf414 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf411, buf412, buf413, None, False, scale=0.08838834764831845)
            buf415 = buf414[0]
            assert_tensor_metadata(buf415, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf415, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf414
            buf419 = buf411; del buf411  # reuse
            # Topologically Sorted Source Nodes: [attn_output_72], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf415, buf419, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg343_1, (1536, 1536), (1536, 1), 'input')
            buf420 = reinterpret_tensor(buf415, (s16, 1536), (1536, 1), 0); del buf415  # reuse
            # Topologically Sorted Source Nodes: [attn_output_72, transpose_76, reshape_56, attn_output_75], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf419, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg343_1, (1536, 1536), (1, 1536), 0), out=buf420)
            del arg343_1
            assert_size_stride_grouped((arg345_1, arg344_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf422 = reinterpret_tensor(buf419, (s16, 1, 1536), (1536, 1536, 1), 0); del buf419  # reuse
            # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_143, attn_output_75, hidden_states_147, pow_38, variance_37, rsqrt_37, hidden_states_149, hidden_states_150], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf398, buf404, buf420, arg345_1, arg344_1.item(), buf422, s16, 1536, stream=raw_stream0)
            del arg344_1
            del arg345_1
            assert_size_stride(arg346_1, (8960, 1536), (1536, 1), 'input')
            buf423 = reinterpret_tensor(buf403, (s16, 8960), (8960, 1), 0); del buf403  # reuse
            # Topologically Sorted Source Nodes: [linear_130], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf422, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg346_1, (1536, 8960), (1, 1536), 0), out=buf423)
            del arg346_1
            assert_size_stride(arg347_1, (8960, 1536), (1536, 1), 'input')
            buf424 = buf402; del buf402  # reuse
            # Topologically Sorted Source Nodes: [linear_131], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf422, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg347_1, (1536, 8960), (1, 1536), 0), out=buf424)
            del arg347_1
            buf425 = reinterpret_tensor(buf423, (s16, 1, 8960), (8960, 8960, 1), 0); del buf423  # reuse
            # Topologically Sorted Source Nodes: [linear_130, silu_18, linear_131, mul_172], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf425, buf424, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg348_1, (1536, 8960), (8960, 1), 'input')
            buf426 = reinterpret_tensor(buf422, (s16, 1536), (1536, 1), 0); del buf422  # reuse
            # Topologically Sorted Source Nodes: [linear_130, silu_18, linear_131, mul_172, down_proj_18], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf425, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg348_1, (8960, 1536), (1, 8960), 0), out=buf426)
            del arg348_1
            assert_size_stride_grouped((arg350_1, arg349_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf428 = reinterpret_tensor(buf407, (s16, 1, 1536), (1536, 1536, 1), 0); del buf407  # reuse
            # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_143, attn_output_75, hidden_states_147, down_proj_18, hidden_states_151, pow_39, variance_38, rsqrt_38, hidden_states_153, hidden_states_154], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf398, buf404, buf420, buf426, arg350_1, arg349_1.item(), buf428, s16, 1536, stream=raw_stream0)
            del arg349_1
            del arg350_1
            assert_size_stride_grouped((arg352_1, arg351_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf429 = buf375; del buf375  # reuse
            # Topologically Sorted Source Nodes: [linear_133], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg352_1, reinterpret_tensor(buf428, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg351_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf429)
            del arg351_1
            del arg352_1
            assert_size_stride_grouped((arg354_1, arg353_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf430 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_134], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg354_1, reinterpret_tensor(buf428, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg353_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf430)
            del arg353_1
            del arg354_1
            buf431 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_22, sin_22, linear_134, view_58, key_states_19, mul_177, x2_39, neg_39, x1_39, cat_116, mul_178, k_embed_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf430, arg4_1, arg3_1, arg5_1.item(), buf431, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg356_1, arg355_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf432 = buf430; del buf430  # reuse
            # Topologically Sorted Source Nodes: [linear_135], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg356_1, reinterpret_tensor(buf428, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg355_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf432)
            del arg355_1
            del arg356_1
            buf433 = reinterpret_tensor(buf428, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf428  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_133, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, linear_135, view_59, value_states_19, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf429, arg4_1, arg3_1, arg5_1.item(), buf433, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf429
            assert_size_stride(arg359_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg359_1 = copy_if_misaligned(arg359_1)
            buf434 = buf413; del buf413  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_133, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, linear_135, view_59, value_states_19, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg359_1, buf431, buf434, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg359_1
            assert_size_stride(arg360_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg360_1 = copy_if_misaligned(arg360_1)
            buf435 = buf412; del buf412  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_133, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, linear_135, view_59, value_states_19, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg360_1, buf432, buf435, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg360_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_133, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, linear_135, view_59, value_states_19, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf436 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf433, buf434, buf435, None, False, scale=0.08838834764831845)
            buf437 = buf436[0]
            assert_tensor_metadata(buf437, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf437, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf436
            buf441 = buf433; del buf433  # reuse
            # Topologically Sorted Source Nodes: [attn_output_76], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf437, buf441, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg361_1, (1536, 1536), (1536, 1), 'input')
            buf442 = reinterpret_tensor(buf437, (s16, 1536), (1536, 1), 0); del buf437  # reuse
            # Topologically Sorted Source Nodes: [attn_output_76, transpose_80, reshape_59, attn_output_79], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf441, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg361_1, (1536, 1536), (1, 1536), 0), out=buf442)
            del arg361_1
            assert_size_stride_grouped((arg363_1, arg362_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf443 = buf398; del buf398  # reuse
            buf445 = reinterpret_tensor(buf441, (s16, 1, 1536), (1536, 1536, 1), 0); del buf441  # reuse
            # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_143, attn_output_75, hidden_states_147, down_proj_18, hidden_states_151, attn_output_79, hidden_states_155, pow_40, variance_39, rsqrt_39, hidden_states_157, hidden_states_158], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf443, buf404, buf420, buf426, buf442, arg363_1, arg362_1.item(), buf445, s16, 1536, stream=raw_stream0)
            del arg362_1
            del arg363_1
            del buf404
            assert_size_stride(arg364_1, (8960, 1536), (1536, 1), 'input')
            buf446 = reinterpret_tensor(buf425, (s16, 8960), (8960, 1), 0); del buf425  # reuse
            # Topologically Sorted Source Nodes: [pow_40, variance_39, rsqrt_39, hidden_states_157, hidden_states_158, linear_137], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf445, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg364_1, (1536, 8960), (1, 1536), 0), out=buf446)
            del arg364_1
            assert_size_stride(arg365_1, (8960, 1536), (1536, 1), 'input')
            buf447 = buf424; del buf424  # reuse
            # Topologically Sorted Source Nodes: [linear_138], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf445, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg365_1, (1536, 8960), (1, 1536), 0), out=buf447)
            del arg365_1
            buf448 = reinterpret_tensor(buf446, (s16, 1, 8960), (8960, 8960, 1), 0); del buf446  # reuse
            # Topologically Sorted Source Nodes: [linear_137, silu_19, linear_138, mul_181], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf448, buf447, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg366_1, (1536, 8960), (8960, 1), 'input')
            buf449 = reinterpret_tensor(buf445, (s16, 1536), (1536, 1), 0); del buf445  # reuse
            # Topologically Sorted Source Nodes: [linear_137, silu_19, linear_138, mul_181, down_proj_19], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf448, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg366_1, (8960, 1536), (1, 8960), 0), out=buf449)
            del arg366_1
            assert_size_stride_grouped((arg368_1, arg367_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf451 = reinterpret_tensor(buf442, (s16, 1, 1536), (1536, 1536, 1), 0); del buf442  # reuse
            # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_159, pow_41, variance_40, rsqrt_40, hidden_states_161, hidden_states_162], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf443, buf449, arg368_1, arg367_1.item(), buf451, s16, 1536, stream=raw_stream0)
            del arg367_1
            del arg368_1
            assert_size_stride_grouped((arg370_1, arg369_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf452 = buf426; del buf426  # reuse
            # Topologically Sorted Source Nodes: [linear_140], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg370_1, reinterpret_tensor(buf451, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg369_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf452)
            del arg369_1
            del arg370_1
            assert_size_stride_grouped((arg372_1, arg371_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf453 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_141], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg372_1, reinterpret_tensor(buf451, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg371_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf453)
            del arg371_1
            del arg372_1
            buf454 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_23, sin_23, linear_141, view_61, key_states_20, mul_186, x2_41, neg_41, x1_41, cat_122, mul_187, k_embed_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf453, arg4_1, arg3_1, arg5_1.item(), buf454, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg374_1, arg373_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf455 = buf453; del buf453  # reuse
            # Topologically Sorted Source Nodes: [linear_142], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg374_1, reinterpret_tensor(buf451, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg373_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf455)
            del arg373_1
            del arg374_1
            buf456 = reinterpret_tensor(buf451, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf451  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_140, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, linear_142, view_62, value_states_20, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf452, arg4_1, arg3_1, arg5_1.item(), buf456, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg377_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg377_1 = copy_if_misaligned(arg377_1)
            buf457 = buf435; del buf435  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_140, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, linear_142, view_62, value_states_20, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg377_1, buf454, buf457, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg377_1
            assert_size_stride(arg378_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg378_1 = copy_if_misaligned(arg378_1)
            buf458 = buf434; del buf434  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_140, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, linear_142, view_62, value_states_20, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg378_1, buf455, buf458, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg378_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_140, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, linear_142, view_62, value_states_20, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf459 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf456, buf457, buf458, None, False, scale=0.08838834764831845)
            buf460 = buf459[0]
            assert_tensor_metadata(buf460, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf460, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf459
            buf464 = buf456; del buf456  # reuse
            # Topologically Sorted Source Nodes: [attn_output_80], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf460, buf464, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg379_1, (1536, 1536), (1536, 1), 'input')
            buf465 = reinterpret_tensor(buf460, (s16, 1536), (1536, 1), 0); del buf460  # reuse
            # Topologically Sorted Source Nodes: [attn_output_80, transpose_84, reshape_62, attn_output_83], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf464, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg379_1, (1536, 1536), (1, 1536), 0), out=buf465)
            del arg379_1
            assert_size_stride_grouped((arg381_1, arg380_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf467 = reinterpret_tensor(buf464, (s16, 1, 1536), (1536, 1536, 1), 0); del buf464  # reuse
            # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_159, attn_output_83, hidden_states_163, pow_42, variance_41, rsqrt_41, hidden_states_165, hidden_states_166], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf443, buf449, buf465, arg381_1, arg380_1.item(), buf467, s16, 1536, stream=raw_stream0)
            del arg380_1
            del arg381_1
            assert_size_stride(arg382_1, (8960, 1536), (1536, 1), 'input')
            buf468 = reinterpret_tensor(buf448, (s16, 8960), (8960, 1), 0); del buf448  # reuse
            # Topologically Sorted Source Nodes: [linear_144], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf467, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg382_1, (1536, 8960), (1, 1536), 0), out=buf468)
            del arg382_1
            assert_size_stride(arg383_1, (8960, 1536), (1536, 1), 'input')
            buf469 = buf447; del buf447  # reuse
            # Topologically Sorted Source Nodes: [linear_145], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf467, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg383_1, (1536, 8960), (1, 1536), 0), out=buf469)
            del arg383_1
            buf470 = reinterpret_tensor(buf468, (s16, 1, 8960), (8960, 8960, 1), 0); del buf468  # reuse
            # Topologically Sorted Source Nodes: [linear_144, silu_20, linear_145, mul_190], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf470, buf469, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg384_1, (1536, 8960), (8960, 1), 'input')
            buf471 = reinterpret_tensor(buf467, (s16, 1536), (1536, 1), 0); del buf467  # reuse
            # Topologically Sorted Source Nodes: [linear_144, silu_20, linear_145, mul_190, down_proj_20], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf470, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg384_1, (8960, 1536), (1, 8960), 0), out=buf471)
            del arg384_1
            assert_size_stride_grouped((arg386_1, arg385_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf473 = reinterpret_tensor(buf452, (s16, 1, 1536), (1536, 1536, 1), 0); del buf452  # reuse
            # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_159, attn_output_83, hidden_states_163, down_proj_20, hidden_states_167, pow_43, variance_42, rsqrt_42, hidden_states_169, hidden_states_170], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf443, buf449, buf465, buf471, arg386_1, arg385_1.item(), buf473, s16, 1536, stream=raw_stream0)
            del arg385_1
            del arg386_1
            assert_size_stride_grouped((arg388_1, arg387_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf474 = buf420; del buf420  # reuse
            # Topologically Sorted Source Nodes: [linear_147], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg388_1, reinterpret_tensor(buf473, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg387_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf474)
            del arg387_1
            del arg388_1
            assert_size_stride_grouped((arg390_1, arg389_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf475 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_148], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg390_1, reinterpret_tensor(buf473, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg389_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf475)
            del arg389_1
            del arg390_1
            buf476 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_24, sin_24, linear_148, view_64, key_states_21, mul_195, x2_43, neg_43, x1_43, cat_128, mul_196, k_embed_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf475, arg4_1, arg3_1, arg5_1.item(), buf476, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg392_1, arg391_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf477 = buf475; del buf475  # reuse
            # Topologically Sorted Source Nodes: [linear_149], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg392_1, reinterpret_tensor(buf473, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg391_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf477)
            del arg391_1
            del arg392_1
            buf478 = reinterpret_tensor(buf473, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf473  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_147, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, linear_149, view_65, value_states_21, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf474, arg4_1, arg3_1, arg5_1.item(), buf478, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf474
            assert_size_stride(arg395_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg395_1 = copy_if_misaligned(arg395_1)
            buf479 = buf458; del buf458  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_147, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, linear_149, view_65, value_states_21, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg395_1, buf476, buf479, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg395_1
            assert_size_stride(arg396_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg396_1 = copy_if_misaligned(arg396_1)
            buf480 = buf457; del buf457  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_147, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, linear_149, view_65, value_states_21, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg396_1, buf477, buf480, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg396_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_147, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, linear_149, view_65, value_states_21, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf481 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf478, buf479, buf480, None, False, scale=0.08838834764831845)
            buf482 = buf481[0]
            assert_tensor_metadata(buf482, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf482, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf481
            buf486 = buf478; del buf478  # reuse
            # Topologically Sorted Source Nodes: [attn_output_84], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf482, buf486, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg397_1, (1536, 1536), (1536, 1), 'input')
            buf487 = reinterpret_tensor(buf482, (s16, 1536), (1536, 1), 0); del buf482  # reuse
            # Topologically Sorted Source Nodes: [attn_output_84, transpose_88, reshape_65, attn_output_87], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf486, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg397_1, (1536, 1536), (1, 1536), 0), out=buf487)
            del arg397_1
            assert_size_stride_grouped((arg399_1, arg398_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf488 = buf443; del buf443  # reuse
            buf490 = reinterpret_tensor(buf486, (s16, 1, 1536), (1536, 1536, 1), 0); del buf486  # reuse
            # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_159, attn_output_83, hidden_states_163, down_proj_20, hidden_states_167, attn_output_87, hidden_states_171, pow_44, variance_43, rsqrt_43, hidden_states_173, hidden_states_174], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf488, buf449, buf465, buf471, buf487, arg399_1, arg398_1.item(), buf490, s16, 1536, stream=raw_stream0)
            del arg398_1
            del arg399_1
            del buf449
            assert_size_stride(arg400_1, (8960, 1536), (1536, 1), 'input')
            buf491 = reinterpret_tensor(buf470, (s16, 8960), (8960, 1), 0); del buf470  # reuse
            # Topologically Sorted Source Nodes: [pow_44, variance_43, rsqrt_43, hidden_states_173, hidden_states_174, linear_151], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf490, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg400_1, (1536, 8960), (1, 1536), 0), out=buf491)
            del arg400_1
            assert_size_stride(arg401_1, (8960, 1536), (1536, 1), 'input')
            buf492 = buf469; del buf469  # reuse
            # Topologically Sorted Source Nodes: [linear_152], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf490, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg401_1, (1536, 8960), (1, 1536), 0), out=buf492)
            del arg401_1
            buf493 = reinterpret_tensor(buf491, (s16, 1, 8960), (8960, 8960, 1), 0); del buf491  # reuse
            # Topologically Sorted Source Nodes: [linear_151, silu_21, linear_152, mul_199], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf493, buf492, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg402_1, (1536, 8960), (8960, 1), 'input')
            buf494 = reinterpret_tensor(buf490, (s16, 1536), (1536, 1), 0); del buf490  # reuse
            # Topologically Sorted Source Nodes: [linear_151, silu_21, linear_152, mul_199, down_proj_21], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf493, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg402_1, (8960, 1536), (1, 8960), 0), out=buf494)
            del arg402_1
            assert_size_stride_grouped((arg404_1, arg403_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf496 = reinterpret_tensor(buf487, (s16, 1, 1536), (1536, 1536, 1), 0); del buf487  # reuse
            # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_175, pow_45, variance_44, rsqrt_44, hidden_states_177, hidden_states_178], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf488, buf494, arg404_1, arg403_1.item(), buf496, s16, 1536, stream=raw_stream0)
            del arg403_1
            del arg404_1
            assert_size_stride_grouped((arg406_1, arg405_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf497 = buf471; del buf471  # reuse
            # Topologically Sorted Source Nodes: [linear_154], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg406_1, reinterpret_tensor(buf496, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg405_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf497)
            del arg405_1
            del arg406_1
            assert_size_stride_grouped((arg408_1, arg407_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf498 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_155], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg408_1, reinterpret_tensor(buf496, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg407_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf498)
            del arg407_1
            del arg408_1
            buf499 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_25, sin_25, linear_155, view_67, key_states_22, mul_204, x2_45, neg_45, x1_45, cat_134, mul_205, k_embed_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf498, arg4_1, arg3_1, arg5_1.item(), buf499, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg410_1, arg409_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf500 = buf498; del buf498  # reuse
            # Topologically Sorted Source Nodes: [linear_156], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg410_1, reinterpret_tensor(buf496, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg409_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf500)
            del arg409_1
            del arg410_1
            buf501 = reinterpret_tensor(buf496, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf496  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_154, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, linear_156, view_68, value_states_22, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf497, arg4_1, arg3_1, arg5_1.item(), buf501, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg413_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg413_1 = copy_if_misaligned(arg413_1)
            buf502 = buf480; del buf480  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_154, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, linear_156, view_68, value_states_22, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg413_1, buf499, buf502, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg413_1
            assert_size_stride(arg414_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg414_1 = copy_if_misaligned(arg414_1)
            buf503 = buf479; del buf479  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_154, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, linear_156, view_68, value_states_22, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg414_1, buf500, buf503, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg414_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_154, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, linear_156, view_68, value_states_22, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf504 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf501, buf502, buf503, None, False, scale=0.08838834764831845)
            buf505 = buf504[0]
            assert_tensor_metadata(buf505, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf505, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf504
            buf509 = buf501; del buf501  # reuse
            # Topologically Sorted Source Nodes: [attn_output_88], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf505, buf509, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg415_1, (1536, 1536), (1536, 1), 'input')
            buf510 = reinterpret_tensor(buf505, (s16, 1536), (1536, 1), 0); del buf505  # reuse
            # Topologically Sorted Source Nodes: [attn_output_88, transpose_92, reshape_68, attn_output_91], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf509, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg415_1, (1536, 1536), (1, 1536), 0), out=buf510)
            del arg415_1
            assert_size_stride(arg416_1, (1536, ), (1, ), 'input')
            buf512 = reinterpret_tensor(buf509, (s16, 1, 1536), (1536, 1536, 1), 0); del buf509  # reuse
            # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_175, attn_output_91, hidden_states_179, pow_46, variance_45, add_136, rsqrt_45, hidden_states_181, hidden_states_182], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14.run(buf488, buf494, buf510, arg416_1, buf512, s16, 1536, stream=raw_stream0)
            del arg416_1
            assert_size_stride(arg417_1, (8960, 1536), (1536, 1), 'input')
            buf513 = reinterpret_tensor(buf493, (s16, 8960), (8960, 1), 0); del buf493  # reuse
            # Topologically Sorted Source Nodes: [linear_158], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf512, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg417_1, (1536, 8960), (1, 1536), 0), out=buf513)
            del arg417_1
            assert_size_stride(arg418_1, (8960, 1536), (1536, 1), 'input')
            buf514 = buf492; del buf492  # reuse
            # Topologically Sorted Source Nodes: [linear_159], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf512, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg418_1, (1536, 8960), (1, 1536), 0), out=buf514)
            del arg418_1
            buf515 = reinterpret_tensor(buf513, (s16, 1, 8960), (8960, 8960, 1), 0); del buf513  # reuse
            # Topologically Sorted Source Nodes: [linear_158, silu_22, linear_159, mul_208], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf515, buf514, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg419_1, (1536, 8960), (8960, 1), 'input')
            buf516 = reinterpret_tensor(buf512, (s16, 1536), (1536, 1), 0); del buf512  # reuse
            # Topologically Sorted Source Nodes: [linear_158, silu_22, linear_159, mul_208, down_proj_22], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf515, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg419_1, (8960, 1536), (1, 8960), 0), out=buf516)
            del arg419_1
            assert_size_stride_grouped((arg421_1, arg420_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf518 = reinterpret_tensor(buf497, (s16, 1, 1536), (1536, 1536, 1), 0); del buf497  # reuse
            # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_175, attn_output_91, hidden_states_179, down_proj_22, hidden_states_183, pow_47, variance_46, rsqrt_46, hidden_states_185, hidden_states_186], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf488, buf494, buf510, buf516, arg421_1, arg420_1.item(), buf518, s16, 1536, stream=raw_stream0)
            del arg420_1
            del arg421_1
            assert_size_stride_grouped((arg423_1, arg422_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf519 = buf465; del buf465  # reuse
            # Topologically Sorted Source Nodes: [linear_161], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg423_1, reinterpret_tensor(buf518, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg422_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf519)
            del arg422_1
            del arg423_1
            assert_size_stride_grouped((arg425_1, arg424_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf520 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_162], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg425_1, reinterpret_tensor(buf518, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg424_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf520)
            del arg424_1
            del arg425_1
            buf521 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_26, sin_26, linear_162, view_70, key_states_23, mul_213, x2_47, neg_47, x1_47, cat_140, mul_214, k_embed_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf520, arg4_1, arg3_1, arg5_1.item(), buf521, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg427_1, arg426_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf522 = buf520; del buf520  # reuse
            # Topologically Sorted Source Nodes: [linear_163], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg427_1, reinterpret_tensor(buf518, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg426_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf522)
            del arg426_1
            del arg427_1
            buf523 = reinterpret_tensor(buf518, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf518  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_161, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, linear_163, view_71, value_states_23, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf519, arg4_1, arg3_1, arg5_1.item(), buf523, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf519
            assert_size_stride(arg430_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg430_1 = copy_if_misaligned(arg430_1)
            buf524 = buf503; del buf503  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_161, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, linear_163, view_71, value_states_23, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg430_1, buf521, buf524, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg430_1
            assert_size_stride(arg431_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg431_1 = copy_if_misaligned(arg431_1)
            buf525 = buf502; del buf502  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_161, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, linear_163, view_71, value_states_23, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg431_1, buf522, buf525, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg431_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_161, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, linear_163, view_71, value_states_23, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf526 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf523, buf524, buf525, None, False, scale=0.08838834764831845)
            buf527 = buf526[0]
            assert_tensor_metadata(buf527, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf527, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf526
            buf531 = buf523; del buf523  # reuse
            # Topologically Sorted Source Nodes: [attn_output_92], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf527, buf531, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg432_1, (1536, 1536), (1536, 1), 'input')
            buf532 = reinterpret_tensor(buf527, (s16, 1536), (1536, 1), 0); del buf527  # reuse
            # Topologically Sorted Source Nodes: [attn_output_92, transpose_96, reshape_71, attn_output_95], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf531, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg432_1, (1536, 1536), (1, 1536), 0), out=buf532)
            del arg432_1
            assert_size_stride_grouped((arg434_1, arg433_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf533 = buf488; del buf488  # reuse
            buf535 = reinterpret_tensor(buf531, (s16, 1, 1536), (1536, 1536, 1), 0); del buf531  # reuse
            # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_175, attn_output_91, hidden_states_179, down_proj_22, hidden_states_183, attn_output_95, hidden_states_187, pow_48, variance_47, rsqrt_47, hidden_states_189, hidden_states_190], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf533, buf494, buf510, buf516, buf532, arg434_1, arg433_1.item(), buf535, s16, 1536, stream=raw_stream0)
            del arg433_1
            del arg434_1
            del buf494
            assert_size_stride(arg435_1, (8960, 1536), (1536, 1), 'input')
            buf536 = reinterpret_tensor(buf515, (s16, 8960), (8960, 1), 0); del buf515  # reuse
            # Topologically Sorted Source Nodes: [pow_48, variance_47, rsqrt_47, hidden_states_189, hidden_states_190, linear_165], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf535, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg435_1, (1536, 8960), (1, 1536), 0), out=buf536)
            del arg435_1
            assert_size_stride(arg436_1, (8960, 1536), (1536, 1), 'input')
            buf537 = buf514; del buf514  # reuse
            # Topologically Sorted Source Nodes: [linear_166], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf535, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg436_1, (1536, 8960), (1, 1536), 0), out=buf537)
            del arg436_1
            buf538 = reinterpret_tensor(buf536, (s16, 1, 8960), (8960, 8960, 1), 0); del buf536  # reuse
            # Topologically Sorted Source Nodes: [linear_165, silu_23, linear_166, mul_217], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf538, buf537, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg437_1, (1536, 8960), (8960, 1), 'input')
            buf539 = reinterpret_tensor(buf535, (s16, 1536), (1536, 1), 0); del buf535  # reuse
            # Topologically Sorted Source Nodes: [linear_165, silu_23, linear_166, mul_217, down_proj_23], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf538, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg437_1, (8960, 1536), (1, 8960), 0), out=buf539)
            del arg437_1
            assert_size_stride_grouped((arg439_1, arg438_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf541 = reinterpret_tensor(buf532, (s16, 1, 1536), (1536, 1536, 1), 0); del buf532  # reuse
            # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_191, pow_49, variance_48, rsqrt_48, hidden_states_193, hidden_states_194], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf533, buf539, arg439_1, arg438_1.item(), buf541, s16, 1536, stream=raw_stream0)
            del arg438_1
            del arg439_1
            assert_size_stride_grouped((arg441_1, arg440_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf542 = buf516; del buf516  # reuse
            # Topologically Sorted Source Nodes: [linear_168], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg441_1, reinterpret_tensor(buf541, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg440_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf542)
            del arg440_1
            del arg441_1
            assert_size_stride_grouped((arg443_1, arg442_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf543 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_169], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg443_1, reinterpret_tensor(buf541, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg442_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf543)
            del arg442_1
            del arg443_1
            buf544 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_27, sin_27, linear_169, view_73, key_states_24, mul_222, x2_49, neg_49, x1_49, cat_146, mul_223, k_embed_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf543, arg4_1, arg3_1, arg5_1.item(), buf544, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg445_1, arg444_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf545 = buf543; del buf543  # reuse
            # Topologically Sorted Source Nodes: [linear_170], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg445_1, reinterpret_tensor(buf541, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg444_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf545)
            del arg444_1
            del arg445_1
            buf546 = reinterpret_tensor(buf541, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf541  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_168, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, linear_170, view_74, value_states_24, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf542, arg4_1, arg3_1, arg5_1.item(), buf546, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg448_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg448_1 = copy_if_misaligned(arg448_1)
            buf547 = buf525; del buf525  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_168, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, linear_170, view_74, value_states_24, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg448_1, buf544, buf547, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg448_1
            assert_size_stride(arg449_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg449_1 = copy_if_misaligned(arg449_1)
            buf548 = buf524; del buf524  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_168, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, linear_170, view_74, value_states_24, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg449_1, buf545, buf548, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg449_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_168, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, linear_170, view_74, value_states_24, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf549 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf546, buf547, buf548, None, False, scale=0.08838834764831845)
            buf550 = buf549[0]
            assert_tensor_metadata(buf550, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf550, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf549
            buf554 = buf546; del buf546  # reuse
            # Topologically Sorted Source Nodes: [attn_output_96], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf550, buf554, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg450_1, (1536, 1536), (1536, 1), 'input')
            buf555 = reinterpret_tensor(buf550, (s16, 1536), (1536, 1), 0); del buf550  # reuse
            # Topologically Sorted Source Nodes: [attn_output_96, transpose_100, reshape_74, attn_output_99], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf554, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg450_1, (1536, 1536), (1, 1536), 0), out=buf555)
            del arg450_1
            assert_size_stride_grouped((arg452_1, arg451_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf557 = reinterpret_tensor(buf554, (s16, 1, 1536), (1536, 1536, 1), 0); del buf554  # reuse
            # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_191, attn_output_99, hidden_states_195, pow_50, variance_49, rsqrt_49, hidden_states_197, hidden_states_198], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf533, buf539, buf555, arg452_1, arg451_1.item(), buf557, s16, 1536, stream=raw_stream0)
            del arg451_1
            del arg452_1
            assert_size_stride(arg453_1, (8960, 1536), (1536, 1), 'input')
            buf558 = reinterpret_tensor(buf538, (s16, 8960), (8960, 1), 0); del buf538  # reuse
            # Topologically Sorted Source Nodes: [linear_172], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf557, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg453_1, (1536, 8960), (1, 1536), 0), out=buf558)
            del arg453_1
            assert_size_stride(arg454_1, (8960, 1536), (1536, 1), 'input')
            buf559 = buf537; del buf537  # reuse
            # Topologically Sorted Source Nodes: [linear_173], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf557, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg454_1, (1536, 8960), (1, 1536), 0), out=buf559)
            del arg454_1
            buf560 = reinterpret_tensor(buf558, (s16, 1, 8960), (8960, 8960, 1), 0); del buf558  # reuse
            # Topologically Sorted Source Nodes: [linear_172, silu_24, linear_173, mul_226], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf560, buf559, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg455_1, (1536, 8960), (8960, 1), 'input')
            buf561 = reinterpret_tensor(buf557, (s16, 1536), (1536, 1), 0); del buf557  # reuse
            # Topologically Sorted Source Nodes: [linear_172, silu_24, linear_173, mul_226, down_proj_24], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf560, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg455_1, (8960, 1536), (1, 8960), 0), out=buf561)
            del arg455_1
            assert_size_stride_grouped((arg457_1, arg456_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf563 = reinterpret_tensor(buf542, (s16, 1, 1536), (1536, 1536, 1), 0); del buf542  # reuse
            # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_191, attn_output_99, hidden_states_195, down_proj_24, hidden_states_199, pow_51, variance_50, rsqrt_50, hidden_states_201, hidden_states_202], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf533, buf539, buf555, buf561, arg457_1, arg456_1.item(), buf563, s16, 1536, stream=raw_stream0)
            del arg456_1
            del arg457_1
            assert_size_stride_grouped((arg459_1, arg458_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf564 = buf510; del buf510  # reuse
            # Topologically Sorted Source Nodes: [linear_175], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg459_1, reinterpret_tensor(buf563, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg458_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf564)
            del arg458_1
            del arg459_1
            assert_size_stride_grouped((arg461_1, arg460_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf565 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_176], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg461_1, reinterpret_tensor(buf563, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg460_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf565)
            del arg460_1
            del arg461_1
            buf566 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_28, sin_28, linear_176, view_76, key_states_25, mul_231, x2_51, neg_51, x1_51, cat_152, mul_232, k_embed_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf565, arg4_1, arg3_1, arg5_1.item(), buf566, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg463_1, arg462_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf567 = buf565; del buf565  # reuse
            # Topologically Sorted Source Nodes: [linear_177], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg463_1, reinterpret_tensor(buf563, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg462_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf567)
            del arg462_1
            del arg463_1
            buf568 = reinterpret_tensor(buf563, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf563  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_175, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, linear_177, view_77, value_states_25, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf564, arg4_1, arg3_1, arg5_1.item(), buf568, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf564
            assert_size_stride(arg466_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg466_1 = copy_if_misaligned(arg466_1)
            buf569 = buf548; del buf548  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_175, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, linear_177, view_77, value_states_25, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg466_1, buf566, buf569, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg466_1
            assert_size_stride(arg467_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg467_1 = copy_if_misaligned(arg467_1)
            buf570 = buf547; del buf547  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_175, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, linear_177, view_77, value_states_25, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg467_1, buf567, buf570, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg467_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_175, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, linear_177, view_77, value_states_25, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf571 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf568, buf569, buf570, None, False, scale=0.08838834764831845)
            buf572 = buf571[0]
            assert_tensor_metadata(buf572, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf572, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf571
            buf576 = buf568; del buf568  # reuse
            # Topologically Sorted Source Nodes: [attn_output_100], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf572, buf576, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg468_1, (1536, 1536), (1536, 1), 'input')
            buf577 = reinterpret_tensor(buf572, (s16, 1536), (1536, 1), 0); del buf572  # reuse
            # Topologically Sorted Source Nodes: [attn_output_100, transpose_104, reshape_77, attn_output_103], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf576, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg468_1, (1536, 1536), (1, 1536), 0), out=buf577)
            del arg468_1
            assert_size_stride_grouped((arg470_1, arg469_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf578 = buf533; del buf533  # reuse
            buf580 = reinterpret_tensor(buf576, (s16, 1, 1536), (1536, 1536, 1), 0); del buf576  # reuse
            # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_191, attn_output_99, hidden_states_195, down_proj_24, hidden_states_199, attn_output_103, hidden_states_203, pow_52, variance_51, rsqrt_51, hidden_states_205, hidden_states_206], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf578, buf539, buf555, buf561, buf577, arg470_1, arg469_1.item(), buf580, s16, 1536, stream=raw_stream0)
            del arg469_1
            del arg470_1
            del buf539
            assert_size_stride(arg471_1, (8960, 1536), (1536, 1), 'input')
            buf581 = reinterpret_tensor(buf560, (s16, 8960), (8960, 1), 0); del buf560  # reuse
            # Topologically Sorted Source Nodes: [pow_52, variance_51, rsqrt_51, hidden_states_205, hidden_states_206, linear_179], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf580, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg471_1, (1536, 8960), (1, 1536), 0), out=buf581)
            del arg471_1
            assert_size_stride(arg472_1, (8960, 1536), (1536, 1), 'input')
            buf582 = buf559; del buf559  # reuse
            # Topologically Sorted Source Nodes: [linear_180], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf580, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg472_1, (1536, 8960), (1, 1536), 0), out=buf582)
            del arg472_1
            buf583 = reinterpret_tensor(buf581, (s16, 1, 8960), (8960, 8960, 1), 0); del buf581  # reuse
            # Topologically Sorted Source Nodes: [linear_179, silu_25, linear_180, mul_235], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf583, buf582, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg473_1, (1536, 8960), (8960, 1), 'input')
            buf584 = reinterpret_tensor(buf580, (s16, 1536), (1536, 1), 0); del buf580  # reuse
            # Topologically Sorted Source Nodes: [linear_179, silu_25, linear_180, mul_235, down_proj_25], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf583, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg473_1, (8960, 1536), (1, 8960), 0), out=buf584)
            del arg473_1
            assert_size_stride_grouped((arg475_1, arg474_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf586 = reinterpret_tensor(buf577, (s16, 1, 1536), (1536, 1536, 1), 0); del buf577  # reuse
            # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_207, pow_53, variance_52, rsqrt_52, hidden_states_209, hidden_states_210], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf578, buf584, arg475_1, arg474_1.item(), buf586, s16, 1536, stream=raw_stream0)
            del arg474_1
            del arg475_1
            assert_size_stride_grouped((arg477_1, arg476_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf587 = buf561; del buf561  # reuse
            # Topologically Sorted Source Nodes: [linear_182], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg477_1, reinterpret_tensor(buf586, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg476_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf587)
            del arg476_1
            del arg477_1
            assert_size_stride_grouped((arg479_1, arg478_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf588 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_183], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg479_1, reinterpret_tensor(buf586, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg478_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf588)
            del arg478_1
            del arg479_1
            buf589 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_29, sin_29, linear_183, view_79, key_states_26, mul_240, x2_53, neg_53, x1_53, cat_158, mul_241, k_embed_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf588, arg4_1, arg3_1, arg5_1.item(), buf589, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg481_1, arg480_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf590 = buf588; del buf588  # reuse
            # Topologically Sorted Source Nodes: [linear_184], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg481_1, reinterpret_tensor(buf586, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg480_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf590)
            del arg480_1
            del arg481_1
            buf591 = reinterpret_tensor(buf586, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf586  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_182, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, linear_184, view_80, value_states_26, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf587, arg4_1, arg3_1, arg5_1.item(), buf591, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            assert_size_stride(arg484_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg484_1 = copy_if_misaligned(arg484_1)
            buf592 = buf570; del buf570  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_182, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, linear_184, view_80, value_states_26, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg484_1, buf589, buf592, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg484_1
            assert_size_stride(arg485_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg485_1 = copy_if_misaligned(arg485_1)
            buf593 = buf569; del buf569  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_182, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, linear_184, view_80, value_states_26, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg485_1, buf590, buf593, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg485_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_182, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, linear_184, view_80, value_states_26, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf594 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf591, buf592, buf593, None, False, scale=0.08838834764831845)
            buf595 = buf594[0]
            assert_tensor_metadata(buf595, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf595, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf594
            buf599 = buf591; del buf591  # reuse
            # Topologically Sorted Source Nodes: [attn_output_104], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf595, buf599, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg486_1, (1536, 1536), (1536, 1), 'input')
            buf600 = reinterpret_tensor(buf595, (s16, 1536), (1536, 1), 0); del buf595  # reuse
            # Topologically Sorted Source Nodes: [attn_output_104, transpose_108, reshape_80, attn_output_107], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf599, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg486_1, (1536, 1536), (1, 1536), 0), out=buf600)
            del arg486_1
            assert_size_stride_grouped((arg488_1, arg487_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf602 = reinterpret_tensor(buf599, (s16, 1, 1536), (1536, 1536, 1), 0); del buf599  # reuse
            # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_207, attn_output_107, hidden_states_211, pow_54, variance_53, rsqrt_53, hidden_states_213, hidden_states_214], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf578, buf584, buf600, arg488_1, arg487_1.item(), buf602, s16, 1536, stream=raw_stream0)
            del arg487_1
            del arg488_1
            assert_size_stride(arg489_1, (8960, 1536), (1536, 1), 'input')
            buf603 = reinterpret_tensor(buf583, (s16, 8960), (8960, 1), 0); del buf583  # reuse
            # Topologically Sorted Source Nodes: [linear_186], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf602, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg489_1, (1536, 8960), (1, 1536), 0), out=buf603)
            del arg489_1
            assert_size_stride(arg490_1, (8960, 1536), (1536, 1), 'input')
            buf604 = buf582; del buf582  # reuse
            # Topologically Sorted Source Nodes: [linear_187], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf602, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg490_1, (1536, 8960), (1, 1536), 0), out=buf604)
            del arg490_1
            buf605 = reinterpret_tensor(buf603, (s16, 1, 8960), (8960, 8960, 1), 0); del buf603  # reuse
            # Topologically Sorted Source Nodes: [linear_186, silu_26, linear_187, mul_244], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf605, buf604, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            assert_size_stride(arg491_1, (1536, 8960), (8960, 1), 'input')
            buf606 = reinterpret_tensor(buf602, (s16, 1536), (1536, 1), 0); del buf602  # reuse
            # Topologically Sorted Source Nodes: [linear_186, silu_26, linear_187, mul_244, down_proj_26], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf605, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg491_1, (8960, 1536), (1, 8960), 0), out=buf606)
            del arg491_1
            assert_size_stride_grouped((arg493_1, arg492_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf608 = reinterpret_tensor(buf587, (s16, 1, 1536), (1536, 1536, 1), 0); del buf587  # reuse
            # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_207, attn_output_107, hidden_states_211, down_proj_26, hidden_states_215, pow_55, variance_54, rsqrt_54, hidden_states_217, hidden_states_218], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf578, buf584, buf600, buf606, arg493_1, arg492_1.item(), buf608, s16, 1536, stream=raw_stream0)
            del arg492_1
            del arg493_1
            assert_size_stride_grouped((arg495_1, arg494_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf609 = buf555; del buf555  # reuse
            # Topologically Sorted Source Nodes: [linear_189], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg495_1, reinterpret_tensor(buf608, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg494_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf609)
            del arg494_1
            del arg495_1
            assert_size_stride_grouped((arg497_1, arg496_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf610 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_190], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg497_1, reinterpret_tensor(buf608, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg496_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf610)
            del arg496_1
            del arg497_1
            buf611 = empty_strided_cuda((s16, 2, 1, 128), (256, 128, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_30, sin_30, linear_190, view_82, key_states_27, mul_249, x2_55, neg_55, x1_55, cat_164, mul_250, k_embed_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(buf610, arg4_1, arg3_1, arg5_1.item(), buf611, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            assert_size_stride_grouped((arg499_1, arg498_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf612 = buf610; del buf610  # reuse
            # Topologically Sorted Source Nodes: [linear_191], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg499_1, reinterpret_tensor(buf608, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg498_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf612)
            del arg498_1
            del arg499_1
            buf613 = reinterpret_tensor(buf608, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf608  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_189, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, linear_191, view_83, value_states_27, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2.run(buf609, arg4_1, arg3_1, arg5_1.item(), buf613, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del arg3_1
            del arg4_1
            del arg5_1
            del buf609
            assert_size_stride(arg502_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg502_1 = copy_if_misaligned(arg502_1)
            buf614 = buf593; del buf593  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_189, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, linear_191, view_83, value_states_27, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg502_1, buf611, buf614, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg502_1
            assert_size_stride(arg503_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg503_1 = copy_if_misaligned(arg503_1)
            buf615 = buf592; del buf592  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_189, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, linear_191, view_83, value_states_27, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 256*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(arg503_1, buf612, buf615, ps0, s91, ps1, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg503_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_189, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, linear_191, view_83, value_states_27, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf616 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf613, buf614, buf615, None, False, scale=0.08838834764831845)
            del buf614
            del buf615
            buf617 = buf616[0]
            assert_tensor_metadata(buf617, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf617, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf616
            buf621 = buf613; del buf613  # reuse
            # Topologically Sorted Source Nodes: [attn_output_108], Original ATen: [aten.clone]
            triton_poi_fused_clone_4_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_4.run(buf617, buf621, triton_poi_fused_clone_4_xnumel, stream=raw_stream0)
            assert_size_stride(arg504_1, (1536, 1536), (1536, 1), 'input')
            buf622 = reinterpret_tensor(buf617, (s16, 1536), (1536, 1), 0); del buf617  # reuse
            # Topologically Sorted Source Nodes: [attn_output_108, transpose_112, reshape_83, attn_output_111], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf621, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg504_1, (1536, 1536), (1, 1536), 0), out=buf622)
            del arg504_1
            assert_size_stride_grouped((arg506_1, arg505_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf623 = buf578; del buf578  # reuse
            buf625 = reinterpret_tensor(buf621, (s16, 1, 1536), (1536, 1536, 1), 0); del buf621  # reuse
            # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_207, attn_output_107, hidden_states_211, down_proj_26, hidden_states_215, attn_output_111, hidden_states_219, pow_56, variance_55, rsqrt_55, hidden_states_221, hidden_states_222], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf623, buf584, buf600, buf606, buf622, arg506_1, arg505_1.item(), buf625, s16, 1536, stream=raw_stream0)
            del arg505_1
            del arg506_1
            del buf584
            del buf600
            del buf606
            del buf622
            assert_size_stride(arg507_1, (8960, 1536), (1536, 1), 'input')
            buf626 = reinterpret_tensor(buf605, (s16, 8960), (8960, 1), 0); del buf605  # reuse
            # Topologically Sorted Source Nodes: [pow_56, variance_55, rsqrt_55, hidden_states_221, hidden_states_222, linear_193], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf625, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg507_1, (1536, 8960), (1, 1536), 0), out=buf626)
            del arg507_1
            assert_size_stride(arg508_1, (8960, 1536), (1536, 1), 'input')
            buf627 = buf604; del buf604  # reuse
            # Topologically Sorted Source Nodes: [linear_194], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf625, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg508_1, (1536, 8960), (1, 1536), 0), out=buf627)
            del arg508_1
            buf628 = reinterpret_tensor(buf626, (s16, 1, 8960), (8960, 8960, 1), 0); del buf626  # reuse
            # Topologically Sorted Source Nodes: [linear_193, silu_27, linear_194, mul_253], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_6_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_6.run(buf628, buf627, triton_poi_fused__unsafe_view_mul_silu_6_xnumel, stream=raw_stream0)
            del buf627
            assert_size_stride(arg509_1, (1536, 8960), (8960, 1), 'input')
            buf629 = reinterpret_tensor(buf625, (s16, 1536), (1536, 1), 0); del buf625  # reuse
            # Topologically Sorted Source Nodes: [linear_193, silu_27, linear_194, mul_253, down_proj_27], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf628, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg509_1, (8960, 1536), (1, 8960), 0), out=buf629)
            del arg509_1
            del buf628
            assert_size_stride(arg510_1, (1536, ), (1, ), 'input')
            buf631 = reinterpret_tensor(buf623, (s16, 1, 1536), (1536, 1536, 1), 0); del buf623  # reuse
            # Topologically Sorted Source Nodes: [down_proj_27, hidden_states_223, pow_57, variance_56, add_168, rsqrt_56, hidden_states_225, hidden_states_226], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15.run(buf631, buf629, arg510_1, s16, 1536, stream=raw_stream0)
            del arg510_1
            del buf629
            buf632 = empty_strided_cuda((s16, 152265), (152265, 1), torch.float32)
            # Topologically Sorted Source Nodes: [down_proj_27, hidden_states_223, pow_57, variance_56, add_168, rsqrt_56, hidden_states_225, hidden_states_226, getitem_1880, logits], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.slice, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf631, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg2_1, (1536, 152265), (1, 1536), 0), out=buf632)
            del arg2_1
            del buf631
        return (reinterpret_tensor(buf5, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf4, reinterpret_tensor(buf27, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf26, reinterpret_tensor(buf50, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf49, reinterpret_tensor(buf72, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf71, reinterpret_tensor(buf95, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf94, reinterpret_tensor(buf117, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf116, reinterpret_tensor(buf140, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf139, reinterpret_tensor(buf162, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf161, reinterpret_tensor(buf185, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf184, reinterpret_tensor(buf207, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf206, reinterpret_tensor(buf230, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf229, reinterpret_tensor(buf252, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf251, reinterpret_tensor(buf275, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf274, reinterpret_tensor(buf297, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf296, reinterpret_tensor(buf320, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf319, reinterpret_tensor(buf342, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf341, reinterpret_tensor(buf365, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf364, reinterpret_tensor(buf387, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf386, reinterpret_tensor(buf410, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf409, reinterpret_tensor(buf432, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf431, reinterpret_tensor(buf455, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf454, reinterpret_tensor(buf477, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf476, reinterpret_tensor(buf500, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf499, reinterpret_tensor(buf522, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf521, reinterpret_tensor(buf545, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf544, reinterpret_tensor(buf567, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf566, reinterpret_tensor(buf590, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf589, reinterpret_tensor(buf612, (s16, 2, 1, 128), (256, 128, 256, 1), 0), buf611, reinterpret_tensor(buf632, (s16, 1, 152265), (152265, 152265, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = 50
    arg1_1 = rand_strided((50, 1), (1, 1), device='cuda:0', dtype=torch.int64)
    arg2_1 = rand_strided((152265, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg3_1 = rand_strided((50, 1), (1, 1), device='cuda:0', dtype=torch.int64)
    arg4_1 = rand_strided((64, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg5_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg6_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg7_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg8_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg9_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg10_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg11_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg12_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg13_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg14_1 = 50
    arg15_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg16_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg17_1 = 76
    arg18_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg19_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg20_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg21_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg22_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg23_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg24_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg25_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg26_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg27_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg28_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg29_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg30_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg31_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg32_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg33_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg34_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg35_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg36_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg37_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg38_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg39_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg40_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg41_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg42_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg43_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg44_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg45_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg46_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg47_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg48_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg49_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg50_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg51_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg52_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg53_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg54_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg55_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg56_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg57_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg58_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg59_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg60_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg61_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg62_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg63_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg64_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg65_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg66_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg67_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg68_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg69_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg70_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg71_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg72_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg73_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg74_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg75_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg76_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg77_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg78_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg79_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg80_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg81_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg82_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg83_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg84_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg85_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg86_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg87_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg88_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg89_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg90_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg91_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg92_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg93_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg94_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg95_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg96_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg97_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg98_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg99_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg100_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg101_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg102_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg103_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg104_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg105_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg106_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg107_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg108_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg109_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg110_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg111_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg112_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg113_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg114_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg115_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg116_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg117_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg118_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg119_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg120_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg121_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg122_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg123_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg124_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg125_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg126_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg127_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg128_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg129_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg130_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg131_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg132_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg133_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg134_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg135_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg136_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg137_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg138_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg139_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg140_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg141_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg142_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg143_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg144_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg145_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg146_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg147_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg148_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg149_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg150_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg151_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg152_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg153_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg154_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg155_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg156_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg157_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg158_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg159_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg160_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg161_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg162_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg163_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg164_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg165_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg166_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg167_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg168_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg169_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg170_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg171_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg172_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg173_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg174_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg175_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg176_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg177_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg178_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg179_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg180_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg181_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg182_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg183_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg184_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg185_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg186_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg187_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg188_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg189_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg190_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg191_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg192_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg193_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg194_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg195_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg196_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg197_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg198_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg199_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg200_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg201_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg202_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg203_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg204_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg205_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg206_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg207_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg208_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg209_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg210_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg211_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg212_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg213_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg214_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg215_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg216_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg217_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg218_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg219_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg220_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg221_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg222_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg223_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg224_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg225_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg226_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg227_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg228_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg229_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg230_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg231_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg232_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg233_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg234_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg235_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg236_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg237_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg238_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg239_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg240_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg241_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg242_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg243_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg244_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg245_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg246_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg247_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg248_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg249_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg250_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg251_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg252_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg253_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg254_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg255_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg256_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg257_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg258_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg259_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg260_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg261_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg262_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg263_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg264_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg265_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg266_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg267_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg268_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg269_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg270_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg271_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg272_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg273_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg274_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg275_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg276_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg277_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg278_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg279_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg280_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg281_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg282_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg283_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg284_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg285_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg286_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg287_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg288_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg289_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg290_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg291_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg292_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg293_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg294_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg295_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg296_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg297_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg298_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg299_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg300_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg301_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg302_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg303_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg304_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg305_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg306_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg307_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg308_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg309_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg310_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg311_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg312_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg313_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg314_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg315_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg316_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg317_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg318_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg319_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg320_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg321_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg322_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg323_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg324_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg325_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg326_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg327_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg328_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg329_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg330_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg331_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg332_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg333_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg334_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg335_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg336_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg337_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg338_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg339_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg340_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg341_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg342_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg343_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg344_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg345_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg346_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg347_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg348_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg349_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg350_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg351_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg352_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg353_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg354_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg355_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg356_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg357_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg358_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg359_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg360_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg361_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg362_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg363_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg364_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg365_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg366_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg367_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg368_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg369_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg370_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg371_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg372_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg373_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg374_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg375_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg376_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg377_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg378_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg379_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg380_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg381_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg382_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg383_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg384_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg385_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg386_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg387_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg388_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg389_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg390_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg391_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg392_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg393_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg394_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg395_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg396_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg397_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg398_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg399_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg400_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg401_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg402_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg403_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg404_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg405_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg406_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg407_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg408_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg409_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg410_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg411_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg412_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg413_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg414_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg415_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg416_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg417_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg418_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg419_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg420_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg421_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg422_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg423_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg424_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg425_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg426_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg427_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg428_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg429_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg430_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg431_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg432_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg433_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg434_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg435_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg436_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg437_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg438_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg439_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg440_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg441_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg442_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg443_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg444_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg445_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg446_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg447_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg448_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg449_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg450_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg451_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg452_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg453_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg454_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg455_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg456_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg457_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg458_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg459_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg460_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg461_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg462_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg463_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg464_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg465_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg466_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg467_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg468_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg469_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg470_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg471_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg472_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg473_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg474_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg475_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg476_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg477_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg478_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg479_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg480_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg481_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg482_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg483_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg484_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg485_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg486_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg487_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg488_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg489_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg490_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg491_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg492_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg493_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg494_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg495_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg496_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg497_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg498_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg499_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg500_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg501_1 = rand_strided((50, 2, 0, 128), (256, 128, 128, 1), device='cuda:0', dtype=torch.float32)
    arg502_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg503_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg504_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg505_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg506_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg507_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg508_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg509_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg510_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg511_1 = 1
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1, arg458_1, arg459_1, arg460_1, arg461_1, arg462_1, arg463_1, arg464_1, arg465_1, arg466_1, arg467_1, arg468_1, arg469_1, arg470_1, arg471_1, arg472_1, arg473_1, arg474_1, arg475_1, arg476_1, arg477_1, arg478_1, arg479_1, arg480_1, arg481_1, arg482_1, arg483_1, arg484_1, arg485_1, arg486_1, arg487_1, arg488_1, arg489_1, arg490_1, arg491_1, arg492_1, arg493_1, arg494_1, arg495_1, arg496_1, arg497_1, arg498_1, arg499_1, arg500_1, arg501_1, arg502_1, arg503_1, arg504_1, arg505_1, arg506_1, arg507_1, arg508_1, arg509_1, arg510_1, arg511_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
