"""Publish completed native FP32 backend evidence without discarding failed bits.

Preparation utility: a completed run, immutable raw manifest and independent
review are required. This does not modify measured source or grant promotion.
"""
import argparse
import csv
import gzip
import hashlib
import io
import json
import math
from pathlib import Path
import statistics
import tarfile
import tempfile

BACKENDS = ('default', 'cublas', 'cublaslt')
CASES = [(u, layer, role) for u in (1, 2, 6, 10)
         for layer in (0, 13, 27) for role in ('gate', 'up', 'down')]


def read(path):
    return json.loads(Path(path).read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def summary(audit):
    assert audit['integrity_audit_passed'] is True
    rows = audit['comparisons']
    expected = set()
    for u, layer, role in CASES:
        for backend in BACKENDS:
            for state in ('original', 'changed', 'restored'):
                for category in ('direct_repeat', 'graph', 'graph_repeat', 'retained_after_other_roles'):
                    expected.add((u, layer, role, backend, state, category))
            for category in ('restored_input', 'after_timing'):
                expected.add((u, layer, role, backend, None, category))
        for backend in ('cublas', 'cublaslt'):
            for state in ('original', 'changed', 'restored'):
                expected.add((u, layer, role, backend, state, 'versus_default'))
    keys = [(r['cohort_index'], r['layer'], r['role'], r['backend'],
             r.get('state'), r['category']) for r in rows]
    assert len(keys) == len(set(keys)) == 1728 and set(keys) == expected
    for r in rows:
        assert r['values'] == (50 * (1536 if r['role'] == 'down' else 8960))
        assert 0 <= r['matching_bits'] <= r['values']
        assert math.isfinite(r['max_abs_finite']) and r['max_abs_finite'] >= 0
        assert all(0 <= r[k] <= r['values'] for k in ('nonfinite_left', 'nonfinite_right'))
    def exact(selected):
        return all(r['matching_bits'] == r['values'] and
                   r['nonfinite_left'] == r['nonfinite_right'] == 0 for r in selected)
    assert audit['candidate_exact'] == exact(rows)
    assert audit['control_exact'] == exact(r for r in rows if r['backend'] != 'cublaslt')
    assert audit['stability_exact'] == exact(r for r in rows if r['category'] != 'versus_default')
    aggregates = {}
    for category in sorted({r['category'] for r in rows}):
        group = [r for r in rows if r['category'] == category]
        aggregates[category] = dict(observations=len(group), values=sum(r['values'] for r in group),
            matching_bits=sum(r['matching_bits'] for r in group),
            max_abs_finite=max(r['max_abs_finite'] for r in group))
    assert aggregates == audit['counts_by_category']
    timing = audit['timing_cases']
    table = {(r['cohort_index'], r['layer'], r['role'], r['backend']): r for r in timing}
    assert len(timing) == len(table) == 108
    assert set(table) == {(u, layer, role, backend) for u, layer, role in CASES for backend in BACKENDS}
    for r in timing:
        v = r['samples_us']
        assert len(v) == 8 and all(math.isfinite(x) and x > 0 for x in v)
        assert r['median_us'] == statistics.median(v)
        assert r['p95_us'] == statistics.quantiles(v, n=100, method='inclusive')[94]
        assert r['min_us'] == min(v) and r['max_us'] == max(v)
    for field, metric in (('candidate_faster_median_cases', 'median_us'), ('candidate_faster_p95_cases', 'p95_us')):
        assert audit[field] == sum(table[u,l,r,'cublaslt'][metric] < table[u,l,r,'default'][metric] for u,l,r in CASES)
    dispatch = audit['dispatch']
    assert len(dispatch) == 36
    assert {(r['cohort_index'],r['layer'],r['backend']) for r in dispatch} == {
        (u,l,b) for u,l,_ in CASES for b in BACKENDS}
    assert audit['dispatch_verified'] == all(r['verified'] for r in dispatch)
    assert audit['projection_cases'] == 36 and audit['end_to_end_promotion'] is False
    # Keep every audit field and negative finding. Counts include repeated
    # observations; they are not independent users or generation score counts.
    return dict(audit, experiment='native-fp32-backend-diagnostic',
        timing_boundary='CUDA-event averages of 32 frozen graph replays; eight rounds. Excludes staging, backend selection, setup/capture, profiler/logging and extraction. Not generation-call latency.',
        ranking_quality_measured=False, generation_latency_measured=False)


def add_tree(entries, root, prefix):
    assert root.is_dir()
    for p in sorted(root.rglob('*')):
        assert not p.is_symlink(), p
        if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc':
            name = prefix + '/' + p.relative_to(root).as_posix()
            assert name not in entries
            entries[name] = p.read_bytes()


def archive_bytes(entries):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in sorted(entries.items()):
                assert not Path(name).is_absolute() and '..' not in Path(name).parts
                item = tarfile.TarInfo(name)
                item.size = len(data); item.mode = 0o444; item.mtime = 0
                archive.addfile(item, io.BytesIO(data))
    return output.getvalue()


def write_shards(root, entries, limit=48*1024*1024):
    """Split by complete members; never omit a large or failed raw output."""
    pending = [dict(sorted(entries.items()))]; shards = []; members = {}
    while pending:
        group = pending.pop(0)
        encoded = archive_bytes(group)
        if len(encoded) >= limit:
            assert len(group) > 1, 'Single member exceeds archive limit; preserve it and review separate chunking'
            keys = list(group); middle = len(keys)//2
            pending[0:0] = [{k: group[k] for k in keys[:middle]}, {k: group[k] for k in keys[middle:]}]
            continue
        name = f'evidence-{len(shards)+1:03d}.tar.gz'
        (root/name).write_bytes(encoded)
        shards.append(dict(path=name, bytes=len(encoded), sha256=sha(encoded), files=len(group)))
        for key, data in group.items():
            members[key] = dict(bytes=len(data), sha256=sha(data), archive=name)
    assert set(members) == set(entries)
    return dict(archives=shards, files=members)


def write_csv(path, rows):
    fields = sorted({k for row in rows for k in row})
    with path.open('w') as f:
        writer = csv.DictWriter(f, fieldnames=fields, lineterminator='\n')
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, separators=(',', ':')) if isinstance(v, (dict,list)) else v for k,v in row.items()})


def export(status_path, audit_path, destination):
    status = read(status_path); audit = read(audit_path)
    assert status['scheduler_state'] == 'COMPLETED', 'Execution failures require a failure-specific report'
    assert not destination.exists(), 'Preserve previous evidence'
    result = summary(audit)
    harness = Path(status['harness']); run = status['run_id']
    raw = harness/'.oscar/results'/run; snapshot = Path(status['source_snapshot'])
    record_path = harness/'.oscar/runs'/(run+'.json'); record = read(record_path)
    assert record['run_id'] == run and record['job_id'] == status['job_id']
    assert record['resources'] == status['resources']
    assert read(raw/'source-manifest.json')['sha256'] == record['sha256']
    assert (raw/'job-id').read_text().strip() == record['job_id']
    assert audit['snapshot_files_verified'] == len(record['sha256']) == len(record['files'])
    for name, expected in record['sha256'].items():
        assert sha((snapshot/name).read_bytes()) == expected, name
    assert Path(status['audit_cwd']) == snapshot
    assert sha((snapshot/'rapidtinyrec/audit_fp32_backend.py').read_bytes()) == audit['audit_source_sha256']
    assert read(snapshot/'source-provenance.json')['source_commit'] == status['source_commit']
    review = read(status['independent_review'])
    assert review['run_id'] == run and review['audit_sha256'] == sha(audit_path.read_bytes())
    assert review['end_to_end_promotion'] is False
    result.update(decision=review['decision'], diagnostic_gate=review['diagnostic_gate'])
    assert not result['diagnostic_gate'] or all(audit[k] for k in ('candidate_exact','control_exact','stability_exact','dispatch_verified'))
    entries = {}; add_tree(entries, raw, 'raw'); add_tree(entries, snapshot, 'source-snapshot')
    raw_manifest = read(status['raw_manifest'])
    assert raw_manifest['run_id'] == run
    expected_raw = {'raw/'+r['path']: dict(bytes=r['size'],sha256=r['sha256']) for r in raw_manifest['files']}
    actual_raw = {n: dict(bytes=len(v),sha256=sha(v)) for n,v in entries.items() if n.startswith('raw/')}
    assert expected_raw == actual_raw
    entries.update({'run-record.json': record_path.read_bytes(), 'status.json': status_path.read_bytes(),
                    'audit.json': audit_path.read_bytes(), 'export_fp32_backend.py': Path(__file__).read_bytes()})
    for field in ('independent_review','raw_manifest','audit_stdout','audit_stderr','ci_log'):
        p = Path(status[field]); entries['review/'+p.name] = p.read_bytes()
    if 'independent_review_script' in status:
        review_script = Path(status['independent_review_script'])
        entries['review/'+review_script.name] = review_script.read_bytes()
    submitter = Path(status['submission_script'])
    entries[submitter.name] = submitter.read_bytes()
    entries['test_fp32_backend_export.py'] = Path(__file__).with_name('test_fp32_backend_export.py').read_bytes()
    if 'prior_failure_status' in status:
        prior_path = Path(status['prior_failure_status']); prior = read(prior_path)
        entries['prior-startup-failure/status.json'] = prior_path.read_bytes()
        add_tree(entries, Path(prior['failure_evidence']), 'prior-startup-failure/published')
        proof_path = Path(status['build_identity_proof'])
        assert sha(proof_path.read_bytes()) == status['build_identity_proof_sha256']
        add_tree(entries, proof_path.parent, 'build-identity')
    entries['reproduce.json'] = json.dumps(dict(audit_command=status['audit_command'],audit_cwd=status['audit_cwd'],
        reproduction='Extract all evidence shards into one directory. From source-snapshot, run python3 -m rapidtinyrec.audit_fp32_backend ../raw/outputs/diagnosis --snapshot . --run-record ../run-record.json --output ../reproduced-audit.json. Keep failures; relocate saved original absolute paths explicitly.'),indent=2).encode()
    destination.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=destination.parent,prefix='.fp32-evidence-') as temporary:
        staged = Path(temporary)/'result'; staged.mkdir()
        for filename,field in (('comparisons.csv','comparisons'),('timing.csv','timing_cases'),('dispatch.csv','dispatch')):
            write_csv(staged/filename,audit[field])
        (staged/'summary.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
        (staged/'audit.json').write_bytes(audit_path.read_bytes())
        manifest = write_shards(staged,entries)
        (staged/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
        source = dict(run_id=run,job_id=status['job_id'],measured_repository_commit=status['source_commit'],
            submitted_source_sha256=record['sha256'],resources=record['resources'],
            evidence_sha256={p.name:sha(p.read_bytes()) for p in staged.iterdir()})
        (staged/'source.json').write_text(json.dumps(source,indent=2)+'\n')
        staged.rename(destination)
    return dict(destination=str(destination),archive_files=len(entries),shards=len(manifest['archives']),
                candidate_exact=audit['candidate_exact'],diagnostic_gate=result['diagnostic_gate'])


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--status',type=Path,required=True)
    ap.add_argument('--audit',type=Path,required=True)
    ap.add_argument('--destination',type=Path,required=True)
    args = ap.parse_args()
    print(json.dumps(export(args.status,args.audit,args.destination),indent=2))


if __name__ == '__main__':
    main()
