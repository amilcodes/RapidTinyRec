import copy
import io
import json
from pathlib import Path
import random
import statistics
import tarfile
import tempfile
import unittest

import export_fp32_backend as export


def fixture():
    rows = []
    for u,l,role in export.CASES:
        def row(backend, category, state=None):
            values = 50*(1536 if role == 'down' else 8960)
            item = dict(cohort_index=u,layer=l,role=role,backend=backend,category=category,
                values=values,matching_bits=values,max_abs_finite=0.,nonfinite_left=0,nonfinite_right=0)
            if state is not None: item['state'] = state
            rows.append(item)
        for backend in export.BACKENDS:
            for state in ('original','changed','restored'):
                for category in ('direct_repeat','graph','graph_repeat','retained_after_other_roles'):
                    row(backend,category,state)
            for category in ('restored_input','after_timing'):row(backend,category)
        for backend in ('cublas','cublaslt'):
            for state in ('original','changed','restored'):row(backend,'versus_default',state)
    timing = []
    for u,l,r in export.CASES:
        for b in export.BACKENDS:
            v = [10. if b == 'cublaslt' else 12.]*8
            timing.append(dict(cohort_index=u,layer=l,role=r,backend=b,samples_us=v,
                median_us=statistics.median(v),p95_us=statistics.quantiles(v,n=100,method='inclusive')[94],min_us=min(v),max_us=max(v)))
    audit = dict(integrity_audit_passed=True,comparisons=rows,timing_cases=timing,
        dispatch=[dict(cohort_index=u,layer=l,backend=b,verified=True) for u in (1,2,6,10) for l in (0,13,27) for b in export.BACKENDS],
        candidate_faster_median_cases=36,candidate_faster_p95_cases=36,projection_cases=36,
        dispatch_verified=True,end_to_end_promotion=False)
    recompute(audit)
    return audit


def recompute(a):
    rows = a['comparisons'];a['counts_by_category'] = {}
    for category in {r['category'] for r in rows}:
        group = [r for r in rows if r['category'] == category]
        a['counts_by_category'][category] = dict(observations=len(group),values=sum(r['values'] for r in group),
            matching_bits=sum(r['matching_bits'] for r in group),max_abs_finite=max(r['max_abs_finite'] for r in group))
    def exact(rs):return all(r['matching_bits']==r['values'] and r['nonfinite_left']==r['nonfinite_right']==0 for r in rs)
    a['candidate_exact'] = exact(rows)
    a['control_exact'] = exact(r for r in rows if r['backend']!='cublaslt')
    a['stability_exact'] = exact(r for r in rows if r['category']!='versus_default')


class ExportTests(unittest.TestCase):
    def test_complete_audit_retained_without_generation_claim(self):
        a = fixture();s = export.summary(a)
        self.assertEqual(len(s['comparisons']),1728)
        for k,v in a.items():self.assertEqual(s[k],v)
        self.assertFalse(s['generation_latency_measured'])
        self.assertFalse(s['ranking_quality_measured'])
        self.assertFalse(s['end_to_end_promotion'])

    def test_negative_candidate_and_control_counts_are_preserved(self):
        for backend in ('cublaslt','cublas'):
            a = fixture();r = next(r for r in a['comparisons'] if r['backend']==backend and r['category']=='graph')
            r['matching_bits']-=1;r['max_abs_finite']=1e-6;recompute(a)
            s = export.summary(a)
            self.assertFalse(s['candidate_exact']);self.assertFalse(s['stability_exact'])
            self.assertEqual(s['control_exact'],backend=='cublaslt')
            self.assertEqual(s['counts_by_category'],a['counts_by_category'])
            a['candidate_exact']=True
            with self.assertRaises(AssertionError):export.summary(a)

    def test_incomplete_or_inflated_evidence_rejected(self):
        for change in ('missing','duplicate','timing','count','dispatch'):
            a = fixture()
            if change=='missing':a['comparisons'].pop()
            if change=='duplicate':a['comparisons'][0]=copy.deepcopy(a['comparisons'][1])
            if change=='timing':a['timing_cases'][0]['samples_us'].pop()
            if change=='count':a['candidate_faster_median_cases']=35
            if change=='dispatch':a['dispatch'][0]['verified']=False
            with self.assertRaises(AssertionError):export.summary(a)

    def test_shards_roundtrip_keep_all_members_and_hashes(self):
        rng = random.Random(1);entries = {f'raw/tensor-{i}':rng.randbytes(600) for i in range(10)}
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);manifest=export.write_shards(root,entries,limit=2048);decoded={}
            self.assertGreater(len(manifest['archives']),1)
            for shard in manifest['archives']:
                data=(root/shard['path']).read_bytes();self.assertLess(len(data),2048)
                self.assertEqual(export.sha(data),shard['sha256'])
                with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
                    for m in archive.getmembers():
                        value=archive.extractfile(m).read();decoded[m.name]=value
                        self.assertEqual(export.sha(value),manifest['files'][m.name]['sha256'])
            self.assertEqual(decoded,entries)
            with self.assertRaises(AssertionError):export.write_shards(root,{'raw/large':rng.randbytes(4096)},limit=2048)

    def test_unfinished_run_cannot_publish(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);s=root/'status.json';a=root/'audit.json'
            s.write_text(json.dumps(dict(scheduler_state='PENDING')));a.write_text('{}')
            with self.assertRaises(AssertionError):export.export(s,a,root/'published')
            self.assertFalse((root/'published').exists())


if __name__ == '__main__':unittest.main()
