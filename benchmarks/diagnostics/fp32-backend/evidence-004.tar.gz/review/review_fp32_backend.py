"""Independent post-run review: raw bytes, API records and role-level outcomes."""
import gzip, hashlib, json, re, statistics, struct
from pathlib import Path
BASE=Path('/Users/AmilAgrawal/Documents/Codex/2026-10-18/let')
status_path=BASE/'outputs/rapidtinyrec_fp32_backend_status.json'
s=json.loads(status_path.read_text()); audit_path=Path(s['audit_result']);a=json.loads(audit_path.read_text())
raw=Path(s['harness'])/'.oscar/results'/s['run_id'];root=raw/'outputs/diagnosis';d=json.loads((root/'diagnosis.json').read_text())
sha=lambda x:hashlib.sha256(x).hexdigest()
m=json.loads(Path(s['raw_manifest']).read_text())
assert len(m['files'])==246
for f in m['files']:
 data=(raw/f['path']).read_bytes();assert len(data)==f['size'] and sha(data)==f['sha256']
record=json.loads((Path(s['harness'])/'.oscar/runs'/(s['run_id']+'.json')).read_text())
assert json.loads((raw/'source-manifest.json').read_text())['sha256']==record['sha256']
assert (raw/'job-id').read_text().strip()==s['job_id']==d['job_id']
assert '#SBATCH --cpus-per-task=4' in (raw/'job.sh').read_text()
assert record['resources']==s['resources']
assert a['integrity_audit_passed'] and a['control_exact'] and a['stability_exact'] and a['dispatch_verified'] and not a['candidate_exact']
assert d['complete'] and len(d['cases'])==12 and d['torch_git_version']=='08187d9e0fba026dc8217405802ab5381dc88d90'
blobs={}
for digest,v in d['tensors'].items():
 c=(root/v['file']).read_bytes();assert sha(c)==v['compressed_sha256'];b=gzip.decompress(c);assert sha(b)==digest and len(b)==v['bytes'];blobs[digest]=b
rows=[];dispatch=[];stats={}
for c in d['cases']:
 assert c['staging_storage_disjoint'] and len(set(c['staging_ptrs']))==3
 assert c['unique_input_output_bytes']==14080000 and c['graph_count']==9 and c['timed_graph_replays']==2304
 assert c['measured_captures']==c['measured_compilations']==0
 for backend,v in c['variants'].items():
  classic_path=root/v['logs']['cublas'];classic=classic_path.read_text() if classic_path.exists() else '';lt=(root/v['logs']['cublaslt']).read_text()
  api=re.findall(r'\[Api\]\[cublasLtMatmul\]',lt)
  if backend=='cublaslt': assert len(api)==3 and 'cublasSgemm' not in classic
  else: assert classic.count('function cublasStatus_t cublasSgemm_v2(')==3 and not api
  trace_lines=[l for l in lt.splitlines() if '[Trace]' in l and 'algo=[' in l]
  assert len(trace_lines)==3 and all('computeType=COMPUTE_32F ' in l for l in trace_lines)
  configs=[re.search(r'algo=\[([^]]+)\]',l).group(1) for l in trace_lines]
  assert all('tile=MATMUL_TILE_128x64' in x and 'numSplitsK=3 ' in x for x in configs[:2])
  assert ('numSplitsK=12 ' if backend=='cublaslt' else 'numSplitsK=16 ') in configs[2]
  dispatch.append(dict(cohort_index=c['cohort_index'],layer=c['layer'],backend=backend,api_calls=3,role_algorithms=dict(zip(['gate','up','down'],configs))))
  for state,detail in v['states'].items():
   for role,refs in detail['roles'].items():
    direct=blobs[refs['direct']['sha256']]
    assert all(blobs[x['sha256']]==direct for x in refs.values())
    base=c['variants']['default']['states'][state]['roles'][role]['direct'];other=blobs[base['sha256']]
    if direct==other: matching=len(direct)//4;delta=0.
    else:
     matching=sum(x==y for x,y in zip(struct.iter_unpack('<I',direct),struct.iter_unpack('<I',other)))
     delta=max(abs(x[0]-y[0]) for x,y in zip(struct.iter_unpack('<f',direct),struct.iter_unpack('<f',other)))
    row=dict(cohort_index=c['cohort_index'],layer=c['layer'],backend=backend,state=state,role=role,values=len(direct)//4,matching_bits=matching,max_abs_finite=delta)
    if backend!='default':
     frozen=next(x for x in a['comparisons'] if x['category']=='versus_default' and all(x[k]==row[k] for k in ['cohort_index','layer','backend','state','role']))
     assert all(frozen[k]==row[k] for k in ['values','matching_bits','max_abs_finite'])
    rows.append(row)
for role in ['gate','up','down']:
 rs=[x for x in rows if x['role']==role and x['backend']=='cublaslt'];original=[x for x in rs if x['state']=='original']
 timing={}
 for backend in ['default','cublas','cublaslt']:
  ts=[x for x in a['timing_cases'] if x['role']==role and x['backend']==backend]
  timing[backend]=dict(median_of_case_medians_us=statistics.median(x['median_us'] for x in ts),median_of_case_p95_us=statistics.median(x['p95_us'] for x in ts),sample_min_us=min(x['min_us'] for x in ts),sample_max_us=max(x['max_us'] for x in ts))
 t={(x['cohort_index'],x['layer'],x['backend']):x for x in a['timing_cases'] if x['role']==role}
 faster={metric:sum(t[u,l,'cublaslt'][metric]<t[u,l,'default'][metric] for u in [1,2,6,10] for l in [0,13,27]) for metric in ['median_us','p95_us']}
 stats[role]=dict(values=sum(x['values'] for x in rs),matching_bits=sum(x['matching_bits'] for x in rs),original_values=sum(x['values'] for x in original),original_matching_bits=sum(x['matching_bits'] for x in original),max_abs_finite=max(x['max_abs_finite'] for x in rs),inexact_original_cases=sum(x['values']!=x['matching_bits'] for x in original),timing=timing,faster_cases=faster)
assert stats['down']['inexact_original_cases']==12 and stats['gate']['inexact_original_cases']==stats['up']['inexact_original_cases']==0
review=dict(run_id=s['run_id'],audit_sha256=sha(audit_path.read_bytes()),diagnostic_gate=False,end_to_end_promotion=False,
 decision='Reject global cuBLASLt preference: all12 original down projections change FP32 bits and are slower in median and p95. Gate/up are exact with the same observed kernel/grid and only small, inconsistent timing differences. No generation pilot/full500 or tuning sweep. Keep accepted folded baseline and reassess score-fidelity versus quality tradeoffs with the user.',
 raw_files_verified=len(m['files']),raw_bytes=sum(x['size'] for x in m['files']),raw_tensor_objects_verified=len(blobs),roles=stats,dispatch=dispatch,
 precision=d['runtime_precision'],model_parameter_logical_bytes=d['model_parameter_logical_bytes'],model_parameter_unique_bytes=d['model_parameter_unique_bytes'],minimum_probe_input_output_bytes_per_case=14080000,
 memory_after_collection=d['memory_after_collection'],case_setup_seconds=[c['setup_s'] for c in d['cases']],case_memory=[dict(cohort_index=c['cohort_index'],layer=c['layer'],before_timing=c['before_timing_memory'],timing=c['timing_memory']) for c in d['cases']],
 model_load_s=d['model_load_s'],activation_collection_s=d['setup']['activation_collection_s'],total_wall_s=d['total_wall_s'],
 limitations=['Fixed eager-collected inputs, not saved compiled intermediates. No generation latency/ranks/SID quality measured.','Timing is eight CUDA-event averages of32 frozen replays, excludes staging and instrumentation. No cross-run compounded speedup.','Native workspace preferences differ: cuBLAS8519680 versus Lt1048576 bytes; no workspace was tuned. Logs show internal Lt machinery even through cublasSgemm.','Allocation prolog prints CPUs1 while frozen SBATCH requests cpus-per-task4; preserve both; no CPU throughput inference.'])
p=BASE/'outputs/rapidtinyrec_fp32_backend_retry1_independent_review.json';p.write_text(json.dumps(review,indent=2)+'\n')
s.update(status='REJECTED_EXACTNESS_AUDITED',integrity_audit_passed=True,control_exact=True,candidate_exact=False,stability_exact=True,dispatch_verified=True,diagnostic_gate=False,end_to_end_promotion=False,independent_review=str(p),independent_review_script=str(Path(__file__).resolve()),decision=review['decision'])
status_path.write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps(dict(roles=stats,decision=review['decision']),indent=2))
