# AOT ID: ['8_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
from torch._inductor.runtime.runtime_utils import assert_tensor_metadata

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/ck/cckvoeogtkik3fvabh6wpahgnd7vvfo7wgbirhk4tknbhnscvv2v.py
# Topologically Sorted Source Nodes: [inputs_embeds, pow_1, variance, rsqrt, hidden_states_1, hidden_states_2], Original ATen: [aten.embedding, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   hidden_states_1 => mul_44
#   hidden_states_2 => mul_47
#   inputs_embeds => embedding
#   pow_1 => pow_1
#   rsqrt => rsqrt
#   variance => mean
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %arg7_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg7_1]
#   %buf0 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf0]
#   %arg6_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg6_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %pow_1 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%embedding, 2), kwargs = {})
#   %mean : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %convert_element_type_default_4 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg6_1, torch.float32), kwargs = {})
#   %add_tensor : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, %convert_element_type_default_4), kwargs = {})
#   %rsqrt : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor,), kwargs = {})
#   %mul_44 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%embedding, %rsqrt), kwargs = {})
#   %mul_47 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg7_1, %mul_44), kwargs = {})
#   return %buf0,%mul_47
triton_red_fused_embedding_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_red_fused_embedding_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_embedding_mean_mul_pow_rsqrt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 620544}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_embedding_mean_mul_pow_rsqrt_0(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    tmp12 = in_ptr3
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp9 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tl.full([1, 1], 1536.0, tl.float32)
        tmp11 = (tmp5 / tmp10)
        tmp13 = tmp12.to(tl.float32)
        tmp14 = tmp11 + tmp13
        tmp15 = libdevice.rsqrt(tmp14)
        tmp16 = tmp9 * tmp15
        tmp17 = tmp7 * tmp16
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp17, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/32/c32aa5q6npcd76funcayh6sijizjpdjun6cwocztm5cywngdumi6.py
# Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, sin, sin_3, linear_1, view_1, key_states, mul_6, x2_1, neg_1, x1_1, cat_2, mul_7, k_embed, cat_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
# Source node to ATen node mapping:
#   cat_2 => cat_1
#   cat_3 => cat_2
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   k_embed => add_216
#   key_states => permute_4
#   linear_1 => view_8
#   matmul => mul_14
#   mul_6 => mul_103
#   mul_7 => mul_114
#   neg_1 => neg_1
#   position_ids_expanded => convert_element_type
#   sin => sin
#   sin_3 => unsqueeze_5
#   view_1 => view_9
#   x1_1 => slice_4
#   x2_1 => slice_5
# Graph fragment:
#   %arg16_1 : Tensor "f32[s16, 2, s53, 128][256*s53, 128*s53, 128, 1]cuda:0" = PlaceHolder[target=arg16_1]
#   %addmm_1 : Tensor "f32[s16, 256][256, 1]cuda:0" = PlaceHolder[target=addmm_1]
#   %arg4_1 : Tensor "f32[64][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %arg3_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg3_1]
#   %arg5_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg5_1]
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %view_8 : Tensor "f32[s16, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_1, [%arg14_1, 1, 256]), kwargs = {})
#   %view_9 : Tensor "f32[s16, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_8, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_4 : Tensor "f32[s16, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_9, [0, 2, 1, 3]), kwargs = {})
#   %mul_103 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_4, %unsqueeze_4), kwargs = {})
#   %slice_5 : Tensor "f32[s16, 2, 1, 64][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_4, 3, 64, 9223372036854775807), kwargs = {})
#   %neg_1 : Tensor "f32[s16, 2, 1, 64][128, 64, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_5,), kwargs = {})
#   %slice_4 : Tensor "f32[s16, 2, 1, 64][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_4, 3, 0, 64), kwargs = {})
#   %cat_1 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %slice_4], -1), kwargs = {})
#   %mul_114 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %unsqueeze_5), kwargs = {})
#   %add_216 : Tensor "f32[s16, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_103, %mul_114), kwargs = {})
#   %cat_2 : Tensor "f32[s16, 2, s53 + 1, 128][256*s53 + 256, 128*s53 + 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.cat.default](args = ([%arg16_1, %add_216], -2), kwargs = {})
#   return %cat_2
triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1 = async_compile.triton('triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 65536}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*i64', 'in_ptr4': 'fp64', 'out_ptr0': '*fp32', 'ks0': 'i64', 'ks1': 'i64', 'ks2': 'i64', 'ks3': 'i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 563856}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr0, ks0, ks1, ks2, ks3, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = ((xindex // 128) % ks0)
    x0 = (xindex % 128)
    x4 = xindex // ks2
    x5 = xindex
    x3 = xindex // ks3
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x1).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = (ks1).to(tl.int64)
    tmp6 = (tmp5).to(tl.int64)
    tmp7 = tmp4 < tmp6
    tmp8 = tl.load(in_ptr0 + (x0 + 128*(x1) + 128*ks1*x4), tmp7 & xmask, eviction_policy='evict_last', other=0.0)
    tmp9 = (ks1).to(tl.int32)
    tmp10 = tmp0 >= tmp9
    tmp11 = (ks0).to(tl.int32)
    tmp12 = tmp0 < tmp11
    tmp13 = tl.load(in_ptr1 + (x0 + 128*x4), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp14 = tl.load(in_ptr2 + ((x5 % 64)), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp15 = tl.load(in_ptr3 + (x3), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp16 = tmp15.to(tl.float32)
    tmp17 = tmp14 * tmp16
    tmp18 = tl_math.cos(tmp17)
    tmp19 = in_ptr4
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp18 * tmp20
    tmp22 = tmp13 * tmp21
    tmp23 = (x0).to(tl.int32)
    tmp24 = tl.full([1], 0, tl.int64)
    tmp25 = tmp23 >= tmp24
    tmp26 = (x0).to(tl.int64)
    tmp27 = (tmp26).to(tl.int64)
    tmp28 = tl.full([1], 64, tl.int64)
    tmp29 = tmp27 < tmp28
    tmp30 = tmp29 & tmp10
    tmp31 = tl.load(in_ptr1 + (64 + 128*x4 + (x0)), tmp30 & xmask, eviction_policy='evict_last', other=0.0)
    tmp32 = -tmp31
    tmp33 = tl.full(tmp32.shape, 0.0, tmp32.dtype)
    tmp34 = tl.where(tmp30, tmp32, tmp33)
    tmp35 = tmp23 >= tmp28
    tmp36 = tl.full([1], 128, tl.int64)
    tmp37 = tmp23 < tmp36
    tmp38 = tmp35 & tmp10
    tmp39 = tl.load(in_ptr1 + (128*x4 + ((-64) + x0)), tmp38 & xmask, eviction_policy='evict_last', other=0.0)
    tmp40 = tl.where(tmp29, tmp34, tmp39)
    tmp41 = tl_math.sin(tmp17)
    tmp42 = tmp41 * tmp20
    tmp43 = tmp40 * tmp42
    tmp44 = tmp22 + tmp43
    tmp45 = tl.full(tmp44.shape, 0.0, tmp44.dtype)
    tmp46 = tl.where(tmp10, tmp44, tmp45)
    tmp47 = tl.where(tmp7, tmp8, tmp46)
    tl.store(out_ptr0 + (x5), tmp47, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/oe/coeb6ody7wfmyktdmd4yxjgba2amcupcfwfp62wo4ib7mrgkv44y.py
# Topologically Sorted Source Nodes: [linear_2, view_2, value_states, cat_4], Original ATen: [aten.view, aten.transpose, aten.cat]
# Source node to ATen node mapping:
#   cat_4 => cat_3
#   linear_2 => view_11
#   value_states => permute_6
#   view_2 => view_12
# Graph fragment:
#   %arg18_1 : Tensor "f32[s16, 2, s40, 128][256*s40, 128*s40, 128, 1]cuda:0" = PlaceHolder[target=arg18_1]
#   %addmm_2 : Tensor "f32[s16, 256][256, 1]cuda:0" = PlaceHolder[target=addmm_2]
#   %view_11 : Tensor "f32[s16, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_2, [%arg14_1, 1, 256]), kwargs = {})
#   %view_12 : Tensor "f32[s16, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_11, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_6 : Tensor "f32[s16, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_12, [0, 2, 1, 3]), kwargs = {})
#   %cat_3 : Tensor "f32[s16, 2, s40 + 1, 128][256*s40 + 256, 128*s40 + 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.cat.default](args = ([%arg18_1, %permute_6], -2), kwargs = {})
#   return %cat_3
triton_poi_fused_cat_transpose_view_2 = async_compile.triton('triton_poi_fused_cat_transpose_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 65536}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'ks0': 'i64', 'ks1': 'i64', 'ks2': 'i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_cat_transpose_view_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 460800}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_cat_transpose_view_2(in_ptr0, in_ptr1, out_ptr0, ks0, ks1, ks2, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = ((xindex // 128) % ks0)
    x0 = (xindex % 128)
    x2 = xindex // ks2
    x3 = xindex
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x1).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = (ks1).to(tl.int64)
    tmp6 = (tmp5).to(tl.int64)
    tmp7 = tmp4 < tmp6
    tmp8 = tl.load(in_ptr0 + (x0 + 128*(x1) + 128*ks1*x2), tmp7 & xmask, eviction_policy='evict_last', other=0.0)
    tmp9 = (ks1).to(tl.int32)
    tmp10 = tmp0 >= tmp9
    tmp11 = (ks0).to(tl.int32)
    tmp12 = tmp0 < tmp11
    tmp13 = tl.load(in_ptr1 + (x0 + 128*x2), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp14 = tl.where(tmp7, tmp8, tmp13)
    tl.store(out_ptr0 + (x3), tmp14, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/5k/c5kfpjgvc6lyueokx6kd24ubyrjmimazrfbt54w3yvguh73ln34k.py
# Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
# Source node to ATen node mapping:
#   cat_1 => cat
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   expand_1 => expand_4
#   expand_2 => expand_5
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   key_tensors => cat_4
#   linear => view_5
#   matmul => mul_14
#   mul_4 => mul_87
#   mul_5 => mul_98
#   neg => neg
#   output => _scaled_dot_product_efficient_attention
#   packed => view_13
#   position_ids_expanded => convert_element_type
#   q_embed => add_180
#   query_states => permute_2
#   sin => sin
#   sin_3 => unsqueeze_5
#   value_tensors => cat_5
#   view => view_6
#   x1 => slice_2
#   x2 => slice_3
# Graph fragment:
#   %addmm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=addmm]
#   %arg4_1 : Tensor "f32[64][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %arg3_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg3_1]
#   %arg5_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg5_1]
#   %view_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [%arg14_1, 1, 1536]), kwargs = {})
#   %view_6 : Tensor "f32[s16, 1, 12, 128][1536, 1536, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_5, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_2 : Tensor "f32[s16, 12, 1, 128][1536, 128, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_6, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %mul_87 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_2, %unsqueeze_4), kwargs = {})
#   %slice_3 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "f32[s16, 12, 1, 64][768, 64, 768, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_3,), kwargs = {})
#   %slice_2 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 0, 64), kwargs = {})
#   %cat : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_2], -1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %mul_98 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_5), kwargs = {})
#   %add_180 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_87, %mul_98), kwargs = {})
#   %view_13 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add_180, [%arg14_1, 2, 6, 128]), kwargs = {})
#   %expand_4 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg20_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %cat_4 : Tensor "f32[s16, 2, s53 + s91 + 1, 128][256*s53 + 256*s91 + 256, 128*s53 + 128*s91 + 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_4, %cat_2], -2), kwargs = {})
#   %expand_5 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg21_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %cat_5 : Tensor "f32[s16, 2, s40 + s91 + 1, 128][256*s40 + 256*s91 + 256, 128*s40 + 128*s91 + 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_5, %cat_3], -2), kwargs = {})
#   %_scaled_dot_product_efficient_attention : [num_users=1] = call_function[target=torch.ops.aten._scaled_dot_product_efficient_attention.default](args = (%view_13, %cat_4, %cat_5, None, False), kwargs = {scale: 0.08838834764831845})
#   return %buf7
triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3 = async_compile.triton('triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*i64', 'in_ptr3': 'fp64', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1536656}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x3 = xindex
    x2 = xindex // 1536
    x0 = (xindex % 128)
    x4 = xindex // 128
    tmp0 = tl.load(in_ptr0 + (x3), xmask)
    tmp1 = tl.load(in_ptr1 + ((x3 % 64)), xmask, eviction_policy='evict_last')
    tmp2 = tl.load(in_ptr2 + (x2), xmask, eviction_policy='evict_last')
    tmp6 = in_ptr3
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp1 * tmp3
    tmp5 = tl_math.cos(tmp4)
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tmp5 * tmp7
    tmp9 = tmp0 * tmp8
    tmp10 = (x0).to(tl.int32)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 >= tmp11
    tmp13 = (x0).to(tl.int64)
    tmp14 = (tmp13).to(tl.int64)
    tmp15 = tl.full([1], 64, tl.int64)
    tmp16 = tmp14 < tmp15
    tmp17 = tl.load(in_ptr0 + (64 + 128*x4 + (x0)), tmp16 & xmask, eviction_policy='evict_last', other=0.0)
    tmp18 = -tmp17
    tmp19 = tl.full(tmp18.shape, 0.0, tmp18.dtype)
    tmp20 = tl.where(tmp16, tmp18, tmp19)
    tmp21 = tmp10 >= tmp15
    tmp22 = tl.full([1], 128, tl.int64)
    tmp23 = tmp10 < tmp22
    tmp24 = tl.load(in_ptr0 + (128*x4 + ((-64) + x0)), tmp21 & xmask, eviction_policy='evict_last', other=0.0)
    tmp25 = tl.where(tmp16, tmp20, tmp24)
    tmp26 = tl_math.sin(tmp4)
    tmp27 = tmp26 * tmp7
    tmp28 = tmp25 * tmp27
    tmp29 = tmp9 + tmp28
    tl.store(out_ptr0 + (x3), tmp29, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/7c/c7c6p6xbbvrjjjv6kfyokysulzw3qg67554ybew2ccp72wxrywl5.py
# Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
# Source node to ATen node mapping:
#   cat_1 => cat
#   cos => cos
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_3
#   expand => expand
#   expand_1 => expand_4
#   expand_2 => expand_5
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_3 => unsqueeze_2
#   key_tensors => cat_4
#   linear => view_5
#   matmul => mul_14
#   mul_4 => mul_87
#   mul_5 => mul_98
#   neg => neg
#   output => _scaled_dot_product_efficient_attention
#   packed => view_13
#   position_ids_expanded => convert_element_type
#   q_embed => add_180
#   query_states => permute_2
#   sin => sin
#   sin_3 => unsqueeze_5
#   value_tensors => cat_5
#   view => view_6
#   x1 => slice_2
#   x2 => slice_3
# Graph fragment:
#   %arg20_1 : Tensor "f32[1, 2, s91, 128][256*s91, 128*s91, 128, 1]cuda:0" = PlaceHolder[target=arg20_1]
#   %cat_2 : Tensor "f32[s16, 2, s53 + 1, 128][256*s53 + 256, 128*s53 + 128, 128, 1]cuda:0" = PlaceHolder[target=cat_2]
#   %view_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [%arg14_1, 1, 1536]), kwargs = {})
#   %view_6 : Tensor "f32[s16, 1, 12, 128][1536, 1536, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_5, [%arg14_1, 1, -1, 128]), kwargs = {})
#   %permute_2 : Tensor "f32[s16, 12, 1, 128][1536, 128, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_6, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[s16, 64, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [%arg14_1, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg3_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul_14 : Tensor "f32[s16, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[s16, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_14, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[s16, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[s16, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [%arg14_1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[s16, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [%arg14_1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cos, %convert_element_type_default_1), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor, 1), kwargs = {})
#   %mul_87 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_2, %unsqueeze_4), kwargs = {})
#   %slice_3 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "f32[s16, 12, 1, 64][768, 64, 768, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_3,), kwargs = {})
#   %slice_2 : Tensor "f32[s16, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 0, 64), kwargs = {})
#   %cat : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_2], -1), kwargs = {})
#   %sin : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_3,), kwargs = {})
#   %convert_element_type_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %mul_tensor_1 : Tensor "f32[s16, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin, %convert_element_type_default_2), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[s16, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_tensor_1, 1), kwargs = {})
#   %mul_98 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_5), kwargs = {})
#   %add_180 : Tensor "f32[s16, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_87, %mul_98), kwargs = {})
#   %view_13 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add_180, [%arg14_1, 2, 6, 128]), kwargs = {})
#   %expand_4 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg20_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %cat_4 : Tensor "f32[s16, 2, s53 + s91 + 1, 128][256*s53 + 256*s91 + 256, 128*s53 + 128*s91 + 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_4, %cat_2], -2), kwargs = {})
#   %expand_5 : Tensor "f32[s16, 2, s91, 128][0, 128*s91, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg21_1, [%arg14_1, -1, -1, -1]), kwargs = {})
#   %cat_5 : Tensor "f32[s16, 2, s40 + s91 + 1, 128][256*s40 + 256*s91 + 256, 128*s40 + 128*s91 + 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%expand_5, %cat_3], -2), kwargs = {})
#   %_scaled_dot_product_efficient_attention : [num_users=1] = call_function[target=torch.ops.aten._scaled_dot_product_efficient_attention.default](args = (%view_13, %cat_4, %cat_5, None, False), kwargs = {scale: 0.08838834764831845})
#   return %buf8
triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4 = async_compile.triton('triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'ks0': 'i64', 'ks1': 'i64', 'ks2': 'i64', 'ks3': 'i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 8321024}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4(in_ptr0, in_ptr1, out_ptr0, ks0, ks1, ks2, ks3, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = ((xindex // 128) % ks0)
    x0 = (xindex % 128)
    x2 = ((xindex // ks2) % 2)
    x5 = xindex // ks2
    x4 = xindex
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x1).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = (ks1).to(tl.int64)
    tmp6 = (tmp5).to(tl.int64)
    tmp7 = tmp4 < tmp6
    tmp8 = tl.load(in_ptr0 + (x0 + 128*(x1) + 128*ks1*x2), tmp7 & xmask, eviction_policy='evict_last', other=0.0)
    tmp9 = (ks1).to(tl.int32)
    tmp10 = tmp0 >= tmp9
    tmp11 = (ks0).to(tl.int32)
    tmp12 = tmp0 < tmp11
    tmp13 = tl.load(in_ptr1 + (x0 + 128*x5 + 128*(x1 + ((-1)*ks1)) + 128*ks3*x5), tmp10 & xmask, eviction_policy='evict_last', other=0.0)
    tmp14 = tl.where(tmp7, tmp8, tmp13)
    tl.store(out_ptr0 + (x4), tmp14, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/iw/ciwkwmmixzr334lo4ivkti4bpvzw3xidzt3ihb3i25gyqbz3qi7l.py
# Topologically Sorted Source Nodes: [attn_output], Original ATen: [aten.clone]
# Source node to ATen node mapping:
#   attn_output => clone_2
# Graph fragment:
#   %getitem : Tensor "f32[s16, 2, 6, 128][1536, 128, 256, 1]cuda:0" = PlaceHolder[target=getitem]
#   %clone_2 : Tensor "f32[s16, 2, 6, 128][1536, 768, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%getitem,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone_2
triton_poi_fused_clone_5 = async_compile.triton('triton_poi_fused_clone_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_clone_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 921600}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_clone_5(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 6)
    x2 = ((xindex // 768) % 2)
    x3 = xindex // 1536
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 128*x2 + 256*x1 + 1536*x3), xmask)
    tl.store(out_ptr0 + (x4), tmp0, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/yf/cyffau64v7kjfr6zy7eqxmno63t4zpvwdsfej5jsb2osqatkwv3p.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, pow_2, variance_1, rsqrt_1, hidden_states_5, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   hidden_states_3 => add_291
#   hidden_states_5 => mul_219
#   hidden_states_6 => mul_222
#   inputs_embeds => embedding
#   pow_2 => pow_2
#   rsqrt_1 => rsqrt_1
#   variance_1 => mean_1
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %arg24_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg24_1]
#   %buf17 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf17]
#   %arg23_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg23_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_291 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %pow_2 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_291, 2), kwargs = {})
#   %mean_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %convert_element_type_default_6 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg23_1, torch.float32), kwargs = {})
#   %add_tensor_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, %convert_element_type_default_6), kwargs = {})
#   %rsqrt_1 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_1,), kwargs = {})
#   %mul_219 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_291, %rsqrt_1), kwargs = {})
#   %mul_222 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg24_1, %mul_219), kwargs = {})
#   return %buf17,%mul_222
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_6 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 927744}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_6(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    tmp16 = in_ptr4
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tmp11 + tmp12
        tmp14 = tl.full([1, 1], 1536.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tmp15 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp13 * tmp19
        tmp21 = tmp9 * tmp20
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp21, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/3x/c3xtgx3cxy3vku34d6jm2sqkbb4bmxadxjh5mtdccmdtxg2qscnz.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_10], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
# Source node to ATen node mapping:
#   linear_4 => view_19
#   linear_5 => view_21
#   mul_10 => mul_252
#   silu => add_331, div, exp, neg_2
# Graph fragment:
#   %mm_1 : Tensor "f32[s16, 8960][8960, 1]cuda:0" = PlaceHolder[target=mm_1]
#   %mm_2 : Tensor "f32[s16, 8960][8960, 1]cuda:0" = PlaceHolder[target=mm_2]
#   %view_19 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [%arg14_1, 1, 8960]), kwargs = {})
#   %neg_2 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%view_19,), kwargs = {})
#   %exp : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_331 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%view_19, %add_331), kwargs = {})
#   %view_21 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [%arg14_1, 1, 8960]), kwargs = {})
#   %mul_252 : Tensor "f32[s16, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%div, %view_21), kwargs = {})
#   return %mul_252
triton_poi_fused__unsafe_view_mul_silu_7 = async_compile.triton('triton_poi_fused__unsafe_view_mul_silu_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_mul_silu_7', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 7168000}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_mul_silu_7(in_out_ptr0, in_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_out_ptr0 + (x0), xmask)
    tmp6 = tl.load(in_ptr0 + (x0), xmask)
    tmp1 = -tmp0
    tmp2 = libdevice.exp(tmp1)
    tmp3 = tl.full([1], 1.0, tl.float32)
    tmp4 = tmp2 + tmp3
    tmp5 = (tmp0 / tmp4)
    tmp7 = tmp5 * tmp6
    tl.store(in_out_ptr0 + (x0), tmp7, xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/bn/cbn64eneoji3e7z3nujvp4rbjh5i7qilxrscdts4cz5q3qjoyx7q.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, down_proj, hidden_states_7, pow_3, variance_2, rsqrt_2, hidden_states_9, hidden_states_10], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   down_proj => view_23
#   hidden_states_10 => mul_279
#   hidden_states_3 => add_291
#   hidden_states_7 => add_360
#   hidden_states_9 => mul_276
#   inputs_embeds => embedding
#   pow_3 => pow_3
#   rsqrt_2 => rsqrt_2
#   variance_2 => mean_2
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %mm_3 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_3]
#   %arg29_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg29_1]
#   %buf23 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf23]
#   %arg28_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg28_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_291 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %view_23 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_360 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_291, %view_23), kwargs = {})
#   %pow_3 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_360, 2), kwargs = {})
#   %mean_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %convert_element_type_default_8 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg28_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, %convert_element_type_default_8), kwargs = {})
#   %rsqrt_2 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_2,), kwargs = {})
#   %mul_276 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_360, %rsqrt_2), kwargs = {})
#   %mul_279 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg29_1, %mul_276), kwargs = {})
#   return %buf23,%mul_279
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    tmp20 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp14 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp16 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tmp13 + tmp14
        tmp17 = tmp15 + tmp16
        tmp18 = tl.full([1, 1], 1536.0, tl.float32)
        tmp19 = (tmp9 / tmp18)
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp19 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp17 * tmp23
        tmp25 = tmp11 * tmp24
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp25, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/t4/ct4horfwvwlfid54p2pifpmwxntxs42n7jjtdtqgpwomhp6sm7d6.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, down_proj, hidden_states_7, attn_output_7, hidden_states_11, pow_4, variance_3, rsqrt_3, hidden_states_13, hidden_states_14], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_3 => view_17
#   attn_output_7 => view_37
#   down_proj => view_23
#   hidden_states_11 => add_601
#   hidden_states_13 => mul_451
#   hidden_states_14 => mul_454
#   hidden_states_3 => add_291
#   hidden_states_7 => add_360
#   inputs_embeds => embedding
#   pow_4 => pow_4
#   rsqrt_3 => rsqrt_3
#   variance_3 => mean_3
# Graph fragment:
#   %arg1_1 : Tensor "i64[s16, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[152265, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %mm_3 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_3]
#   %mm_4 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_4]
#   %add_601 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_601]
#   %arg44_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg44_1]
#   %buf41 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf41]
#   %arg43_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg43_1]
#   %embedding : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_17 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_291 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_17), kwargs = {})
#   %view_23 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_360 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_291, %view_23), kwargs = {})
#   %view_37 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_601 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_360, %view_37), kwargs = {})
#   %pow_4 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_601, 2), kwargs = {})
#   %mean_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %convert_element_type_default_10 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg43_1, torch.float32), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, %convert_element_type_default_10), kwargs = {})
#   %rsqrt_3 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_451 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_601, %rsqrt_3), kwargs = {})
#   %mul_454 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg44_1, %mul_451), kwargs = {})
#   return %add_601,%buf41,%mul_454
triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_9 = async_compile.triton('triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_9', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 400, 'r0_': 2156544}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_9(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp11 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp5 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp7 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tl.device_assert(((0 <= tmp0) & (tmp0 < 152265)) | ~(xmask), "index out of bounds: 0 <= tmp0 < 152265")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1536*tmp0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask & xmask, tmp12, _tmp11)
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp8, r0_mask & xmask)
    tmp11 = tl.sum(_tmp11, 1)[:, None]
    tmp17 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.debug_barrier()
        tmp14 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp11 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp13 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/3g/c3g6fxdlivrn4hptiu6a7nx3xfzawhfzghg5xqwck2ehdg7qkmae.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, pow_5, variance_4, rsqrt_4, hidden_states_17, hidden_states_18], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   down_proj_1 => view_43
#   hidden_states_15 => add_670
#   hidden_states_17 => mul_508
#   hidden_states_18 => mul_511
#   pow_5 => pow_5
#   rsqrt_4 => rsqrt_4
#   variance_4 => mean_4
# Graph fragment:
#   %add_601 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_601]
#   %mm_7 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %arg49_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg49_1]
#   %buf47 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf47]
#   %arg48_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg48_1]
#   %view_43 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_670 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_601, %view_43), kwargs = {})
#   %pow_5 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_670, 2), kwargs = {})
#   %mean_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [-1], True), kwargs = {})
#   %convert_element_type_default_12 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg48_1, torch.float32), kwargs = {})
#   %add_tensor_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_4, %convert_element_type_default_12), kwargs = {})
#   %rsqrt_4 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_4,), kwargs = {})
#   %mul_508 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_670, %rsqrt_4), kwargs = {})
#   %mul_511 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg49_1, %mul_508), kwargs = {})
#   return %buf47,%mul_511
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    tmp13 = in_ptr3
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp8 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp9 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tmp8 + tmp9
        tmp11 = tl.full([1, 1], 1536.0, tl.float32)
        tmp12 = (tmp5 / tmp11)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tmp12 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp10 * tmp16
        tmp18 = tmp7 * tmp17
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp18, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/nk/cnkrfu6v4k7hakxgj5drggbcexoc7qw4ajhpzojbsajzryvfra3q.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, pow_6, variance_5, rsqrt_5, hidden_states_21, hidden_states_22], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_57
#   down_proj_1 => view_43
#   hidden_states_15 => add_670
#   hidden_states_19 => add_911
#   hidden_states_21 => mul_683
#   hidden_states_22 => mul_686
#   pow_6 => pow_6
#   rsqrt_5 => rsqrt_5
#   variance_5 => mean_5
# Graph fragment:
#   %add_601 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_601]
#   %mm_7 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %mm_8 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %arg64_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg64_1]
#   %buf64 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf64]
#   %arg63_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg63_1]
#   %view_43 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_670 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_601, %view_43), kwargs = {})
#   %view_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_911 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_670, %view_57), kwargs = {})
#   %pow_6 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_911, 2), kwargs = {})
#   %mean_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %convert_element_type_default_14 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg63_1, torch.float32), kwargs = {})
#   %add_tensor_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, %convert_element_type_default_14), kwargs = {})
#   %rsqrt_5 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_5,), kwargs = {})
#   %mul_683 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_911, %rsqrt_5), kwargs = {})
#   %mul_686 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg64_1, %mul_683), kwargs = {})
#   return %buf64,%mul_686
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1542144}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    tmp17 = in_ptr4
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp10 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp7 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp9 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/o4/co4b32g7wwsflrsuozu4x5wexxil7qzgx7yrccvrq2nassboayxm.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, down_proj_2, hidden_states_23, pow_7, variance_6, rsqrt_6, hidden_states_25, hidden_states_26], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_57
#   down_proj_1 => view_43
#   down_proj_2 => view_63
#   hidden_states_15 => add_670
#   hidden_states_19 => add_911
#   hidden_states_23 => add_980
#   hidden_states_25 => mul_740
#   hidden_states_26 => mul_743
#   pow_7 => pow_7
#   rsqrt_6 => rsqrt_6
#   variance_6 => mean_6
# Graph fragment:
#   %add_601 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_601]
#   %mm_7 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %mm_8 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %mm_11 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_11]
#   %arg69_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg69_1]
#   %buf70 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf70]
#   %arg68_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg68_1]
#   %view_43 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_670 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_601, %view_43), kwargs = {})
#   %view_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_911 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_670, %view_57), kwargs = {})
#   %view_63 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_11, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_980 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_911, %view_63), kwargs = {})
#   %pow_7 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_980, 2), kwargs = {})
#   %mean_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [-1], True), kwargs = {})
#   %convert_element_type_default_16 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg68_1, torch.float32), kwargs = {})
#   %add_tensor_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_6, %convert_element_type_default_16), kwargs = {})
#   %rsqrt_6 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_6,), kwargs = {})
#   %mul_740 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_980, %rsqrt_6), kwargs = {})
#   %mul_743 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg69_1, %mul_740), kwargs = {})
#   return %buf70,%mul_743
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 10, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1849344}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    tmp21 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp17 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tl.full([1, 1], 1536.0, tl.float32)
        tmp20 = (tmp9 / tmp19)
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tmp20 + tmp22
        tmp24 = libdevice.rsqrt(tmp23)
        tmp25 = tmp18 * tmp24
        tmp26 = tmp11 * tmp25
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp26, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/yr/cyry5apvzafb5cyx2dhzun6gegd3fw5suwb22fhwknn4mtvb35ov.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, down_proj_2, hidden_states_23, attn_output_15, hidden_states_27, pow_8, variance_7, rsqrt_7, hidden_states_29, hidden_states_30], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   attn_output_11 => view_57
#   attn_output_15 => view_77
#   down_proj_1 => view_43
#   down_proj_2 => view_63
#   hidden_states_15 => add_670
#   hidden_states_19 => add_911
#   hidden_states_23 => add_980
#   hidden_states_27 => add_1221
#   hidden_states_29 => mul_915
#   hidden_states_30 => mul_918
#   pow_8 => pow_8
#   rsqrt_7 => rsqrt_7
#   variance_7 => mean_7
# Graph fragment:
#   %add_601 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_601]
#   %mm_7 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %mm_8 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %mm_11 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_11]
#   %mm_12 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_12]
#   %add_1221 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_1221]
#   %arg84_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg84_1]
#   %buf88 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf88]
#   %arg83_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg83_1]
#   %view_43 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_670 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_601, %view_43), kwargs = {})
#   %view_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_911 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_670, %view_57), kwargs = {})
#   %view_63 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_11, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_980 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_911, %view_63), kwargs = {})
#   %view_77 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_12, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_1221 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_980, %view_77), kwargs = {})
#   %pow_8 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_1221, 2), kwargs = {})
#   %mean_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_8, [-1], True), kwargs = {})
#   %convert_element_type_default_18 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg83_1, torch.float32), kwargs = {})
#   %add_tensor_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_7, %convert_element_type_default_18), kwargs = {})
#   %rsqrt_7 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_7,), kwargs = {})
#   %mul_915 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_1221, %rsqrt_7), kwargs = {})
#   %mul_918 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg84_1, %mul_915), kwargs = {})
#   return %add_1221,%buf88,%mul_918
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': 'fp64', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 2770944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp11 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp3 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp5 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp7 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask & xmask, tmp12, _tmp11)
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp8, r0_mask & xmask)
    tmp11 = tl.sum(_tmp11, 1)[:, None]
    tmp17 = in_ptr5
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.debug_barrier()
        tmp14 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp11 / tmp15)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp14 * tmp20
        tmp22 = tmp13 * tmp21
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp22, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/7q/c7qs56gfnlv4fp2uspvpv5zfyvw4abb2ljsjkap22fpmdrf76bqy.py
# Topologically Sorted Source Nodes: [down_proj_7, hidden_states_63, attn_output_35, hidden_states_67, down_proj_8, hidden_states_71, attn_output_39, hidden_states_75, pow_20, variance_19, add_58, rsqrt_19, hidden_states_77, hidden_states_78], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_58 => add_3094
#   attn_output_35 => view_177
#   attn_output_39 => view_197
#   down_proj_7 => view_163
#   down_proj_8 => view_183
#   hidden_states_63 => add_2530
#   hidden_states_67 => add_2771
#   hidden_states_71 => add_2840
#   hidden_states_75 => add_3081
#   hidden_states_77 => mul_2307
#   hidden_states_78 => mul_2310
#   pow_20 => pow_20
#   rsqrt_19 => rsqrt_19
#   variance_19 => mean_19
# Graph fragment:
#   %add_2461 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_2461]
#   %mm_31 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_31]
#   %mm_32 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_32]
#   %mm_35 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_35]
#   %mm_36 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_36]
#   %add_3081 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_3081]
#   %arg203_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg203_1]
#   %buf229 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf229]
#   %view_163 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_31, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_2530 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_2461, %view_163), kwargs = {})
#   %view_177 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_32, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_2771 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_2530, %view_177), kwargs = {})
#   %view_183 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_35, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_2840 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_2771, %view_183), kwargs = {})
#   %view_197 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_36, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_3081 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_2840, %view_197), kwargs = {})
#   %pow_20 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_3081, 2), kwargs = {})
#   %mean_19 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_20, [-1], True), kwargs = {})
#   %add_3094 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_19, 1e-06), kwargs = {})
#   %rsqrt_19 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_3094,), kwargs = {})
#   %mul_2307 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_3081, %rsqrt_19), kwargs = {})
#   %mul_2310 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg203_1, %mul_2307), kwargs = {})
#   return %add_3081,%buf229,%mul_2310
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 2770944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp11 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp3 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp5 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp7 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask & xmask, tmp12, _tmp11)
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp8, r0_mask & xmask)
    tmp11 = tl.sum(_tmp11, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tl.debug_barrier()
        tmp14 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp11 / tmp15)
        tmp17 = tl.full([1, 1], 1e-06, tl.float32)
        tmp18 = tmp16 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp14 * tmp19
        tmp21 = tmp13 * tmp20
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp21, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/ct/cct5oxzlz6yteeunblnfwfujeq4tazy2yzsfgyoiaoutw37ainbx.py
# Topologically Sorted Source Nodes: [down_proj_9, hidden_states_79, attn_output_43, hidden_states_83, pow_22, variance_21, add_64, rsqrt_21, hidden_states_85, hidden_states_86], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_64 => add_3404
#   attn_output_43 => view_217
#   down_proj_9 => view_203
#   hidden_states_79 => add_3150
#   hidden_states_83 => add_3391
#   hidden_states_85 => mul_2539
#   hidden_states_86 => mul_2542
#   pow_22 => pow_22
#   rsqrt_21 => rsqrt_21
#   variance_21 => mean_21
# Graph fragment:
#   %add_3081 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_3081]
#   %mm_39 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_39]
#   %mm_40 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_40]
#   %arg222_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg222_1]
#   %buf252 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf252]
#   %view_203 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_39, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_3150 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_3081, %view_203), kwargs = {})
#   %view_217 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_40, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_3391 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_3150, %view_217), kwargs = {})
#   %pow_22 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_3391, 2), kwargs = {})
#   %mean_21 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_22, [-1], True), kwargs = {})
#   %add_3404 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_21, 1e-06), kwargs = {})
#   %rsqrt_21 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_3404,), kwargs = {})
#   %mul_2539 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_3391, %rsqrt_21), kwargs = {})
#   %mul_2542 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg222_1, %mul_2539), kwargs = {})
#   return %buf252,%mul_2542
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1542144}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp10 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp7 / tmp15)
        tmp17 = tl.full([1, 1], 1e-06, tl.float32)
        tmp18 = tmp16 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp14 * tmp19
        tmp21 = tmp9 * tmp20
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp21, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/5p/c5pwcvyxgolyem2noonk3x45bf4jbai6ikfjfyrgwtnywm2f25y3.py
# Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, pow_29, variance_28, add_84, rsqrt_28, hidden_states_113, hidden_states_114], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_84 => add_4403
#   down_proj_13 => view_283
#   hidden_states_111 => add_4390
#   hidden_states_113 => mul_3292
#   hidden_states_114 => mul_3295
#   pow_29 => pow_29
#   rsqrt_28 => rsqrt_28
#   variance_28 => mean_28
# Graph fragment:
#   %add_4321 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_4321]
#   %mm_55 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_55]
#   %arg286_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg286_1]
#   %buf329 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf329]
#   %view_283 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_55, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4390 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4321, %view_283), kwargs = {})
#   %pow_29 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_4390, 2), kwargs = {})
#   %mean_28 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_29, [-1], True), kwargs = {})
#   %add_4403 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_28, 1e-06), kwargs = {})
#   %rsqrt_28 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4403,), kwargs = {})
#   %mul_3292 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_4390, %rsqrt_28), kwargs = {})
#   %mul_3295 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg286_1, %mul_3292), kwargs = {})
#   return %buf329,%mul_3295
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_16 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_16', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_16', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_16(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp8 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp9 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tmp8 + tmp9
        tmp11 = tl.full([1, 1], 1536.0, tl.float32)
        tmp12 = (tmp5 / tmp11)
        tmp13 = tl.full([1, 1], 1e-06, tl.float32)
        tmp14 = tmp12 + tmp13
        tmp15 = libdevice.rsqrt(tmp14)
        tmp16 = tmp10 * tmp15
        tmp17 = tmp7 * tmp16
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp17, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/ed/ced4zokkmzogi6nyxh6xu4ajnkjxrv2yh3u7rk2uhn7onuwarnrm.py
# Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, attn_output_59, hidden_states_115, down_proj_14, hidden_states_119, pow_31, variance_30, add_90, rsqrt_30, hidden_states_121, hidden_states_122], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_90 => add_4713
#   attn_output_59 => view_297
#   down_proj_13 => view_283
#   down_proj_14 => view_303
#   hidden_states_111 => add_4390
#   hidden_states_115 => add_4631
#   hidden_states_119 => add_4700
#   hidden_states_121 => mul_3524
#   hidden_states_122 => mul_3527
#   pow_31 => pow_31
#   rsqrt_30 => rsqrt_30
#   variance_30 => mean_30
# Graph fragment:
#   %add_4321 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_4321]
#   %mm_55 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_55]
#   %mm_56 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_56]
#   %mm_59 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_59]
#   %arg305_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg305_1]
#   %buf352 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf352]
#   %view_283 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_55, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4390 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4321, %view_283), kwargs = {})
#   %view_297 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_56, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4631 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4390, %view_297), kwargs = {})
#   %view_303 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_59, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_4700 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4631, %view_303), kwargs = {})
#   %pow_31 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_4700, 2), kwargs = {})
#   %mean_30 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_31, [-1], True), kwargs = {})
#   %add_4713 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_30, 1e-06), kwargs = {})
#   %rsqrt_30 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4713,), kwargs = {})
#   %mul_3524 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_4700, %rsqrt_30), kwargs = {})
#   %mul_3527 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg305_1, %mul_3524), kwargs = {})
#   return %buf352,%mul_3527
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_17 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_17', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_17', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1849344}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_17(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp3 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp5 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask & xmask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp12 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp15 = tl.load(in_ptr2 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp17 = tl.load(in_ptr3 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tl.full([1, 1], 1536.0, tl.float32)
        tmp20 = (tmp9 / tmp19)
        tmp21 = tl.full([1, 1], 1e-06, tl.float32)
        tmp22 = tmp20 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp18 * tmp23
        tmp25 = tmp11 * tmp24
        tl.store(out_ptr1 + (r0_1 + 1536*x0), tmp25, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /oscar/scratch/aagraw73/agent-runs/rapidtinyrec-precision-quality/precision-pilot-20261026T053441Z-f040754d1743/compile-cache/fp32/inductor/75/c75z4fvdnvgxqyezfeyg2lbx4ni4c6dagt4tce3tford3f7ibvna.py
# Topologically Sorted Source Nodes: [down_proj_27, hidden_states_223, pow_57, variance_56, rsqrt_56, hidden_states_225, hidden_states_226], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   down_proj_27 => view_563
#   hidden_states_223 => add_8730
#   hidden_states_225 => mul_6540
#   hidden_states_226 => mul_6543
#   pow_57 => pow_57
#   rsqrt_56 => rsqrt_56
#   variance_56 => mean_56
# Graph fragment:
#   %add_8661 : Tensor "f32[s16, 1, 1536][1536, 1536*s16, 1]cuda:0" = PlaceHolder[target=add_8661]
#   %mm_111 : Tensor "f32[s16, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_111]
#   %arg564_1 : Tensor "f32[1536][1]cuda:0" = PlaceHolder[target=arg564_1]
#   %buf658 : Tensor "f32[s16, 1, 1][1, s16, s16]cuda:0" = PlaceHolder[target=buf658]
#   %arg563_1 : Tensor "f64[][]cpu" = PlaceHolder[target=arg563_1]
#   %view_563 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_111, [%arg14_1, 1, 1536]), kwargs = {})
#   %add_8730 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_8661, %view_563), kwargs = {})
#   %pow_57 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_8730, 2), kwargs = {})
#   %mean_56 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_57, [-1], True), kwargs = {})
#   %convert_element_type_default_106 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg563_1, torch.float32), kwargs = {})
#   %add_tensor_51 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_56, %convert_element_type_default_106), kwargs = {})
#   %rsqrt_56 : Tensor "f32[s16, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_51,), kwargs = {})
#   %mul_6540 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_8730, %rsqrt_56), kwargs = {})
#   %mul_6543 : Tensor "f32[s16, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg564_1, %mul_6540), kwargs = {})
#   return %buf658,%mul_6543
triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_18 = async_compile.triton('triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_18', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': 'fp64', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_18', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 1234944}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_18(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp5 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2 * tmp2
        tmp4 = tl.broadcast_to(tmp3, [XBLOCK, R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask & xmask, tmp6, _tmp5)
    tmp5 = tl.sum(_tmp5, 1)[:, None]
    tmp13 = in_ptr2
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr1 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp8 = tl.load(in_out_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp9 = tl.load(in_ptr0 + (r0_1 + 1536*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0)
        tmp10 = tmp8 + tmp9
        tmp11 = tl.full([1, 1], 1536.0, tl.float32)
        tmp12 = (tmp5 / tmp11)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tmp12 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp10 * tmp16
        tmp18 = tmp7 * tmp17
        tl.store(in_out_ptr0 + (r0_1 + 1536*x0), tmp18, r0_mask & xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1, arg458_1, arg459_1, arg460_1, arg461_1, arg462_1, arg463_1, arg464_1, arg465_1, arg466_1, arg467_1, arg468_1, arg469_1, arg470_1, arg471_1, arg472_1, arg473_1, arg474_1, arg475_1, arg476_1, arg477_1, arg478_1, arg479_1, arg480_1, arg481_1, arg482_1, arg483_1, arg484_1, arg485_1, arg486_1, arg487_1, arg488_1, arg489_1, arg490_1, arg491_1, arg492_1, arg493_1, arg494_1, arg495_1, arg496_1, arg497_1, arg498_1, arg499_1, arg500_1, arg501_1, arg502_1, arg503_1, arg504_1, arg505_1, arg506_1, arg507_1, arg508_1, arg509_1, arg510_1, arg511_1, arg512_1, arg513_1, arg514_1, arg515_1, arg516_1, arg517_1, arg518_1, arg519_1, arg520_1, arg521_1, arg522_1, arg523_1, arg524_1, arg525_1, arg526_1, arg527_1, arg528_1, arg529_1, arg530_1, arg531_1, arg532_1, arg533_1, arg534_1, arg535_1, arg536_1, arg537_1, arg538_1, arg539_1, arg540_1, arg541_1, arg542_1, arg543_1, arg544_1, arg545_1, arg546_1, arg547_1, arg548_1, arg549_1, arg550_1, arg551_1, arg552_1, arg553_1, arg554_1, arg555_1, arg556_1, arg557_1, arg558_1, arg559_1, arg560_1, arg561_1, arg562_1, arg563_1, arg564_1, arg565_1 = args
        args.clear()
        s16 = arg0_1
        s74 = s16
        s52 = s16
        s53 = arg15_1
        s40 = arg17_1
        s91 = arg19_1
        s66 = arg36_1
        s6 = arg38_1
        s47 = arg56_1
        s87 = arg58_1
        s84 = arg76_1
        s19 = arg78_1
        s55 = arg96_1
        s24 = arg98_1
        s95 = arg116_1
        s98 = arg118_1
        s22 = arg136_1
        s80 = arg138_1
        s37 = arg156_1
        s2 = arg158_1
        s96 = arg176_1
        s34 = arg178_1
        s64 = arg196_1
        s4 = arg198_1
        s43 = arg215_1
        s17 = arg217_1
        s73 = arg234_1
        s31 = arg236_1
        s63 = arg254_1
        s65 = arg256_1
        s29 = arg274_1
        s45 = arg276_1
        s23 = arg293_1
        s101 = arg295_1
        s51 = arg312_1
        s103 = arg314_1
        s32 = arg332_1
        s68 = arg334_1
        s77 = arg351_1
        s78 = arg353_1
        s38 = arg371_1
        s107 = arg373_1
        s111 = arg391_1
        s112 = arg393_1
        s115 = arg411_1
        s9 = arg413_1
        s39 = arg431_1
        s117 = arg433_1
        s120 = arg451_1
        s121 = arg453_1
        s124 = arg471_1
        s125 = arg473_1
        s129 = arg491_1
        s130 = arg493_1
        s134 = arg511_1
        s135 = arg513_1
        s139 = arg531_1
        s140 = arg533_1
        s144 = arg551_1
        s145 = arg553_1
        s149 = arg565_1
        assert_size_stride_grouped((arg1_1, arg2_1, arg7_1, arg6_1), ((s16, 1), (152265, 1536), (1536, ), ()), ((1, 1), (1536, 1), (1, ), ()), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg1_1 = copy_if_misaligned(arg1_1)
            buf1 = empty_strided_cuda((s16, 1, 1536), (1536, 1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [inputs_embeds, pow_1, variance, rsqrt, hidden_states_1, hidden_states_2], Original ATen: [aten.embedding, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_embedding_mean_mul_pow_rsqrt_0.run(arg1_1, arg2_1, arg7_1, arg6_1.item(), buf1, s16, 1536, stream=raw_stream0)
            del arg6_1
            del arg7_1
            assert_size_stride_grouped((arg9_1, arg8_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf2 = empty_strided_cuda((s16, 1536), (1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg9_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg8_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf2)
            del arg8_1
            del arg9_1
            assert_size_stride_grouped((arg11_1, arg10_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf3 = empty_strided_cuda((s16, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg11_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg10_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf3)
            del arg10_1
            del arg11_1
            assert_size_stride_grouped((arg16_1, arg4_1, arg3_1, arg5_1), ((s16, 2, s53, 128), (64, ), (s16, 1), ()), ((256*s53, 128*s53, 128, 1), (1, ), (1, 1), ()), 'input')
            arg16_1 = copy_if_misaligned(arg16_1)
            arg3_1 = copy_if_misaligned(arg3_1)
            ps0 = 1 + s53
            ps1 = 128 + 128*s53
            ps2 = 256 + 256*s53
            buf4 = empty_strided_cuda((s16, 2, 1 + s53, 128), (256 + 256*s53, 128 + 128*s53, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, sin, sin_3, linear_1, view_1, key_states, mul_6, x2_1, neg_1, x1_1, cat_2, mul_7, k_embed, cat_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s53
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg16_1, buf3, arg4_1, arg3_1, arg5_1.item(), buf4, ps0, s53, ps1, ps2, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg16_1
            assert_size_stride_grouped((arg13_1, arg12_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf5 = buf3; del buf3  # reuse
            # Topologically Sorted Source Nodes: [linear_2], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg13_1, reinterpret_tensor(buf1, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg12_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf5)
            del arg12_1
            del arg13_1
            assert_size_stride(arg18_1, (s16, 2, s40, 128), (256*s40, 128*s40, 128, 1), 'input')
            arg18_1 = copy_if_misaligned(arg18_1)
            ps3 = 1 + s40
            ps4 = 128 + 128*s40
            buf6 = empty_strided_cuda((s16, 2, 1 + s40, 128), (256 + 256*s40, 128 + 128*s40, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_2, view_2, value_states, cat_4], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s40
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg18_1, buf5, buf6, ps3, s40, ps4, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg18_1
            buf7 = reinterpret_tensor(buf1, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf1  # reuse
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf2, arg4_1, arg3_1, arg5_1.item(), buf7, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg20_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg20_1 = copy_if_misaligned(arg20_1)
            ps5 = 1 + s53 + s91
            ps6 = 128 + 128*s53 + 128*s91
            buf8 = empty_strided_cuda((s16, 2, 1 + s53 + s91, 128), (256 + 256*s53 + 256*s91, 128 + 128*s53 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s53 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg20_1, buf4, buf8, ps5, s91, ps6, s53, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg20_1
            assert_size_stride(arg21_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg21_1 = copy_if_misaligned(arg21_1)
            ps7 = 1 + s40 + s91
            ps8 = 128 + 128*s40 + 128*s91
            buf9 = empty_strided_cuda((s16, 2, 1 + s40 + s91, 128), (256 + 256*s40 + 256*s91, 128 + 128*s40 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s40 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg21_1, buf6, buf9, ps7, s91, ps8, s40, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg21_1
            # Topologically Sorted Source Nodes: [linear, view, query_states, getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, cos_3, mul_4, x2, neg, x1, cat_1, sin, sin_3, mul_5, q_embed, packed, expand_1, key_tensors, expand_2, value_tensors, output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.cos, aten.mul, aten.slice, aten.neg, aten.sin, aten.add, aten._scaled_dot_product_efficient_attention]
            buf10 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf7, buf8, buf9, None, False, scale=0.08838834764831845)
            del buf8
            del buf9
            buf11 = buf10[0]
            assert_tensor_metadata(buf11, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf11, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf10
            buf15 = buf7; del buf7  # reuse
            # Topologically Sorted Source Nodes: [attn_output], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf11, buf15, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg22_1, (1536, 1536), (1536, 1), 'input')
            buf16 = reinterpret_tensor(buf11, (s16, 1536), (1536, 1), 0); del buf11  # reuse
            # Topologically Sorted Source Nodes: [attn_output, transpose_4, reshape_2, attn_output_3], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf15, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg22_1, (1536, 1536), (1, 1536), 0), out=buf16)
            del arg22_1
            assert_size_stride_grouped((arg24_1, arg23_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf18 = reinterpret_tensor(buf15, (s16, 1, 1536), (1536, 1536, 1), 0); del buf15  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, pow_2, variance_1, rsqrt_1, hidden_states_5, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_6.run(arg1_1, arg2_1, buf16, arg24_1, arg23_1.item(), buf18, s16, 1536, stream=raw_stream0)
            del arg23_1
            del arg24_1
            assert_size_stride(arg25_1, (8960, 1536), (1536, 1), 'input')
            buf19 = empty_strided_cuda((s16, 8960), (8960, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf18, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg25_1, (1536, 8960), (1, 1536), 0), out=buf19)
            del arg25_1
            assert_size_stride(arg26_1, (8960, 1536), (1536, 1), 'input')
            buf20 = empty_strided_cuda((s16, 8960), (8960, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_5], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf18, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg26_1, (1536, 8960), (1, 1536), 0), out=buf20)
            del arg26_1
            buf21 = reinterpret_tensor(buf19, (s16, 1, 8960), (8960, 8960, 1), 0); del buf19  # reuse
            # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_10], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf21, buf20, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg27_1, (1536, 8960), (8960, 1), 'input')
            buf22 = reinterpret_tensor(buf18, (s16, 1536), (1536, 1), 0); del buf18  # reuse
            # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_10, down_proj], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf21, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg27_1, (8960, 1536), (1, 8960), 0), out=buf22)
            del arg27_1
            assert_size_stride_grouped((arg29_1, arg28_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf24 = reinterpret_tensor(buf2, (s16, 1, 1536), (1536, 1536, 1), 0); del buf2  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, down_proj, hidden_states_7, pow_3, variance_2, rsqrt_2, hidden_states_9, hidden_states_10], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8.run(arg1_1, arg2_1, buf16, buf22, arg29_1, arg28_1.item(), buf24, s16, 1536, stream=raw_stream0)
            del arg28_1
            del arg29_1
            assert_size_stride_grouped((arg31_1, arg30_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf25 = empty_strided_cuda((s16, 1536), (1536, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg31_1, reinterpret_tensor(buf24, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg30_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf25)
            del arg30_1
            del arg31_1
            assert_size_stride_grouped((arg33_1, arg32_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf26 = buf5; del buf5  # reuse
            # Topologically Sorted Source Nodes: [linear_8], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg33_1, reinterpret_tensor(buf24, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg32_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf26)
            del arg32_1
            del arg33_1
            assert_size_stride(arg37_1, (s16, 2, s66, 128), (256*s66, 128*s66, 128, 1), 'input')
            arg37_1 = copy_if_misaligned(arg37_1)
            ps9 = 1 + s66
            ps10 = 128 + 128*s66
            ps11 = 256 + 256*s66
            buf27 = empty_strided_cuda((s16, 2, 1 + s66, 128), (256 + 256*s66, 128 + 128*s66, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_4, sin_4, linear_8, view_4, key_states_1, mul_15, x2_3, neg_3, x1_3, cat_8, mul_16, k_embed_1, cat_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s66
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg37_1, buf26, arg4_1, arg3_1, arg5_1.item(), buf27, ps9, s66, ps10, ps11, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg37_1
            assert_size_stride_grouped((arg35_1, arg34_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf28 = buf26; del buf26  # reuse
            # Topologically Sorted Source Nodes: [linear_9], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg35_1, reinterpret_tensor(buf24, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg34_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf28)
            del arg34_1
            del arg35_1
            assert_size_stride(arg39_1, (s16, 2, s6, 128), (256*s6, 128*s6, 128, 1), 'input')
            arg39_1 = copy_if_misaligned(arg39_1)
            ps12 = 1 + s6
            ps13 = 128 + 128*s6
            buf29 = empty_strided_cuda((s16, 2, 1 + s6, 128), (256 + 256*s6, 128 + 128*s6, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_9, view_5, value_states_1, cat_10], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s6
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg39_1, buf28, buf29, ps12, s6, ps13, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg39_1
            buf30 = reinterpret_tensor(buf24, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf24  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_7, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf25, arg4_1, arg3_1, arg5_1.item(), buf30, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg40_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg40_1 = copy_if_misaligned(arg40_1)
            ps14 = 1 + s66 + s91
            ps15 = 128 + 128*s66 + 128*s91
            buf31 = empty_strided_cuda((s16, 2, 1 + s66 + s91, 128), (256 + 256*s66 + 256*s91, 128 + 128*s66 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_7, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s66 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg40_1, buf27, buf31, ps14, s91, ps15, s66, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg40_1
            assert_size_stride(arg41_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg41_1 = copy_if_misaligned(arg41_1)
            ps16 = 1 + s6 + s91
            ps17 = 128 + 128*s6 + 128*s91
            buf32 = empty_strided_cuda((s16, 2, 1 + s6 + s91, 128), (256 + 256*s6 + 256*s91, 128 + 128*s6 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_7, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s6 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg41_1, buf29, buf32, ps16, s91, ps17, s6, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg41_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_7, view_3, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_7, sin_4, mul_14, q_embed_1, packed_1, expand_3, key_tensors_1, expand_4, value_tensors_1, output_1], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf33 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf30, buf31, buf32, None, False, scale=0.08838834764831845)
            del buf31
            del buf32
            buf34 = buf33[0]
            assert_tensor_metadata(buf34, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf34, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf33
            buf38 = buf30; del buf30  # reuse
            # Topologically Sorted Source Nodes: [attn_output_4], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf34, buf38, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg42_1, (1536, 1536), (1536, 1), 'input')
            buf39 = reinterpret_tensor(buf34, (s16, 1536), (1536, 1), 0); del buf34  # reuse
            # Topologically Sorted Source Nodes: [attn_output_4, transpose_8, reshape_5, attn_output_7], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf38, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg42_1, (1536, 1536), (1, 1536), 0), out=buf39)
            del arg42_1
            assert_size_stride_grouped((arg44_1, arg43_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf40 = reinterpret_tensor(buf16, (s16, 1, 1536), (1536, 1536*s16, 1), 0); del buf16  # reuse
            buf42 = reinterpret_tensor(buf38, (s16, 1, 1536), (1536, 1536, 1), 0); del buf38  # reuse
            # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_3, down_proj, hidden_states_7, attn_output_7, hidden_states_11, pow_4, variance_3, rsqrt_3, hidden_states_13, hidden_states_14], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_embedding_mean_mul_pow_rsqrt_9.run(buf40, arg1_1, arg2_1, buf22, buf39, arg44_1, arg43_1.item(), buf42, s16, 1536, stream=raw_stream0)
            del arg1_1
            del arg43_1
            del arg44_1
            assert_size_stride(arg45_1, (8960, 1536), (1536, 1), 'input')
            buf43 = reinterpret_tensor(buf21, (s16, 8960), (8960, 1), 0); del buf21  # reuse
            # Topologically Sorted Source Nodes: [pow_4, variance_3, rsqrt_3, hidden_states_13, hidden_states_14, linear_11], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf42, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg45_1, (1536, 8960), (1, 1536), 0), out=buf43)
            del arg45_1
            assert_size_stride(arg46_1, (8960, 1536), (1536, 1), 'input')
            buf44 = buf20; del buf20  # reuse
            # Topologically Sorted Source Nodes: [linear_12], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf42, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg46_1, (1536, 8960), (1, 1536), 0), out=buf44)
            del arg46_1
            buf45 = reinterpret_tensor(buf43, (s16, 1, 8960), (8960, 8960, 1), 0); del buf43  # reuse
            # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_19], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf45, buf44, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg47_1, (1536, 8960), (8960, 1), 'input')
            buf46 = reinterpret_tensor(buf42, (s16, 1536), (1536, 1), 0); del buf42  # reuse
            # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_19, down_proj_1], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf45, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg47_1, (8960, 1536), (1, 8960), 0), out=buf46)
            del arg47_1
            assert_size_stride_grouped((arg49_1, arg48_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf48 = reinterpret_tensor(buf39, (s16, 1, 1536), (1536, 1536, 1), 0); del buf39  # reuse
            # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, pow_5, variance_4, rsqrt_4, hidden_states_17, hidden_states_18], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf40, buf46, arg49_1, arg48_1.item(), buf48, s16, 1536, stream=raw_stream0)
            del arg48_1
            del arg49_1
            assert_size_stride_grouped((arg51_1, arg50_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf49 = buf22; del buf22  # reuse
            # Topologically Sorted Source Nodes: [linear_14], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg51_1, reinterpret_tensor(buf48, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg50_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf49)
            del arg50_1
            del arg51_1
            assert_size_stride_grouped((arg53_1, arg52_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf50 = buf28; del buf28  # reuse
            # Topologically Sorted Source Nodes: [linear_15], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg53_1, reinterpret_tensor(buf48, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg52_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf50)
            del arg52_1
            del arg53_1
            assert_size_stride(arg57_1, (s16, 2, s47, 128), (256*s47, 128*s47, 128, 1), 'input')
            arg57_1 = copy_if_misaligned(arg57_1)
            ps18 = 1 + s47
            ps19 = 128 + 128*s47
            ps20 = 256 + 256*s47
            buf51 = empty_strided_cuda((s16, 2, 1 + s47, 128), (256 + 256*s47, 128 + 128*s47, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_5, sin_5, linear_15, view_7, key_states_2, mul_24, x2_5, neg_5, x1_5, cat_14, mul_25, k_embed_2, cat_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s47
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg57_1, buf50, arg4_1, arg3_1, arg5_1.item(), buf51, ps18, s47, ps19, ps20, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg57_1
            assert_size_stride_grouped((arg55_1, arg54_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf52 = buf50; del buf50  # reuse
            # Topologically Sorted Source Nodes: [linear_16], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg55_1, reinterpret_tensor(buf48, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg54_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf52)
            del arg54_1
            del arg55_1
            assert_size_stride(arg59_1, (s16, 2, s87, 128), (256*s87, 128*s87, 128, 1), 'input')
            arg59_1 = copy_if_misaligned(arg59_1)
            ps21 = 1 + s87
            ps22 = 128 + 128*s87
            buf53 = empty_strided_cuda((s16, 2, 1 + s87, 128), (256 + 256*s87, 128 + 128*s87, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_16, view_8, value_states_2, cat_16], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s87
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg59_1, buf52, buf53, ps21, s87, ps22, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg59_1
            buf54 = reinterpret_tensor(buf48, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf48  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_14, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf49, arg4_1, arg3_1, arg5_1.item(), buf54, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg60_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg60_1 = copy_if_misaligned(arg60_1)
            ps23 = 1 + s47 + s91
            ps24 = 128 + 128*s47 + 128*s91
            buf55 = empty_strided_cuda((s16, 2, 1 + s47 + s91, 128), (256 + 256*s47 + 256*s91, 128 + 128*s47 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_14, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s47 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg60_1, buf51, buf55, ps23, s91, ps24, s47, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg60_1
            assert_size_stride(arg61_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg61_1 = copy_if_misaligned(arg61_1)
            ps25 = 1 + s87 + s91
            ps26 = 128 + 128*s87 + 128*s91
            buf56 = empty_strided_cuda((s16, 2, 1 + s87 + s91, 128), (256 + 256*s87 + 256*s91, 128 + 128*s87 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_14, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s87 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg61_1, buf53, buf56, ps25, s91, ps26, s87, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg61_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_14, view_6, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_13, sin_5, mul_23, q_embed_2, packed_2, expand_5, key_tensors_2, expand_6, value_tensors_2, output_2], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf57 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf54, buf55, buf56, None, False, scale=0.08838834764831845)
            del buf55
            del buf56
            buf58 = buf57[0]
            assert_tensor_metadata(buf58, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf58, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf57
            buf62 = buf54; del buf54  # reuse
            # Topologically Sorted Source Nodes: [attn_output_8], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf58, buf62, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg62_1, (1536, 1536), (1536, 1), 'input')
            buf63 = reinterpret_tensor(buf58, (s16, 1536), (1536, 1), 0); del buf58  # reuse
            # Topologically Sorted Source Nodes: [attn_output_8, transpose_12, reshape_8, attn_output_11], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf62, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg62_1, (1536, 1536), (1, 1536), 0), out=buf63)
            del arg62_1
            assert_size_stride_grouped((arg64_1, arg63_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf65 = reinterpret_tensor(buf62, (s16, 1, 1536), (1536, 1536, 1), 0); del buf62  # reuse
            # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, pow_6, variance_5, rsqrt_5, hidden_states_21, hidden_states_22], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf40, buf46, buf63, arg64_1, arg63_1.item(), buf65, s16, 1536, stream=raw_stream0)
            del arg63_1
            del arg64_1
            assert_size_stride(arg65_1, (8960, 1536), (1536, 1), 'input')
            buf66 = reinterpret_tensor(buf45, (s16, 8960), (8960, 1), 0); del buf45  # reuse
            # Topologically Sorted Source Nodes: [linear_18], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf65, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg65_1, (1536, 8960), (1, 1536), 0), out=buf66)
            del arg65_1
            assert_size_stride(arg66_1, (8960, 1536), (1536, 1), 'input')
            buf67 = buf44; del buf44  # reuse
            # Topologically Sorted Source Nodes: [linear_19], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf65, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg66_1, (1536, 8960), (1, 1536), 0), out=buf67)
            del arg66_1
            buf68 = reinterpret_tensor(buf66, (s16, 1, 8960), (8960, 8960, 1), 0); del buf66  # reuse
            # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_28], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf68, buf67, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg67_1, (1536, 8960), (8960, 1), 'input')
            buf69 = reinterpret_tensor(buf65, (s16, 1536), (1536, 1), 0); del buf65  # reuse
            # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_28, down_proj_2], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf68, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg67_1, (8960, 1536), (1, 8960), 0), out=buf69)
            del arg67_1
            assert_size_stride_grouped((arg69_1, arg68_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf71 = reinterpret_tensor(buf49, (s16, 1, 1536), (1536, 1536, 1), 0); del buf49  # reuse
            # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, down_proj_2, hidden_states_23, pow_7, variance_6, rsqrt_6, hidden_states_25, hidden_states_26], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf40, buf46, buf63, buf69, arg69_1, arg68_1.item(), buf71, s16, 1536, stream=raw_stream0)
            del arg68_1
            del arg69_1
            assert_size_stride_grouped((arg71_1, arg70_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf72 = buf25; del buf25  # reuse
            # Topologically Sorted Source Nodes: [linear_21], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg71_1, reinterpret_tensor(buf71, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg70_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf72)
            del arg70_1
            del arg71_1
            assert_size_stride_grouped((arg73_1, arg72_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf73 = buf52; del buf52  # reuse
            # Topologically Sorted Source Nodes: [linear_22], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg73_1, reinterpret_tensor(buf71, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg72_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf73)
            del arg72_1
            del arg73_1
            assert_size_stride(arg77_1, (s16, 2, s84, 128), (256*s84, 128*s84, 128, 1), 'input')
            arg77_1 = copy_if_misaligned(arg77_1)
            ps27 = 1 + s84
            ps28 = 128 + 128*s84
            ps29 = 256 + 256*s84
            buf74 = empty_strided_cuda((s16, 2, 1 + s84, 128), (256 + 256*s84, 128 + 128*s84, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_6, sin_6, linear_22, view_10, key_states_3, mul_33, x2_7, neg_7, x1_7, cat_20, mul_34, k_embed_3, cat_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s84
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg77_1, buf73, arg4_1, arg3_1, arg5_1.item(), buf74, ps27, s84, ps28, ps29, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg77_1
            assert_size_stride_grouped((arg75_1, arg74_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf75 = buf73; del buf73  # reuse
            # Topologically Sorted Source Nodes: [linear_23], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg75_1, reinterpret_tensor(buf71, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg74_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf75)
            del arg74_1
            del arg75_1
            assert_size_stride(arg79_1, (s16, 2, s19, 128), (256*s19, 128*s19, 128, 1), 'input')
            arg79_1 = copy_if_misaligned(arg79_1)
            ps30 = 1 + s19
            ps31 = 128 + 128*s19
            buf76 = empty_strided_cuda((s16, 2, 1 + s19, 128), (256 + 256*s19, 128 + 128*s19, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_23, view_11, value_states_3, cat_22], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s19
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg79_1, buf75, buf76, ps30, s19, ps31, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg79_1
            buf77 = reinterpret_tensor(buf71, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf71  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_21, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf72, arg4_1, arg3_1, arg5_1.item(), buf77, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf72
            assert_size_stride(arg80_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg80_1 = copy_if_misaligned(arg80_1)
            ps32 = 1 + s84 + s91
            ps33 = 128 + 128*s84 + 128*s91
            buf78 = empty_strided_cuda((s16, 2, 1 + s84 + s91, 128), (256 + 256*s84 + 256*s91, 128 + 128*s84 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_21, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s84 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg80_1, buf74, buf78, ps32, s91, ps33, s84, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg80_1
            assert_size_stride(arg81_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg81_1 = copy_if_misaligned(arg81_1)
            ps34 = 1 + s19 + s91
            ps35 = 128 + 128*s19 + 128*s91
            buf79 = empty_strided_cuda((s16, 2, 1 + s19 + s91, 128), (256 + 256*s19 + 256*s91, 128 + 128*s19 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_21, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s19 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg81_1, buf76, buf79, ps34, s91, ps35, s19, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg81_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_21, view_9, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_19, sin_6, mul_32, q_embed_3, packed_3, expand_7, key_tensors_3, expand_8, value_tensors_3, output_3], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf80 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf77, buf78, buf79, None, False, scale=0.08838834764831845)
            del buf78
            del buf79
            buf81 = buf80[0]
            assert_tensor_metadata(buf81, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf81, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf80
            buf85 = buf77; del buf77  # reuse
            # Topologically Sorted Source Nodes: [attn_output_12], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf81, buf85, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg82_1, (1536, 1536), (1536, 1), 'input')
            buf86 = reinterpret_tensor(buf81, (s16, 1536), (1536, 1), 0); del buf81  # reuse
            # Topologically Sorted Source Nodes: [attn_output_12, transpose_16, reshape_11, attn_output_15], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf85, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg82_1, (1536, 1536), (1, 1536), 0), out=buf86)
            del arg82_1
            assert_size_stride_grouped((arg84_1, arg83_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf87 = buf40; del buf40  # reuse
            buf89 = reinterpret_tensor(buf85, (s16, 1, 1536), (1536, 1536, 1), 0); del buf85  # reuse
            # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, attn_output_11, hidden_states_19, down_proj_2, hidden_states_23, attn_output_15, hidden_states_27, pow_8, variance_7, rsqrt_7, hidden_states_29, hidden_states_30], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf87, buf46, buf63, buf69, buf86, arg84_1, arg83_1.item(), buf89, s16, 1536, stream=raw_stream0)
            del arg83_1
            del arg84_1
            del buf46
            assert_size_stride(arg85_1, (8960, 1536), (1536, 1), 'input')
            buf90 = reinterpret_tensor(buf68, (s16, 8960), (8960, 1), 0); del buf68  # reuse
            # Topologically Sorted Source Nodes: [pow_8, variance_7, rsqrt_7, hidden_states_29, hidden_states_30, linear_25], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf89, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg85_1, (1536, 8960), (1, 1536), 0), out=buf90)
            del arg85_1
            assert_size_stride(arg86_1, (8960, 1536), (1536, 1), 'input')
            buf91 = buf67; del buf67  # reuse
            # Topologically Sorted Source Nodes: [linear_26], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf89, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg86_1, (1536, 8960), (1, 1536), 0), out=buf91)
            del arg86_1
            buf92 = reinterpret_tensor(buf90, (s16, 1, 8960), (8960, 8960, 1), 0); del buf90  # reuse
            # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_37], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf92, buf91, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg87_1, (1536, 8960), (8960, 1), 'input')
            buf93 = reinterpret_tensor(buf89, (s16, 1536), (1536, 1), 0); del buf89  # reuse
            # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_37, down_proj_3], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf92, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg87_1, (8960, 1536), (1, 8960), 0), out=buf93)
            del arg87_1
            assert_size_stride_grouped((arg89_1, arg88_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf95 = reinterpret_tensor(buf86, (s16, 1, 1536), (1536, 1536, 1), 0); del buf86  # reuse
            # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_31, pow_9, variance_8, rsqrt_8, hidden_states_33, hidden_states_34], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf87, buf93, arg89_1, arg88_1.item(), buf95, s16, 1536, stream=raw_stream0)
            del arg88_1
            del arg89_1
            assert_size_stride_grouped((arg91_1, arg90_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf96 = buf69; del buf69  # reuse
            # Topologically Sorted Source Nodes: [linear_28], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg91_1, reinterpret_tensor(buf95, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg90_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf96)
            del arg90_1
            del arg91_1
            assert_size_stride_grouped((arg93_1, arg92_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf97 = buf75; del buf75  # reuse
            # Topologically Sorted Source Nodes: [linear_29], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg93_1, reinterpret_tensor(buf95, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg92_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf97)
            del arg92_1
            del arg93_1
            assert_size_stride(arg97_1, (s16, 2, s55, 128), (256*s55, 128*s55, 128, 1), 'input')
            arg97_1 = copy_if_misaligned(arg97_1)
            ps36 = 1 + s55
            ps37 = 128 + 128*s55
            ps38 = 256 + 256*s55
            buf98 = empty_strided_cuda((s16, 2, 1 + s55, 128), (256 + 256*s55, 128 + 128*s55, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_7, sin_7, linear_29, view_13, key_states_4, mul_42, x2_9, neg_9, x1_9, cat_26, mul_43, k_embed_4, cat_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s55
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg97_1, buf97, arg4_1, arg3_1, arg5_1.item(), buf98, ps36, s55, ps37, ps38, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg97_1
            assert_size_stride_grouped((arg95_1, arg94_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf99 = buf97; del buf97  # reuse
            # Topologically Sorted Source Nodes: [linear_30], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg95_1, reinterpret_tensor(buf95, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg94_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf99)
            del arg94_1
            del arg95_1
            assert_size_stride(arg99_1, (s16, 2, s24, 128), (256*s24, 128*s24, 128, 1), 'input')
            arg99_1 = copy_if_misaligned(arg99_1)
            ps39 = 1 + s24
            ps40 = 128 + 128*s24
            buf100 = empty_strided_cuda((s16, 2, 1 + s24, 128), (256 + 256*s24, 128 + 128*s24, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_30, view_14, value_states_4, cat_28], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s24
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg99_1, buf99, buf100, ps39, s24, ps40, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg99_1
            buf101 = reinterpret_tensor(buf95, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf95  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_28, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf96, arg4_1, arg3_1, arg5_1.item(), buf101, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg100_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg100_1 = copy_if_misaligned(arg100_1)
            ps41 = 1 + s55 + s91
            ps42 = 128 + 128*s55 + 128*s91
            buf102 = empty_strided_cuda((s16, 2, 1 + s55 + s91, 128), (256 + 256*s55 + 256*s91, 128 + 128*s55 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_28, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s55 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg100_1, buf98, buf102, ps41, s91, ps42, s55, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg100_1
            assert_size_stride(arg101_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg101_1 = copy_if_misaligned(arg101_1)
            ps43 = 1 + s24 + s91
            ps44 = 128 + 128*s24 + 128*s91
            buf103 = empty_strided_cuda((s16, 2, 1 + s24 + s91, 128), (256 + 256*s24 + 256*s91, 128 + 128*s24 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_28, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s24 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg101_1, buf100, buf103, ps43, s91, ps44, s24, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg101_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_28, view_12, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_25, sin_7, mul_41, q_embed_4, packed_4, expand_9, key_tensors_4, expand_10, value_tensors_4, output_4], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf104 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf101, buf102, buf103, None, False, scale=0.08838834764831845)
            del buf102
            del buf103
            buf105 = buf104[0]
            assert_tensor_metadata(buf105, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf105, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf104
            buf109 = buf101; del buf101  # reuse
            # Topologically Sorted Source Nodes: [attn_output_16], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf105, buf109, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg102_1, (1536, 1536), (1536, 1), 'input')
            buf110 = reinterpret_tensor(buf105, (s16, 1536), (1536, 1), 0); del buf105  # reuse
            # Topologically Sorted Source Nodes: [attn_output_16, transpose_20, reshape_14, attn_output_19], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf109, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg102_1, (1536, 1536), (1, 1536), 0), out=buf110)
            del arg102_1
            assert_size_stride_grouped((arg104_1, arg103_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf112 = reinterpret_tensor(buf109, (s16, 1, 1536), (1536, 1536, 1), 0); del buf109  # reuse
            # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_31, attn_output_19, hidden_states_35, pow_10, variance_9, rsqrt_9, hidden_states_37, hidden_states_38], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf87, buf93, buf110, arg104_1, arg103_1.item(), buf112, s16, 1536, stream=raw_stream0)
            del arg103_1
            del arg104_1
            assert_size_stride(arg105_1, (8960, 1536), (1536, 1), 'input')
            buf113 = reinterpret_tensor(buf92, (s16, 8960), (8960, 1), 0); del buf92  # reuse
            # Topologically Sorted Source Nodes: [linear_32], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf112, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg105_1, (1536, 8960), (1, 1536), 0), out=buf113)
            del arg105_1
            assert_size_stride(arg106_1, (8960, 1536), (1536, 1), 'input')
            buf114 = buf91; del buf91  # reuse
            # Topologically Sorted Source Nodes: [linear_33], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf112, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg106_1, (1536, 8960), (1, 1536), 0), out=buf114)
            del arg106_1
            buf115 = reinterpret_tensor(buf113, (s16, 1, 8960), (8960, 8960, 1), 0); del buf113  # reuse
            # Topologically Sorted Source Nodes: [linear_32, silu_4, linear_33, mul_46], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf115, buf114, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg107_1, (1536, 8960), (8960, 1), 'input')
            buf116 = reinterpret_tensor(buf112, (s16, 1536), (1536, 1), 0); del buf112  # reuse
            # Topologically Sorted Source Nodes: [linear_32, silu_4, linear_33, mul_46, down_proj_4], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf115, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg107_1, (8960, 1536), (1, 8960), 0), out=buf116)
            del arg107_1
            assert_size_stride_grouped((arg109_1, arg108_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf118 = reinterpret_tensor(buf96, (s16, 1, 1536), (1536, 1536, 1), 0); del buf96  # reuse
            # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_31, attn_output_19, hidden_states_35, down_proj_4, hidden_states_39, pow_11, variance_10, rsqrt_10, hidden_states_41, hidden_states_42], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf87, buf93, buf110, buf116, arg109_1, arg108_1.item(), buf118, s16, 1536, stream=raw_stream0)
            del arg108_1
            del arg109_1
            assert_size_stride_grouped((arg111_1, arg110_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf119 = buf63; del buf63  # reuse
            # Topologically Sorted Source Nodes: [linear_35], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg111_1, reinterpret_tensor(buf118, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg110_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf119)
            del arg110_1
            del arg111_1
            assert_size_stride_grouped((arg113_1, arg112_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf120 = buf99; del buf99  # reuse
            # Topologically Sorted Source Nodes: [linear_36], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg113_1, reinterpret_tensor(buf118, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg112_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf120)
            del arg112_1
            del arg113_1
            assert_size_stride(arg117_1, (s16, 2, s95, 128), (256*s95, 128*s95, 128, 1), 'input')
            arg117_1 = copy_if_misaligned(arg117_1)
            ps45 = 1 + s95
            ps46 = 128 + 128*s95
            ps47 = 256 + 256*s95
            buf121 = empty_strided_cuda((s16, 2, 1 + s95, 128), (256 + 256*s95, 128 + 128*s95, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_8, sin_8, linear_36, view_16, key_states_5, mul_51, x2_11, neg_11, x1_11, cat_32, mul_52, k_embed_5, cat_33], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s95
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg117_1, buf120, arg4_1, arg3_1, arg5_1.item(), buf121, ps45, s95, ps46, ps47, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg117_1
            assert_size_stride_grouped((arg115_1, arg114_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf122 = buf120; del buf120  # reuse
            # Topologically Sorted Source Nodes: [linear_37], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg115_1, reinterpret_tensor(buf118, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg114_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf122)
            del arg114_1
            del arg115_1
            assert_size_stride(arg119_1, (s16, 2, s98, 128), (256*s98, 128*s98, 128, 1), 'input')
            arg119_1 = copy_if_misaligned(arg119_1)
            ps48 = 1 + s98
            ps49 = 128 + 128*s98
            buf123 = empty_strided_cuda((s16, 2, 1 + s98, 128), (256 + 256*s98, 128 + 128*s98, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_37, view_17, value_states_5, cat_34], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s98
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg119_1, buf122, buf123, ps48, s98, ps49, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg119_1
            buf124 = reinterpret_tensor(buf118, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf118  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_35, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf119, arg4_1, arg3_1, arg5_1.item(), buf124, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf119
            assert_size_stride(arg120_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg120_1 = copy_if_misaligned(arg120_1)
            ps50 = 1 + s91 + s95
            ps51 = 128 + 128*s91 + 128*s95
            buf125 = empty_strided_cuda((s16, 2, 1 + s91 + s95, 128), (256 + 256*s91 + 256*s95, 128 + 128*s91 + 128*s95, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_35, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s91 + 256*s16*s95
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg120_1, buf121, buf125, ps50, s91, ps51, s95, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg120_1
            assert_size_stride(arg121_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg121_1 = copy_if_misaligned(arg121_1)
            ps52 = 1 + s91 + s98
            ps53 = 128 + 128*s91 + 128*s98
            buf126 = empty_strided_cuda((s16, 2, 1 + s91 + s98, 128), (256 + 256*s91 + 256*s98, 128 + 128*s91 + 128*s98, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_35, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s91 + 256*s16*s98
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg121_1, buf123, buf126, ps52, s91, ps53, s98, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg121_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_35, view_15, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_31, sin_8, mul_50, q_embed_5, packed_5, expand_11, key_tensors_5, expand_12, value_tensors_5, output_5], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf127 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf124, buf125, buf126, None, False, scale=0.08838834764831845)
            del buf125
            del buf126
            buf128 = buf127[0]
            assert_tensor_metadata(buf128, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf128, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf127
            buf132 = buf124; del buf124  # reuse
            # Topologically Sorted Source Nodes: [attn_output_20], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf128, buf132, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg122_1, (1536, 1536), (1536, 1), 'input')
            buf133 = reinterpret_tensor(buf128, (s16, 1536), (1536, 1), 0); del buf128  # reuse
            # Topologically Sorted Source Nodes: [attn_output_20, transpose_24, reshape_17, attn_output_23], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf132, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg122_1, (1536, 1536), (1, 1536), 0), out=buf133)
            del arg122_1
            assert_size_stride_grouped((arg124_1, arg123_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf134 = buf87; del buf87  # reuse
            buf136 = reinterpret_tensor(buf132, (s16, 1, 1536), (1536, 1536, 1), 0); del buf132  # reuse
            # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_31, attn_output_19, hidden_states_35, down_proj_4, hidden_states_39, attn_output_23, hidden_states_43, pow_12, variance_11, rsqrt_11, hidden_states_45, hidden_states_46], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf134, buf93, buf110, buf116, buf133, arg124_1, arg123_1.item(), buf136, s16, 1536, stream=raw_stream0)
            del arg123_1
            del arg124_1
            del buf110
            assert_size_stride(arg125_1, (8960, 1536), (1536, 1), 'input')
            buf137 = reinterpret_tensor(buf115, (s16, 8960), (8960, 1), 0); del buf115  # reuse
            # Topologically Sorted Source Nodes: [pow_12, variance_11, rsqrt_11, hidden_states_45, hidden_states_46, linear_39], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf136, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg125_1, (1536, 8960), (1, 1536), 0), out=buf137)
            del arg125_1
            assert_size_stride(arg126_1, (8960, 1536), (1536, 1), 'input')
            buf138 = buf114; del buf114  # reuse
            # Topologically Sorted Source Nodes: [linear_40], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf136, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg126_1, (1536, 8960), (1, 1536), 0), out=buf138)
            del arg126_1
            buf139 = reinterpret_tensor(buf137, (s16, 1, 8960), (8960, 8960, 1), 0); del buf137  # reuse
            # Topologically Sorted Source Nodes: [linear_39, silu_5, linear_40, mul_55], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf139, buf138, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg127_1, (1536, 8960), (8960, 1), 'input')
            buf140 = reinterpret_tensor(buf136, (s16, 1536), (1536, 1), 0); del buf136  # reuse
            # Topologically Sorted Source Nodes: [linear_39, silu_5, linear_40, mul_55, down_proj_5], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf139, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg127_1, (8960, 1536), (1, 8960), 0), out=buf140)
            del arg127_1
            assert_size_stride_grouped((arg129_1, arg128_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf142 = reinterpret_tensor(buf93, (s16, 1, 1536), (1536, 1536, 1), 0); del buf93  # reuse
            # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_47, pow_13, variance_12, rsqrt_12, hidden_states_49, hidden_states_50], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf134, buf140, arg129_1, arg128_1.item(), buf142, s16, 1536, stream=raw_stream0)
            del arg128_1
            del arg129_1
            assert_size_stride_grouped((arg131_1, arg130_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf143 = buf133; del buf133  # reuse
            # Topologically Sorted Source Nodes: [linear_42], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg131_1, reinterpret_tensor(buf142, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg130_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf143)
            del arg130_1
            del arg131_1
            assert_size_stride_grouped((arg133_1, arg132_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf144 = buf122; del buf122  # reuse
            # Topologically Sorted Source Nodes: [linear_43], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg133_1, reinterpret_tensor(buf142, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg132_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf144)
            del arg132_1
            del arg133_1
            assert_size_stride(arg137_1, (s16, 2, s22, 128), (256*s22, 128*s22, 128, 1), 'input')
            arg137_1 = copy_if_misaligned(arg137_1)
            ps54 = 1 + s22
            ps55 = 128 + 128*s22
            ps56 = 256 + 256*s22
            buf145 = empty_strided_cuda((s16, 2, 1 + s22, 128), (256 + 256*s22, 128 + 128*s22, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_9, sin_9, linear_43, view_19, key_states_6, mul_60, x2_13, neg_13, x1_13, cat_38, mul_61, k_embed_6, cat_39], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s22
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg137_1, buf144, arg4_1, arg3_1, arg5_1.item(), buf145, ps54, s22, ps55, ps56, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg137_1
            assert_size_stride_grouped((arg135_1, arg134_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf146 = buf144; del buf144  # reuse
            # Topologically Sorted Source Nodes: [linear_44], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg135_1, reinterpret_tensor(buf142, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg134_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf146)
            del arg134_1
            del arg135_1
            assert_size_stride(arg139_1, (s16, 2, s80, 128), (256*s80, 128*s80, 128, 1), 'input')
            arg139_1 = copy_if_misaligned(arg139_1)
            ps57 = 1 + s80
            ps58 = 128 + 128*s80
            buf147 = empty_strided_cuda((s16, 2, 1 + s80, 128), (256 + 256*s80, 128 + 128*s80, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_44, view_20, value_states_6, cat_40], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s80
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg139_1, buf146, buf147, ps57, s80, ps58, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg139_1
            buf148 = reinterpret_tensor(buf142, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf142  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf143, arg4_1, arg3_1, arg5_1.item(), buf148, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg140_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg140_1 = copy_if_misaligned(arg140_1)
            ps59 = 1 + s22 + s91
            ps60 = 128 + 128*s22 + 128*s91
            buf149 = empty_strided_cuda((s16, 2, 1 + s22 + s91, 128), (256 + 256*s22 + 256*s91, 128 + 128*s22 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s22 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg140_1, buf145, buf149, ps59, s91, ps60, s22, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg140_1
            assert_size_stride(arg141_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg141_1 = copy_if_misaligned(arg141_1)
            ps61 = 1 + s80 + s91
            ps62 = 128 + 128*s80 + 128*s91
            buf150 = empty_strided_cuda((s16, 2, 1 + s80 + s91, 128), (256 + 256*s80 + 256*s91, 128 + 128*s80 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s80 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg141_1, buf147, buf150, ps61, s91, ps62, s80, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg141_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_42, view_18, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_37, sin_9, mul_59, q_embed_6, packed_6, expand_13, key_tensors_6, expand_14, value_tensors_6, output_6], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf151 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf148, buf149, buf150, None, False, scale=0.08838834764831845)
            del buf149
            del buf150
            buf152 = buf151[0]
            assert_tensor_metadata(buf152, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf152, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf151
            buf156 = buf148; del buf148  # reuse
            # Topologically Sorted Source Nodes: [attn_output_24], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf152, buf156, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg142_1, (1536, 1536), (1536, 1), 'input')
            buf157 = reinterpret_tensor(buf152, (s16, 1536), (1536, 1), 0); del buf152  # reuse
            # Topologically Sorted Source Nodes: [attn_output_24, transpose_28, reshape_20, attn_output_27], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf156, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg142_1, (1536, 1536), (1, 1536), 0), out=buf157)
            del arg142_1
            assert_size_stride_grouped((arg144_1, arg143_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf159 = reinterpret_tensor(buf156, (s16, 1, 1536), (1536, 1536, 1), 0); del buf156  # reuse
            # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_47, attn_output_27, hidden_states_51, pow_14, variance_13, rsqrt_13, hidden_states_53, hidden_states_54], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf134, buf140, buf157, arg144_1, arg143_1.item(), buf159, s16, 1536, stream=raw_stream0)
            del arg143_1
            del arg144_1
            assert_size_stride(arg145_1, (8960, 1536), (1536, 1), 'input')
            buf160 = reinterpret_tensor(buf139, (s16, 8960), (8960, 1), 0); del buf139  # reuse
            # Topologically Sorted Source Nodes: [linear_46], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf159, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg145_1, (1536, 8960), (1, 1536), 0), out=buf160)
            del arg145_1
            assert_size_stride(arg146_1, (8960, 1536), (1536, 1), 'input')
            buf161 = buf138; del buf138  # reuse
            # Topologically Sorted Source Nodes: [linear_47], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf159, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg146_1, (1536, 8960), (1, 1536), 0), out=buf161)
            del arg146_1
            buf162 = reinterpret_tensor(buf160, (s16, 1, 8960), (8960, 8960, 1), 0); del buf160  # reuse
            # Topologically Sorted Source Nodes: [linear_46, silu_6, linear_47, mul_64], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf162, buf161, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg147_1, (1536, 8960), (8960, 1), 'input')
            buf163 = reinterpret_tensor(buf159, (s16, 1536), (1536, 1), 0); del buf159  # reuse
            # Topologically Sorted Source Nodes: [linear_46, silu_6, linear_47, mul_64, down_proj_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf162, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg147_1, (8960, 1536), (1, 8960), 0), out=buf163)
            del arg147_1
            assert_size_stride_grouped((arg149_1, arg148_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf165 = reinterpret_tensor(buf143, (s16, 1, 1536), (1536, 1536, 1), 0); del buf143  # reuse
            # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_47, attn_output_27, hidden_states_51, down_proj_6, hidden_states_55, pow_15, variance_14, rsqrt_14, hidden_states_57, hidden_states_58], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf134, buf140, buf157, buf163, arg149_1, arg148_1.item(), buf165, s16, 1536, stream=raw_stream0)
            del arg148_1
            del arg149_1
            assert_size_stride_grouped((arg151_1, arg150_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf166 = buf116; del buf116  # reuse
            # Topologically Sorted Source Nodes: [linear_49], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg151_1, reinterpret_tensor(buf165, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg150_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf166)
            del arg150_1
            del arg151_1
            assert_size_stride_grouped((arg153_1, arg152_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf167 = buf146; del buf146  # reuse
            # Topologically Sorted Source Nodes: [linear_50], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg153_1, reinterpret_tensor(buf165, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg152_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf167)
            del arg152_1
            del arg153_1
            assert_size_stride(arg157_1, (s16, 2, s37, 128), (256*s37, 128*s37, 128, 1), 'input')
            arg157_1 = copy_if_misaligned(arg157_1)
            ps63 = 1 + s37
            ps64 = 128 + 128*s37
            ps65 = 256 + 256*s37
            buf168 = empty_strided_cuda((s16, 2, 1 + s37, 128), (256 + 256*s37, 128 + 128*s37, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_10, sin_10, linear_50, view_22, key_states_7, mul_69, x2_15, neg_15, x1_15, cat_44, mul_70, k_embed_7, cat_45], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s37
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg157_1, buf167, arg4_1, arg3_1, arg5_1.item(), buf168, ps63, s37, ps64, ps65, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg157_1
            assert_size_stride_grouped((arg155_1, arg154_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf169 = buf167; del buf167  # reuse
            # Topologically Sorted Source Nodes: [linear_51], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg155_1, reinterpret_tensor(buf165, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg154_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf169)
            del arg154_1
            del arg155_1
            assert_size_stride(arg159_1, (s16, 2, s2, 128), (256*s2, 128*s2, 128, 1), 'input')
            arg159_1 = copy_if_misaligned(arg159_1)
            ps66 = 1 + s2
            ps67 = 128 + 128*s2
            buf170 = empty_strided_cuda((s16, 2, 1 + s2, 128), (256 + 256*s2, 128 + 128*s2, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_51, view_23, value_states_7, cat_46], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s2
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg159_1, buf169, buf170, ps66, s2, ps67, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg159_1
            buf171 = reinterpret_tensor(buf165, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf165  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_49, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf166, arg4_1, arg3_1, arg5_1.item(), buf171, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf166
            assert_size_stride(arg160_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg160_1 = copy_if_misaligned(arg160_1)
            ps68 = 1 + s37 + s91
            ps69 = 128 + 128*s37 + 128*s91
            buf172 = empty_strided_cuda((s16, 2, 1 + s37 + s91, 128), (256 + 256*s37 + 256*s91, 128 + 128*s37 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_49, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s37 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg160_1, buf168, buf172, ps68, s91, ps69, s37, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg160_1
            assert_size_stride(arg161_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg161_1 = copy_if_misaligned(arg161_1)
            ps70 = 1 + s2 + s91
            ps71 = 128 + 128*s2 + 128*s91
            buf173 = empty_strided_cuda((s16, 2, 1 + s2 + s91, 128), (256 + 256*s2 + 256*s91, 128 + 128*s2 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_49, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s2 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg161_1, buf170, buf173, ps70, s91, ps71, s2, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg161_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_49, view_21, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_43, sin_10, mul_68, q_embed_7, packed_7, expand_15, key_tensors_7, expand_16, value_tensors_7, output_7], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf174 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf171, buf172, buf173, None, False, scale=0.08838834764831845)
            del buf172
            del buf173
            buf175 = buf174[0]
            assert_tensor_metadata(buf175, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf175, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf174
            buf179 = buf171; del buf171  # reuse
            # Topologically Sorted Source Nodes: [attn_output_28], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf175, buf179, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg162_1, (1536, 1536), (1536, 1), 'input')
            buf180 = reinterpret_tensor(buf175, (s16, 1536), (1536, 1), 0); del buf175  # reuse
            # Topologically Sorted Source Nodes: [attn_output_28, transpose_32, reshape_23, attn_output_31], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf179, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg162_1, (1536, 1536), (1, 1536), 0), out=buf180)
            del arg162_1
            assert_size_stride_grouped((arg164_1, arg163_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf181 = buf134; del buf134  # reuse
            buf183 = reinterpret_tensor(buf179, (s16, 1, 1536), (1536, 1536, 1), 0); del buf179  # reuse
            # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_47, attn_output_27, hidden_states_51, down_proj_6, hidden_states_55, attn_output_31, hidden_states_59, pow_16, variance_15, rsqrt_15, hidden_states_61, hidden_states_62], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf181, buf140, buf157, buf163, buf180, arg164_1, arg163_1.item(), buf183, s16, 1536, stream=raw_stream0)
            del arg163_1
            del arg164_1
            del buf140
            assert_size_stride(arg165_1, (8960, 1536), (1536, 1), 'input')
            buf184 = reinterpret_tensor(buf162, (s16, 8960), (8960, 1), 0); del buf162  # reuse
            # Topologically Sorted Source Nodes: [pow_16, variance_15, rsqrt_15, hidden_states_61, hidden_states_62, linear_53], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf183, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg165_1, (1536, 8960), (1, 1536), 0), out=buf184)
            del arg165_1
            assert_size_stride(arg166_1, (8960, 1536), (1536, 1), 'input')
            buf185 = buf161; del buf161  # reuse
            # Topologically Sorted Source Nodes: [linear_54], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf183, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg166_1, (1536, 8960), (1, 1536), 0), out=buf185)
            del arg166_1
            buf186 = reinterpret_tensor(buf184, (s16, 1, 8960), (8960, 8960, 1), 0); del buf184  # reuse
            # Topologically Sorted Source Nodes: [linear_53, silu_7, linear_54, mul_73], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf186, buf185, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg167_1, (1536, 8960), (8960, 1), 'input')
            buf187 = reinterpret_tensor(buf183, (s16, 1536), (1536, 1), 0); del buf183  # reuse
            # Topologically Sorted Source Nodes: [linear_53, silu_7, linear_54, mul_73, down_proj_7], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf186, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg167_1, (8960, 1536), (1, 8960), 0), out=buf187)
            del arg167_1
            assert_size_stride_grouped((arg169_1, arg168_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf189 = reinterpret_tensor(buf180, (s16, 1, 1536), (1536, 1536, 1), 0); del buf180  # reuse
            # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_63, pow_17, variance_16, rsqrt_16, hidden_states_65, hidden_states_66], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf181, buf187, arg169_1, arg168_1.item(), buf189, s16, 1536, stream=raw_stream0)
            del arg168_1
            del arg169_1
            assert_size_stride_grouped((arg171_1, arg170_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf190 = buf163; del buf163  # reuse
            # Topologically Sorted Source Nodes: [linear_56], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg171_1, reinterpret_tensor(buf189, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg170_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf190)
            del arg170_1
            del arg171_1
            assert_size_stride_grouped((arg173_1, arg172_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf191 = buf169; del buf169  # reuse
            # Topologically Sorted Source Nodes: [linear_57], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg173_1, reinterpret_tensor(buf189, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg172_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf191)
            del arg172_1
            del arg173_1
            assert_size_stride(arg177_1, (s16, 2, s96, 128), (256*s96, 128*s96, 128, 1), 'input')
            arg177_1 = copy_if_misaligned(arg177_1)
            ps72 = 1 + s96
            ps73 = 128 + 128*s96
            ps74 = 256 + 256*s96
            buf192 = empty_strided_cuda((s16, 2, 1 + s96, 128), (256 + 256*s96, 128 + 128*s96, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_11, sin_11, linear_57, view_25, key_states_8, mul_78, x2_17, neg_17, x1_17, cat_50, mul_79, k_embed_8, cat_51], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s96
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg177_1, buf191, arg4_1, arg3_1, arg5_1.item(), buf192, ps72, s96, ps73, ps74, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg177_1
            assert_size_stride_grouped((arg175_1, arg174_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf193 = buf191; del buf191  # reuse
            # Topologically Sorted Source Nodes: [linear_58], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg175_1, reinterpret_tensor(buf189, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg174_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf193)
            del arg174_1
            del arg175_1
            assert_size_stride(arg179_1, (s16, 2, s34, 128), (256*s34, 128*s34, 128, 1), 'input')
            arg179_1 = copy_if_misaligned(arg179_1)
            ps75 = 1 + s34
            ps76 = 128 + 128*s34
            buf194 = empty_strided_cuda((s16, 2, 1 + s34, 128), (256 + 256*s34, 128 + 128*s34, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_58, view_26, value_states_8, cat_52], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s34
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg179_1, buf193, buf194, ps75, s34, ps76, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg179_1
            buf195 = reinterpret_tensor(buf189, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf189  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_56, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf190, arg4_1, arg3_1, arg5_1.item(), buf195, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg180_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg180_1 = copy_if_misaligned(arg180_1)
            ps77 = 1 + s91 + s96
            ps78 = 128 + 128*s91 + 128*s96
            buf196 = empty_strided_cuda((s16, 2, 1 + s91 + s96, 128), (256 + 256*s91 + 256*s96, 128 + 128*s91 + 128*s96, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_56, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s91 + 256*s16*s96
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg180_1, buf192, buf196, ps77, s91, ps78, s96, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg180_1
            assert_size_stride(arg181_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg181_1 = copy_if_misaligned(arg181_1)
            ps79 = 1 + s34 + s91
            ps80 = 128 + 128*s34 + 128*s91
            buf197 = empty_strided_cuda((s16, 2, 1 + s34 + s91, 128), (256 + 256*s34 + 256*s91, 128 + 128*s34 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_56, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s34 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg181_1, buf194, buf197, ps79, s91, ps80, s34, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg181_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_56, view_24, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_49, sin_11, mul_77, q_embed_8, packed_8, expand_17, key_tensors_8, expand_18, value_tensors_8, output_8], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf198 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf195, buf196, buf197, None, False, scale=0.08838834764831845)
            del buf196
            del buf197
            buf199 = buf198[0]
            assert_tensor_metadata(buf199, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf199, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf198
            buf203 = buf195; del buf195  # reuse
            # Topologically Sorted Source Nodes: [attn_output_32], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf199, buf203, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg182_1, (1536, 1536), (1536, 1), 'input')
            buf204 = reinterpret_tensor(buf199, (s16, 1536), (1536, 1), 0); del buf199  # reuse
            # Topologically Sorted Source Nodes: [attn_output_32, transpose_36, reshape_26, attn_output_35], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf203, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg182_1, (1536, 1536), (1, 1536), 0), out=buf204)
            del arg182_1
            assert_size_stride_grouped((arg184_1, arg183_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf206 = reinterpret_tensor(buf203, (s16, 1, 1536), (1536, 1536, 1), 0); del buf203  # reuse
            # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_63, attn_output_35, hidden_states_67, pow_18, variance_17, rsqrt_17, hidden_states_69, hidden_states_70], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf181, buf187, buf204, arg184_1, arg183_1.item(), buf206, s16, 1536, stream=raw_stream0)
            del arg183_1
            del arg184_1
            assert_size_stride(arg185_1, (8960, 1536), (1536, 1), 'input')
            buf207 = reinterpret_tensor(buf186, (s16, 8960), (8960, 1), 0); del buf186  # reuse
            # Topologically Sorted Source Nodes: [linear_60], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf206, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg185_1, (1536, 8960), (1, 1536), 0), out=buf207)
            del arg185_1
            assert_size_stride(arg186_1, (8960, 1536), (1536, 1), 'input')
            buf208 = buf185; del buf185  # reuse
            # Topologically Sorted Source Nodes: [linear_61], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf206, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg186_1, (1536, 8960), (1, 1536), 0), out=buf208)
            del arg186_1
            buf209 = reinterpret_tensor(buf207, (s16, 1, 8960), (8960, 8960, 1), 0); del buf207  # reuse
            # Topologically Sorted Source Nodes: [linear_60, silu_8, linear_61, mul_82], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf209, buf208, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg187_1, (1536, 8960), (8960, 1), 'input')
            buf210 = reinterpret_tensor(buf206, (s16, 1536), (1536, 1), 0); del buf206  # reuse
            # Topologically Sorted Source Nodes: [linear_60, silu_8, linear_61, mul_82, down_proj_8], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf209, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg187_1, (8960, 1536), (1, 8960), 0), out=buf210)
            del arg187_1
            assert_size_stride_grouped((arg189_1, arg188_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf212 = reinterpret_tensor(buf190, (s16, 1, 1536), (1536, 1536, 1), 0); del buf190  # reuse
            # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_63, attn_output_35, hidden_states_67, down_proj_8, hidden_states_71, pow_19, variance_18, rsqrt_18, hidden_states_73, hidden_states_74], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf181, buf187, buf204, buf210, arg189_1, arg188_1.item(), buf212, s16, 1536, stream=raw_stream0)
            del arg188_1
            del arg189_1
            assert_size_stride_grouped((arg191_1, arg190_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf213 = buf157; del buf157  # reuse
            # Topologically Sorted Source Nodes: [linear_63], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg191_1, reinterpret_tensor(buf212, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg190_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf213)
            del arg190_1
            del arg191_1
            assert_size_stride_grouped((arg193_1, arg192_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf214 = buf193; del buf193  # reuse
            # Topologically Sorted Source Nodes: [linear_64], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg193_1, reinterpret_tensor(buf212, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg192_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf214)
            del arg192_1
            del arg193_1
            assert_size_stride(arg197_1, (s16, 2, s64, 128), (256*s64, 128*s64, 128, 1), 'input')
            arg197_1 = copy_if_misaligned(arg197_1)
            ps81 = 1 + s64
            ps82 = 128 + 128*s64
            ps83 = 256 + 256*s64
            buf215 = empty_strided_cuda((s16, 2, 1 + s64, 128), (256 + 256*s64, 128 + 128*s64, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_12, sin_12, linear_64, view_28, key_states_9, mul_87, x2_19, neg_19, x1_19, cat_56, mul_88, k_embed_9, cat_57], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s64
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg197_1, buf214, arg4_1, arg3_1, arg5_1.item(), buf215, ps81, s64, ps82, ps83, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg197_1
            assert_size_stride_grouped((arg195_1, arg194_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf216 = buf214; del buf214  # reuse
            # Topologically Sorted Source Nodes: [linear_65], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg195_1, reinterpret_tensor(buf212, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg194_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf216)
            del arg194_1
            del arg195_1
            assert_size_stride(arg199_1, (s16, 2, s4, 128), (256*s4, 128*s4, 128, 1), 'input')
            arg199_1 = copy_if_misaligned(arg199_1)
            ps84 = 1 + s4
            ps85 = 128 + 128*s4
            buf217 = empty_strided_cuda((s16, 2, 1 + s4, 128), (256 + 256*s4, 128 + 128*s4, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_65, view_29, value_states_9, cat_58], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s4
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg199_1, buf216, buf217, ps84, s4, ps85, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg199_1
            buf218 = reinterpret_tensor(buf212, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf212  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_63, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf213, arg4_1, arg3_1, arg5_1.item(), buf218, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf213
            assert_size_stride(arg200_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg200_1 = copy_if_misaligned(arg200_1)
            ps86 = 1 + s64 + s91
            ps87 = 128 + 128*s64 + 128*s91
            buf219 = empty_strided_cuda((s16, 2, 1 + s64 + s91, 128), (256 + 256*s64 + 256*s91, 128 + 128*s64 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_63, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s64 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg200_1, buf215, buf219, ps86, s91, ps87, s64, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg200_1
            assert_size_stride(arg201_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg201_1 = copy_if_misaligned(arg201_1)
            ps88 = 1 + s4 + s91
            ps89 = 128 + 128*s4 + 128*s91
            buf220 = empty_strided_cuda((s16, 2, 1 + s4 + s91, 128), (256 + 256*s4 + 256*s91, 128 + 128*s4 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_63, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s4 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg201_1, buf217, buf220, ps88, s91, ps89, s4, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg201_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_63, view_27, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_55, sin_12, mul_86, q_embed_9, packed_9, expand_19, key_tensors_9, expand_20, value_tensors_9, output_9], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf221 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf218, buf219, buf220, None, False, scale=0.08838834764831845)
            del buf219
            del buf220
            buf222 = buf221[0]
            assert_tensor_metadata(buf222, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf222, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf221
            buf226 = buf218; del buf218  # reuse
            # Topologically Sorted Source Nodes: [attn_output_36], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf222, buf226, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg202_1, (1536, 1536), (1536, 1), 'input')
            buf227 = reinterpret_tensor(buf222, (s16, 1536), (1536, 1), 0); del buf222  # reuse
            # Topologically Sorted Source Nodes: [attn_output_36, transpose_40, reshape_29, attn_output_39], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf226, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg202_1, (1536, 1536), (1, 1536), 0), out=buf227)
            del arg202_1
            assert_size_stride(arg203_1, (1536, ), (1, ), 'input')
            buf228 = buf181; del buf181  # reuse
            buf230 = reinterpret_tensor(buf226, (s16, 1, 1536), (1536, 1536, 1), 0); del buf226  # reuse
            # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_63, attn_output_35, hidden_states_67, down_proj_8, hidden_states_71, attn_output_39, hidden_states_75, pow_20, variance_19, add_58, rsqrt_19, hidden_states_77, hidden_states_78], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_14.run(buf228, buf187, buf204, buf210, buf227, arg203_1, buf230, s16, 1536, stream=raw_stream0)
            del arg203_1
            del buf187
            assert_size_stride(arg204_1, (8960, 1536), (1536, 1), 'input')
            buf231 = reinterpret_tensor(buf209, (s16, 8960), (8960, 1), 0); del buf209  # reuse
            # Topologically Sorted Source Nodes: [pow_20, variance_19, add_58, rsqrt_19, hidden_states_77, hidden_states_78, linear_67], Original ATen: [aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf230, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg204_1, (1536, 8960), (1, 1536), 0), out=buf231)
            del arg204_1
            assert_size_stride(arg205_1, (8960, 1536), (1536, 1), 'input')
            buf232 = buf208; del buf208  # reuse
            # Topologically Sorted Source Nodes: [linear_68], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf230, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg205_1, (1536, 8960), (1, 1536), 0), out=buf232)
            del arg205_1
            buf233 = reinterpret_tensor(buf231, (s16, 1, 8960), (8960, 8960, 1), 0); del buf231  # reuse
            # Topologically Sorted Source Nodes: [linear_67, silu_9, linear_68, mul_91], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf233, buf232, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg206_1, (1536, 8960), (8960, 1), 'input')
            buf234 = reinterpret_tensor(buf230, (s16, 1536), (1536, 1), 0); del buf230  # reuse
            # Topologically Sorted Source Nodes: [linear_67, silu_9, linear_68, mul_91, down_proj_9], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf233, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg206_1, (8960, 1536), (1, 8960), 0), out=buf234)
            del arg206_1
            assert_size_stride_grouped((arg208_1, arg207_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf236 = reinterpret_tensor(buf227, (s16, 1, 1536), (1536, 1536, 1), 0); del buf227  # reuse
            # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_79, pow_21, variance_20, rsqrt_20, hidden_states_81, hidden_states_82], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf228, buf234, arg208_1, arg207_1.item(), buf236, s16, 1536, stream=raw_stream0)
            del arg207_1
            del arg208_1
            assert_size_stride_grouped((arg210_1, arg209_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf237 = buf210; del buf210  # reuse
            # Topologically Sorted Source Nodes: [linear_70], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg210_1, reinterpret_tensor(buf236, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg209_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf237)
            del arg209_1
            del arg210_1
            assert_size_stride_grouped((arg212_1, arg211_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf238 = buf216; del buf216  # reuse
            # Topologically Sorted Source Nodes: [linear_71], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg212_1, reinterpret_tensor(buf236, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg211_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf238)
            del arg211_1
            del arg212_1
            assert_size_stride(arg216_1, (s16, 2, s43, 128), (256*s43, 128*s43, 128, 1), 'input')
            arg216_1 = copy_if_misaligned(arg216_1)
            ps90 = 1 + s43
            ps91 = 128 + 128*s43
            ps92 = 256 + 256*s43
            buf239 = empty_strided_cuda((s16, 2, 1 + s43, 128), (256 + 256*s43, 128 + 128*s43, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_13, sin_13, linear_71, view_31, key_states_10, mul_96, x2_21, neg_21, x1_21, cat_62, mul_97, k_embed_10, cat_63], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s43
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg216_1, buf238, arg4_1, arg3_1, arg5_1.item(), buf239, ps90, s43, ps91, ps92, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg216_1
            assert_size_stride_grouped((arg214_1, arg213_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf240 = buf238; del buf238  # reuse
            # Topologically Sorted Source Nodes: [linear_72], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg214_1, reinterpret_tensor(buf236, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg213_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf240)
            del arg213_1
            del arg214_1
            assert_size_stride(arg218_1, (s16, 2, s17, 128), (256*s17, 128*s17, 128, 1), 'input')
            arg218_1 = copy_if_misaligned(arg218_1)
            ps93 = 1 + s17
            ps94 = 128 + 128*s17
            buf241 = empty_strided_cuda((s16, 2, 1 + s17, 128), (256 + 256*s17, 128 + 128*s17, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_72, view_32, value_states_10, cat_64], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s17
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg218_1, buf240, buf241, ps93, s17, ps94, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg218_1
            buf242 = reinterpret_tensor(buf236, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf236  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_70, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf237, arg4_1, arg3_1, arg5_1.item(), buf242, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg219_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg219_1 = copy_if_misaligned(arg219_1)
            ps95 = 1 + s43 + s91
            ps96 = 128 + 128*s43 + 128*s91
            buf243 = empty_strided_cuda((s16, 2, 1 + s43 + s91, 128), (256 + 256*s43 + 256*s91, 128 + 128*s43 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_70, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s43 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg219_1, buf239, buf243, ps95, s91, ps96, s43, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg219_1
            assert_size_stride(arg220_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg220_1 = copy_if_misaligned(arg220_1)
            ps97 = 1 + s17 + s91
            ps98 = 128 + 128*s17 + 128*s91
            buf244 = empty_strided_cuda((s16, 2, 1 + s17 + s91, 128), (256 + 256*s17 + 256*s91, 128 + 128*s17 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_70, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s17 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg220_1, buf241, buf244, ps97, s91, ps98, s17, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg220_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_70, view_30, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_61, sin_13, mul_95, q_embed_10, packed_10, expand_21, key_tensors_10, expand_22, value_tensors_10, output_10], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf245 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf242, buf243, buf244, None, False, scale=0.08838834764831845)
            del buf243
            del buf244
            buf246 = buf245[0]
            assert_tensor_metadata(buf246, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf246, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf245
            buf250 = buf242; del buf242  # reuse
            # Topologically Sorted Source Nodes: [attn_output_40], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf246, buf250, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg221_1, (1536, 1536), (1536, 1), 'input')
            buf251 = reinterpret_tensor(buf246, (s16, 1536), (1536, 1), 0); del buf246  # reuse
            # Topologically Sorted Source Nodes: [attn_output_40, transpose_44, reshape_32, attn_output_43], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf250, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg221_1, (1536, 1536), (1, 1536), 0), out=buf251)
            del arg221_1
            assert_size_stride(arg222_1, (1536, ), (1, ), 'input')
            buf253 = reinterpret_tensor(buf250, (s16, 1, 1536), (1536, 1536, 1), 0); del buf250  # reuse
            # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_79, attn_output_43, hidden_states_83, pow_22, variance_21, add_64, rsqrt_21, hidden_states_85, hidden_states_86], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_15.run(buf228, buf234, buf251, arg222_1, buf253, s16, 1536, stream=raw_stream0)
            del arg222_1
            assert_size_stride(arg223_1, (8960, 1536), (1536, 1), 'input')
            buf254 = reinterpret_tensor(buf233, (s16, 8960), (8960, 1), 0); del buf233  # reuse
            # Topologically Sorted Source Nodes: [linear_74], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf253, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg223_1, (1536, 8960), (1, 1536), 0), out=buf254)
            del arg223_1
            assert_size_stride(arg224_1, (8960, 1536), (1536, 1), 'input')
            buf255 = buf232; del buf232  # reuse
            # Topologically Sorted Source Nodes: [linear_75], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf253, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg224_1, (1536, 8960), (1, 1536), 0), out=buf255)
            del arg224_1
            buf256 = reinterpret_tensor(buf254, (s16, 1, 8960), (8960, 8960, 1), 0); del buf254  # reuse
            # Topologically Sorted Source Nodes: [linear_74, silu_10, linear_75, mul_100], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf256, buf255, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg225_1, (1536, 8960), (8960, 1), 'input')
            buf257 = reinterpret_tensor(buf253, (s16, 1536), (1536, 1), 0); del buf253  # reuse
            # Topologically Sorted Source Nodes: [linear_74, silu_10, linear_75, mul_100, down_proj_10], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf256, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg225_1, (8960, 1536), (1, 8960), 0), out=buf257)
            del arg225_1
            assert_size_stride_grouped((arg227_1, arg226_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf259 = reinterpret_tensor(buf237, (s16, 1, 1536), (1536, 1536, 1), 0); del buf237  # reuse
            # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_79, attn_output_43, hidden_states_83, down_proj_10, hidden_states_87, pow_23, variance_22, rsqrt_22, hidden_states_89, hidden_states_90], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf228, buf234, buf251, buf257, arg227_1, arg226_1.item(), buf259, s16, 1536, stream=raw_stream0)
            del arg226_1
            del arg227_1
            assert_size_stride_grouped((arg229_1, arg228_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf260 = buf204; del buf204  # reuse
            # Topologically Sorted Source Nodes: [linear_77], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg229_1, reinterpret_tensor(buf259, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg228_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf260)
            del arg228_1
            del arg229_1
            assert_size_stride_grouped((arg231_1, arg230_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf261 = buf240; del buf240  # reuse
            # Topologically Sorted Source Nodes: [linear_78], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg231_1, reinterpret_tensor(buf259, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg230_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf261)
            del arg230_1
            del arg231_1
            assert_size_stride(arg235_1, (s16, 2, s73, 128), (256*s73, 128*s73, 128, 1), 'input')
            arg235_1 = copy_if_misaligned(arg235_1)
            ps99 = 1 + s73
            ps100 = 128 + 128*s73
            ps101 = 256 + 256*s73
            buf262 = empty_strided_cuda((s16, 2, 1 + s73, 128), (256 + 256*s73, 128 + 128*s73, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_14, sin_14, linear_78, view_34, key_states_11, mul_105, x2_23, neg_23, x1_23, cat_68, mul_106, k_embed_11, cat_69], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s73
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg235_1, buf261, arg4_1, arg3_1, arg5_1.item(), buf262, ps99, s73, ps100, ps101, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg235_1
            assert_size_stride_grouped((arg233_1, arg232_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf263 = buf261; del buf261  # reuse
            # Topologically Sorted Source Nodes: [linear_79], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg233_1, reinterpret_tensor(buf259, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg232_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf263)
            del arg232_1
            del arg233_1
            assert_size_stride(arg237_1, (s16, 2, s31, 128), (256*s31, 128*s31, 128, 1), 'input')
            arg237_1 = copy_if_misaligned(arg237_1)
            ps102 = 1 + s31
            ps103 = 128 + 128*s31
            buf264 = empty_strided_cuda((s16, 2, 1 + s31, 128), (256 + 256*s31, 128 + 128*s31, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_79, view_35, value_states_11, cat_70], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s31
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg237_1, buf263, buf264, ps102, s31, ps103, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg237_1
            buf265 = reinterpret_tensor(buf259, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf259  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_77, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf260, arg4_1, arg3_1, arg5_1.item(), buf265, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf260
            assert_size_stride(arg238_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg238_1 = copy_if_misaligned(arg238_1)
            ps104 = 1 + s73 + s91
            ps105 = 128 + 128*s73 + 128*s91
            buf266 = empty_strided_cuda((s16, 2, 1 + s73 + s91, 128), (256 + 256*s73 + 256*s91, 128 + 128*s73 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_77, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s73 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg238_1, buf262, buf266, ps104, s91, ps105, s73, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg238_1
            assert_size_stride(arg239_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg239_1 = copy_if_misaligned(arg239_1)
            ps106 = 1 + s31 + s91
            ps107 = 128 + 128*s31 + 128*s91
            buf267 = empty_strided_cuda((s16, 2, 1 + s31 + s91, 128), (256 + 256*s31 + 256*s91, 128 + 128*s31 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_77, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s31 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg239_1, buf264, buf267, ps106, s91, ps107, s31, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg239_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_77, view_33, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_67, sin_14, mul_104, q_embed_11, packed_11, expand_23, key_tensors_11, expand_24, value_tensors_11, output_11], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf268 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf265, buf266, buf267, None, False, scale=0.08838834764831845)
            del buf266
            del buf267
            buf269 = buf268[0]
            assert_tensor_metadata(buf269, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf269, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf268
            buf273 = buf265; del buf265  # reuse
            # Topologically Sorted Source Nodes: [attn_output_44], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf269, buf273, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg240_1, (1536, 1536), (1536, 1), 'input')
            buf274 = reinterpret_tensor(buf269, (s16, 1536), (1536, 1), 0); del buf269  # reuse
            # Topologically Sorted Source Nodes: [attn_output_44, transpose_48, reshape_35, attn_output_47], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf273, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg240_1, (1536, 1536), (1, 1536), 0), out=buf274)
            del arg240_1
            assert_size_stride_grouped((arg242_1, arg241_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf275 = buf228; del buf228  # reuse
            buf277 = reinterpret_tensor(buf273, (s16, 1, 1536), (1536, 1536, 1), 0); del buf273  # reuse
            # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_79, attn_output_43, hidden_states_83, down_proj_10, hidden_states_87, attn_output_47, hidden_states_91, pow_24, variance_23, rsqrt_23, hidden_states_93, hidden_states_94], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf275, buf234, buf251, buf257, buf274, arg242_1, arg241_1.item(), buf277, s16, 1536, stream=raw_stream0)
            del arg241_1
            del arg242_1
            del buf234
            assert_size_stride(arg243_1, (8960, 1536), (1536, 1), 'input')
            buf278 = reinterpret_tensor(buf256, (s16, 8960), (8960, 1), 0); del buf256  # reuse
            # Topologically Sorted Source Nodes: [pow_24, variance_23, rsqrt_23, hidden_states_93, hidden_states_94, linear_81], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf277, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg243_1, (1536, 8960), (1, 1536), 0), out=buf278)
            del arg243_1
            assert_size_stride(arg244_1, (8960, 1536), (1536, 1), 'input')
            buf279 = buf255; del buf255  # reuse
            # Topologically Sorted Source Nodes: [linear_82], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf277, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg244_1, (1536, 8960), (1, 1536), 0), out=buf279)
            del arg244_1
            buf280 = reinterpret_tensor(buf278, (s16, 1, 8960), (8960, 8960, 1), 0); del buf278  # reuse
            # Topologically Sorted Source Nodes: [linear_81, silu_11, linear_82, mul_109], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf280, buf279, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg245_1, (1536, 8960), (8960, 1), 'input')
            buf281 = reinterpret_tensor(buf277, (s16, 1536), (1536, 1), 0); del buf277  # reuse
            # Topologically Sorted Source Nodes: [linear_81, silu_11, linear_82, mul_109, down_proj_11], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf280, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg245_1, (8960, 1536), (1, 8960), 0), out=buf281)
            del arg245_1
            assert_size_stride_grouped((arg247_1, arg246_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf283 = reinterpret_tensor(buf274, (s16, 1, 1536), (1536, 1536, 1), 0); del buf274  # reuse
            # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_95, pow_25, variance_24, rsqrt_24, hidden_states_97, hidden_states_98], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf275, buf281, arg247_1, arg246_1.item(), buf283, s16, 1536, stream=raw_stream0)
            del arg246_1
            del arg247_1
            assert_size_stride_grouped((arg249_1, arg248_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf284 = buf257; del buf257  # reuse
            # Topologically Sorted Source Nodes: [linear_84], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg249_1, reinterpret_tensor(buf283, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg248_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf284)
            del arg248_1
            del arg249_1
            assert_size_stride_grouped((arg251_1, arg250_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf285 = buf263; del buf263  # reuse
            # Topologically Sorted Source Nodes: [linear_85], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg251_1, reinterpret_tensor(buf283, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg250_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf285)
            del arg250_1
            del arg251_1
            assert_size_stride(arg255_1, (s16, 2, s63, 128), (256*s63, 128*s63, 128, 1), 'input')
            arg255_1 = copy_if_misaligned(arg255_1)
            ps108 = 1 + s63
            ps109 = 128 + 128*s63
            ps110 = 256 + 256*s63
            buf286 = empty_strided_cuda((s16, 2, 1 + s63, 128), (256 + 256*s63, 128 + 128*s63, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_15, sin_15, linear_85, view_37, key_states_12, mul_114, x2_25, neg_25, x1_25, cat_74, mul_115, k_embed_12, cat_75], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s63
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg255_1, buf285, arg4_1, arg3_1, arg5_1.item(), buf286, ps108, s63, ps109, ps110, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg255_1
            assert_size_stride_grouped((arg253_1, arg252_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf287 = buf285; del buf285  # reuse
            # Topologically Sorted Source Nodes: [linear_86], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg253_1, reinterpret_tensor(buf283, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg252_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf287)
            del arg252_1
            del arg253_1
            assert_size_stride(arg257_1, (s16, 2, s65, 128), (256*s65, 128*s65, 128, 1), 'input')
            arg257_1 = copy_if_misaligned(arg257_1)
            ps111 = 1 + s65
            ps112 = 128 + 128*s65
            buf288 = empty_strided_cuda((s16, 2, 1 + s65, 128), (256 + 256*s65, 128 + 128*s65, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_86, view_38, value_states_12, cat_76], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s65
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg257_1, buf287, buf288, ps111, s65, ps112, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg257_1
            buf289 = reinterpret_tensor(buf283, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf283  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf284, arg4_1, arg3_1, arg5_1.item(), buf289, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg258_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg258_1 = copy_if_misaligned(arg258_1)
            ps113 = 1 + s63 + s91
            ps114 = 128 + 128*s63 + 128*s91
            buf290 = empty_strided_cuda((s16, 2, 1 + s63 + s91, 128), (256 + 256*s63 + 256*s91, 128 + 128*s63 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s63 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg258_1, buf286, buf290, ps113, s91, ps114, s63, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg258_1
            assert_size_stride(arg259_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg259_1 = copy_if_misaligned(arg259_1)
            ps115 = 1 + s65 + s91
            ps116 = 128 + 128*s65 + 128*s91
            buf291 = empty_strided_cuda((s16, 2, 1 + s65 + s91, 128), (256 + 256*s65 + 256*s91, 128 + 128*s65 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s65 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg259_1, buf288, buf291, ps115, s91, ps116, s65, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg259_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_84, view_36, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_73, sin_15, mul_113, q_embed_12, packed_12, expand_25, key_tensors_12, expand_26, value_tensors_12, output_12], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf292 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf289, buf290, buf291, None, False, scale=0.08838834764831845)
            del buf290
            del buf291
            buf293 = buf292[0]
            assert_tensor_metadata(buf293, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf293, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf292
            buf297 = buf289; del buf289  # reuse
            # Topologically Sorted Source Nodes: [attn_output_48], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf293, buf297, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg260_1, (1536, 1536), (1536, 1), 'input')
            buf298 = reinterpret_tensor(buf293, (s16, 1536), (1536, 1), 0); del buf293  # reuse
            # Topologically Sorted Source Nodes: [attn_output_48, transpose_52, reshape_38, attn_output_51], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf297, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg260_1, (1536, 1536), (1, 1536), 0), out=buf298)
            del arg260_1
            assert_size_stride_grouped((arg262_1, arg261_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf300 = reinterpret_tensor(buf297, (s16, 1, 1536), (1536, 1536, 1), 0); del buf297  # reuse
            # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_95, attn_output_51, hidden_states_99, pow_26, variance_25, rsqrt_25, hidden_states_101, hidden_states_102], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf275, buf281, buf298, arg262_1, arg261_1.item(), buf300, s16, 1536, stream=raw_stream0)
            del arg261_1
            del arg262_1
            assert_size_stride(arg263_1, (8960, 1536), (1536, 1), 'input')
            buf301 = reinterpret_tensor(buf280, (s16, 8960), (8960, 1), 0); del buf280  # reuse
            # Topologically Sorted Source Nodes: [linear_88], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf300, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg263_1, (1536, 8960), (1, 1536), 0), out=buf301)
            del arg263_1
            assert_size_stride(arg264_1, (8960, 1536), (1536, 1), 'input')
            buf302 = buf279; del buf279  # reuse
            # Topologically Sorted Source Nodes: [linear_89], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf300, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg264_1, (1536, 8960), (1, 1536), 0), out=buf302)
            del arg264_1
            buf303 = reinterpret_tensor(buf301, (s16, 1, 8960), (8960, 8960, 1), 0); del buf301  # reuse
            # Topologically Sorted Source Nodes: [linear_88, silu_12, linear_89, mul_118], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf303, buf302, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg265_1, (1536, 8960), (8960, 1), 'input')
            buf304 = reinterpret_tensor(buf300, (s16, 1536), (1536, 1), 0); del buf300  # reuse
            # Topologically Sorted Source Nodes: [linear_88, silu_12, linear_89, mul_118, down_proj_12], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf303, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg265_1, (8960, 1536), (1, 8960), 0), out=buf304)
            del arg265_1
            assert_size_stride_grouped((arg267_1, arg266_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf306 = reinterpret_tensor(buf284, (s16, 1, 1536), (1536, 1536, 1), 0); del buf284  # reuse
            # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_95, attn_output_51, hidden_states_99, down_proj_12, hidden_states_103, pow_27, variance_26, rsqrt_26, hidden_states_105, hidden_states_106], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf275, buf281, buf298, buf304, arg267_1, arg266_1.item(), buf306, s16, 1536, stream=raw_stream0)
            del arg266_1
            del arg267_1
            assert_size_stride_grouped((arg269_1, arg268_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf307 = buf251; del buf251  # reuse
            # Topologically Sorted Source Nodes: [linear_91], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg269_1, reinterpret_tensor(buf306, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg268_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf307)
            del arg268_1
            del arg269_1
            assert_size_stride_grouped((arg271_1, arg270_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf308 = buf287; del buf287  # reuse
            # Topologically Sorted Source Nodes: [linear_92], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg271_1, reinterpret_tensor(buf306, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg270_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf308)
            del arg270_1
            del arg271_1
            assert_size_stride(arg275_1, (s16, 2, s29, 128), (256*s29, 128*s29, 128, 1), 'input')
            arg275_1 = copy_if_misaligned(arg275_1)
            ps117 = 1 + s29
            ps118 = 128 + 128*s29
            ps119 = 256 + 256*s29
            buf309 = empty_strided_cuda((s16, 2, 1 + s29, 128), (256 + 256*s29, 128 + 128*s29, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_16, sin_16, linear_92, view_40, key_states_13, mul_123, x2_27, neg_27, x1_27, cat_80, mul_124, k_embed_13, cat_81], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s29
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg275_1, buf308, arg4_1, arg3_1, arg5_1.item(), buf309, ps117, s29, ps118, ps119, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg275_1
            assert_size_stride_grouped((arg273_1, arg272_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf310 = buf308; del buf308  # reuse
            # Topologically Sorted Source Nodes: [linear_93], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg273_1, reinterpret_tensor(buf306, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg272_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf310)
            del arg272_1
            del arg273_1
            assert_size_stride(arg277_1, (s16, 2, s45, 128), (256*s45, 128*s45, 128, 1), 'input')
            arg277_1 = copy_if_misaligned(arg277_1)
            ps120 = 1 + s45
            ps121 = 128 + 128*s45
            buf311 = empty_strided_cuda((s16, 2, 1 + s45, 128), (256 + 256*s45, 128 + 128*s45, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_93, view_41, value_states_13, cat_82], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s45
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg277_1, buf310, buf311, ps120, s45, ps121, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg277_1
            buf312 = reinterpret_tensor(buf306, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf306  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_91, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf307, arg4_1, arg3_1, arg5_1.item(), buf312, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf307
            assert_size_stride(arg278_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg278_1 = copy_if_misaligned(arg278_1)
            ps122 = 1 + s29 + s91
            ps123 = 128 + 128*s29 + 128*s91
            buf313 = empty_strided_cuda((s16, 2, 1 + s29 + s91, 128), (256 + 256*s29 + 256*s91, 128 + 128*s29 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_91, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s29 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg278_1, buf309, buf313, ps122, s91, ps123, s29, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg278_1
            assert_size_stride(arg279_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg279_1 = copy_if_misaligned(arg279_1)
            ps124 = 1 + s45 + s91
            ps125 = 128 + 128*s45 + 128*s91
            buf314 = empty_strided_cuda((s16, 2, 1 + s45 + s91, 128), (256 + 256*s45 + 256*s91, 128 + 128*s45 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_91, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s45 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg279_1, buf311, buf314, ps124, s91, ps125, s45, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg279_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_91, view_39, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_79, sin_16, mul_122, q_embed_13, packed_13, expand_27, key_tensors_13, expand_28, value_tensors_13, output_13], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf315 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf312, buf313, buf314, None, False, scale=0.08838834764831845)
            del buf313
            del buf314
            buf316 = buf315[0]
            assert_tensor_metadata(buf316, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf316, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf315
            buf320 = buf312; del buf312  # reuse
            # Topologically Sorted Source Nodes: [attn_output_52], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf316, buf320, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg280_1, (1536, 1536), (1536, 1), 'input')
            buf321 = reinterpret_tensor(buf316, (s16, 1536), (1536, 1), 0); del buf316  # reuse
            # Topologically Sorted Source Nodes: [attn_output_52, transpose_56, reshape_41, attn_output_55], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf320, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg280_1, (1536, 1536), (1, 1536), 0), out=buf321)
            del arg280_1
            assert_size_stride_grouped((arg282_1, arg281_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf322 = buf275; del buf275  # reuse
            buf324 = reinterpret_tensor(buf320, (s16, 1, 1536), (1536, 1536, 1), 0); del buf320  # reuse
            # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_95, attn_output_51, hidden_states_99, down_proj_12, hidden_states_103, attn_output_55, hidden_states_107, pow_28, variance_27, rsqrt_27, hidden_states_109, hidden_states_110], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf322, buf281, buf298, buf304, buf321, arg282_1, arg281_1.item(), buf324, s16, 1536, stream=raw_stream0)
            del arg281_1
            del arg282_1
            del buf281
            assert_size_stride(arg283_1, (8960, 1536), (1536, 1), 'input')
            buf325 = reinterpret_tensor(buf303, (s16, 8960), (8960, 1), 0); del buf303  # reuse
            # Topologically Sorted Source Nodes: [pow_28, variance_27, rsqrt_27, hidden_states_109, hidden_states_110, linear_95], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf324, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg283_1, (1536, 8960), (1, 1536), 0), out=buf325)
            del arg283_1
            assert_size_stride(arg284_1, (8960, 1536), (1536, 1), 'input')
            buf326 = buf302; del buf302  # reuse
            # Topologically Sorted Source Nodes: [linear_96], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf324, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg284_1, (1536, 8960), (1, 1536), 0), out=buf326)
            del arg284_1
            buf327 = reinterpret_tensor(buf325, (s16, 1, 8960), (8960, 8960, 1), 0); del buf325  # reuse
            # Topologically Sorted Source Nodes: [linear_95, silu_13, linear_96, mul_127], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf327, buf326, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg285_1, (1536, 8960), (8960, 1), 'input')
            buf328 = reinterpret_tensor(buf324, (s16, 1536), (1536, 1), 0); del buf324  # reuse
            # Topologically Sorted Source Nodes: [linear_95, silu_13, linear_96, mul_127, down_proj_13], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf327, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg285_1, (8960, 1536), (1, 8960), 0), out=buf328)
            del arg285_1
            assert_size_stride(arg286_1, (1536, ), (1, ), 'input')
            buf330 = reinterpret_tensor(buf321, (s16, 1, 1536), (1536, 1536, 1), 0); del buf321  # reuse
            # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, pow_29, variance_28, add_84, rsqrt_28, hidden_states_113, hidden_states_114], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_16.run(buf322, buf328, arg286_1, buf330, s16, 1536, stream=raw_stream0)
            del arg286_1
            assert_size_stride_grouped((arg288_1, arg287_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf331 = buf304; del buf304  # reuse
            # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, pow_29, variance_28, add_84, rsqrt_28, hidden_states_113, hidden_states_114, linear_98], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg288_1, reinterpret_tensor(buf330, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg287_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf331)
            del arg287_1
            del arg288_1
            assert_size_stride_grouped((arg290_1, arg289_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf332 = buf310; del buf310  # reuse
            # Topologically Sorted Source Nodes: [linear_99], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg290_1, reinterpret_tensor(buf330, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg289_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf332)
            del arg289_1
            del arg290_1
            assert_size_stride(arg294_1, (s16, 2, s23, 128), (256*s23, 128*s23, 128, 1), 'input')
            arg294_1 = copy_if_misaligned(arg294_1)
            ps126 = 1 + s23
            ps127 = 128 + 128*s23
            ps128 = 256 + 256*s23
            buf333 = empty_strided_cuda((s16, 2, 1 + s23, 128), (256 + 256*s23, 128 + 128*s23, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_17, sin_17, linear_99, view_43, key_states_14, mul_132, x2_29, neg_29, x1_29, cat_86, mul_133, k_embed_14, cat_87], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s23
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg294_1, buf332, arg4_1, arg3_1, arg5_1.item(), buf333, ps126, s23, ps127, ps128, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg294_1
            assert_size_stride_grouped((arg292_1, arg291_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf334 = buf332; del buf332  # reuse
            # Topologically Sorted Source Nodes: [linear_100], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg292_1, reinterpret_tensor(buf330, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg291_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf334)
            del arg291_1
            del arg292_1
            assert_size_stride(arg296_1, (s16, 2, s101, 128), (256*s101, 128*s101, 128, 1), 'input')
            arg296_1 = copy_if_misaligned(arg296_1)
            ps129 = 1 + s101
            ps130 = 128 + 128*s101
            buf335 = empty_strided_cuda((s16, 2, 1 + s101, 128), (256 + 256*s101, 128 + 128*s101, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_100, view_44, value_states_14, cat_88], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s101*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg296_1, buf334, buf335, ps129, s101, ps130, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg296_1
            buf336 = reinterpret_tensor(buf330, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf330  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_98, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf331, arg4_1, arg3_1, arg5_1.item(), buf336, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg297_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg297_1 = copy_if_misaligned(arg297_1)
            ps131 = 1 + s23 + s91
            ps132 = 128 + 128*s23 + 128*s91
            buf337 = empty_strided_cuda((s16, 2, 1 + s23 + s91, 128), (256 + 256*s23 + 256*s91, 128 + 128*s23 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_98, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s23 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg297_1, buf333, buf337, ps131, s91, ps132, s23, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg297_1
            assert_size_stride(arg298_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg298_1 = copy_if_misaligned(arg298_1)
            ps133 = 1 + s101 + s91
            ps134 = 128 + 128*s101 + 128*s91
            buf338 = empty_strided_cuda((s16, 2, 1 + s101 + s91, 128), (256 + 256*s101 + 256*s91, 128 + 128*s101 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_98, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s101*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg298_1, buf335, buf338, ps133, s91, ps134, s101, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg298_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_98, view_42, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_85, sin_17, mul_131, q_embed_14, packed_14, expand_29, key_tensors_14, expand_30, value_tensors_14, output_14], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf339 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf336, buf337, buf338, None, False, scale=0.08838834764831845)
            del buf337
            del buf338
            buf340 = buf339[0]
            assert_tensor_metadata(buf340, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf340, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf339
            buf344 = buf336; del buf336  # reuse
            # Topologically Sorted Source Nodes: [attn_output_56], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf340, buf344, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg299_1, (1536, 1536), (1536, 1), 'input')
            buf345 = reinterpret_tensor(buf340, (s16, 1536), (1536, 1), 0); del buf340  # reuse
            # Topologically Sorted Source Nodes: [attn_output_56, transpose_60, reshape_44, attn_output_59], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf344, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg299_1, (1536, 1536), (1, 1536), 0), out=buf345)
            del arg299_1
            assert_size_stride_grouped((arg301_1, arg300_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf347 = reinterpret_tensor(buf344, (s16, 1, 1536), (1536, 1536, 1), 0); del buf344  # reuse
            # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, attn_output_59, hidden_states_115, pow_30, variance_29, rsqrt_29, hidden_states_117, hidden_states_118], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf322, buf328, buf345, arg301_1, arg300_1.item(), buf347, s16, 1536, stream=raw_stream0)
            del arg300_1
            del arg301_1
            assert_size_stride(arg302_1, (8960, 1536), (1536, 1), 'input')
            buf348 = reinterpret_tensor(buf327, (s16, 8960), (8960, 1), 0); del buf327  # reuse
            # Topologically Sorted Source Nodes: [linear_102], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf347, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg302_1, (1536, 8960), (1, 1536), 0), out=buf348)
            del arg302_1
            assert_size_stride(arg303_1, (8960, 1536), (1536, 1), 'input')
            buf349 = buf326; del buf326  # reuse
            # Topologically Sorted Source Nodes: [linear_103], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf347, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg303_1, (1536, 8960), (1, 1536), 0), out=buf349)
            del arg303_1
            buf350 = reinterpret_tensor(buf348, (s16, 1, 8960), (8960, 8960, 1), 0); del buf348  # reuse
            # Topologically Sorted Source Nodes: [linear_102, silu_14, linear_103, mul_136], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf350, buf349, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg304_1, (1536, 8960), (8960, 1), 'input')
            buf351 = reinterpret_tensor(buf347, (s16, 1536), (1536, 1), 0); del buf347  # reuse
            # Topologically Sorted Source Nodes: [linear_102, silu_14, linear_103, mul_136, down_proj_14], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf350, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg304_1, (8960, 1536), (1, 8960), 0), out=buf351)
            del arg304_1
            assert_size_stride(arg305_1, (1536, ), (1, ), 'input')
            buf353 = reinterpret_tensor(buf331, (s16, 1, 1536), (1536, 1536, 1), 0); del buf331  # reuse
            # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, attn_output_59, hidden_states_115, down_proj_14, hidden_states_119, pow_31, variance_30, add_90, rsqrt_30, hidden_states_121, hidden_states_122], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_17.run(buf322, buf328, buf345, buf351, arg305_1, buf353, s16, 1536, stream=raw_stream0)
            del arg305_1
            assert_size_stride_grouped((arg307_1, arg306_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf354 = buf298; del buf298  # reuse
            # Topologically Sorted Source Nodes: [linear_105], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg307_1, reinterpret_tensor(buf353, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg306_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf354)
            del arg306_1
            del arg307_1
            assert_size_stride_grouped((arg309_1, arg308_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf355 = buf334; del buf334  # reuse
            # Topologically Sorted Source Nodes: [linear_106], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg309_1, reinterpret_tensor(buf353, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg308_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf355)
            del arg308_1
            del arg309_1
            assert_size_stride(arg313_1, (s16, 2, s51, 128), (256*s51, 128*s51, 128, 1), 'input')
            arg313_1 = copy_if_misaligned(arg313_1)
            ps135 = 1 + s51
            ps136 = 128 + 128*s51
            ps137 = 256 + 256*s51
            buf356 = empty_strided_cuda((s16, 2, 1 + s51, 128), (256 + 256*s51, 128 + 128*s51, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_18, sin_18, linear_106, view_46, key_states_15, mul_141, x2_31, neg_31, x1_31, cat_92, mul_142, k_embed_15, cat_93], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s51
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg313_1, buf355, arg4_1, arg3_1, arg5_1.item(), buf356, ps135, s51, ps136, ps137, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg313_1
            assert_size_stride_grouped((arg311_1, arg310_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf357 = buf355; del buf355  # reuse
            # Topologically Sorted Source Nodes: [linear_107], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg311_1, reinterpret_tensor(buf353, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg310_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf357)
            del arg310_1
            del arg311_1
            assert_size_stride(arg315_1, (s16, 2, s103, 128), (256*s103, 128*s103, 128, 1), 'input')
            arg315_1 = copy_if_misaligned(arg315_1)
            ps138 = 1 + s103
            ps139 = 128 + 128*s103
            buf358 = empty_strided_cuda((s16, 2, 1 + s103, 128), (256 + 256*s103, 128 + 128*s103, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_107, view_47, value_states_15, cat_94], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s103*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg315_1, buf357, buf358, ps138, s103, ps139, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg315_1
            buf359 = reinterpret_tensor(buf353, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf353  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_105, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf354, arg4_1, arg3_1, arg5_1.item(), buf359, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf354
            assert_size_stride(arg316_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg316_1 = copy_if_misaligned(arg316_1)
            ps140 = 1 + s51 + s91
            ps141 = 128 + 128*s51 + 128*s91
            buf360 = empty_strided_cuda((s16, 2, 1 + s51 + s91, 128), (256 + 256*s51 + 256*s91, 128 + 128*s51 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_105, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s51 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg316_1, buf356, buf360, ps140, s91, ps141, s51, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg316_1
            assert_size_stride(arg317_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg317_1 = copy_if_misaligned(arg317_1)
            ps142 = 1 + s103 + s91
            ps143 = 128 + 128*s103 + 128*s91
            buf361 = empty_strided_cuda((s16, 2, 1 + s103 + s91, 128), (256 + 256*s103 + 256*s91, 128 + 128*s103 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_105, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s103*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg317_1, buf358, buf361, ps142, s91, ps143, s103, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg317_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_105, view_45, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_91, sin_18, mul_140, q_embed_15, packed_15, expand_31, key_tensors_15, expand_32, value_tensors_15, output_15], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf362 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf359, buf360, buf361, None, False, scale=0.08838834764831845)
            del buf360
            del buf361
            buf363 = buf362[0]
            assert_tensor_metadata(buf363, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf363, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf362
            buf367 = buf359; del buf359  # reuse
            # Topologically Sorted Source Nodes: [attn_output_60], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf363, buf367, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg318_1, (1536, 1536), (1536, 1), 'input')
            buf368 = reinterpret_tensor(buf363, (s16, 1536), (1536, 1), 0); del buf363  # reuse
            # Topologically Sorted Source Nodes: [attn_output_60, transpose_64, reshape_47, attn_output_63], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf367, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg318_1, (1536, 1536), (1, 1536), 0), out=buf368)
            del arg318_1
            assert_size_stride_grouped((arg320_1, arg319_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf369 = buf322; del buf322  # reuse
            buf371 = reinterpret_tensor(buf367, (s16, 1, 1536), (1536, 1536, 1), 0); del buf367  # reuse
            # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_111, attn_output_59, hidden_states_115, down_proj_14, hidden_states_119, attn_output_63, hidden_states_123, pow_32, variance_31, rsqrt_31, hidden_states_125, hidden_states_126], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf369, buf328, buf345, buf351, buf368, arg320_1, arg319_1.item(), buf371, s16, 1536, stream=raw_stream0)
            del arg319_1
            del arg320_1
            del buf328
            assert_size_stride(arg321_1, (8960, 1536), (1536, 1), 'input')
            buf372 = reinterpret_tensor(buf350, (s16, 8960), (8960, 1), 0); del buf350  # reuse
            # Topologically Sorted Source Nodes: [pow_32, variance_31, rsqrt_31, hidden_states_125, hidden_states_126, linear_109], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf371, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg321_1, (1536, 8960), (1, 1536), 0), out=buf372)
            del arg321_1
            assert_size_stride(arg322_1, (8960, 1536), (1536, 1), 'input')
            buf373 = buf349; del buf349  # reuse
            # Topologically Sorted Source Nodes: [linear_110], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf371, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg322_1, (1536, 8960), (1, 1536), 0), out=buf373)
            del arg322_1
            buf374 = reinterpret_tensor(buf372, (s16, 1, 8960), (8960, 8960, 1), 0); del buf372  # reuse
            # Topologically Sorted Source Nodes: [linear_109, silu_15, linear_110, mul_145], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf374, buf373, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg323_1, (1536, 8960), (8960, 1), 'input')
            buf375 = reinterpret_tensor(buf371, (s16, 1536), (1536, 1), 0); del buf371  # reuse
            # Topologically Sorted Source Nodes: [linear_109, silu_15, linear_110, mul_145, down_proj_15], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf374, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg323_1, (8960, 1536), (1, 8960), 0), out=buf375)
            del arg323_1
            assert_size_stride_grouped((arg325_1, arg324_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf377 = reinterpret_tensor(buf368, (s16, 1, 1536), (1536, 1536, 1), 0); del buf368  # reuse
            # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_127, pow_33, variance_32, rsqrt_32, hidden_states_129, hidden_states_130], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf369, buf375, arg325_1, arg324_1.item(), buf377, s16, 1536, stream=raw_stream0)
            del arg324_1
            del arg325_1
            assert_size_stride_grouped((arg327_1, arg326_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf378 = buf351; del buf351  # reuse
            # Topologically Sorted Source Nodes: [linear_112], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg327_1, reinterpret_tensor(buf377, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg326_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf378)
            del arg326_1
            del arg327_1
            assert_size_stride_grouped((arg329_1, arg328_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf379 = buf357; del buf357  # reuse
            # Topologically Sorted Source Nodes: [linear_113], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg329_1, reinterpret_tensor(buf377, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg328_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf379)
            del arg328_1
            del arg329_1
            assert_size_stride(arg333_1, (s16, 2, s32, 128), (256*s32, 128*s32, 128, 1), 'input')
            arg333_1 = copy_if_misaligned(arg333_1)
            ps144 = 1 + s32
            ps145 = 128 + 128*s32
            ps146 = 256 + 256*s32
            buf380 = empty_strided_cuda((s16, 2, 1 + s32, 128), (256 + 256*s32, 128 + 128*s32, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_19, sin_19, linear_113, view_49, key_states_16, mul_150, x2_33, neg_33, x1_33, cat_98, mul_151, k_embed_16, cat_99], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s32
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg333_1, buf379, arg4_1, arg3_1, arg5_1.item(), buf380, ps144, s32, ps145, ps146, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg333_1
            assert_size_stride_grouped((arg331_1, arg330_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf381 = buf379; del buf379  # reuse
            # Topologically Sorted Source Nodes: [linear_114], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg331_1, reinterpret_tensor(buf377, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg330_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf381)
            del arg330_1
            del arg331_1
            assert_size_stride(arg335_1, (s16, 2, s68, 128), (256*s68, 128*s68, 128, 1), 'input')
            arg335_1 = copy_if_misaligned(arg335_1)
            ps147 = 1 + s68
            ps148 = 128 + 128*s68
            buf382 = empty_strided_cuda((s16, 2, 1 + s68, 128), (256 + 256*s68, 128 + 128*s68, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_114, view_50, value_states_16, cat_100], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s68
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg335_1, buf381, buf382, ps147, s68, ps148, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg335_1
            buf383 = reinterpret_tensor(buf377, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf377  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_112, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf378, arg4_1, arg3_1, arg5_1.item(), buf383, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg336_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg336_1 = copy_if_misaligned(arg336_1)
            ps149 = 1 + s32 + s91
            ps150 = 128 + 128*s32 + 128*s91
            buf384 = empty_strided_cuda((s16, 2, 1 + s32 + s91, 128), (256 + 256*s32 + 256*s91, 128 + 128*s32 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_112, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s32 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg336_1, buf380, buf384, ps149, s91, ps150, s32, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg336_1
            assert_size_stride(arg337_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg337_1 = copy_if_misaligned(arg337_1)
            ps151 = 1 + s68 + s91
            ps152 = 128 + 128*s68 + 128*s91
            buf385 = empty_strided_cuda((s16, 2, 1 + s68 + s91, 128), (256 + 256*s68 + 256*s91, 128 + 128*s68 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_112, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s68 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg337_1, buf382, buf385, ps151, s91, ps152, s68, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg337_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_112, view_48, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_97, sin_19, mul_149, q_embed_16, packed_16, expand_33, key_tensors_16, expand_34, value_tensors_16, output_16], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf386 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf383, buf384, buf385, None, False, scale=0.08838834764831845)
            del buf384
            del buf385
            buf387 = buf386[0]
            assert_tensor_metadata(buf387, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf387, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf386
            buf391 = buf383; del buf383  # reuse
            # Topologically Sorted Source Nodes: [attn_output_64], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf387, buf391, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg338_1, (1536, 1536), (1536, 1), 'input')
            buf392 = reinterpret_tensor(buf387, (s16, 1536), (1536, 1), 0); del buf387  # reuse
            # Topologically Sorted Source Nodes: [attn_output_64, transpose_68, reshape_50, attn_output_67], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf391, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg338_1, (1536, 1536), (1, 1536), 0), out=buf392)
            del arg338_1
            assert_size_stride_grouped((arg340_1, arg339_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf394 = reinterpret_tensor(buf391, (s16, 1, 1536), (1536, 1536, 1), 0); del buf391  # reuse
            # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_127, attn_output_67, hidden_states_131, pow_34, variance_33, rsqrt_33, hidden_states_133, hidden_states_134], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf369, buf375, buf392, arg340_1, arg339_1.item(), buf394, s16, 1536, stream=raw_stream0)
            del arg339_1
            del arg340_1
            assert_size_stride(arg341_1, (8960, 1536), (1536, 1), 'input')
            buf395 = reinterpret_tensor(buf374, (s16, 8960), (8960, 1), 0); del buf374  # reuse
            # Topologically Sorted Source Nodes: [linear_116], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf394, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg341_1, (1536, 8960), (1, 1536), 0), out=buf395)
            del arg341_1
            assert_size_stride(arg342_1, (8960, 1536), (1536, 1), 'input')
            buf396 = buf373; del buf373  # reuse
            # Topologically Sorted Source Nodes: [linear_117], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf394, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg342_1, (1536, 8960), (1, 1536), 0), out=buf396)
            del arg342_1
            buf397 = reinterpret_tensor(buf395, (s16, 1, 8960), (8960, 8960, 1), 0); del buf395  # reuse
            # Topologically Sorted Source Nodes: [linear_116, silu_16, linear_117, mul_154], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf397, buf396, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg343_1, (1536, 8960), (8960, 1), 'input')
            buf398 = reinterpret_tensor(buf394, (s16, 1536), (1536, 1), 0); del buf394  # reuse
            # Topologically Sorted Source Nodes: [linear_116, silu_16, linear_117, mul_154, down_proj_16], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf397, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg343_1, (8960, 1536), (1, 8960), 0), out=buf398)
            del arg343_1
            assert_size_stride(arg344_1, (1536, ), (1, ), 'input')
            buf400 = reinterpret_tensor(buf378, (s16, 1, 1536), (1536, 1536, 1), 0); del buf378  # reuse
            # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_127, attn_output_67, hidden_states_131, down_proj_16, hidden_states_135, pow_35, variance_34, add_102, rsqrt_34, hidden_states_137, hidden_states_138], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_17.run(buf369, buf375, buf392, buf398, arg344_1, buf400, s16, 1536, stream=raw_stream0)
            del arg344_1
            assert_size_stride_grouped((arg346_1, arg345_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf401 = buf345; del buf345  # reuse
            # Topologically Sorted Source Nodes: [linear_119], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg346_1, reinterpret_tensor(buf400, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg345_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf401)
            del arg345_1
            del arg346_1
            assert_size_stride_grouped((arg348_1, arg347_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf402 = buf381; del buf381  # reuse
            # Topologically Sorted Source Nodes: [linear_120], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg348_1, reinterpret_tensor(buf400, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg347_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf402)
            del arg347_1
            del arg348_1
            assert_size_stride(arg352_1, (s16, 2, s77, 128), (256*s77, 128*s77, 128, 1), 'input')
            arg352_1 = copy_if_misaligned(arg352_1)
            ps153 = 1 + s77
            ps154 = 128 + 128*s77
            ps155 = 256 + 256*s77
            buf403 = empty_strided_cuda((s16, 2, 1 + s77, 128), (256 + 256*s77, 128 + 128*s77, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_20, sin_20, linear_120, view_52, key_states_17, mul_159, x2_35, neg_35, x1_35, cat_104, mul_160, k_embed_17, cat_105], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s77
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg352_1, buf402, arg4_1, arg3_1, arg5_1.item(), buf403, ps153, s77, ps154, ps155, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg352_1
            assert_size_stride_grouped((arg350_1, arg349_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf404 = buf402; del buf402  # reuse
            # Topologically Sorted Source Nodes: [linear_121], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg350_1, reinterpret_tensor(buf400, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg349_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf404)
            del arg349_1
            del arg350_1
            assert_size_stride(arg354_1, (s16, 2, s78, 128), (256*s78, 128*s78, 128, 1), 'input')
            arg354_1 = copy_if_misaligned(arg354_1)
            ps156 = 1 + s78
            ps157 = 128 + 128*s78
            buf405 = empty_strided_cuda((s16, 2, 1 + s78, 128), (256 + 256*s78, 128 + 128*s78, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_121, view_53, value_states_17, cat_106], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s78
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg354_1, buf404, buf405, ps156, s78, ps157, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg354_1
            buf406 = reinterpret_tensor(buf400, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf400  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_119, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf401, arg4_1, arg3_1, arg5_1.item(), buf406, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf401
            assert_size_stride(arg355_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg355_1 = copy_if_misaligned(arg355_1)
            ps158 = 1 + s77 + s91
            ps159 = 128 + 128*s77 + 128*s91
            buf407 = empty_strided_cuda((s16, 2, 1 + s77 + s91, 128), (256 + 256*s77 + 256*s91, 128 + 128*s77 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_119, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s77 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg355_1, buf403, buf407, ps158, s91, ps159, s77, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg355_1
            assert_size_stride(arg356_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg356_1 = copy_if_misaligned(arg356_1)
            ps160 = 1 + s78 + s91
            ps161 = 128 + 128*s78 + 128*s91
            buf408 = empty_strided_cuda((s16, 2, 1 + s78 + s91, 128), (256 + 256*s78 + 256*s91, 128 + 128*s78 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_119, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s78 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg356_1, buf405, buf408, ps160, s91, ps161, s78, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg356_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_119, view_51, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_103, sin_20, mul_158, q_embed_17, packed_17, expand_35, key_tensors_17, expand_36, value_tensors_17, output_17], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf409 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf406, buf407, buf408, None, False, scale=0.08838834764831845)
            del buf407
            del buf408
            buf410 = buf409[0]
            assert_tensor_metadata(buf410, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf410, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf409
            buf414 = buf406; del buf406  # reuse
            # Topologically Sorted Source Nodes: [attn_output_68], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf410, buf414, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg357_1, (1536, 1536), (1536, 1), 'input')
            buf415 = reinterpret_tensor(buf410, (s16, 1536), (1536, 1), 0); del buf410  # reuse
            # Topologically Sorted Source Nodes: [attn_output_68, transpose_72, reshape_53, attn_output_71], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf414, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg357_1, (1536, 1536), (1, 1536), 0), out=buf415)
            del arg357_1
            assert_size_stride_grouped((arg359_1, arg358_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf416 = buf369; del buf369  # reuse
            buf418 = reinterpret_tensor(buf414, (s16, 1, 1536), (1536, 1536, 1), 0); del buf414  # reuse
            # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_127, attn_output_67, hidden_states_131, down_proj_16, hidden_states_135, attn_output_71, hidden_states_139, pow_36, variance_35, rsqrt_35, hidden_states_141, hidden_states_142], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf416, buf375, buf392, buf398, buf415, arg359_1, arg358_1.item(), buf418, s16, 1536, stream=raw_stream0)
            del arg358_1
            del arg359_1
            del buf375
            assert_size_stride(arg360_1, (8960, 1536), (1536, 1), 'input')
            buf419 = reinterpret_tensor(buf397, (s16, 8960), (8960, 1), 0); del buf397  # reuse
            # Topologically Sorted Source Nodes: [pow_36, variance_35, rsqrt_35, hidden_states_141, hidden_states_142, linear_123], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf418, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg360_1, (1536, 8960), (1, 1536), 0), out=buf419)
            del arg360_1
            assert_size_stride(arg361_1, (8960, 1536), (1536, 1), 'input')
            buf420 = buf396; del buf396  # reuse
            # Topologically Sorted Source Nodes: [linear_124], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf418, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg361_1, (1536, 8960), (1, 1536), 0), out=buf420)
            del arg361_1
            buf421 = reinterpret_tensor(buf419, (s16, 1, 8960), (8960, 8960, 1), 0); del buf419  # reuse
            # Topologically Sorted Source Nodes: [linear_123, silu_17, linear_124, mul_163], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf421, buf420, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg362_1, (1536, 8960), (8960, 1), 'input')
            buf422 = reinterpret_tensor(buf418, (s16, 1536), (1536, 1), 0); del buf418  # reuse
            # Topologically Sorted Source Nodes: [linear_123, silu_17, linear_124, mul_163, down_proj_17], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf421, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg362_1, (8960, 1536), (1, 8960), 0), out=buf422)
            del arg362_1
            assert_size_stride_grouped((arg364_1, arg363_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf424 = reinterpret_tensor(buf415, (s16, 1, 1536), (1536, 1536, 1), 0); del buf415  # reuse
            # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_143, pow_37, variance_36, rsqrt_36, hidden_states_145, hidden_states_146], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf416, buf422, arg364_1, arg363_1.item(), buf424, s16, 1536, stream=raw_stream0)
            del arg363_1
            del arg364_1
            assert_size_stride_grouped((arg366_1, arg365_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf425 = buf398; del buf398  # reuse
            # Topologically Sorted Source Nodes: [linear_126], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg366_1, reinterpret_tensor(buf424, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg365_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf425)
            del arg365_1
            del arg366_1
            assert_size_stride_grouped((arg368_1, arg367_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf426 = buf404; del buf404  # reuse
            # Topologically Sorted Source Nodes: [linear_127], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg368_1, reinterpret_tensor(buf424, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg367_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf426)
            del arg367_1
            del arg368_1
            assert_size_stride(arg372_1, (s16, 2, s38, 128), (256*s38, 128*s38, 128, 1), 'input')
            arg372_1 = copy_if_misaligned(arg372_1)
            ps162 = 1 + s38
            ps163 = 128 + 128*s38
            ps164 = 256 + 256*s38
            buf427 = empty_strided_cuda((s16, 2, 1 + s38, 128), (256 + 256*s38, 128 + 128*s38, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_21, sin_21, linear_127, view_55, key_states_18, mul_168, x2_37, neg_37, x1_37, cat_110, mul_169, k_embed_18, cat_111], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s38
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg372_1, buf426, arg4_1, arg3_1, arg5_1.item(), buf427, ps162, s38, ps163, ps164, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg372_1
            assert_size_stride_grouped((arg370_1, arg369_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf428 = buf426; del buf426  # reuse
            # Topologically Sorted Source Nodes: [linear_128], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg370_1, reinterpret_tensor(buf424, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg369_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf428)
            del arg369_1
            del arg370_1
            assert_size_stride(arg374_1, (s16, 2, s107, 128), (256*s107, 128*s107, 128, 1), 'input')
            arg374_1 = copy_if_misaligned(arg374_1)
            ps165 = 1 + s107
            ps166 = 128 + 128*s107
            buf429 = empty_strided_cuda((s16, 2, 1 + s107, 128), (256 + 256*s107, 128 + 128*s107, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_128, view_56, value_states_18, cat_112], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s107*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg374_1, buf428, buf429, ps165, s107, ps166, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg374_1
            buf430 = reinterpret_tensor(buf424, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf424  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf425, arg4_1, arg3_1, arg5_1.item(), buf430, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg375_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg375_1 = copy_if_misaligned(arg375_1)
            ps167 = 1 + s38 + s91
            ps168 = 128 + 128*s38 + 128*s91
            buf431 = empty_strided_cuda((s16, 2, 1 + s38 + s91, 128), (256 + 256*s38 + 256*s91, 128 + 128*s38 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s38 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg375_1, buf427, buf431, ps167, s91, ps168, s38, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg375_1
            assert_size_stride(arg376_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg376_1 = copy_if_misaligned(arg376_1)
            ps169 = 1 + s107 + s91
            ps170 = 128 + 128*s107 + 128*s91
            buf432 = empty_strided_cuda((s16, 2, 1 + s107 + s91, 128), (256 + 256*s107 + 256*s91, 128 + 128*s107 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s107*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg376_1, buf429, buf432, ps169, s91, ps170, s107, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg376_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_126, view_54, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_109, sin_21, mul_167, q_embed_18, packed_18, expand_37, key_tensors_18, expand_38, value_tensors_18, output_18], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf433 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf430, buf431, buf432, None, False, scale=0.08838834764831845)
            del buf431
            del buf432
            buf434 = buf433[0]
            assert_tensor_metadata(buf434, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf434, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf433
            buf438 = buf430; del buf430  # reuse
            # Topologically Sorted Source Nodes: [attn_output_72], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf434, buf438, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg377_1, (1536, 1536), (1536, 1), 'input')
            buf439 = reinterpret_tensor(buf434, (s16, 1536), (1536, 1), 0); del buf434  # reuse
            # Topologically Sorted Source Nodes: [attn_output_72, transpose_76, reshape_56, attn_output_75], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf438, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg377_1, (1536, 1536), (1, 1536), 0), out=buf439)
            del arg377_1
            assert_size_stride_grouped((arg379_1, arg378_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf441 = reinterpret_tensor(buf438, (s16, 1, 1536), (1536, 1536, 1), 0); del buf438  # reuse
            # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_143, attn_output_75, hidden_states_147, pow_38, variance_37, rsqrt_37, hidden_states_149, hidden_states_150], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf416, buf422, buf439, arg379_1, arg378_1.item(), buf441, s16, 1536, stream=raw_stream0)
            del arg378_1
            del arg379_1
            assert_size_stride(arg380_1, (8960, 1536), (1536, 1), 'input')
            buf442 = reinterpret_tensor(buf421, (s16, 8960), (8960, 1), 0); del buf421  # reuse
            # Topologically Sorted Source Nodes: [linear_130], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf441, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg380_1, (1536, 8960), (1, 1536), 0), out=buf442)
            del arg380_1
            assert_size_stride(arg381_1, (8960, 1536), (1536, 1), 'input')
            buf443 = buf420; del buf420  # reuse
            # Topologically Sorted Source Nodes: [linear_131], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf441, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg381_1, (1536, 8960), (1, 1536), 0), out=buf443)
            del arg381_1
            buf444 = reinterpret_tensor(buf442, (s16, 1, 8960), (8960, 8960, 1), 0); del buf442  # reuse
            # Topologically Sorted Source Nodes: [linear_130, silu_18, linear_131, mul_172], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf444, buf443, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg382_1, (1536, 8960), (8960, 1), 'input')
            buf445 = reinterpret_tensor(buf441, (s16, 1536), (1536, 1), 0); del buf441  # reuse
            # Topologically Sorted Source Nodes: [linear_130, silu_18, linear_131, mul_172, down_proj_18], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf444, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg382_1, (8960, 1536), (1, 8960), 0), out=buf445)
            del arg382_1
            assert_size_stride_grouped((arg384_1, arg383_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf447 = reinterpret_tensor(buf425, (s16, 1, 1536), (1536, 1536, 1), 0); del buf425  # reuse
            # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_143, attn_output_75, hidden_states_147, down_proj_18, hidden_states_151, pow_39, variance_38, rsqrt_38, hidden_states_153, hidden_states_154], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf416, buf422, buf439, buf445, arg384_1, arg383_1.item(), buf447, s16, 1536, stream=raw_stream0)
            del arg383_1
            del arg384_1
            assert_size_stride_grouped((arg386_1, arg385_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf448 = buf392; del buf392  # reuse
            # Topologically Sorted Source Nodes: [linear_133], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg386_1, reinterpret_tensor(buf447, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg385_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf448)
            del arg385_1
            del arg386_1
            assert_size_stride_grouped((arg388_1, arg387_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf449 = buf428; del buf428  # reuse
            # Topologically Sorted Source Nodes: [linear_134], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg388_1, reinterpret_tensor(buf447, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg387_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf449)
            del arg387_1
            del arg388_1
            assert_size_stride(arg392_1, (s16, 2, s111, 128), (256*s111, 128*s111, 128, 1), 'input')
            arg392_1 = copy_if_misaligned(arg392_1)
            ps171 = 1 + s111
            ps172 = 128 + 128*s111
            ps173 = 256 + 256*s111
            buf450 = empty_strided_cuda((s16, 2, 1 + s111, 128), (256 + 256*s111, 128 + 128*s111, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_22, sin_22, linear_134, view_58, key_states_19, mul_177, x2_39, neg_39, x1_39, cat_116, mul_178, k_embed_19, cat_117], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s111*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg392_1, buf449, arg4_1, arg3_1, arg5_1.item(), buf450, ps171, s111, ps172, ps173, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg392_1
            assert_size_stride_grouped((arg390_1, arg389_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf451 = buf449; del buf449  # reuse
            # Topologically Sorted Source Nodes: [linear_135], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg390_1, reinterpret_tensor(buf447, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg389_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf451)
            del arg389_1
            del arg390_1
            assert_size_stride(arg394_1, (s16, 2, s112, 128), (256*s112, 128*s112, 128, 1), 'input')
            arg394_1 = copy_if_misaligned(arg394_1)
            ps174 = 1 + s112
            ps175 = 128 + 128*s112
            buf452 = empty_strided_cuda((s16, 2, 1 + s112, 128), (256 + 256*s112, 128 + 128*s112, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_135, view_59, value_states_19, cat_118], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s112*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg394_1, buf451, buf452, ps174, s112, ps175, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg394_1
            buf453 = reinterpret_tensor(buf447, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf447  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_133, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf448, arg4_1, arg3_1, arg5_1.item(), buf453, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf448
            assert_size_stride(arg395_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg395_1 = copy_if_misaligned(arg395_1)
            ps176 = 1 + s111 + s91
            ps177 = 128 + 128*s111 + 128*s91
            buf454 = empty_strided_cuda((s16, 2, 1 + s111 + s91, 128), (256 + 256*s111 + 256*s91, 128 + 128*s111 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_133, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s111*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg395_1, buf450, buf454, ps176, s91, ps177, s111, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg395_1
            assert_size_stride(arg396_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg396_1 = copy_if_misaligned(arg396_1)
            ps178 = 1 + s112 + s91
            ps179 = 128 + 128*s112 + 128*s91
            buf455 = empty_strided_cuda((s16, 2, 1 + s112 + s91, 128), (256 + 256*s112 + 256*s91, 128 + 128*s112 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_133, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s112*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg396_1, buf452, buf455, ps178, s91, ps179, s112, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg396_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_133, view_57, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_115, sin_22, mul_176, q_embed_19, packed_19, expand_39, key_tensors_19, expand_40, value_tensors_19, output_19], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf456 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf453, buf454, buf455, None, False, scale=0.08838834764831845)
            del buf454
            del buf455
            buf457 = buf456[0]
            assert_tensor_metadata(buf457, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf457, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf456
            buf461 = buf453; del buf453  # reuse
            # Topologically Sorted Source Nodes: [attn_output_76], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf457, buf461, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg397_1, (1536, 1536), (1536, 1), 'input')
            buf462 = reinterpret_tensor(buf457, (s16, 1536), (1536, 1), 0); del buf457  # reuse
            # Topologically Sorted Source Nodes: [attn_output_76, transpose_80, reshape_59, attn_output_79], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf461, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg397_1, (1536, 1536), (1, 1536), 0), out=buf462)
            del arg397_1
            assert_size_stride_grouped((arg399_1, arg398_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf463 = buf416; del buf416  # reuse
            buf465 = reinterpret_tensor(buf461, (s16, 1, 1536), (1536, 1536, 1), 0); del buf461  # reuse
            # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_143, attn_output_75, hidden_states_147, down_proj_18, hidden_states_151, attn_output_79, hidden_states_155, pow_40, variance_39, rsqrt_39, hidden_states_157, hidden_states_158], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf463, buf422, buf439, buf445, buf462, arg399_1, arg398_1.item(), buf465, s16, 1536, stream=raw_stream0)
            del arg398_1
            del arg399_1
            del buf422
            assert_size_stride(arg400_1, (8960, 1536), (1536, 1), 'input')
            buf466 = reinterpret_tensor(buf444, (s16, 8960), (8960, 1), 0); del buf444  # reuse
            # Topologically Sorted Source Nodes: [pow_40, variance_39, rsqrt_39, hidden_states_157, hidden_states_158, linear_137], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf465, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg400_1, (1536, 8960), (1, 1536), 0), out=buf466)
            del arg400_1
            assert_size_stride(arg401_1, (8960, 1536), (1536, 1), 'input')
            buf467 = buf443; del buf443  # reuse
            # Topologically Sorted Source Nodes: [linear_138], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf465, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg401_1, (1536, 8960), (1, 1536), 0), out=buf467)
            del arg401_1
            buf468 = reinterpret_tensor(buf466, (s16, 1, 8960), (8960, 8960, 1), 0); del buf466  # reuse
            # Topologically Sorted Source Nodes: [linear_137, silu_19, linear_138, mul_181], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf468, buf467, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg402_1, (1536, 8960), (8960, 1), 'input')
            buf469 = reinterpret_tensor(buf465, (s16, 1536), (1536, 1), 0); del buf465  # reuse
            # Topologically Sorted Source Nodes: [linear_137, silu_19, linear_138, mul_181, down_proj_19], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf468, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg402_1, (8960, 1536), (1, 8960), 0), out=buf469)
            del arg402_1
            assert_size_stride_grouped((arg404_1, arg403_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf471 = reinterpret_tensor(buf462, (s16, 1, 1536), (1536, 1536, 1), 0); del buf462  # reuse
            # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_159, pow_41, variance_40, rsqrt_40, hidden_states_161, hidden_states_162], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf463, buf469, arg404_1, arg403_1.item(), buf471, s16, 1536, stream=raw_stream0)
            del arg403_1
            del arg404_1
            assert_size_stride_grouped((arg406_1, arg405_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf472 = buf445; del buf445  # reuse
            # Topologically Sorted Source Nodes: [linear_140], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg406_1, reinterpret_tensor(buf471, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg405_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf472)
            del arg405_1
            del arg406_1
            assert_size_stride_grouped((arg408_1, arg407_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf473 = buf451; del buf451  # reuse
            # Topologically Sorted Source Nodes: [linear_141], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg408_1, reinterpret_tensor(buf471, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg407_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf473)
            del arg407_1
            del arg408_1
            assert_size_stride(arg412_1, (s16, 2, s115, 128), (256*s115, 128*s115, 128, 1), 'input')
            arg412_1 = copy_if_misaligned(arg412_1)
            ps180 = 1 + s115
            ps181 = 128 + 128*s115
            ps182 = 256 + 256*s115
            buf474 = empty_strided_cuda((s16, 2, 1 + s115, 128), (256 + 256*s115, 128 + 128*s115, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_23, sin_23, linear_141, view_61, key_states_20, mul_186, x2_41, neg_41, x1_41, cat_122, mul_187, k_embed_20, cat_123], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s115*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg412_1, buf473, arg4_1, arg3_1, arg5_1.item(), buf474, ps180, s115, ps181, ps182, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg412_1
            assert_size_stride_grouped((arg410_1, arg409_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf475 = buf473; del buf473  # reuse
            # Topologically Sorted Source Nodes: [linear_142], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg410_1, reinterpret_tensor(buf471, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg409_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf475)
            del arg409_1
            del arg410_1
            assert_size_stride(arg414_1, (s16, 2, s9, 128), (256*s9, 128*s9, 128, 1), 'input')
            arg414_1 = copy_if_misaligned(arg414_1)
            ps183 = 1 + s9
            ps184 = 128 + 128*s9
            buf476 = empty_strided_cuda((s16, 2, 1 + s9, 128), (256 + 256*s9, 128 + 128*s9, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_142, view_62, value_states_20, cat_124], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s16*s9
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg414_1, buf475, buf476, ps183, s9, ps184, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg414_1
            buf477 = reinterpret_tensor(buf471, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf471  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_140, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf472, arg4_1, arg3_1, arg5_1.item(), buf477, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg415_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg415_1 = copy_if_misaligned(arg415_1)
            ps185 = 1 + s115 + s91
            ps186 = 128 + 128*s115 + 128*s91
            buf478 = empty_strided_cuda((s16, 2, 1 + s115 + s91, 128), (256 + 256*s115 + 256*s91, 128 + 128*s115 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_140, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s115*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg415_1, buf474, buf478, ps185, s91, ps186, s115, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg415_1
            assert_size_stride(arg416_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg416_1 = copy_if_misaligned(arg416_1)
            ps187 = 1 + s9 + s91
            ps188 = 128 + 128*s9 + 128*s91
            buf479 = empty_strided_cuda((s16, 2, 1 + s9 + s91, 128), (256 + 256*s9 + 256*s91, 128 + 128*s9 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_140, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s9 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg416_1, buf476, buf479, ps187, s91, ps188, s9, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg416_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_140, view_60, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_121, sin_23, mul_185, q_embed_20, packed_20, expand_41, key_tensors_20, expand_42, value_tensors_20, output_20], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf480 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf477, buf478, buf479, None, False, scale=0.08838834764831845)
            del buf478
            del buf479
            buf481 = buf480[0]
            assert_tensor_metadata(buf481, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf481, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf480
            buf485 = buf477; del buf477  # reuse
            # Topologically Sorted Source Nodes: [attn_output_80], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf481, buf485, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg417_1, (1536, 1536), (1536, 1), 'input')
            buf486 = reinterpret_tensor(buf481, (s16, 1536), (1536, 1), 0); del buf481  # reuse
            # Topologically Sorted Source Nodes: [attn_output_80, transpose_84, reshape_62, attn_output_83], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf485, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg417_1, (1536, 1536), (1, 1536), 0), out=buf486)
            del arg417_1
            assert_size_stride_grouped((arg419_1, arg418_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf488 = reinterpret_tensor(buf485, (s16, 1, 1536), (1536, 1536, 1), 0); del buf485  # reuse
            # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_159, attn_output_83, hidden_states_163, pow_42, variance_41, rsqrt_41, hidden_states_165, hidden_states_166], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf463, buf469, buf486, arg419_1, arg418_1.item(), buf488, s16, 1536, stream=raw_stream0)
            del arg418_1
            del arg419_1
            assert_size_stride(arg420_1, (8960, 1536), (1536, 1), 'input')
            buf489 = reinterpret_tensor(buf468, (s16, 8960), (8960, 1), 0); del buf468  # reuse
            # Topologically Sorted Source Nodes: [linear_144], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf488, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg420_1, (1536, 8960), (1, 1536), 0), out=buf489)
            del arg420_1
            assert_size_stride(arg421_1, (8960, 1536), (1536, 1), 'input')
            buf490 = buf467; del buf467  # reuse
            # Topologically Sorted Source Nodes: [linear_145], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf488, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg421_1, (1536, 8960), (1, 1536), 0), out=buf490)
            del arg421_1
            buf491 = reinterpret_tensor(buf489, (s16, 1, 8960), (8960, 8960, 1), 0); del buf489  # reuse
            # Topologically Sorted Source Nodes: [linear_144, silu_20, linear_145, mul_190], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf491, buf490, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg422_1, (1536, 8960), (8960, 1), 'input')
            buf492 = reinterpret_tensor(buf488, (s16, 1536), (1536, 1), 0); del buf488  # reuse
            # Topologically Sorted Source Nodes: [linear_144, silu_20, linear_145, mul_190, down_proj_20], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf491, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg422_1, (8960, 1536), (1, 8960), 0), out=buf492)
            del arg422_1
            assert_size_stride_grouped((arg424_1, arg423_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf494 = reinterpret_tensor(buf472, (s16, 1, 1536), (1536, 1536, 1), 0); del buf472  # reuse
            # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_159, attn_output_83, hidden_states_163, down_proj_20, hidden_states_167, pow_43, variance_42, rsqrt_42, hidden_states_169, hidden_states_170], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf463, buf469, buf486, buf492, arg424_1, arg423_1.item(), buf494, s16, 1536, stream=raw_stream0)
            del arg423_1
            del arg424_1
            assert_size_stride_grouped((arg426_1, arg425_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf495 = buf439; del buf439  # reuse
            # Topologically Sorted Source Nodes: [linear_147], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg426_1, reinterpret_tensor(buf494, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg425_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf495)
            del arg425_1
            del arg426_1
            assert_size_stride_grouped((arg428_1, arg427_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf496 = buf475; del buf475  # reuse
            # Topologically Sorted Source Nodes: [linear_148], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg428_1, reinterpret_tensor(buf494, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg427_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf496)
            del arg427_1
            del arg428_1
            assert_size_stride(arg432_1, (s16, 2, s39, 128), (256*s39, 128*s39, 128, 1), 'input')
            arg432_1 = copy_if_misaligned(arg432_1)
            ps189 = 1 + s39
            ps190 = 128 + 128*s39
            ps191 = 256 + 256*s39
            buf497 = empty_strided_cuda((s16, 2, 1 + s39, 128), (256 + 256*s39, 128 + 128*s39, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_24, sin_24, linear_148, view_64, key_states_21, mul_195, x2_43, neg_43, x1_43, cat_128, mul_196, k_embed_21, cat_129], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s16*s39
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg432_1, buf496, arg4_1, arg3_1, arg5_1.item(), buf497, ps189, s39, ps190, ps191, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg432_1
            assert_size_stride_grouped((arg430_1, arg429_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf498 = buf496; del buf496  # reuse
            # Topologically Sorted Source Nodes: [linear_149], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg430_1, reinterpret_tensor(buf494, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg429_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf498)
            del arg429_1
            del arg430_1
            assert_size_stride(arg434_1, (s16, 2, s117, 128), (256*s117, 128*s117, 128, 1), 'input')
            arg434_1 = copy_if_misaligned(arg434_1)
            ps192 = 1 + s117
            ps193 = 128 + 128*s117
            buf499 = empty_strided_cuda((s16, 2, 1 + s117, 128), (256 + 256*s117, 128 + 128*s117, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_149, view_65, value_states_21, cat_130], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s117*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg434_1, buf498, buf499, ps192, s117, ps193, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg434_1
            buf500 = reinterpret_tensor(buf494, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf494  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_147, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf495, arg4_1, arg3_1, arg5_1.item(), buf500, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf495
            assert_size_stride(arg435_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg435_1 = copy_if_misaligned(arg435_1)
            ps194 = 1 + s39 + s91
            ps195 = 128 + 128*s39 + 128*s91
            buf501 = empty_strided_cuda((s16, 2, 1 + s39 + s91, 128), (256 + 256*s39 + 256*s91, 128 + 128*s39 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_147, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s16*s39 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg435_1, buf497, buf501, ps194, s91, ps195, s39, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg435_1
            assert_size_stride(arg436_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg436_1 = copy_if_misaligned(arg436_1)
            ps196 = 1 + s117 + s91
            ps197 = 128 + 128*s117 + 128*s91
            buf502 = empty_strided_cuda((s16, 2, 1 + s117 + s91, 128), (256 + 256*s117 + 256*s91, 128 + 128*s117 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_147, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s117*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg436_1, buf499, buf502, ps196, s91, ps197, s117, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg436_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_147, view_63, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_127, sin_24, mul_194, q_embed_21, packed_21, expand_43, key_tensors_21, expand_44, value_tensors_21, output_21], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf503 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf500, buf501, buf502, None, False, scale=0.08838834764831845)
            del buf501
            del buf502
            buf504 = buf503[0]
            assert_tensor_metadata(buf504, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf504, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf503
            buf508 = buf500; del buf500  # reuse
            # Topologically Sorted Source Nodes: [attn_output_84], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf504, buf508, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg437_1, (1536, 1536), (1536, 1), 'input')
            buf509 = reinterpret_tensor(buf504, (s16, 1536), (1536, 1), 0); del buf504  # reuse
            # Topologically Sorted Source Nodes: [attn_output_84, transpose_88, reshape_65, attn_output_87], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf508, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg437_1, (1536, 1536), (1, 1536), 0), out=buf509)
            del arg437_1
            assert_size_stride_grouped((arg439_1, arg438_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf510 = buf463; del buf463  # reuse
            buf512 = reinterpret_tensor(buf508, (s16, 1, 1536), (1536, 1536, 1), 0); del buf508  # reuse
            # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_159, attn_output_83, hidden_states_163, down_proj_20, hidden_states_167, attn_output_87, hidden_states_171, pow_44, variance_43, rsqrt_43, hidden_states_173, hidden_states_174], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf510, buf469, buf486, buf492, buf509, arg439_1, arg438_1.item(), buf512, s16, 1536, stream=raw_stream0)
            del arg438_1
            del arg439_1
            del buf469
            assert_size_stride(arg440_1, (8960, 1536), (1536, 1), 'input')
            buf513 = reinterpret_tensor(buf491, (s16, 8960), (8960, 1), 0); del buf491  # reuse
            # Topologically Sorted Source Nodes: [pow_44, variance_43, rsqrt_43, hidden_states_173, hidden_states_174, linear_151], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf512, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg440_1, (1536, 8960), (1, 1536), 0), out=buf513)
            del arg440_1
            assert_size_stride(arg441_1, (8960, 1536), (1536, 1), 'input')
            buf514 = buf490; del buf490  # reuse
            # Topologically Sorted Source Nodes: [linear_152], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf512, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg441_1, (1536, 8960), (1, 1536), 0), out=buf514)
            del arg441_1
            buf515 = reinterpret_tensor(buf513, (s16, 1, 8960), (8960, 8960, 1), 0); del buf513  # reuse
            # Topologically Sorted Source Nodes: [linear_151, silu_21, linear_152, mul_199], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf515, buf514, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg442_1, (1536, 8960), (8960, 1), 'input')
            buf516 = reinterpret_tensor(buf512, (s16, 1536), (1536, 1), 0); del buf512  # reuse
            # Topologically Sorted Source Nodes: [linear_151, silu_21, linear_152, mul_199, down_proj_21], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf515, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg442_1, (8960, 1536), (1, 8960), 0), out=buf516)
            del arg442_1
            assert_size_stride_grouped((arg444_1, arg443_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf518 = reinterpret_tensor(buf509, (s16, 1, 1536), (1536, 1536, 1), 0); del buf509  # reuse
            # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_175, pow_45, variance_44, rsqrt_44, hidden_states_177, hidden_states_178], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf510, buf516, arg444_1, arg443_1.item(), buf518, s16, 1536, stream=raw_stream0)
            del arg443_1
            del arg444_1
            assert_size_stride_grouped((arg446_1, arg445_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf519 = buf492; del buf492  # reuse
            # Topologically Sorted Source Nodes: [linear_154], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg446_1, reinterpret_tensor(buf518, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg445_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf519)
            del arg445_1
            del arg446_1
            assert_size_stride_grouped((arg448_1, arg447_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf520 = buf498; del buf498  # reuse
            # Topologically Sorted Source Nodes: [linear_155], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg448_1, reinterpret_tensor(buf518, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg447_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf520)
            del arg447_1
            del arg448_1
            assert_size_stride(arg452_1, (s16, 2, s120, 128), (256*s120, 128*s120, 128, 1), 'input')
            arg452_1 = copy_if_misaligned(arg452_1)
            ps198 = 1 + s120
            ps199 = 128 + 128*s120
            ps200 = 256 + 256*s120
            buf521 = empty_strided_cuda((s16, 2, 1 + s120, 128), (256 + 256*s120, 128 + 128*s120, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_25, sin_25, linear_155, view_67, key_states_22, mul_204, x2_45, neg_45, x1_45, cat_134, mul_205, k_embed_22, cat_135], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s120*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg452_1, buf520, arg4_1, arg3_1, arg5_1.item(), buf521, ps198, s120, ps199, ps200, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg452_1
            assert_size_stride_grouped((arg450_1, arg449_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf522 = buf520; del buf520  # reuse
            # Topologically Sorted Source Nodes: [linear_156], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg450_1, reinterpret_tensor(buf518, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg449_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf522)
            del arg449_1
            del arg450_1
            assert_size_stride(arg454_1, (s16, 2, s121, 128), (256*s121, 128*s121, 128, 1), 'input')
            arg454_1 = copy_if_misaligned(arg454_1)
            ps201 = 1 + s121
            ps202 = 128 + 128*s121
            buf523 = empty_strided_cuda((s16, 2, 1 + s121, 128), (256 + 256*s121, 128 + 128*s121, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_156, view_68, value_states_22, cat_136], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s121*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg454_1, buf522, buf523, ps201, s121, ps202, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg454_1
            buf524 = reinterpret_tensor(buf518, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf518  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_154, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf519, arg4_1, arg3_1, arg5_1.item(), buf524, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg455_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg455_1 = copy_if_misaligned(arg455_1)
            ps203 = 1 + s120 + s91
            ps204 = 128 + 128*s120 + 128*s91
            buf525 = empty_strided_cuda((s16, 2, 1 + s120 + s91, 128), (256 + 256*s120 + 256*s91, 128 + 128*s120 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_154, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s120*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg455_1, buf521, buf525, ps203, s91, ps204, s120, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg455_1
            assert_size_stride(arg456_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg456_1 = copy_if_misaligned(arg456_1)
            ps205 = 1 + s121 + s91
            ps206 = 128 + 128*s121 + 128*s91
            buf526 = empty_strided_cuda((s16, 2, 1 + s121 + s91, 128), (256 + 256*s121 + 256*s91, 128 + 128*s121 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_154, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s121*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg456_1, buf523, buf526, ps205, s91, ps206, s121, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg456_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_154, view_66, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_133, sin_25, mul_203, q_embed_22, packed_22, expand_45, key_tensors_22, expand_46, value_tensors_22, output_22], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf527 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf524, buf525, buf526, None, False, scale=0.08838834764831845)
            del buf525
            del buf526
            buf528 = buf527[0]
            assert_tensor_metadata(buf528, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf528, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf527
            buf532 = buf524; del buf524  # reuse
            # Topologically Sorted Source Nodes: [attn_output_88], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf528, buf532, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg457_1, (1536, 1536), (1536, 1), 'input')
            buf533 = reinterpret_tensor(buf528, (s16, 1536), (1536, 1), 0); del buf528  # reuse
            # Topologically Sorted Source Nodes: [attn_output_88, transpose_92, reshape_68, attn_output_91], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf532, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg457_1, (1536, 1536), (1, 1536), 0), out=buf533)
            del arg457_1
            assert_size_stride_grouped((arg459_1, arg458_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf535 = reinterpret_tensor(buf532, (s16, 1, 1536), (1536, 1536, 1), 0); del buf532  # reuse
            # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_175, attn_output_91, hidden_states_179, pow_46, variance_45, rsqrt_45, hidden_states_181, hidden_states_182], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf510, buf516, buf533, arg459_1, arg458_1.item(), buf535, s16, 1536, stream=raw_stream0)
            del arg458_1
            del arg459_1
            assert_size_stride(arg460_1, (8960, 1536), (1536, 1), 'input')
            buf536 = reinterpret_tensor(buf515, (s16, 8960), (8960, 1), 0); del buf515  # reuse
            # Topologically Sorted Source Nodes: [linear_158], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf535, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg460_1, (1536, 8960), (1, 1536), 0), out=buf536)
            del arg460_1
            assert_size_stride(arg461_1, (8960, 1536), (1536, 1), 'input')
            buf537 = buf514; del buf514  # reuse
            # Topologically Sorted Source Nodes: [linear_159], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf535, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg461_1, (1536, 8960), (1, 1536), 0), out=buf537)
            del arg461_1
            buf538 = reinterpret_tensor(buf536, (s16, 1, 8960), (8960, 8960, 1), 0); del buf536  # reuse
            # Topologically Sorted Source Nodes: [linear_158, silu_22, linear_159, mul_208], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf538, buf537, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg462_1, (1536, 8960), (8960, 1), 'input')
            buf539 = reinterpret_tensor(buf535, (s16, 1536), (1536, 1), 0); del buf535  # reuse
            # Topologically Sorted Source Nodes: [linear_158, silu_22, linear_159, mul_208, down_proj_22], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf538, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg462_1, (8960, 1536), (1, 8960), 0), out=buf539)
            del arg462_1
            assert_size_stride_grouped((arg464_1, arg463_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf541 = reinterpret_tensor(buf519, (s16, 1, 1536), (1536, 1536, 1), 0); del buf519  # reuse
            # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_175, attn_output_91, hidden_states_179, down_proj_22, hidden_states_183, pow_47, variance_46, rsqrt_46, hidden_states_185, hidden_states_186], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf510, buf516, buf533, buf539, arg464_1, arg463_1.item(), buf541, s16, 1536, stream=raw_stream0)
            del arg463_1
            del arg464_1
            assert_size_stride_grouped((arg466_1, arg465_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf542 = buf486; del buf486  # reuse
            # Topologically Sorted Source Nodes: [linear_161], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg466_1, reinterpret_tensor(buf541, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg465_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf542)
            del arg465_1
            del arg466_1
            assert_size_stride_grouped((arg468_1, arg467_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf543 = buf522; del buf522  # reuse
            # Topologically Sorted Source Nodes: [linear_162], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg468_1, reinterpret_tensor(buf541, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg467_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf543)
            del arg467_1
            del arg468_1
            assert_size_stride(arg472_1, (s16, 2, s124, 128), (256*s124, 128*s124, 128, 1), 'input')
            arg472_1 = copy_if_misaligned(arg472_1)
            ps207 = 1 + s124
            ps208 = 128 + 128*s124
            ps209 = 256 + 256*s124
            buf544 = empty_strided_cuda((s16, 2, 1 + s124, 128), (256 + 256*s124, 128 + 128*s124, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_26, sin_26, linear_162, view_70, key_states_23, mul_213, x2_47, neg_47, x1_47, cat_140, mul_214, k_embed_23, cat_141], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s124*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg472_1, buf543, arg4_1, arg3_1, arg5_1.item(), buf544, ps207, s124, ps208, ps209, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg472_1
            assert_size_stride_grouped((arg470_1, arg469_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf545 = buf543; del buf543  # reuse
            # Topologically Sorted Source Nodes: [linear_163], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg470_1, reinterpret_tensor(buf541, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg469_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf545)
            del arg469_1
            del arg470_1
            assert_size_stride(arg474_1, (s16, 2, s125, 128), (256*s125, 128*s125, 128, 1), 'input')
            arg474_1 = copy_if_misaligned(arg474_1)
            ps210 = 1 + s125
            ps211 = 128 + 128*s125
            buf546 = empty_strided_cuda((s16, 2, 1 + s125, 128), (256 + 256*s125, 128 + 128*s125, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_163, view_71, value_states_23, cat_142], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s125*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg474_1, buf545, buf546, ps210, s125, ps211, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg474_1
            buf547 = reinterpret_tensor(buf541, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf541  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_161, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf542, arg4_1, arg3_1, arg5_1.item(), buf547, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf542
            assert_size_stride(arg475_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg475_1 = copy_if_misaligned(arg475_1)
            ps212 = 1 + s124 + s91
            ps213 = 128 + 128*s124 + 128*s91
            buf548 = empty_strided_cuda((s16, 2, 1 + s124 + s91, 128), (256 + 256*s124 + 256*s91, 128 + 128*s124 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_161, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s124*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg475_1, buf544, buf548, ps212, s91, ps213, s124, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg475_1
            assert_size_stride(arg476_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg476_1 = copy_if_misaligned(arg476_1)
            ps214 = 1 + s125 + s91
            ps215 = 128 + 128*s125 + 128*s91
            buf549 = empty_strided_cuda((s16, 2, 1 + s125 + s91, 128), (256 + 256*s125 + 256*s91, 128 + 128*s125 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_161, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s125*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg476_1, buf546, buf549, ps214, s91, ps215, s125, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg476_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_161, view_69, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_139, sin_26, mul_212, q_embed_23, packed_23, expand_47, key_tensors_23, expand_48, value_tensors_23, output_23], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf550 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf547, buf548, buf549, None, False, scale=0.08838834764831845)
            del buf548
            del buf549
            buf551 = buf550[0]
            assert_tensor_metadata(buf551, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf551, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf550
            buf555 = buf547; del buf547  # reuse
            # Topologically Sorted Source Nodes: [attn_output_92], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf551, buf555, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg477_1, (1536, 1536), (1536, 1), 'input')
            buf556 = reinterpret_tensor(buf551, (s16, 1536), (1536, 1), 0); del buf551  # reuse
            # Topologically Sorted Source Nodes: [attn_output_92, transpose_96, reshape_71, attn_output_95], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf555, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg477_1, (1536, 1536), (1, 1536), 0), out=buf556)
            del arg477_1
            assert_size_stride_grouped((arg479_1, arg478_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf557 = buf510; del buf510  # reuse
            buf559 = reinterpret_tensor(buf555, (s16, 1, 1536), (1536, 1536, 1), 0); del buf555  # reuse
            # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_175, attn_output_91, hidden_states_179, down_proj_22, hidden_states_183, attn_output_95, hidden_states_187, pow_48, variance_47, rsqrt_47, hidden_states_189, hidden_states_190], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf557, buf516, buf533, buf539, buf556, arg479_1, arg478_1.item(), buf559, s16, 1536, stream=raw_stream0)
            del arg478_1
            del arg479_1
            del buf516
            assert_size_stride(arg480_1, (8960, 1536), (1536, 1), 'input')
            buf560 = reinterpret_tensor(buf538, (s16, 8960), (8960, 1), 0); del buf538  # reuse
            # Topologically Sorted Source Nodes: [pow_48, variance_47, rsqrt_47, hidden_states_189, hidden_states_190, linear_165], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf559, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg480_1, (1536, 8960), (1, 1536), 0), out=buf560)
            del arg480_1
            assert_size_stride(arg481_1, (8960, 1536), (1536, 1), 'input')
            buf561 = buf537; del buf537  # reuse
            # Topologically Sorted Source Nodes: [linear_166], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf559, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg481_1, (1536, 8960), (1, 1536), 0), out=buf561)
            del arg481_1
            buf562 = reinterpret_tensor(buf560, (s16, 1, 8960), (8960, 8960, 1), 0); del buf560  # reuse
            # Topologically Sorted Source Nodes: [linear_165, silu_23, linear_166, mul_217], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf562, buf561, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg482_1, (1536, 8960), (8960, 1), 'input')
            buf563 = reinterpret_tensor(buf559, (s16, 1536), (1536, 1), 0); del buf559  # reuse
            # Topologically Sorted Source Nodes: [linear_165, silu_23, linear_166, mul_217, down_proj_23], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf562, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg482_1, (8960, 1536), (1, 8960), 0), out=buf563)
            del arg482_1
            assert_size_stride_grouped((arg484_1, arg483_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf565 = reinterpret_tensor(buf556, (s16, 1, 1536), (1536, 1536, 1), 0); del buf556  # reuse
            # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_191, pow_49, variance_48, rsqrt_48, hidden_states_193, hidden_states_194], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf557, buf563, arg484_1, arg483_1.item(), buf565, s16, 1536, stream=raw_stream0)
            del arg483_1
            del arg484_1
            assert_size_stride_grouped((arg486_1, arg485_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf566 = buf539; del buf539  # reuse
            # Topologically Sorted Source Nodes: [linear_168], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg486_1, reinterpret_tensor(buf565, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg485_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf566)
            del arg485_1
            del arg486_1
            assert_size_stride_grouped((arg488_1, arg487_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf567 = buf545; del buf545  # reuse
            # Topologically Sorted Source Nodes: [linear_169], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg488_1, reinterpret_tensor(buf565, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg487_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf567)
            del arg487_1
            del arg488_1
            assert_size_stride(arg492_1, (s16, 2, s129, 128), (256*s129, 128*s129, 128, 1), 'input')
            arg492_1 = copy_if_misaligned(arg492_1)
            ps216 = 1 + s129
            ps217 = 128 + 128*s129
            ps218 = 256 + 256*s129
            buf568 = empty_strided_cuda((s16, 2, 1 + s129, 128), (256 + 256*s129, 128 + 128*s129, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_27, sin_27, linear_169, view_73, key_states_24, mul_222, x2_49, neg_49, x1_49, cat_146, mul_223, k_embed_24, cat_147], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s129*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg492_1, buf567, arg4_1, arg3_1, arg5_1.item(), buf568, ps216, s129, ps217, ps218, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg492_1
            assert_size_stride_grouped((arg490_1, arg489_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf569 = buf567; del buf567  # reuse
            # Topologically Sorted Source Nodes: [linear_170], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg490_1, reinterpret_tensor(buf565, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg489_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf569)
            del arg489_1
            del arg490_1
            assert_size_stride(arg494_1, (s16, 2, s130, 128), (256*s130, 128*s130, 128, 1), 'input')
            arg494_1 = copy_if_misaligned(arg494_1)
            ps219 = 1 + s130
            ps220 = 128 + 128*s130
            buf570 = empty_strided_cuda((s16, 2, 1 + s130, 128), (256 + 256*s130, 128 + 128*s130, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_170, view_74, value_states_24, cat_148], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s130*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg494_1, buf569, buf570, ps219, s130, ps220, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg494_1
            buf571 = reinterpret_tensor(buf565, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf565  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_168, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf566, arg4_1, arg3_1, arg5_1.item(), buf571, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg495_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg495_1 = copy_if_misaligned(arg495_1)
            ps221 = 1 + s129 + s91
            ps222 = 128 + 128*s129 + 128*s91
            buf572 = empty_strided_cuda((s16, 2, 1 + s129 + s91, 128), (256 + 256*s129 + 256*s91, 128 + 128*s129 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_168, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s129*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg495_1, buf568, buf572, ps221, s91, ps222, s129, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg495_1
            assert_size_stride(arg496_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg496_1 = copy_if_misaligned(arg496_1)
            ps223 = 1 + s130 + s91
            ps224 = 128 + 128*s130 + 128*s91
            buf573 = empty_strided_cuda((s16, 2, 1 + s130 + s91, 128), (256 + 256*s130 + 256*s91, 128 + 128*s130 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_168, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s130*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg496_1, buf570, buf573, ps223, s91, ps224, s130, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg496_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_168, view_72, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_145, sin_27, mul_221, q_embed_24, packed_24, expand_49, key_tensors_24, expand_50, value_tensors_24, output_24], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf574 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf571, buf572, buf573, None, False, scale=0.08838834764831845)
            del buf572
            del buf573
            buf575 = buf574[0]
            assert_tensor_metadata(buf575, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf575, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf574
            buf579 = buf571; del buf571  # reuse
            # Topologically Sorted Source Nodes: [attn_output_96], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf575, buf579, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg497_1, (1536, 1536), (1536, 1), 'input')
            buf580 = reinterpret_tensor(buf575, (s16, 1536), (1536, 1), 0); del buf575  # reuse
            # Topologically Sorted Source Nodes: [attn_output_96, transpose_100, reshape_74, attn_output_99], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf579, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg497_1, (1536, 1536), (1, 1536), 0), out=buf580)
            del arg497_1
            assert_size_stride_grouped((arg499_1, arg498_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf582 = reinterpret_tensor(buf579, (s16, 1, 1536), (1536, 1536, 1), 0); del buf579  # reuse
            # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_191, attn_output_99, hidden_states_195, pow_50, variance_49, rsqrt_49, hidden_states_197, hidden_states_198], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf557, buf563, buf580, arg499_1, arg498_1.item(), buf582, s16, 1536, stream=raw_stream0)
            del arg498_1
            del arg499_1
            assert_size_stride(arg500_1, (8960, 1536), (1536, 1), 'input')
            buf583 = reinterpret_tensor(buf562, (s16, 8960), (8960, 1), 0); del buf562  # reuse
            # Topologically Sorted Source Nodes: [linear_172], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf582, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg500_1, (1536, 8960), (1, 1536), 0), out=buf583)
            del arg500_1
            assert_size_stride(arg501_1, (8960, 1536), (1536, 1), 'input')
            buf584 = buf561; del buf561  # reuse
            # Topologically Sorted Source Nodes: [linear_173], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf582, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg501_1, (1536, 8960), (1, 1536), 0), out=buf584)
            del arg501_1
            buf585 = reinterpret_tensor(buf583, (s16, 1, 8960), (8960, 8960, 1), 0); del buf583  # reuse
            # Topologically Sorted Source Nodes: [linear_172, silu_24, linear_173, mul_226], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf585, buf584, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg502_1, (1536, 8960), (8960, 1), 'input')
            buf586 = reinterpret_tensor(buf582, (s16, 1536), (1536, 1), 0); del buf582  # reuse
            # Topologically Sorted Source Nodes: [linear_172, silu_24, linear_173, mul_226, down_proj_24], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf585, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg502_1, (8960, 1536), (1, 8960), 0), out=buf586)
            del arg502_1
            assert_size_stride_grouped((arg504_1, arg503_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf588 = reinterpret_tensor(buf566, (s16, 1, 1536), (1536, 1536, 1), 0); del buf566  # reuse
            # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_191, attn_output_99, hidden_states_195, down_proj_24, hidden_states_199, pow_51, variance_50, rsqrt_50, hidden_states_201, hidden_states_202], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf557, buf563, buf580, buf586, arg504_1, arg503_1.item(), buf588, s16, 1536, stream=raw_stream0)
            del arg503_1
            del arg504_1
            assert_size_stride_grouped((arg506_1, arg505_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf589 = buf533; del buf533  # reuse
            # Topologically Sorted Source Nodes: [linear_175], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg506_1, reinterpret_tensor(buf588, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg505_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf589)
            del arg505_1
            del arg506_1
            assert_size_stride_grouped((arg508_1, arg507_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf590 = buf569; del buf569  # reuse
            # Topologically Sorted Source Nodes: [linear_176], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg508_1, reinterpret_tensor(buf588, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg507_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf590)
            del arg507_1
            del arg508_1
            assert_size_stride(arg512_1, (s16, 2, s134, 128), (256*s134, 128*s134, 128, 1), 'input')
            arg512_1 = copy_if_misaligned(arg512_1)
            ps225 = 1 + s134
            ps226 = 128 + 128*s134
            ps227 = 256 + 256*s134
            buf591 = empty_strided_cuda((s16, 2, 1 + s134, 128), (256 + 256*s134, 128 + 128*s134, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_28, sin_28, linear_176, view_76, key_states_25, mul_231, x2_51, neg_51, x1_51, cat_152, mul_232, k_embed_25, cat_153], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s134*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg512_1, buf590, arg4_1, arg3_1, arg5_1.item(), buf591, ps225, s134, ps226, ps227, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg512_1
            assert_size_stride_grouped((arg510_1, arg509_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf592 = buf590; del buf590  # reuse
            # Topologically Sorted Source Nodes: [linear_177], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg510_1, reinterpret_tensor(buf588, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg509_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf592)
            del arg509_1
            del arg510_1
            assert_size_stride(arg514_1, (s16, 2, s135, 128), (256*s135, 128*s135, 128, 1), 'input')
            arg514_1 = copy_if_misaligned(arg514_1)
            ps228 = 1 + s135
            ps229 = 128 + 128*s135
            buf593 = empty_strided_cuda((s16, 2, 1 + s135, 128), (256 + 256*s135, 128 + 128*s135, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_177, view_77, value_states_25, cat_154], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s135*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg514_1, buf592, buf593, ps228, s135, ps229, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg514_1
            buf594 = reinterpret_tensor(buf588, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf588  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_175, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf589, arg4_1, arg3_1, arg5_1.item(), buf594, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del buf589
            assert_size_stride(arg515_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg515_1 = copy_if_misaligned(arg515_1)
            ps230 = 1 + s134 + s91
            ps231 = 128 + 128*s134 + 128*s91
            buf595 = empty_strided_cuda((s16, 2, 1 + s134 + s91, 128), (256 + 256*s134 + 256*s91, 128 + 128*s134 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_175, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s134*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg515_1, buf591, buf595, ps230, s91, ps231, s134, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg515_1
            assert_size_stride(arg516_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg516_1 = copy_if_misaligned(arg516_1)
            ps232 = 1 + s135 + s91
            ps233 = 128 + 128*s135 + 128*s91
            buf596 = empty_strided_cuda((s16, 2, 1 + s135 + s91, 128), (256 + 256*s135 + 256*s91, 128 + 128*s135 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_175, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s135*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg516_1, buf593, buf596, ps232, s91, ps233, s135, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg516_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_175, view_75, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_151, sin_28, mul_230, q_embed_25, packed_25, expand_51, key_tensors_25, expand_52, value_tensors_25, output_25], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf597 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf594, buf595, buf596, None, False, scale=0.08838834764831845)
            del buf595
            del buf596
            buf598 = buf597[0]
            assert_tensor_metadata(buf598, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf598, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf597
            buf602 = buf594; del buf594  # reuse
            # Topologically Sorted Source Nodes: [attn_output_100], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf598, buf602, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg517_1, (1536, 1536), (1536, 1), 'input')
            buf603 = reinterpret_tensor(buf598, (s16, 1536), (1536, 1), 0); del buf598  # reuse
            # Topologically Sorted Source Nodes: [attn_output_100, transpose_104, reshape_77, attn_output_103], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf602, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg517_1, (1536, 1536), (1, 1536), 0), out=buf603)
            del arg517_1
            assert_size_stride_grouped((arg519_1, arg518_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf604 = buf557; del buf557  # reuse
            buf606 = reinterpret_tensor(buf602, (s16, 1, 1536), (1536, 1536, 1), 0); del buf602  # reuse
            # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_191, attn_output_99, hidden_states_195, down_proj_24, hidden_states_199, attn_output_103, hidden_states_203, pow_52, variance_51, rsqrt_51, hidden_states_205, hidden_states_206], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf604, buf563, buf580, buf586, buf603, arg519_1, arg518_1.item(), buf606, s16, 1536, stream=raw_stream0)
            del arg518_1
            del arg519_1
            del buf563
            assert_size_stride(arg520_1, (8960, 1536), (1536, 1), 'input')
            buf607 = reinterpret_tensor(buf585, (s16, 8960), (8960, 1), 0); del buf585  # reuse
            # Topologically Sorted Source Nodes: [pow_52, variance_51, rsqrt_51, hidden_states_205, hidden_states_206, linear_179], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf606, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg520_1, (1536, 8960), (1, 1536), 0), out=buf607)
            del arg520_1
            assert_size_stride(arg521_1, (8960, 1536), (1536, 1), 'input')
            buf608 = buf584; del buf584  # reuse
            # Topologically Sorted Source Nodes: [linear_180], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf606, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg521_1, (1536, 8960), (1, 1536), 0), out=buf608)
            del arg521_1
            buf609 = reinterpret_tensor(buf607, (s16, 1, 8960), (8960, 8960, 1), 0); del buf607  # reuse
            # Topologically Sorted Source Nodes: [linear_179, silu_25, linear_180, mul_235], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf609, buf608, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg522_1, (1536, 8960), (8960, 1), 'input')
            buf610 = reinterpret_tensor(buf606, (s16, 1536), (1536, 1), 0); del buf606  # reuse
            # Topologically Sorted Source Nodes: [linear_179, silu_25, linear_180, mul_235, down_proj_25], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf609, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg522_1, (8960, 1536), (1, 8960), 0), out=buf610)
            del arg522_1
            assert_size_stride_grouped((arg524_1, arg523_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf612 = reinterpret_tensor(buf603, (s16, 1, 1536), (1536, 1536, 1), 0); del buf603  # reuse
            # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_207, pow_53, variance_52, rsqrt_52, hidden_states_209, hidden_states_210], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf604, buf610, arg524_1, arg523_1.item(), buf612, s16, 1536, stream=raw_stream0)
            del arg523_1
            del arg524_1
            assert_size_stride_grouped((arg526_1, arg525_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf613 = buf586; del buf586  # reuse
            # Topologically Sorted Source Nodes: [linear_182], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg526_1, reinterpret_tensor(buf612, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg525_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf613)
            del arg525_1
            del arg526_1
            assert_size_stride_grouped((arg528_1, arg527_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf614 = buf592; del buf592  # reuse
            # Topologically Sorted Source Nodes: [linear_183], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg528_1, reinterpret_tensor(buf612, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg527_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf614)
            del arg527_1
            del arg528_1
            assert_size_stride(arg532_1, (s16, 2, s139, 128), (256*s139, 128*s139, 128, 1), 'input')
            arg532_1 = copy_if_misaligned(arg532_1)
            ps234 = 1 + s139
            ps235 = 128 + 128*s139
            ps236 = 256 + 256*s139
            buf615 = empty_strided_cuda((s16, 2, 1 + s139, 128), (256 + 256*s139, 128 + 128*s139, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_29, sin_29, linear_183, view_79, key_states_26, mul_240, x2_53, neg_53, x1_53, cat_158, mul_241, k_embed_26, cat_159], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s139*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg532_1, buf614, arg4_1, arg3_1, arg5_1.item(), buf615, ps234, s139, ps235, ps236, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg532_1
            assert_size_stride_grouped((arg530_1, arg529_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf616 = buf614; del buf614  # reuse
            # Topologically Sorted Source Nodes: [linear_184], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg530_1, reinterpret_tensor(buf612, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg529_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf616)
            del arg529_1
            del arg530_1
            assert_size_stride(arg534_1, (s16, 2, s140, 128), (256*s140, 128*s140, 128, 1), 'input')
            arg534_1 = copy_if_misaligned(arg534_1)
            ps237 = 1 + s140
            ps238 = 128 + 128*s140
            buf617 = empty_strided_cuda((s16, 2, 1 + s140, 128), (256 + 256*s140, 128 + 128*s140, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_184, view_80, value_states_26, cat_160], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s140*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg534_1, buf616, buf617, ps237, s140, ps238, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg534_1
            buf618 = reinterpret_tensor(buf612, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf612  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_182, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf613, arg4_1, arg3_1, arg5_1.item(), buf618, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            assert_size_stride(arg535_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg535_1 = copy_if_misaligned(arg535_1)
            ps239 = 1 + s139 + s91
            ps240 = 128 + 128*s139 + 128*s91
            buf619 = empty_strided_cuda((s16, 2, 1 + s139 + s91, 128), (256 + 256*s139 + 256*s91, 128 + 128*s139 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_182, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s139*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg535_1, buf615, buf619, ps239, s91, ps240, s139, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg535_1
            assert_size_stride(arg536_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg536_1 = copy_if_misaligned(arg536_1)
            ps241 = 1 + s140 + s91
            ps242 = 128 + 128*s140 + 128*s91
            buf620 = empty_strided_cuda((s16, 2, 1 + s140 + s91, 128), (256 + 256*s140 + 256*s91, 128 + 128*s140 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_182, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s140*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg536_1, buf617, buf620, ps241, s91, ps242, s140, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg536_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_182, view_78, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_157, sin_29, mul_239, q_embed_26, packed_26, expand_53, key_tensors_26, expand_54, value_tensors_26, output_26], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf621 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf618, buf619, buf620, None, False, scale=0.08838834764831845)
            del buf619
            del buf620
            buf622 = buf621[0]
            assert_tensor_metadata(buf622, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf622, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf621
            buf626 = buf618; del buf618  # reuse
            # Topologically Sorted Source Nodes: [attn_output_104], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf622, buf626, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg537_1, (1536, 1536), (1536, 1), 'input')
            buf627 = reinterpret_tensor(buf622, (s16, 1536), (1536, 1), 0); del buf622  # reuse
            # Topologically Sorted Source Nodes: [attn_output_104, transpose_108, reshape_80, attn_output_107], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf626, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg537_1, (1536, 1536), (1, 1536), 0), out=buf627)
            del arg537_1
            assert_size_stride_grouped((arg539_1, arg538_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf629 = reinterpret_tensor(buf626, (s16, 1, 1536), (1536, 1536, 1), 0); del buf626  # reuse
            # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_207, attn_output_107, hidden_states_211, pow_54, variance_53, rsqrt_53, hidden_states_213, hidden_states_214], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf604, buf610, buf627, arg539_1, arg538_1.item(), buf629, s16, 1536, stream=raw_stream0)
            del arg538_1
            del arg539_1
            assert_size_stride(arg540_1, (8960, 1536), (1536, 1), 'input')
            buf630 = reinterpret_tensor(buf609, (s16, 8960), (8960, 1), 0); del buf609  # reuse
            # Topologically Sorted Source Nodes: [linear_186], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf629, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg540_1, (1536, 8960), (1, 1536), 0), out=buf630)
            del arg540_1
            assert_size_stride(arg541_1, (8960, 1536), (1536, 1), 'input')
            buf631 = buf608; del buf608  # reuse
            # Topologically Sorted Source Nodes: [linear_187], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf629, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg541_1, (1536, 8960), (1, 1536), 0), out=buf631)
            del arg541_1
            buf632 = reinterpret_tensor(buf630, (s16, 1, 8960), (8960, 8960, 1), 0); del buf630  # reuse
            # Topologically Sorted Source Nodes: [linear_186, silu_26, linear_187, mul_244], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf632, buf631, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            assert_size_stride(arg542_1, (1536, 8960), (8960, 1), 'input')
            buf633 = reinterpret_tensor(buf629, (s16, 1536), (1536, 1), 0); del buf629  # reuse
            # Topologically Sorted Source Nodes: [linear_186, silu_26, linear_187, mul_244, down_proj_26], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf632, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg542_1, (8960, 1536), (1, 8960), 0), out=buf633)
            del arg542_1
            assert_size_stride_grouped((arg544_1, arg543_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf635 = reinterpret_tensor(buf613, (s16, 1, 1536), (1536, 1536, 1), 0); del buf613  # reuse
            # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_207, attn_output_107, hidden_states_211, down_proj_26, hidden_states_215, pow_55, variance_54, rsqrt_54, hidden_states_217, hidden_states_218], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf604, buf610, buf627, buf633, arg544_1, arg543_1.item(), buf635, s16, 1536, stream=raw_stream0)
            del arg543_1
            del arg544_1
            assert_size_stride_grouped((arg546_1, arg545_1), ((1536, ), (1536, 1536)), ((1, ), (1536, 1)), 'input')
            buf636 = buf580; del buf580  # reuse
            # Topologically Sorted Source Nodes: [linear_189], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg546_1, reinterpret_tensor(buf635, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg545_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf636)
            del arg545_1
            del arg546_1
            assert_size_stride_grouped((arg548_1, arg547_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf637 = buf616; del buf616  # reuse
            # Topologically Sorted Source Nodes: [linear_190], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg548_1, reinterpret_tensor(buf635, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg547_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf637)
            del arg547_1
            del arg548_1
            assert_size_stride(arg552_1, (s16, 2, s144, 128), (256*s144, 128*s144, 128, 1), 'input')
            arg552_1 = copy_if_misaligned(arg552_1)
            ps243 = 1 + s144
            ps244 = 128 + 128*s144
            ps245 = 256 + 256*s144
            buf638 = empty_strided_cuda((s16, 2, 1 + s144, 128), (256 + 256*s144, 128 + 128*s144, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, cos_30, sin_30, linear_190, view_82, key_states_27, mul_249, x2_55, neg_55, x1_55, cat_164, mul_250, k_embed_27, cat_165], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add]
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel = 256*s16 + 256*s144*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1.run(arg552_1, buf637, arg4_1, arg3_1, arg5_1.item(), buf638, ps243, s144, ps244, ps245, triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_1_xnumel, stream=raw_stream0)
            del arg552_1
            assert_size_stride_grouped((arg550_1, arg549_1), ((256, ), (256, 1536)), ((1, ), (1536, 1)), 'input')
            buf639 = buf637; del buf637  # reuse
            # Topologically Sorted Source Nodes: [linear_191], Original ATen: [aten.view, aten.t, aten.addmm]
            extern_kernels.addmm(arg550_1, reinterpret_tensor(buf635, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg549_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf639)
            del arg549_1
            del arg550_1
            assert_size_stride(arg554_1, (s16, 2, s145, 128), (256*s145, 128*s145, 128, 1), 'input')
            arg554_1 = copy_if_misaligned(arg554_1)
            ps246 = 1 + s145
            ps247 = 128 + 128*s145
            buf640 = empty_strided_cuda((s16, 2, 1 + s145, 128), (256 + 256*s145, 128 + 128*s145, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [linear_191, view_83, value_states_27, cat_166], Original ATen: [aten.view, aten.transpose, aten.cat]
            triton_poi_fused_cat_transpose_view_2_xnumel = 256*s16 + 256*s145*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_cat_transpose_view_2.run(arg554_1, buf639, buf640, ps246, s145, ps247, triton_poi_fused_cat_transpose_view_2_xnumel, stream=raw_stream0)
            del arg554_1
            del buf639
            buf641 = reinterpret_tensor(buf635, (s16, 2, 6, 128), (1536, 768, 128, 1), 0); del buf635  # reuse
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_189, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3.run(buf636, arg4_1, arg3_1, arg5_1.item(), buf641, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg3_1
            del arg4_1
            del arg5_1
            del buf636
            assert_size_stride(arg555_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg555_1 = copy_if_misaligned(arg555_1)
            ps248 = 1 + s144 + s91
            ps249 = 128 + 128*s144 + 128*s91
            buf642 = empty_strided_cuda((s16, 2, 1 + s144 + s91, 128), (256 + 256*s144 + 256*s91, 128 + 128*s144 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_189, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s144*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg555_1, buf638, buf642, ps248, s91, ps249, s144, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg555_1
            assert_size_stride(arg556_1, (1, 2, s91, 128), (256*s91, 128*s91, 128, 1), 'input')
            arg556_1 = copy_if_misaligned(arg556_1)
            ps250 = 1 + s145 + s91
            ps251 = 128 + 128*s145 + 128*s91
            buf643 = empty_strided_cuda((s16, 2, 1 + s145 + s91, 128), (256 + 256*s145 + 256*s91, 128 + 128*s145 + 128*s91, 128, 1), torch.float32)
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_189, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel = 256*s16 + 256*s145*s16 + 256*s16*s91
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4.run(arg556_1, buf640, buf643, ps250, s91, ps251, s145, triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_4_xnumel, stream=raw_stream0)
            del arg556_1
            # Topologically Sorted Source Nodes: [getitem, expand, getitem_3, position_ids_expanded, matmul, freqs, emb, cos, sin, linear_189, view_81, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_163, sin_30, mul_248, q_embed_27, packed_27, expand_55, key_tensors_27, expand_56, value_tensors_27, output_27], Original ATen: [aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin, aten.view, aten.mul, aten.slice, aten.neg, aten.add, aten._scaled_dot_product_efficient_attention]
            buf644 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf641, buf642, buf643, None, False, scale=0.08838834764831845)
            del buf642
            del buf643
            buf645 = buf644[0]
            assert_tensor_metadata(buf645, (s16, 2, 6, 128), (1536, 128, 256, 1), torch.float32, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            assert_alignment(buf645, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
            del buf644
            buf649 = buf641; del buf641  # reuse
            # Topologically Sorted Source Nodes: [attn_output_108], Original ATen: [aten.clone]
            triton_poi_fused_clone_5_xnumel = 1536*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_clone_5.run(buf645, buf649, triton_poi_fused_clone_5_xnumel, stream=raw_stream0)
            assert_size_stride(arg557_1, (1536, 1536), (1536, 1), 'input')
            buf650 = reinterpret_tensor(buf645, (s16, 1536), (1536, 1), 0); del buf645  # reuse
            # Topologically Sorted Source Nodes: [attn_output_108, transpose_112, reshape_83, attn_output_111], Original ATen: [aten.clone, aten._unsafe_view, aten.transpose, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf649, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg557_1, (1536, 1536), (1, 1536), 0), out=buf650)
            del arg557_1
            assert_size_stride_grouped((arg559_1, arg558_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf651 = buf604; del buf604  # reuse
            buf653 = reinterpret_tensor(buf649, (s16, 1, 1536), (1536, 1536, 1), 0); del buf649  # reuse
            # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_207, attn_output_107, hidden_states_211, down_proj_26, hidden_states_215, attn_output_111, hidden_states_219, pow_56, variance_55, rsqrt_55, hidden_states_221, hidden_states_222], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf651, buf610, buf627, buf633, buf650, arg559_1, arg558_1.item(), buf653, s16, 1536, stream=raw_stream0)
            del arg558_1
            del arg559_1
            del buf610
            del buf627
            del buf633
            del buf650
            assert_size_stride(arg560_1, (8960, 1536), (1536, 1), 'input')
            buf654 = reinterpret_tensor(buf632, (s16, 8960), (8960, 1), 0); del buf632  # reuse
            # Topologically Sorted Source Nodes: [pow_56, variance_55, rsqrt_55, hidden_states_221, hidden_states_222, linear_193], Original ATen: [aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf653, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg560_1, (1536, 8960), (1, 1536), 0), out=buf654)
            del arg560_1
            assert_size_stride(arg561_1, (8960, 1536), (1536, 1), 'input')
            buf655 = buf631; del buf631  # reuse
            # Topologically Sorted Source Nodes: [linear_194], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf653, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg561_1, (1536, 8960), (1, 1536), 0), out=buf655)
            del arg561_1
            buf656 = reinterpret_tensor(buf654, (s16, 1, 8960), (8960, 8960, 1), 0); del buf654  # reuse
            # Topologically Sorted Source Nodes: [linear_193, silu_27, linear_194, mul_253], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
            triton_poi_fused__unsafe_view_mul_silu_7_xnumel = 8960*s16
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__unsafe_view_mul_silu_7.run(buf656, buf655, triton_poi_fused__unsafe_view_mul_silu_7_xnumel, stream=raw_stream0)
            del buf655
            assert_size_stride(arg562_1, (1536, 8960), (8960, 1), 'input')
            buf657 = reinterpret_tensor(buf653, (s16, 1536), (1536, 1), 0); del buf653  # reuse
            # Topologically Sorted Source Nodes: [linear_193, silu_27, linear_194, mul_253, down_proj_27], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf656, (s16, 8960), (8960, 1), 0), reinterpret_tensor(arg562_1, (8960, 1536), (1, 8960), 0), out=buf657)
            del arg562_1
            del buf656
            assert_size_stride_grouped((arg564_1, arg563_1), ((1536, ), ()), ((1, ), ()), 'input')
            buf659 = reinterpret_tensor(buf651, (s16, 1, 1536), (1536, 1536, 1), 0); del buf651  # reuse
            # Topologically Sorted Source Nodes: [down_proj_27, hidden_states_223, pow_57, variance_56, rsqrt_56, hidden_states_225, hidden_states_226], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__unsafe_view_add_mean_mul_pow_rsqrt_18.run(buf659, buf657, arg564_1, arg563_1.item(), s16, 1536, stream=raw_stream0)
            del arg563_1
            del arg564_1
            del buf657
            buf660 = empty_strided_cuda((s16, 152265), (152265, 1), torch.float32)
            # Topologically Sorted Source Nodes: [down_proj_27, hidden_states_223, pow_57, variance_56, rsqrt_56, hidden_states_225, hidden_states_226, getitem_1880, logits], Original ATen: [aten._unsafe_view, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.slice, aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(buf659, (s16, 1536), (1536, 1), 0), reinterpret_tensor(arg2_1, (1536, 152265), (1, 1536), 0), out=buf660)
            del arg2_1
            del buf659
        return (buf6, buf4, buf29, buf27, buf53, buf51, buf76, buf74, buf100, buf98, buf123, buf121, buf147, buf145, buf170, buf168, buf194, buf192, buf217, buf215, buf241, buf239, buf264, buf262, buf288, buf286, buf311, buf309, buf335, buf333, buf358, buf356, buf382, buf380, buf405, buf403, buf429, buf427, buf452, buf450, buf476, buf474, buf499, buf497, buf523, buf521, buf546, buf544, buf570, buf568, buf593, buf591, buf617, buf615, buf640, buf638, reinterpret_tensor(buf660, (s16, 1, 152265), (152265, 152265, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = 50
    arg1_1 = rand_strided((50, 1), (1, 1), device='cuda:0', dtype=torch.int64)
    arg2_1 = rand_strided((152265, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg3_1 = rand_strided((50, 1), (1, 1), device='cuda:0', dtype=torch.int64)
    arg4_1 = rand_strided((64, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg5_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg6_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg7_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg8_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg9_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg10_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg11_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg12_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg13_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg14_1 = 50
    arg15_1 = 2
    arg16_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg17_1 = 2
    arg18_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg19_1 = 76
    arg20_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg21_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg22_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg23_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg24_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg25_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg26_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg27_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg28_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg29_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg30_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg31_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg32_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg33_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg34_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg35_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg36_1 = 2
    arg37_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg38_1 = 2
    arg39_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg40_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg41_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg42_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg43_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg44_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg45_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg46_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg47_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg48_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg49_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg50_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg51_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg52_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg53_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg54_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg55_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg56_1 = 2
    arg57_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg58_1 = 2
    arg59_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg60_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg61_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg62_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg63_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg64_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg65_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg66_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg67_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg68_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg69_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg70_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg71_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg72_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg73_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg74_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg75_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg76_1 = 2
    arg77_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg78_1 = 2
    arg79_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg80_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg81_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg82_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg83_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg84_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg85_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg86_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg87_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg88_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg89_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg90_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg91_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg92_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg93_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg94_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg95_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg96_1 = 2
    arg97_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg98_1 = 2
    arg99_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg100_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg101_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg102_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg103_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg104_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg105_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg106_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg107_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg108_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg109_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg110_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg111_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg112_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg113_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg114_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg115_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg116_1 = 2
    arg117_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg118_1 = 2
    arg119_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg120_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg121_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg122_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg123_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg124_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg125_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg126_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg127_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg128_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg129_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg130_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg131_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg132_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg133_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg134_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg135_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg136_1 = 2
    arg137_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg138_1 = 2
    arg139_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg140_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg141_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg142_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg143_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg144_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg145_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg146_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg147_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg148_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg149_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg150_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg151_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg152_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg153_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg154_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg155_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg156_1 = 2
    arg157_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg158_1 = 2
    arg159_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg160_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg161_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg162_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg163_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg164_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg165_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg166_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg167_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg168_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg169_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg170_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg171_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg172_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg173_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg174_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg175_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg176_1 = 2
    arg177_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg178_1 = 2
    arg179_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg180_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg181_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg182_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg183_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg184_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg185_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg186_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg187_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg188_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg189_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg190_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg191_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg192_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg193_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg194_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg195_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg196_1 = 2
    arg197_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg198_1 = 2
    arg199_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg200_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg201_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg202_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg203_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg204_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg205_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg206_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg207_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg208_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg209_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg210_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg211_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg212_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg213_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg214_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg215_1 = 2
    arg216_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg217_1 = 2
    arg218_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg219_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg220_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg221_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg222_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg223_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg224_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg225_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg226_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg227_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg228_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg229_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg230_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg231_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg232_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg233_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg234_1 = 2
    arg235_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg236_1 = 2
    arg237_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg238_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg239_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg240_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg241_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg242_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg243_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg244_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg245_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg246_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg247_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg248_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg249_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg250_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg251_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg252_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg253_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg254_1 = 2
    arg255_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg256_1 = 2
    arg257_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg258_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg259_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg260_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg261_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg262_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg263_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg264_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg265_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg266_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg267_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg268_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg269_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg270_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg271_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg272_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg273_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg274_1 = 2
    arg275_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg276_1 = 2
    arg277_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg278_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg279_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg280_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg281_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg282_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg283_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg284_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg285_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg286_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg287_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg288_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg289_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg290_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg291_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg292_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg293_1 = 2
    arg294_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg295_1 = 2
    arg296_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg297_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg298_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg299_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg300_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg301_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg302_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg303_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg304_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg305_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg306_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg307_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg308_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg309_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg310_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg311_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg312_1 = 2
    arg313_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg314_1 = 2
    arg315_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg316_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg317_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg318_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg319_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg320_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg321_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg322_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg323_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg324_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg325_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg326_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg327_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg328_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg329_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg330_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg331_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg332_1 = 2
    arg333_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg334_1 = 2
    arg335_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg336_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg337_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg338_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg339_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg340_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg341_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg342_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg343_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg344_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg345_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg346_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg347_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg348_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg349_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg350_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg351_1 = 2
    arg352_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg353_1 = 2
    arg354_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg355_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg356_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg357_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg358_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg359_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg360_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg361_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg362_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg363_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg364_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg365_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg366_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg367_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg368_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg369_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg370_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg371_1 = 2
    arg372_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg373_1 = 2
    arg374_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg375_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg376_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg377_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg378_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg379_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg380_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg381_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg382_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg383_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg384_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg385_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg386_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg387_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg388_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg389_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg390_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg391_1 = 2
    arg392_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg393_1 = 2
    arg394_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg395_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg396_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg397_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg398_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg399_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg400_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg401_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg402_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg403_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg404_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg405_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg406_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg407_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg408_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg409_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg410_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg411_1 = 2
    arg412_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg413_1 = 2
    arg414_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg415_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg416_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg417_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg418_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg419_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg420_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg421_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg422_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg423_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg424_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg425_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg426_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg427_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg428_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg429_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg430_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg431_1 = 2
    arg432_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg433_1 = 2
    arg434_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg435_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg436_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg437_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg438_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg439_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg440_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg441_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg442_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg443_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg444_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg445_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg446_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg447_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg448_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg449_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg450_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg451_1 = 2
    arg452_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg453_1 = 2
    arg454_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg455_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg456_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg457_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg458_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg459_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg460_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg461_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg462_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg463_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg464_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg465_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg466_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg467_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg468_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg469_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg470_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg471_1 = 2
    arg472_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg473_1 = 2
    arg474_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg475_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg476_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg477_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg478_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg479_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg480_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg481_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg482_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg483_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg484_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg485_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg486_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg487_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg488_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg489_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg490_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg491_1 = 2
    arg492_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg493_1 = 2
    arg494_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg495_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg496_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg497_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg498_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg499_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg500_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg501_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg502_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg503_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg504_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg505_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg506_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg507_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg508_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg509_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg510_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg511_1 = 2
    arg512_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg513_1 = 2
    arg514_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg515_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg516_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg517_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg518_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg519_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg520_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg521_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg522_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg523_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg524_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg525_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg526_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg527_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg528_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg529_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg530_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg531_1 = 2
    arg532_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg533_1 = 2
    arg534_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg535_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg536_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg537_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg538_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg539_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg540_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg541_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg542_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg543_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg544_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg545_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg546_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg547_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg548_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg549_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg550_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg551_1 = 2
    arg552_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg553_1 = 2
    arg554_1 = rand_strided((50, 2, 2, 128), (512, 256, 128, 1), device='cuda:0', dtype=torch.float32)
    arg555_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg556_1 = rand_strided((1, 2, 76, 128), (19456, 9728, 128, 1), device='cuda:0', dtype=torch.float32)
    arg557_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg558_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg559_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg560_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg561_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float32)
    arg562_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float32)
    arg563_1 = rand_strided((), (), device='cpu', dtype=torch.float64)
    arg564_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg565_1 = 1
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1, arg458_1, arg459_1, arg460_1, arg461_1, arg462_1, arg463_1, arg464_1, arg465_1, arg466_1, arg467_1, arg468_1, arg469_1, arg470_1, arg471_1, arg472_1, arg473_1, arg474_1, arg475_1, arg476_1, arg477_1, arg478_1, arg479_1, arg480_1, arg481_1, arg482_1, arg483_1, arg484_1, arg485_1, arg486_1, arg487_1, arg488_1, arg489_1, arg490_1, arg491_1, arg492_1, arg493_1, arg494_1, arg495_1, arg496_1, arg497_1, arg498_1, arg499_1, arg500_1, arg501_1, arg502_1, arg503_1, arg504_1, arg505_1, arg506_1, arg507_1, arg508_1, arg509_1, arg510_1, arg511_1, arg512_1, arg513_1, arg514_1, arg515_1, arg516_1, arg517_1, arg518_1, arg519_1, arg520_1, arg521_1, arg522_1, arg523_1, arg524_1, arg525_1, arg526_1, arg527_1, arg528_1, arg529_1, arg530_1, arg531_1, arg532_1, arg533_1, arg534_1, arg535_1, arg536_1, arg537_1, arg538_1, arg539_1, arg540_1, arg541_1, arg542_1, arg543_1, arg544_1, arg545_1, arg546_1, arg547_1, arg548_1, arg549_1, arg550_1, arg551_1, arg552_1, arg553_1, arg554_1, arg555_1, arg556_1, arg557_1, arg558_1, arg559_1, arg560_1, arg561_1, arg562_1, arg563_1, arg564_1, arg565_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
