
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*i64', 'in_ptr3': 'fp64', 'out_ptr0': '*fp32', 'ks0': 'i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=84, cc=86, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_clone_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 2335584}, 'backend_hash': 'AC46575B1351A648C125447A131E182C9AA2F39CAFBB6BA7C39A0D686CF1F7AB', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_efficient_attention__to_copy_add_bmm_cat_clone_cos_expand_mul_neg_sin_slice_transpose_unsqueeze_view_2(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, ks0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x3 = xindex
    x2 = xindex // 1536
    x0 = (xindex % 128)
    x4 = xindex // 128
    x1 = ((xindex // 128) % 12)
    tmp0 = tl.load(in_ptr0 + (x3), xmask)
    tmp1 = tl.load(in_ptr1 + ((x3 % 64)), xmask, eviction_policy='evict_last')
    tmp2 = tl.load(in_ptr2 + (x2), xmask, eviction_policy='evict_last')
    tmp6 = in_ptr3
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp1 * tmp3
    tmp5 = tl_math.cos(tmp4)
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tmp5 * tmp7
    tmp9 = tmp0 * tmp8
    tmp10 = (x0).to(tl.int32)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 >= tmp11
    tmp13 = (x0).to(tl.int64)
    tmp14 = (tmp13).to(tl.int64)
    tmp15 = tl.full([1], 64, tl.int64)
    tmp16 = tmp14 < tmp15
    tmp17 = tl.load(in_ptr0 + (64 + 128*x4 + (x0)), tmp16 & xmask, eviction_policy='evict_last', other=0.0)
    tmp18 = -tmp17
    tmp19 = tl.full(tmp18.shape, 0.0, tmp18.dtype)
    tmp20 = tl.where(tmp16, tmp18, tmp19)
    tmp21 = tmp10 >= tmp15
    tmp22 = tl.full([1], 128, tl.int64)
    tmp23 = tmp10 < tmp22
    tmp24 = tl.load(in_ptr0 + (128*x4 + ((-64) + x0)), tmp21 & xmask, eviction_policy='evict_last', other=0.0)
    tmp25 = tl.where(tmp16, tmp20, tmp24)
    tmp26 = tl_math.sin(tmp4)
    tmp27 = tmp26 * tmp7
    tmp28 = tmp25 * tmp27
    tmp29 = tmp9 + tmp28
    tl.store(out_ptr0 + (x0 + 128*x2 + 128*ks0*x1), tmp29, xmask)
