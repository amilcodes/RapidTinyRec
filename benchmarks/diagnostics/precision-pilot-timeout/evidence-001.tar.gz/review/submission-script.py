"""One fail-closed submission; --recover can only recover the same saved run."""
import argparse
import datetime
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
H = BASE / 'work/rapidtinyrec_precision'
SRC = BASE / 'work/rapidtinyrec_quality_source'
OUT = BASE / 'outputs'
KIT = '/Users/AmilAgrawal/Documents/Codex/2026-10-22/hel/outputs/oscar-agent-kit/oscar.py'
CONFIG = 'oscar.precision.json'
PROFILE = 'precision-pilot'
STATUS = OUT / 'rapidtinyrec_precision_pilot_status.json'
INTENT = OUT / 'rapidtinyrec_precision_pilot_submission_intent.json'
LEDGER = OUT / 'rapidtinyrec_research_loop_state.json'
FROZEN = H / '.oscar/pre_submission/pilot'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, indent=2) + '\n')
    tmp.replace(path)


def record_status(status):
    status['updated_at_utc'] = now()
    save(STATUS, status)
    quality=read(OUT / 'rapidtinyrec_quality_status.json')
    quality.update(active_gpu_job=status.get('job_id'),pilot_status=str(STATUS),status=status['status'],next_action=status.get('next_action'),updated_at_utc=status['updated_at_utc'])
    save(OUT / 'rapidtinyrec_quality_status.json',quality)
    ledger = read(LEDGER)
    ledger.update(active_experiment=status, current_gpu_job=status.get('job_id'),
                  remaining_gpu_job=status.get('job_id'), updated_at_utc=status['updated_at_utc'])
    for candidate in ledger.get('candidate_queue', []):
        if candidate['name'] == status['name']:
            candidate['status'] = status['status']
    save(LEDGER, ledger)


def audit_command(run):
    snapshot = H / '.oscar/source_snapshots' / run
    return [
        'python3', '-m', 'rapidtinyrec.audit_precision',
        str(H / '.oscar/results' / run / 'outputs'),
        '--historical', str(BASE / 'work/minionerec_oscar/.oscar/results/benchmark-gqa-fp32-20261023T054059Z-7b4f0ee334cb/outputs/gqa_500_users'),
        '--snapshot', str(snapshot / 'rapidtinyrec'),
        '--run-record', str(H / '.oscar/runs' / (run + '.json')),
        '--release-root', str(BASE / 'work/minionerec_trace/release'),
        '--output', str(OUT / 'rapidtinyrec_precision_pilot_audit.json')]


def finalize(record):
    assert record['profile'] == PROFILE and record['job_id']
    status = read(STATUS)
    assert status.get('run_id') in (None, record['run_id'])
    assert status.get('job_id') in (None, record['job_id'])
    snapshot = H / '.oscar/source_snapshots' / record['run_id']
    # Persist identity before any additional checks/copying or other work.
    status.update(status='SUBMITTED', submitted=True, run_id=record['run_id'], job_id=record['job_id'],
                  submitted_at_utc=record['created_at'], resources=record['resources'],
                  source_snapshot=str(snapshot), audit_cwd=str(snapshot),
                  audit_command=audit_command(record['run_id']))
    record_status(status)
    save(INTENT, dict(read(INTENT), run_id=record['run_id'], job_id=record['job_id'], submitted=True))
    intent = read(INTENT)
    assert record['sha256'] == intent['sha256']
    assert record['resources'] == read(FROZEN / CONFIG)['profiles'][PROFILE]
    snapshot.mkdir(parents=True, exist_ok=True)
    for name, expected in record['sha256'].items():
        source = FROZEN / name
        assert sha(source) == expected
        target = snapshot / name
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        assert sha(target) == expected
        target.chmod(0o444)
    target = snapshot / '.submission-config.json'
    if not target.exists():
        shutil.copy2(FROZEN / CONFIG, target)
    assert sha(target) == sha(FROZEN / CONFIG)
    target.chmod(0o444)
    status.update(snapshot_files_verified=len(record['files']),
                  next_action='Monitor this existing run only. After terminal fetch immutable raw outputs, execute the saved audit from its frozen cwd and independently inspect exactness, ownership, repeats, quality, latency by length/half and memory. Preserve failures. Full500 quality review only after audited control exactness, within-policy stability, validity, dispatch and predeclared material performance gates. Candidate/control bit drift is informational. No automatic promotion.')
    record_status(status)
    ledger = read(LEDGER)
    if not any(e.get('run_id') == record['run_id'] for e in ledger['experiments']):
        ledger['experiments'].append(dict(status))
    save(LEDGER, ledger)
    print(json.dumps(status, indent=2))


def recover():
    assert INTENT.exists(), 'No existing submission intent to recover'
    intent = read(INTENT)
    records = [p for p in (H / '.oscar/runs').glob(PROFILE + '-*.json')
               if read(p)['created_at'] >= intent['intent_at_utc']]
    assert len(records) == 1, 'Inspect intent/stdout/remote state; never submit a replacement here'
    record = read(records[0])
    if not record.get('job_id'):
        subprocess.run(['python3', KIT, '--config', CONFIG, 'recover', record['run_id']], cwd=H, check=True)
        record = read(records[0])
    finalize(record)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--recover', action='store_true')
    args = ap.parse_args()
    if args.recover:
        recover()
        return
    assert not INTENT.exists(), 'Existing intent: use --recover, never submit again'
    status = read(STATUS); ledger = read(LEDGER)
    assert not status.get('submitted') and not status.get('run_id') and not status.get('job_id')
    assert not ledger.get('current_gpu_job') and not ledger.get('remaining_gpu_job')
    assert ledger.get('active_experiment') in (None, status), 'Another active or uncertain experiment'
    assert not read(OUT / 'rapidtinyrec_serving_status.json').get('active_gpu_job')
    assert not read(OUT / 'rapidtinyrec_quality_status.json').get('active_gpu_job')
    assert not list((H / '.oscar/runs').glob(PROFILE + '-*.json'))
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SRC, text=True).strip()
    commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SRC, text=True).strip()
    assert commit == status['source_commit'] == read(H / 'source-provenance.json')['source_commit']
    ci = json.loads(subprocess.check_output(['gh', 'run', 'view', str(status['ci_run_id']), '--json',
        'headSha,status,conclusion,url'], cwd=SRC, text=True))
    assert ci['headSha'] == commit and ci['status'] == 'completed' and ci['conclusion'] == 'success', ci
    config = read(H / CONFIG)
    queue = subprocess.check_output(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15',
        config['ssh_target'], 'squeue -u aagraw73 -h -o "%i|%j|%T|%M|%R"'], text=True)
    assert not queue.strip(), 'Existing account jobs: inspect; one GPU experiment at a time'
    plan = json.loads(subprocess.check_output(['python3', KIT, '--config', CONFIG, 'plan', '--profile', PROFILE], cwd=H, text=True))
    assert plan['resources'] == config['profiles'][PROFILE]
    hashes = {name: sha(H / name) for name in plan['files']}
    provenance = read(H / 'source-provenance.json')
    for name, expected in provenance['source_files'].items():
        assert hashes[name] == expected
        assert hashlib.sha256(subprocess.check_output(['git', 'show', f'{commit}:{name}'], cwd=SRC)).hexdigest() == expected
    FROZEN.mkdir(parents=True, exist_ok=False)
    for name, expected in hashes.items():
        target = FROZEN / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(H / name, target)
        assert sha(target) == expected
        target.chmod(0o444)
    intent = dict(intent_at_utc=now(), source_commit=commit, sha256=hashes, resources=plan['resources'],
                  profile=PROFILE, harness=str(H), submitted=False, ci=ci,
                  audit_command_template=audit_command('{run_id}'),
                  audit_cwd_template=str(H / '.oscar/source_snapshots/{run_id}'))
    with INTENT.open('x') as f:
        json.dump(intent, f, indent=2)
    status.update(status='SUBMITTING_DO_NOT_DUPLICATE', ci_conclusion='success', ci_url=ci['url'],
                  resources=plan['resources'], automation_id='packed-mlp-rounding-diagnostic-follow-up')
    record_status(status)
    stdout = OUT / 'rapidtinyrec_precision_pilot_submit.json'
    stderr = OUT / 'rapidtinyrec_precision_pilot_submit.stderr'
    with stdout.open('x') as f, stderr.open('x') as e:
        result = subprocess.run(['python3', KIT, '--config', CONFIG, 'submit', '--profile', PROFILE], cwd=H, stdout=f, stderr=e)
    if result.returncode:
        raise SystemExit('Submission uncertain: inspect saved outputs and run records; --recover only, never resubmit')
    finalize(read(stdout))


if __name__ == '__main__':
    main()
