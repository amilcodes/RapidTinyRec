"""Schema-specific precision pilot publication; fidelity is not quality acceptance.

Requires a complete independently audited run. Execution/integrity failures need
a separate failure archive/report; never fabricate a completed result. No GPU
work or bootstrap is performed here. Raw failures and all audit fields survive.
"""
import argparse
import csv
import gzip
import hashlib
import io
import json
import math
from pathlib import Path
import tarfile
import tempfile

VARIANTS=('folded_fp32','folded_tf32')


def read(path):return json.loads(Path(path).read_text())
def sha(data):return hashlib.sha256(data).hexdigest()


def comparison(c, requests=None):
    if requests is not None:assert c['requests']==requests
    for name,width in [('rank_positions',50),('sequence_values',50),('transition_values',250)]:
        assert c[name]==c['requests']*width
        assert 0<=c['matching_'+name]<=c[name]
    for name in ('max_sequence_difference_common','max_transition_difference_common'):
        assert math.isfinite(c[name]) and c[name]>=0
    return all(c['matching_'+k]==c[k] for k in ('rank_positions','sequence_values','transition_values'))


def summary(a):
    assert a['integrity_audit_passed'] is True
    full=a['unique_users']==500
    assert a['unique_users'] in (4,500) and a['paired_requests']==(500 if full else 24)
    candidate_exact=comparison(a['comparison'],a['paired_requests'])
    assert set(a['historical_comparisons'])==set(VARIANTS)
    for c in a['historical_comparisons'].values():comparison(c,a['paired_requests'])
    control=comparison(a['historical_comparisons']['folded_fp32'])
    stable=comparison(a['repeated_comparison']) and a['ancestry_stable']
    assert len(a['phases'])==4
    for i,p in enumerate(a['phases']):
        assert p['phase']==i and p['variant']==('folded_fp32','folded_tf32','folded_tf32','folded_fp32')[i]
        for name in ('warmup_comparison','repeat_comparison','profile_comparison'):
            ok=comparison(p[name]);stable=stable and ok
        comparison(p['warmup_historical_comparison'])
        if p['variant']=='folded_fp32':control=control and comparison(p['warmup_historical_comparison'])
        assert p['measurement_compilations']==p['measurement_captures']==0
    assert a['candidate_bit_exact']==candidate_exact
    assert a['control_exact']==control and a['stability_exact']==stable
    assert a['dispatch_verified']==all(p['dispatch']['verified'] for p in a['phases'])
    q=a['quality']
    assert q['schema']=='paired-sid-quality-v1' and q['primary_metrics']==['ndcg@10','hit_rate@10']
    assert q['overall']['independent_users']==len(q['per_user'])==a['unique_users']
    assert len({u['cohort_index'] for u in q['per_user']})==a['unique_users']
    assert q['bootstrap']['samples']==10000 and q['bootstrap']['seed']==20261026
    assert q['promotion'] is False and q['noninferiority_established'] is False
    for counts in q['output_validity'].values():
        assert set(counts)=={'invalid_outputs','duplicate_valid_sids'}
        assert all(type(v) is int and 0<=v<=50*a['unique_users'] for v in counts.values())
    assert set(q['output_validity'])=={'control','candidate'}
    valid=q['token_repeat_stability'] and all(v==0 for c in q['output_validity'].values() for v in c.values())
    assert a['validity_passed']==valid
    strata=[a['latency_ms'],*a['latency_by_length_ms'].values(),*a['latency_by_half_ms'].values()]
    for t in strata+list(a['latency_by_length_half_ms'].values()):
        assert set(t)==set(VARIANTS)
        for x in t.values():assert all(math.isfinite(x[k]) and x[k]>0 for k in ('median_ms','p95_ms'))
    useful=all(t[VARIANTS[1]][k]<=.9*t[VARIANTS[0]][k] for t in strata for k in ('median_ms','p95_ms'))
    no_regression=all(t[VARIANTS[1]][k]<=t[VARIANTS[0]][k] for t in a['latency_by_length_half_ms'].values() for k in ('median_ms','p95_ms'))
    assert a['performance_gate']['minimum_reduction_percent']==10
    assert a['performance_gate']['passed']==(useful and no_regression)
    eligible=control and stable and valid and a['dispatch_verified'] and useful and no_regression
    assert a['eligible_for_full_quality_review']==eligible
    assert a['promotion'] is False and a['noninferiority_established'] is False
    return dict(a,experiment='tf32-quality-full' if full else 'tf32-quality-pilot',
        timing_boundary='Generation includes staging/wrappers/original HF clones; excludes prep, output/transition extraction, scans, profiling and files. Setup intervals nest; model load is separate.',
        interpretation='Candidate/control bits are fidelity evidence, not a quality-loss test. Small pilots do not establish population parity; no accepted noninferiority margin or automatic adoption.')


def add_tree(entries, root, prefix):
    assert root.is_dir()
    for p in sorted(root.rglob('*')):
        assert not p.is_symlink(), p
        if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc':
            name = prefix + '/' + p.relative_to(root).as_posix()
            assert name not in entries
            entries[name] = p.read_bytes()


def archive_bytes(entries):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in sorted(entries.items()):
                assert not Path(name).is_absolute() and '..' not in Path(name).parts
                item = tarfile.TarInfo(name)
                item.size = len(data); item.mode = 0o444; item.mtime = 0
                archive.addfile(item, io.BytesIO(data))
    return output.getvalue()


def write_shards(root, entries, limit=48*1024*1024):
    """Split by complete members; never omit a large or failed raw output."""
    pending = [dict(sorted(entries.items()))]; shards = []; members = {}
    while pending:
        group = pending.pop(0)
        encoded = archive_bytes(group)
        if len(encoded) >= limit:
            assert len(group) > 1, 'Single member exceeds archive limit; preserve it and review separate chunking'
            keys = list(group); middle = len(keys)//2
            pending[0:0] = [{k: group[k] for k in keys[:middle]}, {k: group[k] for k in keys[middle:]}]
            continue
        name = f'evidence-{len(shards)+1:03d}.tar.gz'
        (root/name).write_bytes(encoded)
        shards.append(dict(path=name, bytes=len(encoded), sha256=sha(encoded), files=len(group)))
        for key, data in group.items():
            members[key] = dict(bytes=len(data), sha256=sha(data), archive=name)
    assert set(members) == set(entries)
    return dict(archives=shards, files=members)


def write_csv(path, rows):
    fields = sorted({k for row in rows for k in row})
    with path.open('w') as f:
        writer = csv.DictWriter(f, fieldnames=fields, lineterminator='\n')
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, separators=(',', ':')) if isinstance(v, (dict,list)) else v for k,v in row.items()})


def verify_raw(entries, manifest, run):
    assert manifest['run_id']==run
    expected={'raw/'+r['path']:dict(bytes=r['size'],sha256=r['sha256']) for r in manifest['files']}
    assert len(expected)==len(manifest['files'])
    actual={n:dict(bytes=len(v),sha256=sha(v)) for n,v in entries.items() if n.startswith('raw/')}
    assert expected==actual,'Complete immutable raw inventory required'


def export(status_path,audit_path,destination):
    status=read(status_path);a=read(audit_path);result=summary(a)
    assert status['scheduler_state']=='COMPLETED','Execution failures need a failure-specific report'
    assert not destination.exists(),'Never overwrite evidence'
    run=status['run_id'];h=Path(status['harness']);raw=h/'.oscar/results'/run;snapshot=Path(status['source_snapshot'])
    record_path=h/'.oscar/runs'/(run+'.json');record=read(record_path)
    assert record['run_id']==run and str(record['job_id'])==str(status['job_id'])
    assert record['resources']==status['resources']
    assert read(raw/'source-manifest.json')['sha256']==record['sha256']
    assert (raw/'job-id').read_text().strip()==str(record['job_id'])
    assert a['snapshot_files_verified']==len(record['files'])==len(record['sha256'])
    for name,want in record['sha256'].items():assert sha((snapshot/name).read_bytes())==want,name
    assert Path(status['audit_cwd'])==snapshot
    assert sha((snapshot/'rapidtinyrec/audit_precision.py').read_bytes())==a['audit_script_sha256']
    assert read(snapshot/'source-provenance.json')['source_commit']==status['source_commit']
    review=read(status['independent_review'])
    assert review['run_id']==run and review['audit_sha256']==sha(audit_path.read_bytes())
    assert review['promotion'] is False and review['noninferiority_established'] is False
    assert review['eligible_for_full_quality_review']==a['eligible_for_full_quality_review']
    result['decision']=review['decision']
    entries={};add_tree(entries,raw,'raw');add_tree(entries,snapshot,'source-snapshot')
    verify_raw(entries,read(status['raw_manifest']),run)
    entries.update({'audit.json':audit_path.read_bytes(),'run-record.json':record_path.read_bytes(),
        'status.json':status_path.read_bytes(),'export_precision.py':Path(__file__).read_bytes(),
        'test_precision_export.py':Path(__file__).with_name('test_precision_export.py').read_bytes()})
    for field in ('independent_review','raw_manifest','audit_stdout','audit_stderr','ci_log','submission_script'):
        path=Path(status[field]);entries['review/'+path.name]=path.read_bytes()
    if status.get('independent_review_script'):
        path=Path(status['independent_review_script']);entries['review/'+path.name]=path.read_bytes()
    entries['reproduce.json']=json.dumps(dict(audit_command=status['audit_command'],audit_cwd=status['audit_cwd'],
        instructions='Extract all shards. Run the frozen audit from source-snapshot, explicitly relocating --snapshot, --run-record, results, --historical and --release-root to verified resources. A full500 bootstrap requires allocated compute. Keep failed gates; never promote from archive validity.'),indent=2).encode()
    requests=[]
    for phase in range(4):
        rows=read(raw/'outputs'/f'phase_{phase}'/'requests.json')
        assert len(rows)==(250 if a['unique_users']==500 else 12)
        for r in rows:
            requests.append(dict(phase=phase,variant=r['variant'],repeat=r['repeat'],cohort_index=r['cohort_index'],
                                 prompt_tokens=r['prompt_tokens'],generation_ms=1000*r['run']['elapsed_s']))
    destination.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=destination.parent,prefix='.precision-evidence-') as tmp:
        staged=Path(tmp)/'result';staged.mkdir()
        write_csv(staged/'requests.csv',requests)
        write_csv(staged/'quality-per-user.csv',a['quality']['per_user'])
        write_csv(staged/'dispatch.csv',[dict(phase=p['phase'],variant=p['variant'],**p['dispatch']) for p in a['phases']])
        (staged/'summary.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
        (staged/'audit.json').write_bytes(audit_path.read_bytes())
        manifest=write_shards(staged,entries)
        (staged/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
        source=dict(run_id=run,job_id=status['job_id'],measured_repository_commit=status['source_commit'],
            submitted_source_sha256=record['sha256'],resources=record['resources'],
            evidence_sha256={p.name:sha(p.read_bytes()) for p in staged.iterdir()})
        (staged/'source.json').write_text(json.dumps(source,indent=2)+'\n');staged.rename(destination)
    return dict(destination=str(destination),archive_files=len(entries),shards=len(manifest['archives']),
                candidate_bit_exact=a['candidate_bit_exact'],eligible_for_full_quality_review=a['eligible_for_full_quality_review'],promotion=False)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--status',type=Path,required=True);ap.add_argument('--audit',type=Path,required=True)
    ap.add_argument('--destination',type=Path,required=True);args=ap.parse_args()
    print(json.dumps(export(args.status,args.audit,args.destination),indent=2))

if __name__=='__main__':main()
