"""Archive an incomplete TF32 pilot without invoking the completed-run exporter."""
import json
from pathlib import Path
import tarfile
from export_precision import add_tree, sha, write_shards
BASE = Path(__file__).resolve().parents[2]
read=lambda p:json.loads(Path(p).read_text())
def main():
 s=read(BASE/'outputs/rapidtinyrec_precision_pilot_status.json')
 r=read(BASE/'outputs/quality_frontier/precision-timeout-independent-review.json')
 assert s['scheduler_state']==r['scheduler_state']=='TIMEOUT'
 assert s['run_id']==r['run_id']=='precision-pilot-20261026T053441Z-f040754d1743'
 assert s['job_id']==r['job_id']=='7958148'
 assert r['original_integrity_audit_passed'] is False
 assert all(r[k] is False for k in ('full_performance_gate_evaluable','eligible_for_full_quality_review','promotion','noninferiority_established'))
 assert sha(Path(s['audit_result']).read_bytes())==r['audit_sha256']
 root=Path(s['harness'])/'.oscar/results'/s['run_id']
 snapshot=Path(s['source_snapshot'])
 record=Path(s['harness'])/'.oscar/runs'/(s['run_id']+'.json')
 entries={};add_tree(entries,root,'raw');add_tree(entries,snapshot,'source')
 manifest=read(s['raw_manifest'])
 assert len(manifest['files'])==235
 assert {k[4:] for k in entries if k.startswith('raw/')}=={x['path'] for x in manifest['files']}
 for row in manifest['files']:
  data=entries['raw/'+row['path']]
  assert len(data)==row['size'] and sha(data)==row['sha256']
 for name,digest in read(record)['sha256'].items():assert sha(entries['source/'+name])==digest
 extra={'run-record.json':record,'status-at-export.json':BASE/'outputs/rapidtinyrec_precision_pilot_status.json','failed-audit.json':Path(s['audit_result']),'raw-manifest.json':Path(s['raw_manifest']),'audit.stdout':Path(s['audit_stdout']),'audit.stderr':Path(s['audit_stderr']),'independent-review.json':BASE/'outputs/quality_frontier/precision-timeout-independent-review.json','ci-measured-source.log':Path(s['ci_log']),'submission-script.py':Path(s['submission_script']),'submission-intent.json':BASE/'outputs/rapidtinyrec_precision_pilot_submission_intent.json','review_precision_timeout.py':Path(__file__).with_name('review_precision_timeout.py'),'archive_precision_timeout.py':Path(__file__),'export_precision.py':Path(__file__).with_name('export_precision.py')}
 for name,p in extra.items():entries['review/'+name]=p.read_bytes()
 dest=BASE/'work/rapidtinyrec_quality_source/benchmarks/diagnostics/precision-pilot-timeout'
 dest.mkdir(parents=True,exist_ok=False)
 archive=write_shards(dest,entries)
 seen=set()
 for item in archive['archives']:
  p=dest/item['path'];assert sha(p.read_bytes())==item['sha256'] and p.stat().st_size<48*1024*1024
  with tarfile.open(p,'r:gz') as tf:
   for member in tf.getmembers():
    assert member.isfile() and member.name not in seen
    data=tf.extractfile(member).read();expected=archive['files'][member.name]
    assert len(data)==expected['bytes'] and sha(data)==expected['sha256']
    seen.add(member.name)
 assert seen==set(entries)
 archive.update(run_id=s['run_id'],schema='precision-timeout-archive-v1',scheduler_state='TIMEOUT',verified_members=len(seen))
 (dest/'archive-manifest.json').write_text(json.dumps(archive,indent=2)+'\n')
 (dest/'summary.json').write_text(json.dumps(r,indent=2)+'\n')
 (dest/'failed-audit.json').write_bytes(Path(s['audit_result']).read_bytes())
 (dest/'reproduction.json').write_text(json.dumps({'audit_cwd':s['audit_cwd'],'audit_command':s['audit_command'],'expected_audit_exit_code':1,'expected_missing_file':'outputs/phase_2/summary.json','partial_review_command':['python3',str(extra['review_precision_timeout.py'])],'partial_review_note':'Requires original workspace paths and absent output target; output is diagnostic only. Script calls unchanged frozen audit and inspects its exception frame for completed phase checks. It never supplies missing phases. Historical/release roots are required and remain separately pinned resources.','archive_verification':'Verify archive SHA256 and every extracted member against archive-manifest.json; do not submit a GPU job.'},indent=2)+'\n')
 (dest/'README.md').write_text('''# TF32 pilot timeout evidence

Job 7958148 reached its 30-minute limit during phase 2 setup. Phases 0 (FP32) and 1 (TF32) completed; phase 3 never started. The original frozen auditor exited 1 because phase_2/summary.json is absent. This is an incomplete execution, not a completed performance or quality pass.

The complete fetched raw tree (235 files), submitted source/config snapshot (59 verified submitted files plus metadata), logs, generated code, API traces, original failed audit, source CI log, submission record and independent diagnostic review are preserved in hashed shards below 48 MiB. Every archived member was read back and verified. archive-manifest.json enumerates all members.

The diagnostic review calls the unchanged frozen auditor, catches its missing-file exception, and retrieves completed phase checks from that exception frame. It recomputes paired timings and four-user quality using frozen helpers. Full integrity remains failed; no missing phase is invented. This review is performed by the same research agent, not an independent reviewer identity.

In the first AB half, median/p95 generation was 114.947196/117.922076 ms FP32 versus 83.586782/84.571161 ms TF32 (27.28%/28.28% lower). There are 12 pairs across four users, three repeats each. Control is historically exact in available outputs; available within-policy checks and real model TF32 dispatch pass. Candidate scores differ; 591/600 repeated rank positions match (197/200 unique-user positions). One user's list changes. Hit/NDCG/MRR at 1/5/10/20/50 are unchanged for these four users only, with no invalid or duplicate outputs. A degenerate bootstrap interval on four unchanged user deltas does not establish population equivalence.

summary.json retains all available length, per-user, memory, dispatch, fidelity and quality details. Second-half and length-by-second-half statistics do not exist. The full predeclared performance gate cannot be evaluated, full500 eligibility is false, promotion is false and noninferiority is not established.

Completed phase setup took 758.051 and 782.936 seconds; compiler and capture durations nest inside setup and must not be summed as disjoint costs. Phase 2 had nonempty disk artifacts but still timed out in warmup. No fatal Python error or OOM is evident. Logging/compiler/capture contributions have not been isolated. Diagnose setup cost before designing a separately frozen bounded repair; no automatic replacement or full500 submission.
''')
 print(json.dumps({'members':len(seen),'raw_files':235,'archives':archive['archives'],'destination':str(dest)},indent=2))
if __name__=='__main__':main()
