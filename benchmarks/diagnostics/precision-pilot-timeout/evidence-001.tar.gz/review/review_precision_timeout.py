"""Diagnose preserved partial evidence; never turn an incomplete pilot into a pass.

The original auditor is called unchanged. Its exception traceback exposes the
completed phase checks for diagnosis only. The original failed audit is retained.
No missing phases are synthesized and the full-pilot gates remain unavailable.
"""
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parents[2]


def read(p):
    return json.loads(Path(p).read_text())


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    status = read(BASE/'outputs/rapidtinyrec_precision_pilot_status.json')
    assert status['scheduler_state'] == 'TIMEOUT' and status['job_id'] == '7958148'
    snapshot = Path(status['source_snapshot'])
    root = Path(status['harness'])/'.oscar/results'/status['run_id']
    record_path = Path(status['harness'])/'.oscar/runs'/(status['run_id']+'.json')
    record = read(record_path)
    for name, digest in record['sha256'].items():
        assert sha(snapshot/name) == digest, name
    raw_manifest = read(status['raw_manifest'])
    files = {p.relative_to(root).as_posix(): p for p in root.rglob('*') if p.is_file()}
    assert set(files) == {r['path'] for r in raw_manifest['files']}
    for row in raw_manifest['files']:
        p = files[row['path']]
        assert p.stat().st_size == row['size'] and sha(p) == row['sha256']
        assert not p.stat().st_mode & 0o222
    assert read(root/'source-manifest.json')['sha256'] == record['sha256']
    assert (root/'job-id').read_text().strip() == status['job_id']
    assert read(snapshot/'source-provenance.json')['source_commit'] == status['source_commit']
    original = read(status['audit_result'])
    assert original['integrity_audit_passed'] is False
    assert 'phase_2/summary.json' in original['traceback']
    sys.path.insert(0, str(snapshot))
    from rapidtinyrec import audit_precision as frozen
    historical = Path(status['audit_command'][status['audit_command'].index('--historical')+1])
    release = Path(status['audit_command'][status['audit_command'].index('--release-root')+1])
    try:
        frozen.audit(root/'outputs', historical, snapshot/'rapidtinyrec', record_path, release)
    except FileNotFoundError as error:
        assert str(error.filename) == str(root/'outputs/phase_2/summary.json')
        trace = error.__traceback__
        captured = None
        while trace is not None:
            if trace.tb_frame.f_code is frozen.audit.__code__:
                captured = dict(trace.tb_frame.f_locals)
            trace = trace.tb_next
        assert captured is not None
    else:
        raise AssertionError('Incomplete run unexpectedly passed')
    phases = captured['phases']
    assert [p['phase'] for p in phases] == [0, 1]
    paired = [captured['joined'][k] for k in sorted(captured['joined'])]
    assert len(paired) == 12 and all(set(r['runs']) == set(frozen.VARIANTS) for r in paired)
    assert all(r['repeat'] in (0, 1, 2) for r in paired)
    # Recompute from saved rows, independently of summary latency values.
    timing = frozen.latency(paired, frozen.VARIANTS)
    historical_comparisons = {v: frozen.compare(rows) for v, rows in captured['historical_pairs'].items()}
    comparison = frozen.compare([(r['runs']['folded_fp32'], r['runs']['folded_tf32']) for r in paired])
    quality_input = frozen.quality_inputs(release, captured['users'], paired)
    quality = frozen.evaluate(**quality_input)
    assert quality['overall']['independent_users'] == 4
    partial = dict(historical_comparisons=historical_comparisons,
                   repeated_comparison=frozen.compare(captured['repeated']),
                   ancestry_stable=captured['ancestry_stable'], phases=phases,
                   comparison=comparison)
    result = dict(schema='precision-timeout-review-v1', run_id=status['run_id'],
        job_id=status['job_id'], audit_sha256=sha(status['audit_result']),
        frozen_auditor_sha256=sha(snapshot/'rapidtinyrec/audit_precision.py'),
        scheduler_state='TIMEOUT', elapsed_s=1820,
        raw_files_verified=len(files), raw_bytes=sum(p.stat().st_size for p in files.values()),
        source_files_verified=len(record['sha256']),
        original_integrity_audit_passed=False, original_audit_exit_code=status['audit_exit_code'],
        original_audit_missing_file='outputs/phase_2/summary.json',
        completed_phases=[0,1], incomplete_phase=2, absent_phases=[3],
        completed_request_rows=24, partial_pairs=12, unique_users=4,
        partial_phase_checks=phases, partial_fidelity=frozen.fidelity_gate(partial),
        partial_comparison=comparison, partial_historical_comparisons=historical_comparisons,
        partial_latency_ms=timing,
        partial_reductions_percent={s:100*(1-timing['folded_tf32'][s]/timing['folded_fp32'][s]) for s in ('median_ms','p95_ms')},
        partial_latency_by_length_ms={str(n):frozen.latency([r for r in paired if r['prompt_tokens']==n],frozen.VARIANTS) for n in (76,121)},
        partial_per_user=[dict(cohort_index=i,latency_ms=frozen.latency([r for r in paired if r['cohort_index']==i],frozen.VARIANTS)) for i in (1,2,6,10)],
        partial_quality=quality, partial_quality_input_sha256=frozen.json_digest(quality_input),
        partial_dispatch_verified=all(p['dispatch']['verified'] for p in phases),
        partial_validity_passed=quality['token_repeat_stability'] and all(v==0 for c in quality['output_validity'].values() for v in c.values()),
        full_performance_gate_evaluable=False, eligible_for_full_quality_review=False,
        promotion=False, noninferiority_established=False,
        diagnosis='Slurm time limit interrupted phase2 setup/warmup. Phase0/1 setup took 758.051s/782.936s; compiler/capture timings nest within setup. Phase2 reused nonempty disk artifacts but had not reached measurements; phase3 never started. No OOM or Python fatal exception appears in fetched stderr. The precise contribution of API logging versus capture versus compiler work is not isolated.',
        limitations='Only first AB half completed, no second-half or cross-process repeat verification. Four users cannot establish quality parity. Partial comparisons are descriptive, not a completed pilot or a gate waiver.',
        decision='Preserve and publish timeout evidence. Block full500 and automatic resubmission. Diagnose setup budget before proposing any separately frozen bounded repair; retain exact checks and ABBA design.')
    dest = BASE/'outputs/quality_frontier/precision-timeout-independent-review.json'
    assert not dest.exists()
    dest.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:result[k] for k in ['completed_phases','partial_reductions_percent','partial_fidelity','partial_dispatch_verified','partial_validity_passed','decision']},indent=2))


if __name__ == '__main__':
    main()
