"""Archive audited beam replay, including raw helper ties and negative gates.

Preparation only until a completed run has a saved audit and independent review.
The measured package/snapshot is never modified by this exporter.
"""
import argparse
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import struct
import tarfile
import tempfile

BASE = Path(__file__).resolve().parents[2]
VARIANTS = ('folded_prefix_replay', 'beam_replay')


def read(path):
    return json.loads(path.read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def flatten(run, field):
    return run[field] if field == 'sequence_logp' else [x for row in run[field] for x in row]


def bit_bytes(values):
    return b''.join(struct.pack('!f', value) for value in values)


def export_pair(pair):
    row = {k: pair[k] for k in ('repeat', 'cohort_index', 'prompt_tokens')}
    for variant in VARIANTS:
        run = pair['runs'][variant]
        row[variant + '_phase'] = pair['phases'][variant]
        row[variant + '_ms'] = run['elapsed_s'] * 1000
        row[variant + '_ranking_sha256'] = digest(json.dumps(run['token_ids'], separators=(',', ':')).encode())
        for field in ('sequence_logp', 'transition_logp'):
            row[variant + '_' + field + '_sha256'] = digest(bit_bytes(flatten(run, field)))
    left, right = (pair['runs'][v] for v in VARIANTS)
    row['matching_rank_positions'] = sum(a == b for a, b in zip(left['token_ids'], right['token_ids']))
    row['matching_rank_list'] = left['token_ids'] == right['token_ids']
    for field, label in (('sequence_logp', 'sequence'), ('transition_logp', 'transition')):
        a, b = (flatten(run, field) for run in (left, right))
        row['matching_' + label + '_values'] = sum(bit_bytes([x]) == bit_bytes([y]) for x, y in zip(a, b))
        row['max_' + label + '_difference_at_rank'] = max(abs(x - y) for x, y in zip(a, b))
        # Also report common-candidate deltas; rank-position and candidate-aligned
        # comparisons answer different questions if ordering changes.
        a, b = ({tuple(ids): score for ids, score in zip(run['token_ids'], run[field])} for run in (left, right))
        deltas = []
        for ids in a.keys() & b.keys():
            x, y = ([a[ids]], [b[ids]]) if label == 'sequence' else (a[ids], b[ids])
            deltas.extend(abs(i-j) for i, j in zip(x, y))
        row['max_' + label + '_difference_common'] = max(deltas, default=0.)
    return row


def summary(audit, rows):
    assert audit['integrity_audit_passed'] and len(rows) == audit['paired_requests']
    assert len({r['cohort_index'] for r in rows}) == audit['unique_users']
    for field in ('matching_rank_positions', 'matching_sequence_values', 'matching_transition_values'):
        assert sum(r[field] for r in rows) == audit['comparison'][field], field
    assert sum(r['matching_rank_list'] for r in rows) == audit['comparison']['matching_rank_lists']
    # Carry the entire audit, including every negative probe/repeat/quality gate,
    # instead of reconstructing a successful subset or replacing counts by totals.
    return dict(audit, experiment='beam-replay', control=VARIANTS[0], candidate=VARIANTS[1],
        timing_boundary='Synchronized generation call including staging and original HF score clones; excludes input preparation, output/transition extraction, post-request audit scans and file writes.',
        max_sequence_difference_at_rank=max(r['max_sequence_difference_at_rank'] for r in rows),
        max_transition_difference_at_rank=max(r['max_transition_difference_at_rank'] for r in rows))


def export_probes(probe, phase, audited):
    """Retain each helper/output comparison, including integer ancestry drift."""
    rows=[]
    for category, field, comparisons in (
        ('graph_direct','graph_direct','comparisons'),
        ('direct_repeated','graph_direct','direct_repeat_comparisons'),
        ('retained_after_five_steps','retained_after_five_steps','comparisons'),
    ):
        selected=probe[field]
        assert len(selected)==280
        assert len({(r['scenario'],r['request'],r['method'],r['step']) for r in selected})==280
        exported=[]
        for item in selected:
            expected=3 if item['method']=='_get_running_beams_for_next_iteration' else 4
            assert len(item[comparisons])==expected
            for index,c in enumerate(item[comparisons]):
                assert 0<=c['matching_bits']<=c['values']
                row=dict(phase=phase,category=category,scenario=item['scenario'],request=item['request'],
                    prompt_tokens=item['prompt_tokens'],step=item['step'],helper=item['method'],output_index=index,
                    dtype=c['dtype'],shape=json.dumps(c['shape'],separators=(',',':')),
                    values=c['values'],matching_bits=c['matching_bits'],max_abs_finite=c['max_abs_finite'],
                    finite_mask_equal=c['finite_mask_equal'],no_nan=c['no_nan'],
                    left_sha256=c['left_sha256'],right_sha256=c['right_sha256'],
                    independent_step_outputs=item.get('independent_step_outputs',''))
                exported.append(row)
        assert len(exported)==980
        aggregate=dict(values=sum(r['values'] for r in exported),matching_bits=sum(r['matching_bits'] for r in exported),
            max_abs_finite=max(r['max_abs_finite'] for r in exported))
        assert aggregate==audited[category]
        rows.extend(exported)
    return rows


def add_tree(entries, root, prefix):
    assert root.is_dir()
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            name = prefix + '/' + path.relative_to(root).as_posix()
            assert name not in entries
            entries[name] = path.read_bytes()


def write_archive(path, entries):
    with path.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in sorted(entries.items()):
                item = tarfile.TarInfo(name)
                item.size = len(data); item.mode = 0o444; item.mtime = 0
                archive.addfile(item, io.BytesIO(data))


def export(status_path, audit_path, destination):
    status = read(status_path); audit = read(audit_path)
    assert status['scheduler_state'] == 'COMPLETED', 'Execution failures need a failure-specific report'
    assert not destination.exists(), 'Preserve existing exports; choose a new destination'
    harness = Path(status['harness']); run_id = status['run_id']
    raw = harness / '.oscar/results' / run_id
    snapshot = Path(status['source_snapshot'])
    record_path = harness / '.oscar/runs' / (run_id + '.json')
    record = read(record_path)
    assert record['run_id'] == run_id and record['job_id'] == status['job_id']
    assert record['resources'] == status['resources']
    assert read(raw / 'source-manifest.json')['sha256'] == record['sha256']
    assert (raw / 'job-id').read_text().strip() == record['job_id']
    assert audit['snapshot_files_verified'] == len(record['files']) == len(record['sha256'])
    for name, expected in record['sha256'].items():
        assert digest((snapshot / name).read_bytes()) == expected, name
    audit_source = Path(status.get('audit_revision_snapshot', str(snapshot)))
    assert digest((audit_source / 'rapidtinyrec/audit_beam_replay.py').read_bytes()) == audit['audit_script_sha256']
    assert digest((audit_source / 'rapidtinyrec/audit_beam_helpers.py').read_bytes()) == audit['audit_helpers_sha256']
    if audit_source != snapshot:
        revision = read(audit_source / 'audit-source-manifest.json')
        assert revision['commit'] == status['audit_revision_commit']
        for name, expected in revision['sha256'].items():
            assert digest((audit_source / name).read_bytes()) == expected
    provenance = read(snapshot / 'source-provenance.json')
    assert provenance['source_commit'] == status['source_commit']
    joined = {}
    for phase, variant in enumerate((VARIANTS[0], VARIANTS[1], VARIANTS[1], VARIANTS[0])):
        path = raw / 'outputs' / f'phase_{phase}'
        assert read(path / 'manifest.json')['variant'] == variant
        for item in read(path / 'requests.json'):
            assert item['variant'] == variant
            key = item['repeat'], item['cohort_index']
            pair = joined.setdefault(key, dict(repeat=key[0], cohort_index=key[1], prompt_tokens=item['prompt_tokens'], runs={}, phases={}))
            assert pair['prompt_tokens'] == item['prompt_tokens'] and variant not in pair['runs']
            pair['runs'][variant] = item['run']; pair['phases'][variant] = phase
    assert all(set(pair['runs']) == set(VARIANTS) for pair in joined.values())
    rows = [export_pair(joined[key]) for key in sorted(joined)]
    result = summary(audit, rows)
    probe_rows=[]
    for phase in (1,2):
        phase_root=raw/'outputs'/f'phase_{phase}'
        probe=read(phase_root/'beam_probe.json')
        assert digest((phase_root/probe['raw_outputs_file']).read_bytes())==probe['raw_outputs_sha256']
        audited=audit['phases'][phase]
        assert audited['phase']==phase and audited['variant']==VARIANTS[1]
        probe_rows.extend(export_probes(probe,phase,audited['beam_probe']))
    assert len(probe_rows)==5880
    review = read(Path(status['independent_review']))
    assert review['run_id'] == run_id
    result.update(performance_gate=review['performance_gate'], decision=review['decision'])
    entries = {}
    add_tree(entries, raw, 'raw')
    add_tree(entries, snapshot, 'source-snapshot')
    if audit_source != snapshot:
        add_tree(entries, audit_source, 'audit-source')
    if 'original_audit' in status:
        for key in ('audit_stdout','audit_stderr'):
            path = Path(status['original_audit'][key])
            entries['review/original-' + path.name] = path.read_bytes()
    entries['run-record.json'] = record_path.read_bytes()
    entries['status.json'] = status_path.read_bytes()
    entries['audit.json'] = audit_path.read_bytes()
    entries['export_beam_replay.py'] = Path(__file__).read_bytes()
    for name in ('submit_beam_pilot.py', 'test_beam_export.py', 'review_beam_pilot.py'):
        entries[name] = Path(__file__).with_name(name).read_bytes()
    # Full500 uses its own guarded submitter and must retain the exact pilot
    # evidence that authorized it. Do not substitute mutable status for those
    # two hash-pinned audit/review inputs.
    submitter = Path(status['submission_script'])
    entries[submitter.name] = submitter.read_bytes()
    if 'independent_review_script' in status:
        reviewer = Path(status['independent_review_script'])
        entries[reviewer.name] = reviewer.read_bytes()
    if 'pilot_status' in status:
        pilot_path = Path(status['pilot_status']); pilot = read(pilot_path)
        entries['pilot-gate/status.json'] = pilot_path.read_bytes()
        for field, hash_field in (('audit_result','pilot_audit_sha256'),('independent_review','pilot_review_sha256')):
            path = Path(pilot[field]); data = path.read_bytes()
            assert digest(data) == status[hash_field]
            entries['pilot-gate/' + path.name] = data
    for field in ('independent_review', 'raw_manifest', 'audit_stdout', 'audit_stderr', 'ci_log'):
        path = Path(status[field])
        entries['review/' + path.name] = path.read_bytes()
    entries['reproduce.json'] = json.dumps(dict(audit_command=status['audit_command'], audit_cwd=status['audit_cwd'],
        submitted_profile=record['profile'], resources=record['resources'],
        archive_reproduction='Run python3 -m rapidtinyrec.audit_beam_replay from audit-source if present, otherwise source-snapshot; point results at raw/outputs, --snapshot at source-snapshot/rapidtinyrec, and use archived run-record plus pinned historical GQA/token map. Preserve both original failed audit and corrected audit provenance. Relocate absolute paths explicitly.'), indent=2).encode()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=destination.parent, prefix='.beam-evidence-') as temporary:
        staged = Path(temporary) / 'result'; staged.mkdir()
        with (staged / 'requests.csv').open('w') as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator='\n')
            writer.writeheader(); writer.writerows(rows)
        result['requests_sha256'] = digest((staged / 'requests.csv').read_bytes())
        with (staged/'helper-probes.csv').open('w') as f:
            writer=csv.DictWriter(f,fieldnames=list(probe_rows[0]),lineterminator='\n')
            writer.writeheader();writer.writerows(probe_rows)
        result['helper_probes_sha256']=digest((staged/'helper-probes.csv').read_bytes())
        result['helper_output_comparisons']=len(probe_rows)
        (staged / 'summary.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
        (staged / 'audit.json').write_bytes(audit_path.read_bytes())
        write_archive(staged / 'evidence.tar.gz', entries)
        manifest = {name: dict(bytes=len(data), sha256=digest(data)) for name, data in sorted(entries.items())}
        (staged / 'archive-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
        source = dict(run_id=run_id, job_id=status['job_id'], measured_repository_commit=status['source_commit'],
            submitted_source_sha256=record['sha256'], resources=record['resources'],
            raw_sha256={n: digest(v) for n, v in entries.items() if n.startswith('raw/')},
            evidence_sha256={p.name: digest(p.read_bytes()) for p in staged.iterdir()})
        (staged / 'source.json').write_text(json.dumps(source, indent=2) + '\n')
        staged.rename(destination)
    return dict(destination=str(destination), pairs=len(rows), archive_files=len(entries), exactness_passed=audit['exactness_passed'])


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--status', type=Path, required=True)
    ap.add_argument('--audit', type=Path, required=True)
    ap.add_argument('--destination', type=Path, required=True)
    args = ap.parse_args()
    print(json.dumps(export(args.status, args.audit, args.destination), indent=2))


if __name__ == '__main__':
    main()
